#!/bin/bash

if [ $# -eq 0 ]; then
    echo >&2 "Usage: threaddump  [pid] [ <count> [ <delay> ] ]"
    echo >&2 "Defaults: count = 20, delay = 30 (seconds)"
    exit 1
fi

pid=$1           # required
count=${2:-20}   # defaults to 20 times
delay=${3:-30}   # defaults to 30 second

while [ $count -gt 0 ]
do
    jstack $pid >jstack.$pid.$(date +%H%M%S)
    sleep $delay
    let count--
    echo -n "."
done
