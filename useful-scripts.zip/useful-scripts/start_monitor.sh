#!/bin/bash
if [ "$#" -ne  2 ]
then
 echo "Usage: start_monitor.ksh interval_sec iterations";
  exit 1
  fi

interval_sec=$1
iterations=$2

TIMESTAMP=`date +%Y%m%d_%H%M%S`
DIRNAME=${hostname}_OSstats_${TIMESTAMP}

mkdir $DIRNAME
echo "*** Started at $TIMESTAMP ***" > $DIRNAME/params.txt
echo " " >> $DIRNAME/params.txt
echo "*** Run on server ***" >> $DIRNAME/params.txt
uname -a >> $DIRNAME/params.txt
echo " " >> $DIRNAME/params.txt
echo " " >> $DIRNAME/params.txt
echo "interval = $interval_sec, iterations=$iterations" >> $DIRNAME/params.txt

nohup netstat -in $interval_sec $iterations > $DIRNAME/netstat.out &
nohup vmstat $interval_sec $iterations > $DIRNAME/vmstat.out &
nohup mpstat -P ALL $interval_sec $iterations > $DIRNAME/mpstat.out &
nohup iostat -xtc $interval_sec $iterations > $DIRNAME/iostat.out &
nohup top -b  -d $interval_sec -n $iterations > $DIRNAME/top.out &
nohup sar -u $interval_sec $iterations > $DIRNAME/sar.out &

