package com.gs.pwm.quantum.batch.mongo.dao;

import static org.springframework.util.Assert.notNull;

import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.Assert;

import com.gs.pwm.quantum.batch.mongo.config.Database;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;

/**
 * Created by IntelliJ IDEA.
 *
 * @author Baruch S.
 * @since Apr 15, 2010
 */
public abstract class AbstractMongoDao {

	protected DB db;
	public static final String JOB_EXECUTION_ID_KEY = "jobExecutionId";
	
	public static final String JOB_INSTANCE_ID_KEY = "jobInstanceId";
	public static final String JOB_NAME_KEY = "jobName";
	public static final String JOB_KEY_KEY = "jobKey";
	public static final String JOB_PARAMETERS_KEY = "jobParameters";

	public static final String UPDATED_EXISTING_STATUS = "updatedExisting";
	public static final String VERSION_KEY = "version";
	public static final String START_TIME_KEY = "startTime";
	public static final String END_TIME_KEY = "endTime";
	public static final String CREATE_TIME_KEY = "createTime";
	public static final String EXIT_CODE_KEY = "exitCode";
	public static final String EXIT_MESSAGE_KEY = "exitMessage";
	public static final String LAST_UPDATED_KEY = "lastUpdated";
	public static final String STATUS_KEY = "status";

	public static final String STEP_EXECUTION_ID_KEY = "stepExecutionId";
	public static final String STEP_NAME_KEY = "stepName";
	public static final String COMMIT_COUNT_KEY = "commitCount";
	public static final String READ_COUNT_KEY = "readCount";
	public static final String FILTER_COUT_KEY = "filterCout";
	public static final String WRITE_COUNT_KEY = "writeCount";
	public static final String READ_SKIP_COUNT_KEY = "readSkipCount";
	public static final String WRITE_SKIP_COUNT_KEY = "writeSkipCount";
	public static final String PROCESS_SKIP_COUT_KEY = "processSkipCout";
	public static final String ROLLBACK_COUNT_KEY = "rollbackCount";

	public static final String SEQUENCES_COLLECTION_NAME = "BatchJobSequences";
	public static final String ID_KEY = "_id";
	public static final String NS_KEY = "_ns";
	//public static final String DOT_ESCAPE_STRING = "\\{dot\\}";
	public static final String DOT_ESCAPE_STRING = "\uff0E";
	public static final String DOT_STRING = "\\.";
	//public static final String DOT_STRING_ESCAPE = "\uff0E";
	
	public static final String TYPE_SUFFIX = "_TYPE";
	
	

	@Autowired
	@Database(Database.Purpose.BATCH)
	public void setDb(DB db) {
		this.db = db;
	}

	protected abstract DBCollection getCollection();

	protected Long getNextId(String name) {
		DBCollection collection = db.getCollection(SEQUENCES_COLLECTION_NAME);
		BasicDBObject sequence = new BasicDBObject("name", name);
		collection.update(sequence, new BasicDBObject("$inc",
				new BasicDBObject("value", 1L)), true, false);
		return (Long) collection.findOne(sequence).get("value");
	}

	protected void removeSystemFields(DBObject dbObject) {
		dbObject.removeField(ID_KEY);
		dbObject.removeField(NS_KEY);
	}

	protected BasicDBObject jobExecutionIdObj(Long id) {
		return new BasicDBObject(JOB_EXECUTION_ID_KEY, id);
	}

	protected BasicDBObject jobInstanceIdObj(Long id) {
		return new BasicDBObject(JOB_INSTANCE_ID_KEY, id);
	}

	protected BasicDBObject stepExecutionIdObj(Long id) {
		return new BasicDBObject(STEP_EXECUTION_ID_KEY, id);
	}
	
	protected void validateJobExecution(JobExecution jobExecution) {

		Assert.notNull(jobExecution);
		Assert.notNull(jobExecution.getJobId(),
				"JobExecution Job-Id cannot be null.");
		Assert.notNull(jobExecution.getStatus(),
				"JobExecution status cannot be null.");
		Assert.notNull(jobExecution.getCreateTime(),
				"JobExecution create time cannot be null");
	}
	
	protected void validateStepExecution(StepExecution stepExecution) {
		notNull(stepExecution);
		notNull(stepExecution.getStepName(),
				"StepExecution step name cannot be null.");
		notNull(stepExecution.getStartTime(),
				"StepExecution start time cannot be null.");
		notNull(stepExecution.getStatus(),
				"StepExecution status cannot be null.");
	}
}
