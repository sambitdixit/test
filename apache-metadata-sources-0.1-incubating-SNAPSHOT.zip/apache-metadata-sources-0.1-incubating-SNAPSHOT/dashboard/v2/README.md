# DGC Metadata

## Instructions

### Prerequisite
1. Nodejs (http://nodejs.org/download/)
2. ```npm install -g grunt-cli```

### Setup:

```
git clone https://github.com/hortonworks/dgi-metadata-ui.git
cd dgi-metadata-ui
npm install
grunt server
```
Server will start at: 
<http://localhost:3020/>
