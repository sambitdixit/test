package com.walmart.platform.soa.http.client;

import java.net.InetAddress;
import java.util.HashMap;
import java.util.Map;
import java.util.Queue;
import java.util.UUID;
import java.util.concurrent.ConcurrentLinkedQueue;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
import org.apache.http.params.HttpParams;
import org.codehaus.jackson.map.AnnotationIntrospector;
import org.codehaus.jackson.map.JsonDeserializer;
import org.codehaus.jackson.map.JsonSerializer;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.introspect.Annotated;
import org.codehaus.jackson.map.introspect.JacksonAnnotationIntrospector;
import org.codehaus.jackson.type.JavaType;
import org.codehaus.jackson.xc.JaxbAnnotationIntrospector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.walmart.platform.soa.common.HeaderElements;

public class PlatformHttpClient {

	protected static Logger logger = LoggerFactory
			.getLogger(PlatformHttpClient.class);

	private static Queue<PlatformHttpClient> instanceCache = new ConcurrentLinkedQueue<PlatformHttpClient>();

	protected String consumerId = "10";

	protected String consumerType = "Java";

	protected String serviceVersion = "1.0.0";

	protected String serviceEnv = "dev";

	protected String consumerAuthToken = "dummy";

	private final HttpClient httpClient = getThreadSafeClient();

	private static ObjectMapper mapper = new ObjectMapper();

	public void setConsumerId(String consumerId) {
		this.consumerId = consumerId;
	}

	public void setConsumerType(String consumerType) {
		this.consumerType = consumerType;
	}

	public void setServiceVersion(String serviceVersion) {
		this.serviceVersion = serviceVersion;
	}

	public void setServiceEnv(String serviceEnv) {
		this.serviceEnv = serviceEnv;
	}

	protected void setConsumerAuthToken(String consumerAuthToken) {
		this.consumerAuthToken = consumerAuthToken;
	}

	public static PlatformHttpClient getInstance() {
		PlatformHttpClient instance = instanceCache.peek();
		if (instance == null) {
			instance = new PlatformHttpClient();
			instanceCache.add(instance);
			initMapper();
		}
		return instance;
	}

	public static DefaultHttpClient getThreadSafeClient() {
		DefaultHttpClient client = new DefaultHttpClient();
		ClientConnectionManager mgr = client.getConnectionManager();
		HttpParams params = client.getParams();
		client = new DefaultHttpClient(new ThreadSafeClientConnManager(
				mgr.getSchemeRegistry()), params);
		return client;
	}

	private static void initMapper() {
		AnnotationIntrospector primary = new JaxbJsonAnnotationIntrospector();
		AnnotationIntrospector secondary = new JacksonAnnotationIntrospector();
		AnnotationIntrospector pair = new AnnotationIntrospector.Pair(primary,
				secondary);
		mapper.getDeserializationConfig().withAnnotationIntrospector(pair);
		mapper.getSerializationConfig().withAnnotationIntrospector(pair);
	}
	
	
	/**
	 * Does HTTP GET invocation and return response of type <T>
	 * 
	 * @param endPointUrl
	 *            the http/https url
	 * @param request
	 *            the request body
	 * @param <R>
	 *            the expected payload type
	 * @param <T>
	 *            the response type
	 * @param customHeaders
	 *            custom header that should be pass along with this request
	 * @return 
	 */
	public <T, R> T get(String endPointUrl, Class<T> responseClass,
			Class<R> typeClass, Map<String, String> customHeaders) {

		try {
			final Map<String, String> headers = buildSOARIHeaders(customHeaders);
			logger.info("executing GET {} with headers {}", endPointUrl,
					headers);
			HttpGet get = new HttpGet(endPointUrl);
			get.addHeader("content-type", "application/json;charset=UTF-8");
			get.addHeader("Content-Type", "application/json;charset=UTF-8");
			get.addHeader("Accept", "application/json");
			setHttpHeaders(get, headers);

			HttpResponse response = httpClient.execute(get);
			if (response.getStatusLine().getStatusCode() != HttpStatus.SC_OK) {
				logger.error("GET method failed: " + response.getStatusLine());
			} else {
				
				if(typeClass!=null){
				
				JavaType type = mapper.getTypeFactory()
						.constructParametricType(responseClass, typeClass);
				return mapper
						.readValue(response.getEntity().getContent(), type);
				}
				
				return mapper
						.readValue(response.getEntity().getContent(),responseClass);
			}
		} catch (Exception e) {
			throw new RuntimeException(e);
		}

		return null;
	}


	/**
	 * Does HTTP POST invocation and return response of type <T>
	 * 
	 * @param endPointUrl
	 *            the http/https url
	 * @param request
	 *            the request body
	 * @param <R>
	 *            the expected payload type
	 * @param <T>
	 *            the response type
	 * @param customHeaders
	 *            custom header that should be pass along with this request
	 * @return 
	 */
	public <T, R> T post(String endPointUrl, Object request,
			Class<T> responseClass, Class<R> typeClass,
			Map<String, String> customHeaders) {

		try {
			final Map<String, String> headers = buildSOARIHeaders(customHeaders);
			logger.info("executing PUT at {} with headers {}", endPointUrl,
					headers);
			String jsonValue = mapper.writeValueAsString(request);
			HttpEntity requestEntity = new StringEntity(jsonValue);

			HttpPost post = new HttpPost(endPointUrl);
			
			post.addHeader("content-type", "application/json;charset=UTF-8");
			post.addHeader("Content-Type", "application/json;charset=UTF-8");
			post.addHeader("Accept", "application/json");
			setHttpHeaders(post, headers);
			
			post.setEntity(requestEntity);
			HttpResponse response = httpClient.execute(post);

			if (response.getStatusLine().getStatusCode() != HttpStatus.SC_OK) {
				logger.error("POST method failed: " + response.getStatusLine());
			} else {
				JavaType type = mapper.getTypeFactory()
						.constructParametricType(responseClass, typeClass);
				return mapper
						.readValue(response.getEntity().getContent(), type);
			}
		} catch (Exception e) {
			throw new RuntimeException(e);
		}

		return null;
	}

	/**
	 * Does HTTP PUT invocation and return response of type <T>
	 * 
	 * @param endPointUrl
	 *            the http/https url
	 * @param request
	 *            the ServiceRequest of type <T>
	 * @param <T>
	 *            the response type
	 * @param <R>
	 *            the expected payload type
	 * @param customHeaders
	 *            custom header that should be pass along with this request           
	 *  
	 * @return 
	 * 
	 */
	public <T, R> T put(String endPointUrl, Object request,
			Class<T> responseClass, Class<R> typeClass,
			Map<String, String> customHeaders) {

		try {
			final Map<String, String> headers = buildSOARIHeaders(customHeaders);
			logger.info("executing PUT at {} with headers {}", endPointUrl,
					headers);
			String jsonValue = mapper.writeValueAsString(request);
			HttpEntity requestEntity = new StringEntity(jsonValue);

			HttpPut put = new HttpPut(endPointUrl);
			
			put.addHeader("content-type", "application/json;charset=UTF-8");
			put.addHeader("Content-Type", "application/json;charset=UTF-8");
			put.addHeader("Accept", "application/json");
			setHttpHeaders(put, headers);
			
			put.setEntity(requestEntity);
			HttpResponse response = httpClient.execute(put);

			if (response.getStatusLine().getStatusCode() != HttpStatus.SC_OK) {
				logger.error("PUT method failed: " + response.getStatusLine());
			} else {
				JavaType type = mapper.getTypeFactory()
						.constructParametricType(responseClass, typeClass);
				return mapper
						.readValue(response.getEntity().getContent(), type);
			}
		} catch (Exception e) {
			throw new RuntimeException(e);
		}

		return null;
	}

	/**
	 * Does HTTP DELETE invocation
	 * 
	 * @param endPointUrl
	 *            the url resource to be delete
	 * @param request
	 *            the request body
	 * @param <T>
	 *            the response type
	 * @param <R>
	 *            the expected payload type
	 *            
	 * @param customHeaders
	 *            custom header that should be pass along with this request
	 */
	public <T, R> T delete(String endPointUrl, Class<T> responseClass,
			Class<R> typeClass, Map<String, String> customHeaders) {
		try {
			final Map<String, String> headers = buildSOARIHeaders(customHeaders);
			logger.info("executing DELETE {} with headers {}", endPointUrl,
					headers);
			HttpDelete delete = new HttpDelete(endPointUrl);
			
			delete.addHeader("content-type", "application/json;charset=UTF-8");
			delete.addHeader("Content-Type", "application/json;charset=UTF-8");
			delete.addHeader("Accept", "application/json");
			setHttpHeaders(delete, headers);
			
			HttpResponse response = httpClient.execute(delete);

			if (response.getStatusLine().getStatusCode() != HttpStatus.SC_OK) {
				logger.error("Delete failed: " + response.getStatusLine());
			} else {
				JavaType type = mapper.getTypeFactory()
						.constructParametricType(responseClass, typeClass);
				return mapper
						.readValue(response.getEntity().getContent(), type);
			}
		} catch (Exception e) {
			throw new RuntimeException(e);
		}

		return null;
	}

	/**
	 * 
	 * @param customHeaders
	 *            any custom headers that need to merge and return
	 * @return the mandatory headers and customHeaders if not null
	 */

	protected Map<String, String> buildSOARIHeaders(
			Map<String, String> customHeaders) {

		Map<String, String> headers = new HashMap<String, String>();

		if (customHeaders != null) {
			headers.putAll(customHeaders);
		}
		initAuthToken(headers);
		initConsumerId(headers);
		initConsumerGUID(headers);
		initConsumerIP(headers);
		initConsumerInTimeStamp(headers);
		initConsumerType(headers);
		initServiceVersion(headers);
		initServiceEnv(headers);

		return headers;
	}

	protected void initAuthToken(Map<String, String> headers) {
		populateKeyWithValueIfNull(HeaderElements.CONSUMER_AUTH_TOKEN,
				consumerAuthToken, headers);
	}

	protected void initServiceEnv(Map<String, String> headers) {
		populateKeyWithValueIfNull(HeaderElements.SERVICE_ENV, serviceEnv,
				headers);
	}

	protected void initServiceVersion(Map<String, String> headers) {
		populateKeyWithValueIfNull(HeaderElements.SERVICE_VERSION,
				serviceVersion, headers);
	}

	protected void initConsumerType(Map<String, String> headers) {
		populateKeyWithValueIfNull(HeaderElements.CONSUMER_TYPE, consumerType,
				headers);
	}

	protected void initConsumerInTimeStamp(Map<String, String> headers) {
		populateKeyWithValueIfNull(HeaderElements.CONSUMER_IN_TIMESTAMP,
				String.valueOf(System.currentTimeMillis()), headers);
	}

	protected void initConsumerIP(Map<String, String> headers) {
		if (isValueNull(HeaderElements.CONSUMER_IP, headers)) {
			headers.put(HeaderElements.CONSUMER_IP, getIpAddress());
		}
	}

	/**
	 * this implementation will swallow any network exception and return "" for
	 * ip address the child can override it as needed
	 * 
	 * @return the ipAddress or "" if there are any exception
	 */
	protected String getIpAddress() {
		try {
			InetAddress addr = InetAddress.getLocalHost();
			return addr.getHostAddress();
		} catch (Exception e) {
			logger.info("not able to get host address, so ignoring the exception and return empty value");
		}

		return "";
	}

	protected void initConsumerGUID(Map<String, String> headers) {
		populateKeyWithValueIfNull(HeaderElements.CONSUMER_GUID, getGUID(),
				headers);
	}

	protected String getGUID() {
		return UUID.randomUUID().toString();
	}

	protected void initConsumerId(Map<String, String> headers) {
		populateKeyWithValueIfNull(HeaderElements.CONSUMER_ID, consumerId,
				headers);
	}

	protected void populateKeyWithValueIfNull(String key, String value,
			Map<String, String> headers) {
		if (isValueNull(key, headers)) {
			headers.put(key, value);
		}
	}

	protected boolean isValueNull(String key, Map<String, String> map) {
		if (map != null && map.containsKey(key)) {
			return map.get(key) == null;
		}
		return true;
	}

	private void setHttpHeaders(HttpRequestBase method,
			Map<String, String> headers) {
		for (Map.Entry<String, String> entry : headers.entrySet()) {
			String key = entry.getKey();
			String value = entry.getValue();
			method.addHeader(key, value);
		}
	}

	static class JaxbJsonAnnotationIntrospector extends
			JaxbAnnotationIntrospector {
		public JsonDeserializer<?> findDeserializer(Annotated am) {
			return super.findDeserializer(am);
		}

		public JsonSerializer<?> findSerializer(Annotated am) {
			return super.findSerializer(am);
		}
	}
}
