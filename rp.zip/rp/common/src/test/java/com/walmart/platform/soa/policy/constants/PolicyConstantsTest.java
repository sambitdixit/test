package com.walmart.platform.soa.policy.constants;

import org.testng.annotations.Test;

import com.walmart.platform.soa.policy.constants.PolicyEvaluationConstants;

public class PolicyConstantsTest {

	@Test
	public void testConstants() {

		System.out.println(PolicyEvaluationConstants.VIOLATION_CODE);
		System.out.println(PolicyEvaluationConstants.EXCEPTION_CODE);

		System.out.println(PolicyEvaluationConstants.DOT_SEPARATOR);
		System.out.println(PolicyEvaluationConstants.FAIL);

		System.out.println(PolicyEvaluationConstants.VIOLATION_INFO);
		System.out.println(PolicyEvaluationConstants.EXCEPTION_INFO);

		System.out.println(PolicyEvaluationConstants.VIOLATION_MESSAGE);
		System.out.println(PolicyEvaluationConstants.EXCEPTION_MESSAGE);
	}
}
