package com.walmart.platform.soa.policy.enums;

import org.testng.annotations.Test;

import com.walmart.platform.soa.policy.enums.ActionStatus;


/**
 * @author msing37
 *
 */
public class ActionStatusTest {
	
	@Test
	public void testActionStatus() {
		
		ActionStatus aStatus = ActionStatus.SUCCESS;
		System.out.println(aStatus);
		
		for(ActionStatus actionStatus : ActionStatus.values()) {
			System.out.println(actionStatus.name() + " : " + actionStatus.getActionStatus());
		}
	}
}
