package com.walmart.platform.soa.policy.comparator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.walmart.platform.soa.policy.comparator.PolicyEvalComparator;
import com.walmart.platform.soa.policy.comparator.SortParameter;
import com.walmart.platform.soa.policy.definition.model.PolicyDefinition;

public class PolicyEvalComparatorTest {

	@Test
	  public void testComparator() {
		  List<PolicyDefinition> pds = new ArrayList<PolicyDefinition>();
		  
		  PolicyDefinition pd = new PolicyDefinition();
		  pd.setType("SLA");
		  pd.setOrder("1");
		 
		  
		  PolicyDefinition pd1 = new PolicyDefinition();
		  pd1.setType("SLA");
		  pd1.setOrder("2");
		  
		  PolicyDefinition pd2 = new PolicyDefinition();
		  pd2.setType("MEDIATION");
		  pd2.setOrder("1");
		  
		  PolicyDefinition pd3 = new PolicyDefinition();
		  pd3.setType("THROTTLING");
		  pd3.setOrder("2");
		  
		  pds.add(pd3);
		  pds.add(pd2);
		  pds.add(pd1);
		  pds.add(pd);
		  
		  System.out.println("List before sort--" + pds);
		  Collections.sort(pds,PolicyEvalComparator.getInPolicyComparator(SortParameter.TYPE_ASCENDING,SortParameter.ORDER_ASCENDING));
		  System.out.println("List after sort--" + pds);
		  Assert.assertNotNull(pds);
		  
		  System.out.println("List before sort--" + pds);
		  Collections.sort(pds,PolicyEvalComparator.getOutPolicyComparator(SortParameter.TYPE_DESCENDING,SortParameter.ORDER_DESCENDING));
		  System.out.println("List after sort--" + pds);
		  Assert.assertNotNull(pds);
	}

}
