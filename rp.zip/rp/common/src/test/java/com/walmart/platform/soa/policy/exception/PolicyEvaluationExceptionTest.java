package com.walmart.platform.soa.policy.exception;

import java.util.ArrayList;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.walmart.platform.kernel.exception.error.Error;
import com.walmart.platform.soa.policy.exception.PolicyEvaluationException;

public class PolicyEvaluationExceptionTest {

	@Test
	public void testPolicyEvaluationException(){
		Error e1 = new Error(); 
		PolicyEvaluationException ex = new PolicyEvaluationException(e1, new Exception("Test"));
		Assert.assertNotNull(ex.getCause());
		Error e2 = new Error();
		List<Error> l = new ArrayList<Error>();
		l.add(e1);
		l.add(e2);
		PolicyEvaluationException ex2 = new PolicyEvaluationException(l, new Exception("Test"));
		Assert.assertNotNull(ex2.getCause());
	}
}
