package com.walmart.platform.soa.policy.exception;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.walmart.platform.soa.policy.exception.PolicyExceptionUtil;

public class PolicyExceptionUtilTest {

	@Test
	public void testRaisePolicyEvaluationException() {

		try {
			PolicyExceptionUtil.raisePolicyEvaluationException(null,
					new Exception("test"));
		} catch (Exception e) {
			System.out.println(e.getMessage());
			Assert.assertNotNull(e);
		}
	}

	@Test
	public void testGetStackTraceString() {
		Exception ex1 = new Exception("test error");
		String s = PolicyExceptionUtil.getErrorStackTrace(ex1);
		Assert.assertNotNull(s);
	}

	@Test
	public void testGetErrorCause() {
		Exception ex = new Exception("test error");
		String s = PolicyExceptionUtil.getErrorCause(ex, 1);
		Assert.assertNotNull(s);
	}

}
