package com.walmart.platform.soa.policy.enums;

import org.testng.annotations.Test;

import com.walmart.platform.soa.policy.enums.PolicyInTypes;
import com.walmart.platform.soa.policy.enums.PolicyOutTypes;

public class PolicyTypesTest {

  @Test
  public void getName() {
	  System.out.println("--PolicyInTypes--");
	  for (PolicyInTypes policy : PolicyInTypes.values()){
		  System.out.println("Policy Name==" + policy.getName() +"  Policy Order==" +policy.getOrder());
	  }
	  
	  System.out.println("--PolicyOutTypes--");
	  for (PolicyOutTypes policy : PolicyOutTypes.values()){
		  System.out.println("Policy Name==" + policy.getName()+"  Policy Order==" +policy.getOrder());
	  }
  }
}
