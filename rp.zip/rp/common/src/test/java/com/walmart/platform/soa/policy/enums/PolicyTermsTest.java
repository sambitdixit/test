package com.walmart.platform.soa.policy.enums;

import org.testng.annotations.Test;

import com.walmart.platform.soa.policy.enums.PolicyTerms;


/**
 * @author msing37
 *
 */
public class PolicyTermsTest {

	@Test
	public void testPolicyTerms() {
		
		PolicyTerms pTerm = PolicyTerms.ASSUMPTION_ACTUAL_VALUE;
		System.out.println(pTerm);
		
		for(PolicyTerms policyTerm : PolicyTerms.values()) {
			System.out.println(policyTerm.name() + " : " + policyTerm.getTerm());
		}
	}
}
