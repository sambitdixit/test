package com.walmart.platform.soa.policy.exception;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.walmart.platform.kernel.exception.error.Error;
import com.walmart.platform.soa.policy.exception.PolicyViolationException;

public class PolicyViolationExceptionTest {

	@Test
	public void testPolicyViolationException() {
		Error e1 = new Error();
		e1.setCode("400");
		e1.setDescription("test1 error");
		PolicyViolationException ex = new PolicyViolationException(e1);
		Assert.assertNotNull(ex.getErrorCode());
		Error err = new Error();
		err.setCode("500");
		err.setDescription("test error");
		PolicyViolationException ex2 = new PolicyViolationException(err);
		Assert.assertNotNull(ex2.getErrorCode());
	}
}
