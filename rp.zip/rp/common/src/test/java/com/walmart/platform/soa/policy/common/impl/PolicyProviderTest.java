package com.walmart.platform.soa.policy.common.impl;

import java.io.IOException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.walmart.platform.soa.policy.common.IPolicyProvider;
import com.walmart.platform.soa.policy.common.impl.PolicyProvider;
import com.walmart.platform.soa.policy.definition.model.Action;
import com.walmart.platform.soa.policy.definition.model.PolicyDefinition;

/**
 * @author msing37
 *
 */
public class PolicyProviderTest {

	
	/**
	 * Tests for happy flow of un-marshaling the PolicyDefintion from policy-xml file 
	 */
	@Test
	public void getPolicyRules() {
		IPolicyProvider policyProvider = PolicyProvider.instance();
		URL url = this.getClass().getClassLoader()
				.getResource("policies/ThrottlePolicy.xml");
		
		String policyDef = null;
		PolicyDefinition policy = null;
		try {
			policyDef = policyProvider.readPolicyFileAsString(url.getFile());
			Assert.assertNotNull(policyDef);
			policy = policyProvider.getPolicyDefinition(policyDef);
		} catch (IOException e) {
			e.printStackTrace();
		}
		Assert.assertNotNull(policy);
		System.out.println("" + policy.toString());
	}
	
	/**
	 * Tests out PolicyProvider's isValidPolicy's method for invalid Policy <br>
	 * 
	 * NOTE : Policy Un-marshaling fails because Single rule of the policy have two ALLOW Actions
	 */
	@Test
	public void testInvalidPolicy() {
		IPolicyProvider policyProvider = PolicyProvider.instance();
		URL url = this.getClass().getClassLoader()
				.getResource("policies/RuleHavingSameActionPolicy.xml");
		
		String policyDef = null;
		PolicyDefinition policy = null;
		try {
			policyDef = policyProvider.readPolicyFileAsString(url.getFile());
			Assert.assertNotNull(policyDef);
			policy = policyProvider.getPolicyDefinition(policyDef);
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		Assert.assertNull(policy);
	}
	
	
	@Test
	public void testInvalidAlertPolicy() {
		IPolicyProvider policyProvider = PolicyProvider.instance();
		URL url = this.getClass().getClassLoader()
				.getResource("policies/InvalidAlertSGPolicy.xml");
		
		String policyDef = null;
		PolicyDefinition policy = null;
		try {
			policyDef = policyProvider.readPolicyFileAsString(url.getFile());
			Assert.assertNotNull(policyDef);
			policy = policyProvider.getPolicyDefinition(policyDef);
			Assert.assertNull(policy);
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		Assert.assertNull(policy);
	}
	
	@Test
	public void testScatterGatherPolicyLoad() {
		IPolicyProvider policyProvider = PolicyProvider.instance();
		URL url = this.getClass().getClassLoader().getResource("policies/ScatterGatherPolicy.xml");
		String policyDef = null;
		PolicyDefinition policy = null;
		try {
			policyDef = policyProvider.readPolicyFileAsString(url.getFile());
			Assert.assertNotNull(policyDef);
			policy = policyProvider.getPolicyDefinition(policyDef);
			for(Action action : policy.getRule().get(0).getThen().getAction()) {
				System.out.println(action.getType());
				String actionValue = action.getValue();
				Map<String, String> sgProperties = new HashMap<String, String>();
				for(String s : actionValue.split(",")) {
					s = s.replace("\t", "");
					sgProperties.put(s.split("=")[0], s.split("=")[1]);
				}
				System.out.println(sgProperties);
			}
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		Assert.assertNotNull(policy);
	}
	
}
