package com.walmart.platform.soa.policy.exception;

import com.walmart.platform.kernel.exception.error.Error;
import com.walmart.platform.kernel.exception.layers.base.PlatformRuntimeException;

/**
 * Exception class used when policy is violated
 * 
 * @author msing37
 *
 */
public class PolicyViolationException extends PlatformRuntimeException {

	/**
	 * class version ID for serialization
	 */
	private static final long serialVersionUID = 1L;
	
    /**
     *
     * @param error
     * @param ex
     */
	public PolicyViolationException(Error error) {
		super(error, null);
	}
}
