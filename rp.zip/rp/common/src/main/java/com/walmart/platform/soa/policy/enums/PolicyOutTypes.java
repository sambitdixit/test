package com.walmart.platform.soa.policy.enums;

/**
 * @author sdikshi
 * @author ranand
 * 
 */
public enum PolicyOutTypes {

	SLA("SLA", 0),MEDIATION("MEDIATION",1);

	private final String name;

	private final Integer order;

	private PolicyOutTypes(String name, int order) {
		this.name = name;
		this.order = order;
	}

	public String getName() {
		return name;
	}

	public Integer getOrder() {
		return order;
	}

}
