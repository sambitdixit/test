package com.walmart.platform.soa.policy.enums;

/**
 * @author sdikshi
 * @author ranand
 *
 */
public enum PolicyInTypes {

	SECURITY("SECURITY", 0), SLA("SLA", 1), THROTTLING("THROTTLING",
			2), MEDIATION("MEDIATION", 3);

	private final String name;

	private final Integer order;

	private PolicyInTypes(String name, int order) {
		this.name = name;
		this.order = order;
	}

	public String getName() {
		return name;
	}

	public Integer getOrder() {
		return order;
	}

}
