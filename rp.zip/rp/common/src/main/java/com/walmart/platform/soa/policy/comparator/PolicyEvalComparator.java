package com.walmart.platform.soa.policy.comparator;

import java.util.Comparator;

import com.walmart.platform.soa.policy.definition.model.PolicyDefinition;
import com.walmart.platform.soa.policy.enums.PolicyInTypes;
import com.walmart.platform.soa.policy.enums.PolicyOutTypes;

/**
 * Evaluates multiple comparator types by ascending or descending order of
 * policy types, policy order.
 * 
 * @author sdikshi
 * 
 */
public final class PolicyEvalComparator {

    private PolicyEvalComparator() {
    }

    /**
	 * Gets handle to PolicyInComparator based on SortParameter.
	 * 
	 * @param sortParameters
	 * @return
	 */
	public static Comparator<PolicyDefinition> getInPolicyComparator(
			SortParameter... sortParameters) {
		return new PolicyInComparator(sortParameters);
	}

	/**
	 * Gets handle to PolicyOutComparator based on SortParameter.
	 * 
	 * @param sortParameters
	 * @return
	 */
	public static Comparator<PolicyDefinition> getOutPolicyComparator(
			SortParameter... sortParameters) {
		return new PolicyOutComparator(sortParameters);
	}

	/**
	 * Comparator that compares two PolicyDefinition objects for IN policy
	 * types.
	 * 
	 * @author sambitdikshit
	 * 
	 */
	private static final class PolicyInComparator implements Comparator<PolicyDefinition> {
		private SortParameter[] parameters;

		private Integer policyInTypePosition(String policyType) {
			for (PolicyInTypes policy : PolicyInTypes.values()) {
				if (policy.getName().equals(policyType)) {
					return policy.getOrder();
                }
			}
			return null;

		}

		private PolicyInComparator(SortParameter[] parameters) {
            if(parameters != null && parameters.length > 0) {
                SortParameter[] paramArray = new SortParameter[parameters.length];
                System.arraycopy(parameters, 0, paramArray, 0, parameters.length);
                this.parameters = paramArray;
            }
		}

        @Override
		public int compare(PolicyDefinition p1, PolicyDefinition p2) {
			int comparison;
			Integer i1;
			Integer i2;
			for (SortParameter parameter : parameters) {
				switch (parameter) {
				case ORDER_ASCENDING:
					comparison = p1.getOrder().compareTo(p2.getOrder());
					if (comparison != 0) {
						return comparison;
                    }
					break;
				case ORDER_DESCENDING:
					comparison = p2.getOrder().compareTo(p1.getOrder());
					if (comparison != 0) {
						return comparison;
                    }
					break;
				case TYPE_ASCENDING:
					i1 = policyInTypePosition(p1.getType());
					i2 = policyInTypePosition(p2.getType());
					if (i1 != null && i2 != null) {
						comparison = i1 - i2;
					} else {
						comparison = p1.getType().compareTo(p2.getType());
					}
					if (comparison != 0) {
						return comparison;
                    }
					break;
				case TYPE_DESCENDING:
					i1 = policyInTypePosition(p1.getType());
					i2 = policyInTypePosition(p2.getType());
					if (i1 != null && i2 != null) {
						comparison = i2 - i1;
					} else {
						comparison = p2.getType().compareTo(p1.getType());
					}
					if (comparison != 0) {
						return comparison;
                    }
					break;
				}
			}
			return 0;
		}
	}

	/**
	 * PolicyOutComparator to compare out policy types.
	 * 
	 * @author sambitdikshit
	 * 
	 */
	private static final class PolicyOutComparator implements Comparator<PolicyDefinition> {
		private SortParameter[] parameters;

		private Integer policyOutTypePosition(String policyType) {
			for (PolicyOutTypes policy : PolicyOutTypes.values()) {
				if (policy.getName().equals(policyType)) {
					return policy.getOrder();
                }
			}
			return null;
		}

		private PolicyOutComparator(SortParameter[] parameters) {
			if(parameters != null && parameters.length > 0) {
                SortParameter[] paramArray = new SortParameter[parameters.length];
                System.arraycopy(parameters, 0, paramArray, 0, parameters.length);
                this.parameters = paramArray;
            }
		}

        @Override
		public int compare(PolicyDefinition p1, PolicyDefinition p2) {
			int comparison;
			Integer i1;
			Integer i2;
			for (SortParameter parameter : parameters) {
				switch (parameter) {
				case ORDER_ASCENDING:
					comparison = p1.getOrder().compareTo(p2.getOrder());
					if (comparison != 0) {
						return comparison;
                    }
					break;
				case ORDER_DESCENDING:
					comparison = p2.getOrder().compareTo(p1.getOrder());
					if (comparison != 0) {
						return comparison;
                    }
					break;
				case TYPE_ASCENDING:
					i1 = policyOutTypePosition(p1.getType());
					i2 = policyOutTypePosition(p2.getType());
					if (i1 != null && i2 != null) {
						comparison = i1 - i2;
					} else {
						comparison = p1.getType().compareTo(p2.getType());
					}
					if (comparison != 0) {
						return comparison;
                    }
					break;
				case TYPE_DESCENDING:
					i1 = policyOutTypePosition(p1.getType());
					i2 = policyOutTypePosition(p2.getType());
					if (i1 != null && i2 != null) {
						comparison = i2 - i1;
					} else {
						comparison = p2.getType().compareTo(p1.getType());
					}
					if (comparison != 0) {
						return comparison;
                    }
					break;
				}
			}
			return 0;
		}
	}
}
