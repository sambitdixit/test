package com.walmart.platform.soa.policy.common;

import java.io.IOException;

import com.walmart.platform.soa.policy.definition.model.PolicyDefinition;

/**
 * @author sdikshi
 *
 */
public interface IPolicyProvider {

	/**
	 * Reads the file specified at 'path' and returns its content as String
	 *
	 * @param path
	 * @return
	 * @throws IOException
	 */
	public String readPolicyFileAsString(String path) throws IOException;
	
	
	/**
	 * Reads the file specified at 'path' and returns its content as byte []
	 * 
	 * @param path
	 * @return
	 * @throws IOException
	 */
	public byte[] readPolicyFileAsByteArray(String path) throws IOException;
	
	
	/**
	 * Reader API which takes the policy definition as input and returns the
	 * JAXB object of the policy XML definition.
	 * 
	 * @param policyDefinition policy expressed as a String
	 * @return policy object corresponding to String policy
	 */
	public PolicyDefinition getPolicyDefinition(String policyDefinition);
	
	
	/**
	 * Reader API which takes the policy definition byte array as input and
	 * returns the JAXB object of the policy XML definition. <br>
	 * 
	 * It also does a check to ensure policy doesn't violate any constraint <br>
	 * 
	 * @param arr policy expressed as byte array
	 * @return policy object corresponding to arr
	 */
	public PolicyDefinition getPolicyDefinition(byte[] arr);
}
