package com.walmart.platform.soa.policy.constants;

/**
 * @author msing37
 *
 */
public class PolicyEvaluationConstants {
	
	public static final String VIOLATION_CODE = "403";
	public static final String EXCEPTION_CODE = "403";
	
	public static final String DOT_SEPARATOR = ".";
	public static int FAIL = 403;
	
	public static final String VIOLATION_INFO = "policy violated";
	public static final String EXCEPTION_INFO = "exception occured while executing policies";
	
	public static final String VIOLATION_MESSAGE = "policy violated";
	public static final String EXCEPTION_MESSAGE = "exception occured while executing policies";
	
}
