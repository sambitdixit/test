package com.walmart.platform.soa.policy.exception;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringReader;
import java.io.StringWriter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.walmart.platform.kernel.exception.error.Error;
import com.walmart.platform.kernel.exception.error.ErrorCategory;
import com.walmart.platform.kernel.exception.error.ErrorSeverity;
import com.walmart.platform.kernel.exception.layers.base.PlatformRuntimeException;
import com.walmart.platform.soa.policy.constants.PolicyEvaluationConstants;
import com.walmart.platform.soa.policy.definition.model.Action;
import com.walmart.platform.soa.policy.definition.model.PolicyDefinition;

/**
 * Utility class to raise Policy Evalaution/Violation related exceptions
 * 
 * @author msing37
 * 
 */
public abstract class PolicyExceptionUtil {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(PolicyExceptionUtil.class);

	/**
	 * Creates an Error object from supplied policy definition & exception and, <br>
	 * raises a PolicyEvaluationException
	 * 
	 * @param policyDefinition
	 *            policy which was being executed
	 * @param ex
	 *            exception encountered while executing said policy
	 */
	public static void raisePolicyEvaluationException(
			PolicyDefinition policyDefinition, Exception ex) {

		String errorField = policyDefinition.getPolicyName()
				+ PolicyEvaluationConstants.DOT_SEPARATOR + policyDefinition.getType();

		PlatformRuntimeException ex1 = new PolicyEvaluationException(getError(
				PolicyEvaluationConstants.EXCEPTION_CODE, errorField, ex.getMessage(),
				getErrorCause(ex, 3), ErrorSeverity.ERROR,
				ErrorCategory.APPLICATION), ex);
		ex1.setHttpStatusCode(PolicyEvaluationConstants.FAIL);

		throw ex1;
	}

	/**
	 * Creates appropriate {@link Error} when a policy is violated
	 * 
	 * @param policyDefinition
	 *            policy which was being executed
	 * @param action
	 *            Description of the error
	 * @return
	 */
	public static void raisePolicyViolationException(
			PolicyDefinition policyDefinition, Action errorAction,
			boolean hardViolation) {

		String errorCode = (errorAction == null || errorAction.getErrorcode() == null) ? PolicyEvaluationConstants.VIOLATION_CODE
				: PolicyEvaluationConstants.VIOLATION_CODE
						+ PolicyEvaluationConstants.DOT_SEPARATOR
						+ errorAction.getErrorcode();
		String errorField = policyDefinition.getPolicyName()
				+ PolicyEvaluationConstants.DOT_SEPARATOR + errorAction.getType();
		String errorDescription = (errorAction == null || errorAction
				.getMessage() == null) ? PolicyEvaluationConstants.VIOLATION_MESSAGE
				: errorAction.getMessage();
		String errorInfo = PolicyEvaluationConstants.VIOLATION_INFO;
		ErrorSeverity errorSeverity = hardViolation ? ErrorSeverity.ERROR
				: ErrorSeverity.WARN;
		ErrorCategory errorCategory = ErrorCategory.REQUEST;

		PlatformRuntimeException pRE = new PolicyViolationException(getError(
				errorCode, errorField, errorDescription, errorInfo,
				errorSeverity, errorCategory));
		pRE.setHttpStatusCode((errorAction == null || errorAction.getHttpcode() == null) ? PolicyEvaluationConstants.FAIL
				: errorAction.getHttpcode());

		throw pRE;
	}

	// Utility methods

	/**
	 * Returns the error object create from given error fields
	 * 
	 * @param code
	 * @param field
	 * @param description
	 * @param info
	 * @param severity
	 * @param category
	 * @return
	 */
	private static Error getError(String code, String field,
			String description, String info, ErrorSeverity severity,
			ErrorCategory category) {

		Error error = new Error();

		error.setCode(code);
		error.setField(field);
		error.setDescription(description);
		error.setInfo(info);
		error.setSeverity(severity);
		error.setCategory(category);

		return error;
	}

	/**
	 * Gets the cause with specific line no and returns as string.
	 * 
	 * @param error
	 * @param lineFetchCount
	 * @return
	 */
	public static String getErrorCause(Throwable error, int lineFetchCount) {
		String str;
		int lineNumber = 0;
		StringBuilder buffer = new StringBuilder();
		BufferedReader reader = new BufferedReader(new StringReader(
				getErrorStackTrace(error)));
		try {
			while ((str = reader.readLine()) != null) {
				if (str.length() > 0) {
					if (str.contains("Caused by:")) {
						lineNumber = 0;
						buffer.append(str).append("\n");
					} else if (lineNumber <= lineFetchCount) {
						buffer.append(str).append("\n");
					}
				}
				lineNumber++;
			}
		} catch (IOException e) {
			if (LOGGER.isErrorEnabled()) {
				LOGGER.error("Error in getCauseByStackTrace", e);
			}
		}
		return escapeJavaStackTrace(buffer.toString());
	}

	/**
	 * Gets the stack trace.
	 * 
	 * @param t
	 * @return
	 */
	public static String getErrorStackTrace(Throwable t) {
		StringBuilder sb = new StringBuilder();
		StringWriter out = new StringWriter();
		t.printStackTrace(new PrintWriter(out));
		sb.append(out.toString());
		return sb.toString();
	}

	/**
	 * @param str
	 * @return
	 */
	public static String escapeJavaStackTrace(String str) {
		if (str == null) {
			return null;
		}

		StringWriter writer = new StringWriter(str.length() * 2);

		try {
			int sz;
			sz = str.length();
			for (int i = 0; i < sz; i++) {
				char ch = str.charAt(i);

				// handle unicode
				if (ch > 0xfff) {
					writer.write("\\u" + Integer.toHexString(ch).toUpperCase());
				} else if (ch > 0xff) {
					writer.write("\\u0" + Integer.toHexString(ch).toUpperCase());
				} else if (ch > 0x7f) {
					writer.write("\\u00"
							+ Integer.toHexString(ch).toUpperCase());
				} else if (ch < 32) {
					switch (ch) {
					case '\b':
						writer.write('\\');
						writer.write('b');
						break;
					case '\n':
						writer.write('\\');
						writer.write('n');
						break;
					case '\t':
						writer.write('\\');
						writer.write('t');
						break;
					case '\f':
						writer.write('\\');
						writer.write('f');
						break;
					case '\r':
						writer.write('\\');
						writer.write('r');
						break;
					default:
						if (ch > 0xf) {
							writer.write("\\u00"
									+ Integer.toHexString(ch).toUpperCase());
						} else {
							writer.write("\\u000"
									+ Integer.toHexString(ch).toUpperCase());
						}
						break;
					}
				} else {
					switch (ch) {
					case '\'':
						writer.write('\'');
						break;
					case '"':
						writer.write('\\');
						writer.write('"');
						break;
					case '\\':
						writer.write('\\');
						writer.write('\\');
						break;
					case '/':
						writer.write('\\');
						writer.write('/');
						break;
					default:
						writer.write(ch);
						break;
					}
				}
			}
		} catch (Exception e) {
			return null;
		}

		return writer.toString();
	}

}
