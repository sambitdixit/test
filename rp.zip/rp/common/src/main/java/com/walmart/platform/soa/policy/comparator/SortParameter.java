package com.walmart.platform.soa.policy.comparator;

/**
 * Enum of policy sort order.
 * 
 * @author sdikshi
 * 
 */
public enum SortParameter {
	ORDER_ASCENDING, ORDER_DESCENDING, TYPE_ASCENDING, TYPE_DESCENDING
}
