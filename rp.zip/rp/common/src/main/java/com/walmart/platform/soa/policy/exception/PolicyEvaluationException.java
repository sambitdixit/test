package com.walmart.platform.soa.policy.exception;

import java.util.List;

import com.walmart.platform.kernel.exception.error.Error;
import com.walmart.platform.kernel.exception.layers.base.PlatformRuntimeException;

/**
 * Exception class to be used for all rule related exception.
 * 
 * @author sdikshi
 * @author msing37
 * 
 */
public class PolicyEvaluationException extends PlatformRuntimeException {

	/**
	 * class version ID for serialization
	 */
	private static final long serialVersionUID = 1L;
	
	/**
     *
     * @param error
     * @param ex
     */
	public PolicyEvaluationException(Error error, Throwable ex) {
		super(error, ex);

	}

    /**
     *
     * @param errors
     * @param ex
     */
	public PolicyEvaluationException(List<Error> errors, Throwable ex) {
		super(errors,ex);
		
	}
	
	
}
