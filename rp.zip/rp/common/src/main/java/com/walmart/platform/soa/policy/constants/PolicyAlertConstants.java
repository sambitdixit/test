package com.walmart.platform.soa.policy.constants;

/**
 * @author sdikshi
 *
 */
public class PolicyAlertConstants {


	/** Variables to be taken from policy **/
	public static int DEFAULT_REFRESH_INTERVAL = 10000;
	public static int DEFAULT_VIOLATION_THRESHOLD = -1;
	
	/** Used in Policy Alert **/
	public static long ALERT_REFRESH_INTERVAL =  1000;// in milli seconds
	public static long ALERT_START_INTERVAL = 1000;// in milli seconds
	public static  String CACHE_KEY_SEPARATOR = "##";
	public static long TIME_TO_LIVE = 3600 * 1000;
	
	/** Used in Notification Delegator*/
	public static String MAIL_HOST = "honts3552.homeoffice.wal-mart.com";
	public static String MAIL_SMTP="mail.smtp.host";
}
