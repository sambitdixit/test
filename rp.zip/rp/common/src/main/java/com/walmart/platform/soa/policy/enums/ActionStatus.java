package com.walmart.platform.soa.policy.enums;

/**
 * @author sdikshi
 *
 */
public enum ActionStatus {

	SUCCESS("SUCCESS"), FAIL("FAIL");
	
	private String actionStatus;
	
	private ActionStatus(String status) {
		this.actionStatus = status;
	}
	
	public String getActionStatus() {
		return this.actionStatus;
	}
	
}
