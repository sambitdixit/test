package com.walmart.platform.soa.policy.common.impl;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;

import org.mvel2.MVEL;
import org.mvel2.optimizers.OptimizerFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.walmart.platform.soa.policy.common.IPolicyProvider;
import com.walmart.platform.soa.policy.definition.model.Action;
import com.walmart.platform.soa.policy.definition.model.AlertThreshold;
import com.walmart.platform.soa.policy.definition.model.Assumption;
import com.walmart.platform.soa.policy.definition.model.PolicyDefinition;
import com.walmart.platform.soa.policy.definition.model.Rule;

/**
 * @author sdikshi
 */
public final class PolicyProvider implements IPolicyProvider {

	private static final Logger LOGGER = LoggerFactory.getLogger(PolicyProvider.class);

	private static PolicyProvider resp = new PolicyProvider();

	
	/**
	 * Private constructor 
	 */
	private PolicyProvider() {
		OptimizerFactory.setDefaultOptimizer("reflective");
	}
	
	/**
     * Static method to return singleton instance
     * 
     * @return
     */
	public static PolicyProvider instance() {
		return resp;
	}

	
	/* 
	 * Reads policy file from supplied path and returns the policy definition content as string. 
	 * 
	 */
	public String readPolicyFileAsString(String path) throws IOException {

		StringBuilder fileContent = new StringBuilder();
		BufferedReader fileReader = new BufferedReader(new FileReader(path));
		String line = "";
		while ((line = fileReader.readLine()) != null) {
			fileContent.append(line);
		}
		fileReader.close();
		return fileContent.toString();
	}

	
	/* 
	 * Reads policy file from supplied path and returns the policy definition content as byte array. 
	 * 
	 */
	public byte[] readPolicyFileAsByteArray(String path) throws IOException {

		StringBuilder fileContent = new StringBuilder();
		BufferedReader fileReader = new BufferedReader(new FileReader(path));

		String line = "";
		while ((line = fileReader.readLine()) != null) {
			fileContent.append(line);
		}
		fileReader.close();
		return fileContent.toString().getBytes();
	}
	
	
	/* (non-Javadoc)
	 * @see com.walmart.platform.soa.policy.common.IPolicyProvider#getPolicyDefinition(java.lang.String)
	 */
	public PolicyDefinition getPolicyDefinition(String policyDefinition) {
		LOGGER.debug("PolicyProvider.getPolicy(URL policyURL) start");

		byte[] arr;
		PolicyDefinition policy = null;
		if (policyDefinition != null) {
			try {
				arr = policyDefinition.getBytes();
				policy = getPolicyDefinition(arr);

			} catch (Exception ioe) {
				LOGGER.error("Not able to read policy", ioe);
			}
			LOGGER.debug("PolicyProvider.getPolicy(URL policyURL) end");

		}
		return policy;
	}
	
	public boolean valiateIndividualTags(String total,String policyName){
		if(total == null){
			LOGGER.error("<total> value not specified in <AlertThreshold> for policy: "+policyName);
			return false;
		}
		else{
			int number=-1;
			try{
				number = Integer.parseInt(total);
			}catch( NumberFormatException e){
				LOGGER.error("Value of <total> in <AlertThreshold> in Policy "+policyName+" is not a number");
				return false;
			}
			
			if(number <= 0){
				LOGGER.error("Value of <total> in <AlertThreshold> in Policy "+policyName+" is not a positive integer");
				return false;
			}
		}
		return true;
	}

	public boolean validateAlertThreshold(PolicyDefinition pd){
		AlertThreshold alertThreshold = pd.getAlertThreshold();
		String policyName = pd.getPolicyName();
		if(alertThreshold != null){
			return ( valiateIndividualTags(alertThreshold.getTotal(),policyName) && valiateIndividualTags(alertThreshold.getWithinPeriod(),policyName));
		}
		return true;
	}
	
	public PolicyDefinition getPolicyDefinition(byte[] arr) {
		LOGGER.debug("PolicyProvider.getPolicy(byte[] arr) start");

		PolicyDefinition policy = null;
		try {

			ByteArrayInputStream bais = new ByteArrayInputStream(arr);
			JAXBContext jc = JAXBContext.newInstance(PolicyDefinition.class);
			Unmarshaller u = jc.createUnmarshaller();
			policy = (PolicyDefinition) u.unmarshal(bais);
			if(!validateAlertThreshold(policy)){
				return null;
			}
			policy = compilePolicyRules(policy);

		} catch (Exception e) {
			LOGGER.error("Not able to unmarshal PolicyDefinition", e);
		}
		
		LOGGER.debug("PolicyProvider.getPolicy(byte[] arr) end");
		if(!isValidPolicy(policy)) {
			return null;
		}
		else {
			return policy;
		}
	}


	/**
	 * Pre-compiles the policy assumptions for better performance in MVEL.
	 * 
	 * @param policy policy whose rules are to be compiled
	 * @return policy with compiled rules
	 */
	private PolicyDefinition compilePolicyRules(PolicyDefinition policy) {
		LOGGER.debug("PolicyProvider.compilePolicyRules(Policy policy) start");
		try {
			for (Rule rule : policy.getRule()) {
				for (Assumption as : rule.getIf()) {
					String expression = as.getLeftTerm() + " " + as.getOp() + " " + as.getRightTerm();
					Object compiledExpression = MVEL.compileExpression(expression);
					as.setCompiledExpression(compiledExpression);
				}
			}
		} catch (Exception e) {
			LOGGER.error("Error while compiling PolicyDefinition Object", e);
		}
		LOGGER.debug("PolicyProvider.compilePolicyRules(Policy policy) end");
		return policy;
	}
	
	
	/**
	 * Checks whether actions in each rule of the policy are of different type
	 * 
	 * @param policyDefinition Policy to be tests for invalid rules
	 * @return false if rule(s) of policy contains same action types 
	 */
	private boolean isValidPolicy(PolicyDefinition policyDefinition) {
		
		LOGGER.debug("PolicyProvider.isValidPolicy(PolicyDefinition policyDefinition) start");
		
		Set<String> actionTypes = null;
		boolean validPolicy = true;
		for(Rule pRule : policyDefinition.getRule()) {
			actionTypes = new HashSet<String>();
			for(Action action : pRule.getThen().getAction()) {
				if(!actionTypes.add(action.getType().name())) {
					if(validPolicy) {
						LOGGER.error(policyDefinition.getPolicyName() + " contains rule(s) having same actions which is not allowed");
						validPolicy = false;
					}
					LOGGER.error("Rule " + pRule.getId() + " contains two or more actions of type " + action.getType().name());
				}
			}
		}
		
		LOGGER.debug("PolicyProvider.isValidPolicy(PolicyDefinition policyDefinition) end");
		
		return validPolicy;
	}
	
	
	
	
}