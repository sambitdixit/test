##Soari Policy Evaluation Framework

It provides a way to define a single or composite policy/rules at design time and its evaluation at runtime.  It evolved from the core requirement of ESB and Registry where there is a need to have policy based SLA enforcements. The key requirements and philosophy of the policy framework was 

* Ability to define policies in a simple expressive language that is understandable by business as well as technical people. 
* Ability to define policies with flow(request/response), order (policy one needs to be evaluated before policy two), policy types(SLA,Throttling, Mediation etc) at design time. 
* Ability to inject different types of evaluation expressions. 
* Ability to create a composite policies. 
* Execution of policy should be fast. 
* Overall foot print of policy engine should be extremely lightweight. 
* Minimal third party dependencies. 

###Structure:
The policy framework consists of 2 modules. 

 * model -  This contains the schema and its generated POJOs of the policy language. 
 
 * engine - This contains the core policy evaluation engine. Policy engine uses the model to parse policy xml document and serialize to POJOs. This framework is built on top of MVEL expression evaluation engine. http://mvel.codehaus.org. 
 

###Dependencies:
```
1. Model module has following dependencies. 

<dependency>
  <groupId>javax.xml.bind</groupId>
  <artifactId>jaxb-api</artifactId>
  <version>2.2</version>
</dependency>
<dependency>
  <groupId>com.sun.xml.bind</groupId>
  <artifactId>jaxb-impl</artifactId>
  <version>2.2</version>
</dependency>
<dependency>
  <groupId>commons-lang</groupId>
  <artifactId>commons-lang</artifactId>
</dependency>

2. Engine module has following dependencies. 

<dependency>
  <groupId>com.walmart.platform</groupId>
  <artifactId>soari-policy-model</artifactId>
  <version>${project.version}</version>
</dependency>

<dependency>
  <groupId>com.walmart.platform</groupId>
  <artifactId>platform-kernel</artifactId>
  <version>1.1.4</version>
</dependency>

<dependency>
 <groupId>org.mvel</groupId>
 <artifactId>mvel2</artifactId>
 <version>2.1.3.Final</version>
</dependency>
		
```		
###How to use: 

If you want to use this framework, add the following dependency to you pom.xml. 

```
<dependency>
	<groupId>com.walmart.platform</groupId>
	<artifactId>soari-policy-engine</artifactId>
	<version>${soari.version}</version>
</dependency>
```

where soari.version - 3.0.1-SNAPSHOT onwards. This dependency will automatically inherit the related dependencies automatically for you. You dont need to provide individual dependencies explicitly. If you want, you can do that but its not required. 

For usage, please look at the examples section below. 

###Examples:

```
1. Code - https://gecgithub01.walmart.com/platform/soa-ri/tree/development/policy/engine/src/test/java/com/walmart/platform/soa/policy/evaluation/examples

2. Sample policy documents - https://gecgithub01.walmart.com/platform/soa-ri/tree/development/policy/engine/src/test/resources/policies

```

###Current State: 

It is available from 3.0.1-SNAPSHOT.  Use/extend it for right use case ONLY. 

###Limitation: 

It does not complex expressions and nested expression. Whatever expressions are doable by MVEL, all of them will work automatically since the core engine is built on top of MVEL.  
