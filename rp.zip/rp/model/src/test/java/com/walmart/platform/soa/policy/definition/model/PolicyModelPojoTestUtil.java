package com.walmart.platform.soa.policy.definition.model;

import com.openpojo.reflection.PojoClass;
import com.openpojo.reflection.PojoClassFilter;
import com.openpojo.reflection.filters.FilterChain;
import com.openpojo.reflection.impl.PojoClassFactory;
import com.openpojo.validation.PojoValidator;
import com.openpojo.validation.rule.impl.NoPublicFieldsRule;
import com.openpojo.validation.rule.impl.NoStaticExceptFinalRule;
import com.openpojo.validation.test.impl.GetterTester;
import com.openpojo.validation.test.impl.SetterTester;

/**
 * POJO TestUtil based on openpojo to test DTOs and POJOs
 */
public class PolicyModelPojoTestUtil {

	private final PojoValidator pojoValidator;

	/**
	 * Instantiates a new pojo test util.
	 */
	public PolicyModelPojoTestUtil() {
		pojoValidator = new PojoValidator();
		
		// Create Rules to validate structure for POJO_PACKAGE
		pojoValidator.addRule(new NoPublicFieldsRule());
		pojoValidator.addRule(new NoStaticExceptFinalRule());
		// pojoValidator.addRule(new NoNestedClassRule());
		// pojoValidator.addRule(new GetterMustExistRule());
		// pojoValidator.addRule(new SetterMustExistRule());

		// Create Testers to validate behaviour for POJO_PACKAGE);
		pojoValidator.addTester(new SetterTester());
		pojoValidator.addTester(new GetterTester());
		// pojoValidator.addTester(new BusinessIdentityTester());
	}

	/**
	 * Test pojo structure and behavior.
	 * 
	 * @param packages
	 *            the packages
	 * @param classFilters
	 *            the class filters
	 */
	public void testPojoStructureAndBehavior(final String[] packages,
			final PojoClassFilter... classFilters) {
		for (final String pojoPackage : packages) {
			testPojoStructureAndBehavior(pojoPackage, classFilters);
		}
	}

	/**
	 * Test pojo structure and behavior.
	 * 
	 * @param pojoPackage
	 *            the pojo package
	 * @param classFilters
	 *            the class filters
	 */
	public void testPojoStructureAndBehavior(final String pojoPackage,
			final PojoClassFilter... classFilters) {
		final FilterChain filterChain = new FilterChain(classFilters);
		for (final PojoClass pojoClass : PojoClassFactory.getPojoClasses(
				pojoPackage, filterChain)) {
			testPojoStructureAndBehavior(pojoClass);
		}
	}

	/**
	 * Test pojo structure and behavior.
	 * 
	 * @param pojoClass
	 *            the pojo class
	 */
	public void testPojoStructureAndBehavior(final PojoClass pojoClass) {
		pojoValidator.runValidation(pojoClass);
	}
}