package com.walmart.platform.soa.policy.definition.model;

import org.testng.annotations.Test;

import com.openpojo.reflection.PojoClassFilter;
import com.openpojo.reflection.filters.FilterEnum;
 
/**
 * The Class GenericPojoTester.
 */
 
public class PolicyModelPojoTester {
 
    // The package to test
    /** The Constant POJO_PACKAGE. */
    private static final String POJO_PACKAGE = "com.walmart.platform.soa.policy.definition.model";
 
    /** The pojo class filters. */
    private final PojoClassFilter[] pojoClassFilters = {new FilterEnum()};
 
    /**
     * Test pojo structure and behavior.
     */
    @Test
    public void testPojoStructureAndBehavior() {
        final PolicyModelPojoTestUtil pojoTestUtil = new PolicyModelPojoTestUtil();
        pojoTestUtil.testPojoStructureAndBehavior(POJO_PACKAGE, pojoClassFilters);
    }
}