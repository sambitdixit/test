package com.walmart.platform.soa.policy.definition.model;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotNull;
import static org.testng.Assert.assertNull;
import static org.testng.Assert.fail;

import java.util.ArrayList;
import java.util.Collection;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class AllPojoTest {
    Actions as;
    Action a;
    Assumption asm;
    ObjectFactory of;
    PolicyDefinition pd;
    Rule r;

    @BeforeClass
    public void setup() throws Exception {
        as = new Actions();
        a = new Action();
        as.getAction().add(a);
        asm = new Assumption();
        pd = new PolicyDefinition();
        r = new Rule();
        of = new ObjectFactory();
    }

    @Test
    public void testEquals() {

        a.withType(ActionType.ALLOW);
        Assert.assertEquals(a.getType(), ActionType.ALLOW);
        a.withMessage("HelloWorld");
        Assert.assertEquals(a.getMessage(), "HelloWorld");
        a.withValue("true");
        Assert.assertEquals(a.getValue(), "true");
        a.withErrorcode("ERROR:404");
        Assert.assertEquals(a.getErrorcode(), "ERROR:404");
        a.withHttpcode(500);
        Assert.assertEquals(a.getHttpcode() == 500, true);
        System.out.println(a.toString());

        asm.withLeftTerm("requestUri");
        Assert.assertEquals(asm.getLeftTerm(), "requestUri");
        asm.withOp("=");
        Assert.assertEquals(asm.getOp(), "=");
        asm.withRightTerm("/abc/a");
        Assert.assertEquals(asm.getRightTerm(), "/abc/a");
        System.out.println(asm.toString());

        pd.withFlow(FlowType.REQUEST);
        Assert.assertEquals(pd.getFlow(), FlowType.REQUEST);
        
        pd.withContext(ContextType.ESB);
        Assert.assertEquals(pd.getContext(), ContextType.ESB);
        Assert.assertEquals(pd.getFlow(), FlowType.REQUEST);
        
        
        pd.withOrder("0");
        Assert.assertEquals(pd.getOrder(), "0");
        pd.withPolicyId("1");
        Assert.assertEquals(pd.getPolicyId(), "1");
        pd.withType("SLA");
        Assert.assertEquals(pd.getType(), "SLA");
        pd.withPolicyName("AllowedContentTypes");
        Assert.assertEquals(pd.getPolicyName(), "AllowedContentTypes");

        r.withId("1");
        assertEquals(r.getId(), "1");
        assertNotNull(pd.toString());
        assertNotNull(pd.withRule((Collection) null));
        Collection<Rule> ruleCollection = new ArrayList<Rule>();
        ruleCollection.add(r);
        assertNotNull(pd.withRule(ruleCollection));
    }

    @Test
    public void testNotNull() {

        assertNotNull(of.createAction());
        assertNotNull(of.createActions());
        assertNotNull(of.createAssumption());
        assertNotNull(of.createPolicyDefinition());
        assertNotNull(of.createRule());
        assertNotNull(of.createPolicyDefinition(pd));
        assertNotNull(r.withIf(asm).withThen(as));
        assertNotNull(pd.withRule(r));
        assertNotNull(pd);
    }

    @Test
    public void testPolicyDefinition() {
        PolicyDefinition policyDefinition = new PolicyDefinition();
        Assert.assertNotNull(policyDefinition);
    }

    @Test
    public void testActions() {
        Action action = new Action();
        action.setType(ActionType.DENY);
        action.setErrorcode("500");
        action.setHttpcode(200);
        action.setMessage("msg");
        action.setValue("value");

        Actions actions = new Actions();
        assertNotNull(actions.getAction());
        assertNotNull(actions.getAction());
        assertNotNull(actions.withAction((Action) null));
        assertNotNull(actions.withAction((Collection) null));
        assertNotNull(actions.toString());

        Collection<Action> actionCollection = new ArrayList<Action>();
        actionCollection.add(action);

        try {
            actions.withAction(action);
            actions.withAction(actionCollection);
        } catch (Exception e) {
            fail("exception not expected");
        }
    }

    @Test
    public void testFlowType() {
        assertEquals(FlowType.REQUEST.value(), "REQUEST");
        assertEquals(FlowType.fromValue("RESPONSE"), FlowType.RESPONSE);
    }

    @Test
    public void testActionType() {
        assertEquals(ActionType.DENY.value(), "DENY");
        assertEquals( ActionType.fromValue("DENY"), ActionType.DENY);
    }

    @Test
    public void testAssumption() {
        Assumption assumption = new Assumption();
        assumption.withCompiledExpression(new Object());
        assertNotNull(assumption.getCompiledExpression());
    }

    @Test
    public void testRule() {
        Rule rule = new Rule();
        assertNotNull(rule.getIf());
        assertNotNull(rule.toString());
        assertNull(rule.getThen());
        Assumption assumption = new Assumption();
        Collection<Assumption> assumptionCollection = new ArrayList<Assumption>(1);
        assumptionCollection.add(assumption);
        assertNotNull(rule.withIf(assumptionCollection));
        assertNotNull(rule.withIf((Collection)null));
    }
}
