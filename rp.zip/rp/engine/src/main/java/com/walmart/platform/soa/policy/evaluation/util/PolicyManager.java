package com.walmart.platform.soa.policy.evaluation.util;

import java.util.List;

import org.mvel2.MVEL;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.walmart.platform.soa.policy.common.impl.PolicyProvider;
import com.walmart.platform.soa.policy.definition.model.Action;
import com.walmart.platform.soa.policy.definition.model.Actions;
import com.walmart.platform.soa.policy.definition.model.Assumption;
import com.walmart.platform.soa.policy.definition.model.PolicyDefinition;
import com.walmart.platform.soa.policy.definition.model.Rule;
import com.walmart.platform.soa.policy.enums.ActionStatus;
import com.walmart.platform.soa.policy.evaluation.context.IPolicyContext;
import com.walmart.platform.soa.policy.evaluation.context.impl.PolicyContext;
import com.walmart.platform.soa.policy.exception.PolicyEvaluationException;


/**
 * 
 * @author sdikshi
 * @author msing37 
 */
public final class PolicyManager {

	private static final Logger LOGGER = LoggerFactory.getLogger(PolicyManager.class);
	private static PolicyProvider provider = PolicyProvider.instance();
	private static final String KEY_VALUE_SEPARATOR = ":";
	private static final String ENTRY_SEPARATOR = "|";
	public static final String DOT_SEPARATOR = ".";

	
	/**
	 * Loads a policy from a policy definition string.
	 * 
	 * @param policyDefinition
	 * @return
	 */
	public static PolicyDefinition loadPolicy(String policyDefinition) {
		PolicyDefinition policy = provider.getPolicyDefinition(policyDefinition);
		if (policy == null) {
			LOGGER.error("policy can not be loaded.");
		}
		return policy;
	}


	/**
	 * Loads policy definition from byte array.
	 * 
	 * 
	 * @param policyDefinition
	 * @return
	 */
	public static PolicyDefinition loadPolicy(byte[] policyDefinition) {
		PolicyDefinition policy = provider.getPolicyDefinition(policyDefinition);
		if (policy == null) {
			LOGGER.error("policy can not be loaded.");
		}
		return policy;
	}


	/**
	 * Executes the policy for the supplied policy definition. It loads the
	 * policy and executes the rules specified for the policy.
	 * 
	 * @param policyDef
	 * @param context
	 * @return
	 * @throws PolicyEvaluationException
	 */
	public static IPolicyContext executePolicy(String policyDef,
			PolicyContext context) {
		PolicyDefinition policy = loadPolicy(policyDef);
		return executePolicy(policy, context);
	}


	/**
	 * Executes the policy for the supplied policy definition byte array. It
	 * loads the policy and executes the rules specified for the policy.
	 * 
	 * @param policyId
	 * @param policyDef
	 * @param context
	 * @return
	 * @throws PolicyEvaluationException
	 */
	public static IPolicyContext executePolicy(byte[] policyDef,
			PolicyContext context) {
		PolicyDefinition policy = loadPolicy(policyDef);
		return executePolicy(policy, context);
	}


	/**
	 * Executes the supplied policy instance with policy context.<br>
	 * For policy evaluation, <b>OR</b> semantics is followed i.e. 
	 * if any of the Rule is evaluated, the next rules are not evaluated 
	 * 
	 * @param policy
	 * @param context
	 * @return
	 * @throws PolicyEvaluationException
	 */
	public static IPolicyContext executePolicy(PolicyDefinition policy,
			IPolicyContext context) {

		// Clean action context before every policy execution
		context.getActionContext().clear();

		for (Rule rule : policy.getRule()) {
			boolean allIfOK = false;
			allIfOK = executeAsssumptions(rule.getIf(), context);
			if (allIfOK) {
				executeActions(rule.getThen(), context);
				context.setExecutionStatus(true);
				break;
			} 
			else {
				executeElseActions(rule.getThen(), context);
			}
		}

		return context;
	}


	/**
	 * @param assumptions
	 * @param ctx
	 * @return
	 */
	private static boolean executeAsssumptions(List<Assumption> assumptions,
			IPolicyContext ctx) {

		StringBuilder expectedValues = new StringBuilder();
		StringBuilder actualValues = new StringBuilder();

		Boolean ok = false;
		for (Assumption a : assumptions) {
			Object result = MVEL.executeExpression(
					a.getCompiledExpression(), ctx.getAssumptionContext());
			ok = new Boolean("" + result);

			// append assumption's left & right term to string buffer
			if(a.getLeftTerm().startsWith("REQ")) {
				actualValues.append(a.getLeftTerm()).append(KEY_VALUE_SEPARATOR).append(ctx.getAssumptionContext(a.getLeftTerm())).append(ENTRY_SEPARATOR);;
				expectedValues.append(a.getRightTerm()).append(KEY_VALUE_SEPARATOR).append(ctx.getAssumptionContext(a.getRightTerm())).append(ENTRY_SEPARATOR);

			}
			else {
				actualValues.append(a.getRightTerm()).append(KEY_VALUE_SEPARATOR).append(ctx.getAssumptionContext(a.getRightTerm())).append(ENTRY_SEPARATOR);
				expectedValues.append(a.getLeftTerm()).append(KEY_VALUE_SEPARATOR).append(ctx.getAssumptionContext(a.getLeftTerm())).append(ENTRY_SEPARATOR);
			}

			// if assumptions evaluated to true, then continue otherwise quit
			if (ok) {
				continue;
			} else {
				break;
			}
		}

		// put all the values to assumption context
		ctx.setActualValues(actualValues.toString().substring(0, actualValues.toString().length()-1));
		ctx.setExpectedValues(expectedValues.toString().substring(0, expectedValues.toString().length()-1));

		return ok;
	}


	/**
	 * @param acs
	 * @param ctx
	 */
	private static void executeActions(Actions acs, IPolicyContext ctx) {
		for (Action action : acs.getAction()) {
			ctx.setActionContext(action.getType().name() + DOT_SEPARATOR + ActionStatus.SUCCESS.name(), action);
		}
	}


	/**
	 * Executes the actions for false if cases where we need to populate ONLY
	 * the error codes, error messages, http code etc. This is called only when
	 * the if condition fails.
	 * 
	 * @param acs
	 * @param ctx
	 * @param isLastRuleSuccess
	 */
	private static void executeElseActions(Actions acs, IPolicyContext ctx) {
		for (Action action : acs.getAction()) {
			ctx.setActionContext(action.getType().name( ) + DOT_SEPARATOR + ActionStatus.FAIL.name(), action);
		}
	}

}