package com.walmart.platform.soa.policy.alert.cache;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.walmart.platform.soa.policy.constants.PolicyAlertConstants;
import com.walmart.platform.soa.service.khoj.client.KhojData;
import com.walmart.platform.soa.service.khoj.client.PolicyData;

/**
 * Class which populates the data corresponding to request, Violations etc.
 * based on <ServiceName,SerVersion,SerEnv> into the cache.
 * 
 * @author sdikshi
 * @author smenon2
 * @since 4.1.1
 */
public enum AlertCachePopulator {

	INSTANCE;

	private static Map<String, Map<String, AlertCacheValue>> cache = new ConcurrentHashMap<String, Map<String, AlertCacheValue>>();

	/**
	 * Method to be called by the user. Used to populate in-memory cache
	 * 
	 * @param protocolHeaders
	 * @param violatedPolicy
	 */
	public void gatherAlertData(KhojData serviceInfoData, PolicyData pd) {

		long inTime = System.currentTimeMillis();
		String key = generateKey(serviceInfoData);
		String violatedPolicy = pd.getName();

		Map<String, AlertCacheValue> alertValues;
		
		alertValues = cache.get(key);

		if (alertValues != null) {
			AlertCacheValue alertCacheValue = alertValues.get(violatedPolicy);
			if (alertCacheValue != null) {
				synchronized (alertCacheValue) {
					if (alertCacheValue.getPolicyData().hashCode() != pd.hashCode()) {
						alertCacheValue.setPolicyData(pd);
					}
					alertCacheValue.setViolationCount(alertCacheValue.getViolationCount() + 1);
					alertCacheValue.setLastViolation(inTime);
				}
			} else {
				AlertCacheValue alertEntry = generateAlertCacheValue(pd,inTime, 0, serviceInfoData.getServiceOwner());
				cache.get(key).put(violatedPolicy, alertEntry);
			}
		}

		else {
			Map<String, AlertCacheValue> alertCacheEntry = generateAlertCacheEntry(pd,inTime, violatedPolicy, serviceInfoData.getServiceOwner());
			cache.put(key, alertCacheEntry);
		}
	}

	/**
	 * Generates cache key from service name, service version, service env. 
	 * 
	 * @param khojData
	 * @return
	 */
	private String generateKey(KhojData khojData) {
		String serviceName = khojData.getServiceName();
		String serviceVersion = khojData.getServiceVersion();
		String serviceEnv = khojData.getServiceEnv();
		String key = serviceName + PolicyAlertConstants.CACHE_KEY_SEPARATOR
				+ serviceVersion + PolicyAlertConstants.CACHE_KEY_SEPARATOR
				+ serviceEnv;
		return key;
	}

	/**
	 * Generates a new AlertCacheValue object. 
	 * 
	 * @param policyData
	 * @param lastViolation
	 * @param windowExpireTime
	 * @param serviceOwner
	 * @return
	 */
	private AlertCacheValue generateAlertCacheValue(PolicyData policyData,
			long lastViolation, long windowExpireTime, String serviceOwner) {
		AlertCacheValue alertCacheValue = new AlertCacheValue();
		alertCacheValue.setLastViolation(lastViolation);
		alertCacheValue.setPolicyData(policyData);
		alertCacheValue.setWindowExpireTime(windowExpireTime);
		alertCacheValue.setViolationCount(1);
		alertCacheValue.setServiceOwner(serviceOwner);
		return alertCacheValue;
	}

	/**
	 * Generates a new AlertCacheEntry for specific policy violation. 
	 * 
	 * @param pd
	 * @param inTime
	 * @param violatedPolicy
	 * @param serviceOwner
	 * @return
	 */
	private Map<String, AlertCacheValue> generateAlertCacheEntry(PolicyData pd,
			long inTime, String violatedPolicy, String serviceOwner) {
		AlertCacheValue alertCacheValue = generateAlertCacheValue(pd, inTime,0, serviceOwner);
		Map<String, AlertCacheValue> alertEntry = new ConcurrentHashMap<String, AlertCacheValue>();
		alertEntry.put(violatedPolicy, alertCacheValue);
		return alertEntry;
	}

	/**
	 * Get singleton instance of cache
	 * 
	 * @return
	 */
	public Map<String, Map<String, AlertCacheValue>> getCahce() {
		return cache;
	}

}
