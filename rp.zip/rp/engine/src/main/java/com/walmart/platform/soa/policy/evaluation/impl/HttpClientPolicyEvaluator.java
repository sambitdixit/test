package com.walmart.platform.soa.policy.evaluation.impl;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.walmart.platform.soa.common.HeaderElements;
import com.walmart.platform.soa.common.HeaderElements.DiscoveryStrategy;
import com.walmart.platform.soa.common.HeaderElements.FlowType;
import com.walmart.platform.soa.common.util.SOAStringUtil;
import com.walmart.platform.soa.policy.evaluation.context.impl.PolicyContext;
import com.walmart.platform.soa.service.khoj.client.KhojClient;
import com.walmart.platform.soa.service.khoj.client.KhojData;
import com.walmart.platform.soa.service.khoj.client.QoSData;

/**
 * Policy Evaluator for (HTTP) client-side policy in/out Interceptors to execute
 * both SLA & SECURITY type of policies <br><br>
 * s
 * 
 * This Evaluator provides its own implementation of abstract as well as
 * overrides inherited methods from {@link AbstractPolicyEvaluator} and, also
 * adds few private utility methods
 * 
 * 
 * @author msing37
 * @author sdikshi
 * 
 */
public final class HttpClientPolicyEvaluator extends AbstractPolicyEvaluator {

	private static final Logger LOGGER = LoggerFactory.getLogger(HttpClientPolicyEvaluator.class);
	private static HttpClientPolicyEvaluator self = new HttpClientPolicyEvaluator();
	

	@Override
	public <T> PolicyContext populatePolicyContext(KhojData khojData,
			Map<String, T> responseHeaders, String flowType) {

		PolicyContext policyContext = populateServiceDetail(khojData);

		policyContext.setRequestIPAddress((String) responseHeaders.get(HeaderElements.CONSUMER_IP));
		policyContext.setRequestGUID((String) responseHeaders.get(HeaderElements.CONSUMER_GUID));
		policyContext.setConsumerId((String) responseHeaders.get(HeaderElements.CONSUMER_ID));
		Object statusCode = responseHeaders.get(HeaderElements.HTTP_STATUS_CODE);
		if(statusCode!=null){
		 policyContext.setRequestResponseStatusCode(String.valueOf(statusCode));
		}
		
		Object tempObj = responseHeaders.get(HeaderElements.CONSUMER_SOURCE_ID);
		if(tempObj!=null){
			String consumerSourceId = String.valueOf(tempObj);
			policyContext.setConsumerSourceId(consumerSourceId);
		}
		
		// put QoS data in policy's context
		for (QoSData qos : khojData.getQosList()) {
			policyContext.setAssumptionContext(qos.getName(), qos.getValue());
		}

		// in case of service-response at client-side, set round-trip time and
		// network latency time
		if (FlowType.RESPONSE.name().equals(flowType)) {
			setHTTPClientSideResponseTimes(responseHeaders, policyContext);
		} else {
			// do request flow processing i.e. PolicyOutInterceptor
		}

		return policyContext;
	}
	
	@Override
	public <T> KhojData getKhojData(Map<String, T> responseHeaders,
			DiscoveryStrategy discoveryStrategy) {

		KhojData khojData = null;

		String serviceName = (String) responseHeaders.get(HeaderElements.SERVICE_NAME);

		if (serviceName != null && !policySkipFilter.contains(serviceName)) {

			// get remaining service attributes which are needed to make query
			// to Khoj cache
			String serviceVersion = (String) responseHeaders
					.get(HeaderElements.SERVICE_VERSION);
			String serviceEnv = (String) responseHeaders
					.get(HeaderElements.SERVICE_ENV);
			String consumerId = (String) responseHeaders
					.get(HeaderElements.CONSUMER_ID);
			// get Service's KhojData using KhojClient,
			// 'SERVICE' discovery strategy will be used irrespective of client
			// or server side interceptors
			KhojClient khojClient = KhojClient.getInstance();
			khojData = khojClient.getKhojData(discoveryStrategy.name(),
					serviceName, serviceVersion, serviceEnv, consumerId);
			
			if(khojData == null) {
				khojData = getDummyKhojData(serviceName, serviceEnv, serviceVersion);
			}
		}

		return khojData;
	}
	
	/**
	 * Extracts the service response time and network latency and sets these
	 * values into policyContext
	 * 
	 * @param responseHeaders
	 *            Map containing client & service's side in/out time-stamps
	 * @param policyContext
	 *            policy execution context
	 */
	protected <T> void setHTTPClientSideResponseTimes(
			Map<String, T> responseHeaders, PolicyContext policyContext) {
		
		long serviceInTime = getTimestamp(responseHeaders, HeaderElements.SERVICE_IN_TIMESTAMP);
		long serviceOutTime = getTimestamp(responseHeaders, HeaderElements.SERVICE_OUT_TIMESTAMP);
		long clientInTime = getTimestamp(responseHeaders, HeaderElements.CONSUMER_IN_TIMESTAMP);
		long clientOutTime = getTimestamp(responseHeaders, HeaderElements.CONSUMER_OUT_TIMESTAMP);
		
		setClientResponseTimes(serviceInTime, serviceOutTime, clientInTime,clientOutTime, policyContext);

	}

	
	/**
	 * Fetches SAORI time-stamp value from transport headers, default value is zero 
	 * 
	 * @param protocolHeaders
	 * @param timestampIdentifier
	 * @return
	 */
	protected <T> long getTimestamp(Map<String, T> protocolHeaders, String timestampIdentifier) {
		String temp = (String) protocolHeaders.get(timestampIdentifier);
		try {
			if(SOAStringUtil.isBlank(temp)) {
				return 0;
			}
			else {
				return Long.parseLong(temp);
			}
		}
		catch(NumberFormatException e) {
			LOGGER.error(timestampIdentifier + " not a number at soa client side, using default value 0", e);
		}
		return 0;
	}
	
	/**
	 * Returns singleton instance of self
	 * 
	 * @return
	 */
	public static HttpClientPolicyEvaluator getInstance() {
		if (self == null) {
			self = new HttpClientPolicyEvaluator();
		}
		return self;
	}

}
