package com.walmart.platform.soa.policy.evaluation.context;

import java.util.Map;

import com.walmart.platform.soa.policy.definition.model.Action;
import com.walmart.platform.soa.policy.definition.model.ActionType;
import com.walmart.platform.soa.policy.enums.ActionStatus;

/**
 * @author sdikshi
 * @author ranand
 * 
 */
public interface IPolicyContext {

    /**
     *
     * @param key
     * @return
     */
	Action getActionContext(String key);

    /**
     *
     * @param key
     * @param action
     */
	void setActionContext(String key, Action action);

    /**
     *
     * @return
     */
	Map<String, Action> getActionContext();

    /**
     *
     * @param assumptionContext
     */
	void setAssumptionContext(Map<String, String> assumptionContext);

    /**
     *
     * @return
     */
	Map<String, String> getAssumptionContext();

    /**
     *
     * @param key
     * @param value
     */
	void setAssumptionContext(String key,String value);

    /**
     *
     * @param key
     * @return
     */
	String getAssumptionContext(String key);
	
	
	/**
	 * @return
	 */
	String getActualValues();
	
	
	/**
	 * @return
	 */
	String getExpectedValues();
	
	
	/**
	 * @param valueContext
	 */
	void setActualValues(String actualValues);
	
	/**
	 * @param valueContext
	 */
	void setExpectedValues(String expectedValue);

	
	/**
	 * @return the executionStatus
	 */
	boolean getExecutionStatus();

	/**
	 * @param executionStatus
	 *            the executionStatus to set
	 */
	void setExecutionStatus(boolean executionStatus);

    /**
     *
     * @return
     */
	Action getActionAllow();

    /**
     *
     * @return
     */
	Action getActionDeny();

    /**
     *
     * @return
     */
	Action getActionAlert();

    /**
     *
     * @return
     */
	Action getActionRouteVersion();

    /**
     *
     * @return
     */
	Action getActionRouteUrl();

    /**
     *
     * @return
     */
	Action getActionThrottle();
	
	/**
	 * Fetches the appropriate action from the action context <br><br>
	 * 
	 * <b>NOTE:</b> Key to fetch the action from action context, will be made<br>
	 * by concatenating actionType & status
	 * 
	 * @param actionType one of the {@link ActionType}
	 * @param actionStatus one of the {@link ActionStatus}
	 * 
	 * @return
	 */
	Action getAction(ActionType actionType, ActionStatus actionStatus);
	
	
	/**
	 * Returns action's value as map. <br> 
	 * 
	 * <b>NOTE:</b> Multiple values of the action must be specified in policy.xml (under value tag) as following: <br>
	 * key1=value1,key2=value2
	 * 
	 * @param action
	 * @return
	 */
	Map<String, String> getActionValueAsMap(Action action);

}