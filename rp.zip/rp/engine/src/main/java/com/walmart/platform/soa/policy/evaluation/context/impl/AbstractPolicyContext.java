package com.walmart.platform.soa.policy.evaluation.context.impl;

import java.util.HashMap;
import java.util.Map;

import com.walmart.platform.soa.policy.definition.model.Action;
import com.walmart.platform.soa.policy.definition.model.ActionType;
import com.walmart.platform.soa.policy.enums.ActionStatus;
import com.walmart.platform.soa.policy.evaluation.context.IPolicyContext;
import com.walmart.platform.soa.policy.evaluation.util.PolicyManager;

/**
 * @author sdikshi
 * @author ranand
 * 
 */
public abstract class AbstractPolicyContext implements IPolicyContext {

	private static final String VALUES_SEPRATOR = ",";
	private static final String KEY_VALUE_SEPARATOR = "=";
	private static final String DEFAULT_KEY = "actionKey";

	// holds assumption related context parameters.
	protected Map<String, String> assumptionContext = new HashMap<String, String>();

	// holds action related context parameters.
	protected Map<String, Action> actionContext = new HashMap<String, Action>();

	// hold the values for all assumption's left and right terms for each rule
	// of the policy
	protected String actualValues;
	protected String expectedValues;

	protected boolean executionStatus = false;

	@Override
	public Action getActionContext(String key) {
		return actionContext.get(key);
	}

	@Override
	public void setActionContext(String key, Action action) {
		actionContext.put(key, action);
	}

	@Override
	public Map<String, Action> getActionContext() {
		return actionContext;
	}

	@Override
	public Map<String, String> getAssumptionContext() {
		return assumptionContext;
	}

	@Override
	public void setAssumptionContext(Map<String, String> assumptionContext) {
		if (assumptionContext != null && !(assumptionContext.isEmpty())) {
			assumptionContext.putAll(assumptionContext);
		}
	}

	@Override
	public void setAssumptionContext(String key, String value) {
		assumptionContext.put(key, value);
	}

	@Override
	public String getAssumptionContext(String key) {
		return assumptionContext.get(key);
	}

	@Override
	public String getActualValues() {
		return this.actualValues;
	}

	@Override
	public String getExpectedValues() {
		return this.expectedValues;
	}

	@Override
	public void setActualValues(String actualValues) {
		this.actualValues = actualValues;
	}

	@Override
	public void setExpectedValues(String expectedValues) {
		this.expectedValues = expectedValues;
	}

	@Override
	public boolean getExecutionStatus() {
		return executionStatus;
	}

	@Override
	public void setExecutionStatus(boolean executionStatus) {
		this.executionStatus = executionStatus;
	}

	@Override
	public Action getActionAllow() {
		Action action = actionContext.get(ActionType.ALLOW.name());
		if (action == null) {
			action = new Action();
			action.setType(ActionType.ALLOW);
			action.setValue("false");
		}
		return action;
	}

	@Override
	public Action getActionDeny() {
		Action action = actionContext.get(ActionType.DENY.name());
		if (action == null) {
			action = new Action();
			action.setType(ActionType.DENY);
			action.setValue("false");
		}
		return action;
	}

	@Override
	public Action getActionAlert() {
		Action action = actionContext.get(ActionType.ALERT.name());
		if (action == null) {
			action = new Action();
			action.setType(ActionType.ALERT);
			action.setValue("false");
		}
		return action;
	}

	@Override
	public Action getActionRouteVersion() {
		Action action = actionContext.get(ActionType.ROUTE_VERSION.name());
		if (action == null) {
			action = new Action();
			action.setType(ActionType.ROUTE_VERSION);
			action.setValue(null);
		}
		return action;
	}

	@Override
	public Action getActionRouteUrl() {
		Action action = actionContext.get(ActionType.ROUTE_URL.name());
		if (action == null) {
			action = new Action();
			action.setType(ActionType.ROUTE_URL);
			action.setValue(null);
		}
		return action;
	}

	@Override
	public Action getActionThrottle() {
		Action action = actionContext.get(ActionType.THROTTLE_DENY.name());
		if (action == null) {
			action = new Action();
			action.setType(ActionType.THROTTLE_DENY);
			action.setValue(null);
		}
		return action;
	}

	@Override
	public Action getAction(ActionType actionType, ActionStatus policyStatus) {
		return actionContext.get(actionType.name()
				+ PolicyManager.DOT_SEPARATOR + policyStatus.name());
	}

	@Override
	public Map<String, String> getActionValueAsMap(Action action) {

		Map<String, String> valueMap = new HashMap<String, String>();

		String actionValue = null;
		String[] values = null;
		String[] keyValue = null;

		// if action value is not null, then go ahead
		if ((actionValue = action.getValue()) != null) {

			// get multiple key-value pairs
			values = actionValue.split(VALUES_SEPRATOR);

			// for each pari, put key and value in map, if no key then use
			// default key
			int i = 1;
			for (String value : values) {
				keyValue = value.split(KEY_VALUE_SEPARATOR);
				if (keyValue.length == 1) {
					valueMap.put(DEFAULT_KEY + i++, keyValue[0]);
				} else {
					valueMap.put(keyValue[0], keyValue[1]);
				}
			}
		}

		return valueMap;
	}

}
