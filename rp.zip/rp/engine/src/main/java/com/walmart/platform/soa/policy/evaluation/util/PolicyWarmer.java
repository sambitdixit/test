package com.walmart.platform.soa.policy.evaluation.util;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.walmart.platform.soa.policy.alert.PolicyAlertExecutor;
import com.walmart.platform.soa.policy.common.impl.PolicyProvider;
import com.walmart.platform.soa.policy.definition.model.Action;
import com.walmart.platform.soa.policy.definition.model.ActionType;
import com.walmart.platform.soa.policy.definition.model.PolicyDefinition;
import com.walmart.platform.soa.policy.enums.ActionStatus;
import com.walmart.platform.soa.policy.enums.PolicyTerms;
import com.walmart.platform.soa.policy.evaluation.context.impl.PolicyContext;
import com.walmart.platform.soa.policy.exception.PolicyExceptionUtil;

/**
 * This class is used:<br>
 * 1. when server/client or ESB is started to load the MVEL and
 * 2. to load default policies and QoS
 * 
 * Policy Engine
 * 
 * @author sdikshi
 * @author msing37
 * 
 */
public final class PolicyWarmer {

	private static final Logger LOGGER = LoggerFactory.getLogger(PolicyWarmer.class);
	
	private static final String WARM_UP_POLICY_DIR = "META-INF/policies/";
	
	private static List<String> warmupPolicies=new ArrayList<String>();
	 
	
	/**
	 * The default buffer size to use.
	 */
	private static final int DEFAULT_BUFFER_SIZE = 1024 * 4;

	private static PolicyWarmer self = new PolicyWarmer();
	private boolean isWarmedup = false;

	/**
	 * Private Constructor
	 */
	private PolicyWarmer() {
		addDefaultWarmUpPolicies();
		isWarmedup = warmUpPolicyEngine();
		PolicyAlertExecutor.getInstance();
	}

	/**
	 * Returns the singleton instance
	 * 
	 * @return
	 */
	public static PolicyWarmer instance() {
		return self;
	}
	
	/**
	 * Accessor for iwWarmedUp
	 * 
	 * @return
	 */
	public boolean isWarmedUp() {
		return isWarmedup;
	}

	/**
	 * Add default policies that will be used to warm up the policy engine during start up. 
	 * 
	 */
	private void addDefaultWarmUpPolicies(){
		warmupPolicies.add(WARM_UP_POLICY_DIR + "warmup-policy1.xml");
		warmupPolicies.add(WARM_UP_POLICY_DIR + "warmup-policy2.xml");
		warmupPolicies.add(WARM_UP_POLICY_DIR + "warmup-policy3.xml");
	}
	
	
	/**
	 * Converts an InputStream to byte array. 
	 * 
	 * @param input
	 * @return
	 * @throws IOException
	 */
	private byte[] toByteArray(InputStream input) throws IOException {
		ByteArrayOutputStream output = new ByteArrayOutputStream();
		byte[] buffer = new byte[DEFAULT_BUFFER_SIZE];
		int n = 0;
		while (-1 != (n = input.read(buffer))) {
			output.write(buffer, 0, n);
		}
		return output.toByteArray();
	}

	/**
	 * Loads MVEL & other policy engine modules to avoid initial delays
	 * 
	 * @return
	 */
	private boolean warmUpPolicyEngine() {

		boolean isWarmedUp = false;
		LOGGER.debug("Start of  warmup policy engine.");

		List<PolicyDefinition> policyDefs = null;
		try {
			for(String warmupPolicy:warmupPolicies){
				InputStream is = PolicyWarmer.class.getClassLoader().getResourceAsStream(warmupPolicy);
				if(is!=null){
					policyDefs = new ArrayList<PolicyDefinition>();
					byte[] policyDefBytes = toByteArray(is);
					policyDefs.add(PolicyProvider.instance().getPolicyDefinition(policyDefBytes));	
					is.close();
				}	
			}
			
			
			/*
			*File policyDir = new File(WARMUP_POLICY_FOLDER_URL.getFile());
			*String policyDefStr = null;
			* // populate policy definitions
			if (policyDir.exists()) {
				policyDefs = new ArrayList<PolicyDefinition>();
				for (File policyFile : policyDir.listFiles()) {
					policyDefStr = PolicyProvider.instance()
							.readPolicyFileAsString(
									policyFile.getAbsolutePath());
					policyDefs.add(PolicyManager.loadPolicy(policyDefStr));
				}
			} else {
				LOGGER.debug("couldn't find folder containing warmup policies");
				return false;
			}*/
		} catch (Exception ex) {
			LOGGER.error("exception occurred while laading warmup policies", ex);
			return false;
		}

		// populate policy context
		PolicyContext policyContext = new PolicyContext();
		policyContext.setAssumptionContext("QOS_ALLOWED_CONTENT_TYPES","application/json,application/xml,text/xml");
		policyContext.setAssumptionContext("QOS_MAX_DATA_SIZE", "100");
		policyContext.setRequestContentType("application/json");
		policyContext.setRequestDataSize("1000");
		if (policyDefs == null || policyDefs.isEmpty()) {
			LOGGER.debug("no warm up policies were found");
			return false;
		} else {
			for (PolicyDefinition policyDefinition : policyDefs) {
				PolicyContext resPolicyContext = null;
				try {
					resPolicyContext = (PolicyContext) PolicyManager.executePolicy(policyDefinition, policyContext);
				} catch (Exception ex) {
					try {
						PolicyExceptionUtil.raisePolicyEvaluationException(policyDefinition, ex);
					} catch (Exception ex2) {
						// This exception is not being logged to avoid the flooding logmon.log
						// LOGGER.error("policy evaluation exception", ex2);
					}
					continue;
				}

				Map<PolicyTerms, String> valueContext = new HashMap<PolicyTerms, String>();

				valueContext.put(PolicyTerms.ASSUMPTION_EXPECTED_VALUE,resPolicyContext.getExpectedValues());
				valueContext.put(PolicyTerms.ASSUMPTION_ACTUAL_VALUE,resPolicyContext.getActualValues());

				// local variables to be used
				Action allowAction = null;
				Action denyAction = null;
				Action alertAction = null;
				boolean allow = true;
				boolean deny = false;
				boolean alert = false;
				boolean hardViolation = false;

				// Get Allow action
				if ((allowAction = resPolicyContext.getAction(ActionType.ALLOW,ActionStatus.FAIL)) != null) {
					allow = false;
					hardViolation = true;
				} else {
					allowAction = resPolicyContext.getAction(ActionType.ALLOW,ActionStatus.SUCCESS);
				}

				// Get Deny action
				if ((denyAction = resPolicyContext.getAction(ActionType.DENY,ActionStatus.SUCCESS)) != null) {
					deny = true;
					hardViolation = true;
				} else {
					denyAction = resPolicyContext.getAction(ActionType.DENY,ActionStatus.FAIL);
				}

				// Get ALERT action
				if ((alertAction = resPolicyContext.getAction(ActionType.ALERT,ActionStatus.SUCCESS)) != null) {
					alert = true;
				} else {
					alertAction = resPolicyContext.getAction(ActionType.ALERT,ActionStatus.FAIL);
				}

				if (!allow || deny || alert) {
					Action errorAction = allowAction != null ? allowAction
							: denyAction != null ? denyAction
									: alertAction != null ? alertAction : null;
					try {
						PolicyExceptionUtil.raisePolicyViolationException(
								policyDefinition, errorAction, hardViolation);
					} catch (Exception ex) {
						// This exception is not being logged to avoid the
						// flooding logmon.log
						// LOGGER.error("policy violated",
						// policyDefinition.getPolicyName());
					}
				}
			}

		}

		isWarmedUp = true;
		LOGGER.debug("End of warmup policy engine.");
		return isWarmedUp;
	}

}
