package com.walmart.platform.soa.policy.evaluation.util;

//import java.util.regex.Pattern;

/**
 * @author sdikshi
 *
 */
public class SecuritySLAManager {
	
//	private static Pattern sqlInjectionPattern = Pattern.compile("[\\s]*((delete)|(exec)|(drop\\s*table)|(insert)|(shutdown)|(update)|(or))");
//	private static Pattern ssiPattern = Pattern.compile("<!--\\s*<!--(include|exec|echo|config|printenv)\\s+.*");
//	private static Pattern javascriptInjection = Pattern.compile("<\\s*script\\b[^>]*>[^<]+<\\s*/\\s*script\\s*>");
//	private static Pattern javaInjection = Pattern.compile(".*Exception in thread.*");
	
	public static String cleanXSS(String value) {
		// You'll need to remove the spaces from the html entities below
		value = value.replaceAll("<", "& lt;").replaceAll(">", "& gt;");
		value = value.replaceAll("\\(", "& #40;").replaceAll("\\)", "& #41;");
		value = value.replaceAll("'", "& #39;");
		value = value.replaceAll("eval\\((.*)\\)", "");
		value = value.replaceAll("[\\\"\\\'][\\s]*javascript:(.*)[\\\"\\\']",
				"\"\"");
		value = value.replaceAll("script", "");
		return value;
	}
	
	
	
}
