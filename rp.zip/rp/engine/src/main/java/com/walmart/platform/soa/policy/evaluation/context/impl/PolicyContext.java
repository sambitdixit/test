package com.walmart.platform.soa.policy.evaluation.context.impl;

import com.walmart.platform.soa.policy.enums.PolicyTerms;

/**
 * Class that holds the parameters required to evaluate policy rule assumptions
 * and action specific parameters.
 *
 * @author sdikshi
 * @author msing37
 */
public class PolicyContext extends AbstractPolicyContext {

	//Service related policy context below.

	/**
	 * @return
	 */
	public String getServiceEndpointUrl() {
		return assumptionContext.get(PolicyTerms.REQUEST_SERVICE_ENDPOINT_URL.getTerm());
	}

	/**
	 * @param endpointurl
	 */
	public void setServiceEndpointUrl(String endpointurl) {
		assumptionContext.put(PolicyTerms.REQUEST_SERVICE_ENDPOINT_URL.getTerm(), endpointurl);
	}

	/**
	 * @return
	 */
	public String getServiceContractUrl() {
		return assumptionContext.get(PolicyTerms.REQUEST_SERVICE_CONTRACT_URL.getTerm());
	}

	/**
	 * @param contracturl
	 */
	public void setServiceContractUrl(String contracturl) {
		assumptionContext.put(PolicyTerms.REQUEST_SERVICE_CONTRACT_URL.getTerm(), contracturl);
	}

	/**
	 * @return
	 */
	public String getServiceEsbProxyUrl() {
		return assumptionContext.get(PolicyTerms.REQUEST_SERVICE_ESB_PROXY_URL.getTerm());
	}

	/**
	 * @param esbproxyurl
	 */
	public void setServiceEsbProxyUrl(String esbproxyurl) {
		assumptionContext.put(PolicyTerms.REQUEST_SERVICE_ESB_PROXY_URL.getTerm(), esbproxyurl);
	}

	/**
	 * @return
	 */
	public String getServiceName() {
		return assumptionContext.get(PolicyTerms.REQUEST_SERVICE_NAME.getTerm());
	}

	/**
	 * @param servicename
	 */
	public void setServiceName(String servicename) {
		assumptionContext.put(PolicyTerms.REQUEST_SERVICE_NAME.getTerm(), servicename);
	}

	/**
	 * @return
	 */
	public String getServiceVersion() {
		return assumptionContext.get(PolicyTerms.REQUEST_SERVICE_VERSION.getTerm());
	}

	/**
	 * @param version
	 */
	public void setServiceVersion(String version) {
		assumptionContext.put(PolicyTerms.REQUEST_SERVICE_VERSION.getTerm(), version);
	}

	/**
	 * @return serviceEnv
	 */
	public String getServiceEnv() {
		return assumptionContext.get(PolicyTerms.REQUEST_SERVICE_ENV.getTerm());
	}

	/**
	 * @param serviceEnv
	 */
	public void setServiceEnv(String serviceEnv) {
		assumptionContext.put(PolicyTerms.REQUEST_SERVICE_ENV.getTerm(), serviceEnv);
	}

	/**
	 * @return
	 */
	public String getServiceUsageType() {
		return assumptionContext.get(PolicyTerms.REQUEST_SERVICE_USAGE_TYPE.getTerm());
	}

	/**
	 * @param usagetype
	 */
	public void setServiceUsageType(String usagetype) {
		assumptionContext.put(PolicyTerms.REQUEST_SERVICE_USAGE_TYPE.getTerm(),
				usagetype);
	}

	/**
	 * @return
	 */
	public String getServiceUsageDomain() {
		return assumptionContext
				.get(PolicyTerms.REQUEST_SERVICE_USAGE_DOMAIN.getTerm());
	}

	/**
	 * @param usagedomain
	 */
	public void setServiceUsageDomain(String usagedomain) {
		assumptionContext.put(PolicyTerms.REQUEST_SERVICE_USAGE_DOMAIN.getTerm(), usagedomain);
	}

	/**
	 * @return
	 */
	public String getServiceCategory() {
		return assumptionContext.get(PolicyTerms.REQUEST_SERVICE_CATEGORY.getTerm());
	}

	/**
	 * @param servicetype
	 */
	public void setServiceCategory(String servicetype) {
		assumptionContext.put(PolicyTerms.REQUEST_SERVICE_CATEGORY.getTerm(), servicetype);
	}

	/**
	 * @return
	 */
	public String getServiceOwner() {
		return assumptionContext.get(PolicyTerms.REQUEST_SERVICE_OWNER.getTerm());
	}

	/**
	 * @param svcOwner
	 */
	public void setServiceOwner(String svcOwner) {
		assumptionContext.put(PolicyTerms.REQUEST_SERVICE_OWNER.getTerm(), svcOwner);
	}

	//Consumer related policy context data below.

	/**
	 * @return consumerId
	 */
	public String getConsumerId() {
		return assumptionContext.get(PolicyTerms.REQUEST_CONSUMER_ID.getTerm());
	}

	/**
	 * @param consumerId
	 */
	public void setConsumerId(String consumerId) {
		assumptionContext.put(PolicyTerms.REQUEST_CONSUMER_ID.getTerm(), consumerId);
	}

	/**
	 * @return consumerType
	 */
	public String getConsumerType() {
		return assumptionContext.get(PolicyTerms.REQUEST_CONSUMER_TYPE.getTerm());
	}

	/**
	 * @param consumerType
	 */
	public void setConsumerType(String consumerType) {
		assumptionContext.put(PolicyTerms.REQUEST_CONSUMER_TYPE.getTerm(), consumerType);
	}
	
	/**
	 * @return consumerSourceId
	 */
	public String getConsumerSourceId() {
		return assumptionContext.get(PolicyTerms.REQUEST_CONSUMER_SOURCE_ID.getTerm());
	}

	/**
	 * @param consumerSourceId
	 */
	public void setConsumerSourceId(String consumerSourceId) {
	  if(consumerSourceId!=null && !consumerSourceId.isEmpty()) {
		assumptionContext.put(PolicyTerms.REQUEST_CONSUMER_SOURCE_ID.getTerm(), consumerSourceId);
	  }
	}
	
	//Request related policy context

	/**
	 *
	 * @return
	 */
	public String getRequestDataSize() {
		return assumptionContext.get(PolicyTerms.REQUEST_DATA_SIZE.getTerm());
	}

	/**
	 *
	 * @param reqDataSize
	 */
	public void setRequestDataSize(String reqDataSize) {
		assumptionContext.put(PolicyTerms.REQUEST_DATA_SIZE.getTerm(), reqDataSize);
	}

	/**
	 *
	 * @return
	 */
	public String getRequestUrlLength() {
		return assumptionContext.get(PolicyTerms.REQUEST_URL_LENGTH.getTerm());
	}

	/**
	 *
	 * @param reqUrlLength
	 */
	public void setRequestUrlLength(String reqUrlLength) {
		assumptionContext.put(PolicyTerms.REQUEST_URL_LENGTH.getTerm(), reqUrlLength);
	}

	/**
	 * Gets the service response time
	 * 
	 * @return
	 */
	public String getRequestResponseTime() {
		return assumptionContext.get(PolicyTerms.REQUEST_RESPONSE_TIME.getTerm());
	}

	/**
	 * Sets the service response time
	 * 
	 * @param reqResTime
	 */
	public void setRequestResponseTime(String reqResTime) {
		assumptionContext.put(PolicyTerms.REQUEST_RESPONSE_TIME.getTerm(), reqResTime);
	}
	
	/**
	 * Gets the total response time
	 * 
	 * @return
	 */
	public String getRequestRoundTripTime() {
		return assumptionContext.get(PolicyTerms.REQUEST_ROUND_TRIP_TIME.getTerm());
	}
	
	/**
	 * Sets the total response time
	 * 
	 * @param totalResTime
	 */
	public void setRequestRoundTripTime(String totalResTime) {
		assumptionContext.put(PolicyTerms.REQUEST_ROUND_TRIP_TIME.getTerm(), totalResTime);
	}

	/**
	 * Gets the network latency
	 * 
	 * @return
	 */
	public String getRequestNetworkLatency() {
		return assumptionContext.get(PolicyTerms.REQUEST_NETWORK_LATENCY.getTerm());
	}
	
	/**
	 *
	 * Sets the network latency
	 * 
	 * @param reqNetworkLatency
	 */
	public void setRequestNetworkLatency(String reqNetworkLatency) {
		assumptionContext.put(PolicyTerms.REQUEST_NETWORK_LATENCY.getTerm(), reqNetworkLatency);
	}

	
	/**
	 * @param ipAddrs
	 */
	public void setRequestIPAddress(String ipAddrs) {
		assumptionContext.put(PolicyTerms.REQUEST_IP_ADDRESS.getTerm(), ipAddrs);
	}
	
	/**
	 * @return
	 */
	public String getRequestIPAddress() {
		return assumptionContext.get(PolicyTerms.REQUEST_IP_ADDRESS.getTerm());
	}
	
	/**
	 * @param guid
	 */
	public void setRequestGUID(String guid) {
		assumptionContext.put(PolicyTerms.REQUEST_GUID.getTerm(), guid);
	}
	
	/**
	 * @return
	 */
	public String getRequestGUID() {
		return assumptionContext.get(PolicyTerms.REQUEST_GUID.getTerm());
	}
	
	/**
	 *
	 * @return
	 */
	public String getRequestHttpVerb() {
		return assumptionContext.get(PolicyTerms.REQUEST_HTTP_VERB.getTerm());
	}

	/**
	 *
	 * @param reqHttpVerbs
	 */
	public void setRequestHttpVerb(String reqHttpVerbs) {
		assumptionContext.put(PolicyTerms.REQUEST_HTTP_VERB.getTerm(), reqHttpVerbs);
	}

	/**
	 *
	 * @return
	 */
	public String getRequestHttpUri() {
		return assumptionContext.get(PolicyTerms.REQUEST_HTTP_URI.getTerm());
	}

	/**
	 *
	 * @param reqHttpUri
	 */
	public void setRequestHttpUri(String reqHttpUri) {
		assumptionContext.put(PolicyTerms.REQUEST_HTTP_URI.getTerm(), reqHttpUri);
	}

	/**
	 *
	 * @return
	 */
	public String getRequestContentType() {
		return assumptionContext.get(PolicyTerms.REQUEST_CONTENT_TYPE.getTerm());
	}

	/**
	 *
	 * @param reqContentType
	 */
	public void setRequestContentType(String reqContentType) {
		assumptionContext.put(PolicyTerms.REQUEST_CONTENT_TYPE.getTerm(), reqContentType);
	}

	/**
	 *
	 * @return
	 */
	public String getRequestAcceptType() {
		return assumptionContext.get(PolicyTerms.REQUEST_ACCEPT_TYPE.getTerm());
	}

	/**
	 *
	 * @param reqAcceptType
	 */
	public void setRequestAcceptType(String reqAcceptType) {
		assumptionContext.put(PolicyTerms.REQUEST_ACCEPT_TYPE.getTerm(), reqAcceptType);
	}

	/**
	 *
	 * @return
	 */
	public String getRequestResponseStatusCode() {
		return assumptionContext.get(PolicyTerms.REQUEST_RESPONSE_STATUS_CODE);
	}

	/**
	 *
	 * @param reqResStatusCode
	 */
	public void setRequestResponseStatusCode(String reqResStatusCode) {
		if(reqResStatusCode!=null && !reqResStatusCode.isEmpty()){
		 assumptionContext.put(PolicyTerms.REQUEST_RESPONSE_STATUS_CODE.getTerm(), reqResStatusCode);
		}
	}
	
	/**
	 *
	 * @return
	 */
	public String getRequestErrorCount() {
		return assumptionContext.get(PolicyTerms.REQUEST_ERROR_COUNT.getTerm());
	}

	/**
	 *
	 * @param reqErrorCount
	 */
	public void setRequestErrorCount(String reqErrorCount) {
		assumptionContext.put(PolicyTerms.REQUEST_ERROR_COUNT.getTerm(), reqErrorCount);
	}


	/**
	 *
	 * @return subscribed consumers separated by comma.
	 */
	public String getSubscribedConsumers() {
		return assumptionContext.get(PolicyTerms.SUBSCRIBED_CONSUMERS.getTerm());
	}

	/**
	 *
	 * @param suscribed consumers separated by comma. 
	 */
	public void setSubscribedConsumers(String subscribedConsumers) {
		assumptionContext.put(PolicyTerms.SUBSCRIBED_CONSUMERS.getTerm(), subscribedConsumers);
	}

	/**
	 *
	 * @return valid consumers separated by comma.
	 */
	public String getValidConsumers() {
		return assumptionContext.get(PolicyTerms.VALID_CONSUMERS.getTerm());
	}

	/**
	 *
	 * @param valid consumers separated by comma. 
	 */
	public void setValidConsumers(String validConsumers) {
		assumptionContext.put(PolicyTerms.VALID_CONSUMERS.getTerm(), validConsumers);
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "PolicyContext [assumptionContext=" + assumptionContext
				+ ", actionContext=" + actionContext + ", executionStatus="
				+ executionStatus + "]";
	}

}
