package com.walmart.platform.soa.policy.evaluation.impl;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.walmart.platform.soa.common.HeaderElements;
import com.walmart.platform.soa.common.HeaderElements.FlowType;
import com.walmart.platform.soa.policy.evaluation.context.impl.PolicyContext;
import com.walmart.platform.soa.service.khoj.client.KhojData;
import com.walmart.platform.soa.service.khoj.client.QoSData;

/**
 * Policy Evaluator for server-side policy in/out Interceptors to execute both
 * SLA & SECURITY type of policies <br>
 * <br>
 * 
 * This Evaluator provides its own implementation of abstract methods from
 * {@link AbstractPolicyEvaluator} and also adds few private methods of its own
 * 
 * 
 * 
 * @author msing37
 * @author sdikshi
 * 
 */
public final class ServerPolicyEvaluator extends AbstractPolicyEvaluator {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(ServerPolicyEvaluator.class);

	@Override
	protected <T> PolicyContext populatePolicyContext(KhojData khojData,
			Map<String, T> protocolHeaders, String flowType) {

		PolicyContext policyContext = populateServiceDetail(khojData);

		// Put request-related details
		policyContext.setRequestIPAddress(getFirst(protocolHeaders,HeaderElements.CONSUMER_IP));
		policyContext.setRequestGUID(getFirst(protocolHeaders,HeaderElements.CONSUMER_GUID));
		policyContext.setConsumerId(getFirst(protocolHeaders,HeaderElements.CONSUMER_ID));
		policyContext.setRequestResponseStatusCode(getFirst(protocolHeaders,HeaderElements.HTTP_STATUS_CODE));
		policyContext.setConsumerSourceId(getFirst(protocolHeaders,HeaderElements.CONSUMER_SOURCE_ID));
		
		
		// put QoS data in policy's context
		for (QoSData qos : khojData.getQosList()) {
			policyContext.setAssumptionContext(qos.getName(), qos.getValue());
		}

		// in case of service-response at client-side, set round-trip time and
		// network latency time
		// For REQUEST flow, populate following
		if (FlowType.REQUEST.name().equalsIgnoreCase(flowType)) {

			String temp = null;
			
			// if local protocol is used, then MaxUrlLength Policy won't have
			// any effect
			if (khojData.getUrl() != null
					&& khojData.getUrl().startsWith("local")) {
				policyContext.setRequestUrlLength("0");
			} else {
				
				policyContext.setRequestHttpUri(temp = getFirst(
						protocolHeaders, HeaderElements.HTTP_REQUEST_URI));
				policyContext.setRequestUrlLength(String
						.valueOf(temp == null ? 0 : temp.length()));
			}

			// consumer-related parameters
			policyContext.setConsumerType(getFirst(protocolHeaders,
					HeaderElements.CONSUMER_TYPE));

			// request-content types parameters
			policyContext.setRequestContentType(getFirst(protocolHeaders,
					HeaderElements.CONTENT_TYPE));
			policyContext.setRequestAcceptType(getFirst(protocolHeaders,
					HeaderElements.ACCEPT));
			policyContext.setRequestHttpVerb(getFirst(protocolHeaders,
					HeaderElements.HTTP_REQUEST_METHOD));
			policyContext.setRequestDataSize(
					(temp = getFirst(protocolHeaders,HeaderElements.CONTENT_LENGTH)) != null ? temp : "0" );

		} else {
			policyContext
					.setRequestResponseTime(calculateServiceResponseTime(protocolHeaders));
		}

		return policyContext;
	}

	/**
	 * Calculates and returns the service execution time
	 * 
	 * @param protocolHeaders
	 *            Map containing service in/out time-stamp
	 */
	private <T> String calculateServiceResponseTime(Map<String, T> protocolHeaders) {

		// fetch time-stamps from header
		long serviceInTime = getTimestamp(protocolHeaders, HeaderElements.SERVICE_IN_TIMESTAMP);
		long serviceOutTime = getTimestamp(protocolHeaders, HeaderElements.SERVICE_OUT_TIMESTAMP);
		
		// calculate response time and network latency
		String serviceResponseTime = String.valueOf(serviceOutTime- serviceInTime);

		// log time-stamps
		LOGGER.debug("Service-In-Time : " + serviceInTime);
		LOGGER.debug("Service-Out-Time : " + serviceOutTime);
		LOGGER.debug("Service Response time : " + serviceResponseTime);

		return serviceResponseTime;
	}
}