package com.walmart.platform.soa.policy.evaluation;

import java.util.Map;

import com.walmart.platform.soa.common.HeaderElements.DiscoveryStrategy;
import com.walmart.platform.soa.common.HeaderElements.FlowType;
import com.walmart.platform.soa.service.khoj.client.KhojData;

/**
 * This interface declares API used for policy evaluation in server/client side
 * interceptors
 * 
 * @author sdikshi
 * @author msing37
 * 
 */
public interface IPolicyEvaluator {

	/**
	 * Returns service-specific KhojData by querying KhojDirectory using
	 * KhojClient
	 * 
	 * @param protocolHeaders
	 *            map containing service-parameters such as name, version,
	 *            environment etc.
	 * @param discoveryStrategy
	 *            either SERVICE or CONSUMER
	 * @return
	 */
	<T> KhojData getKhojData(Map<String, T> protocolHeaders,
			DiscoveryStrategy discoveryStrategy);

	/**
	 * Returns KhojData which is populated from values passed as parameters <br>
	 * It also adds default Policies & QoSes. <br>
	 * 
	 * <b>NOTE:</b> This method is used to populate the khoj data for the
	 * services which are not registered in service registered
	 * 
	 * @param serviceName
	 * @param serviceEnv
	 * @param serviceVersion
	 * @return
	 */
	 KhojData getDummyKhojData(String serviceName, String serviceEnv,
			String serviceVersion);

	/**
	 * Executes service-related policies <br>
	 * 
	 * Following steps are performed : <br>
	 * <ol>
	 * <li>Service-related policy Data and QoS Data are extracted from KhojData
	 * for matching flowType, policyContext and policyType
	 * <li>List of PolicyDefintions from policy data is created
	 * <li>Policy Context is populated for ongoing request/response
	 * <li>Policies are executed using {@link PolicyExecutor}
	 * <li>Appropriate actions are taken (raise Policy Exception/Violation)
	 * based on response from above step
	 * </ol>
	 * 
	 * @param khojData
	 *            service-specific KhojData present in KhojCache
	 * @param protocolHeaders
	 *            service & request/response specific attributes
	 * @param discoveryStrategy
	 *            either SERVICE or CONSUMER
	 * @param flowType
	 *            either REQUEST or RESPONSE
	 * @param policyDefContext
	 *            either SERVICE or CONSUMER
	 * @param policyDefType
	 *            either SLA or SECURITY
	 */
	<T> void executePolicy(KhojData khojData, Map<String, T> protocolHeaders,
			DiscoveryStrategy discoveryStrategy, FlowType flowType,
			String policyDefContext, String policyDefType);

}