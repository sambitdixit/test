package com.walmart.platform.soa.policy.alert.cache;

import com.walmart.platform.soa.service.khoj.client.PolicyData;

/**
 * Object whose list will be stored as its value in cache
 * 
 * @author sdikshi
 * @author smenon2
 * @since 4.1.1
 */
public class AlertCacheValue {

	long windowExpireTime;
	PolicyData policyData;
	int violationCount;
	long lastViolation;
	String serviceOwner;
	
	public long getWindowExpireTime() {
		return windowExpireTime;
	}
	
	public void setWindowExpireTime(long windowExpireTime) {
		this.windowExpireTime = windowExpireTime;
	}
	
	public PolicyData getPolicyData() {
		return policyData;
	}
	
	public void setPolicyData(PolicyData policyData) {
		this.policyData = policyData;
	}
	
	public int getViolationCount() {
		return violationCount;
	}
	
	public void setViolationCount(int violationCount) {
		this.violationCount = violationCount;
	}
	
	public long getLastViolation() {
		return lastViolation;
	}
	
	public void setLastViolation(long lastViolation) {
		this.lastViolation = lastViolation;
	}

	public String getServiceOwner() {
		return serviceOwner;
	}

	public void setServiceOwner(String serviceOwner) {
		this.serviceOwner = serviceOwner;
	}

	@Override
	public String toString() {
		return "AlertCacheValue [windowExpireTime=" + windowExpireTime
				+ ", policyData=" + policyData + ", violationCount="
				+ violationCount + ", lastViolation=" + lastViolation
				+ ", serviceOwner=" + serviceOwner + "]";
	}
	
}