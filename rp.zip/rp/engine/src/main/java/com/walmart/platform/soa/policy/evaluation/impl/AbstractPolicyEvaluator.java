package com.walmart.platform.soa.policy.evaluation.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.walmart.platform.logging.client.type.AuditLogger;
import com.walmart.platform.soa.common.HeaderElements;
import com.walmart.platform.soa.common.HeaderElements.DiscoveryStrategy;
import com.walmart.platform.soa.common.HeaderElements.FlowType;
import com.walmart.platform.soa.common.logging.LoggingConstant;
import com.walmart.platform.soa.common.util.AuditUtil;
import com.walmart.platform.soa.common.util.SOAStringUtil;
import com.walmart.platform.soa.policy.alert.cache.AlertCachePopulator;
import com.walmart.platform.soa.policy.definition.model.Action;
import com.walmart.platform.soa.policy.definition.model.ActionType;
import com.walmart.platform.soa.policy.definition.model.ContextType;
import com.walmart.platform.soa.policy.definition.model.PolicyDefinition;
import com.walmart.platform.soa.policy.enums.ActionStatus;
import com.walmart.platform.soa.policy.enums.PolicyTerms;
import com.walmart.platform.soa.policy.evaluation.IPolicyEvaluator;
import com.walmart.platform.soa.policy.evaluation.context.impl.PolicyContext;
import com.walmart.platform.soa.policy.evaluation.util.PolicyManager;
import com.walmart.platform.soa.policy.exception.PolicyExceptionUtil;
import com.walmart.platform.soa.policy.exception.PolicyViolationException;
import com.walmart.platform.soa.service.khoj.client.KhojClient;
import com.walmart.platform.soa.service.khoj.client.KhojData;
import com.walmart.platform.soa.service.khoj.client.KhojDirectory;
import com.walmart.platform.soa.service.khoj.client.PolicyData;
import com.walmart.platform.soa.service.khoj.client.QoSData;

/**
 * This abstract class provides generic implementation of
 * {@link IPolicyEvaluator} interface <br>
 * It also contains few utility methods and abstract methods which are used in
 * its sub-classes <br>
 * 
 * @author msing37
 * @author sdikshi
 * @since 4.0.1
 * 
 */
public abstract class AbstractPolicyEvaluator implements IPolicyEvaluator {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(AbstractPolicyEvaluator.class);

	protected static final List<String> policySkipFilter = KhojDirectory.getInstance().getRegistryServiceName();

	
	@Override
	public <T> KhojData getKhojData(Map<String, T> protocolHeaders,
			DiscoveryStrategy discoveryStrategy) {

		KhojData khojData = null;

		String serviceName = getFirst(protocolHeaders, HeaderElements.SERVICE_NAME);

		if (serviceName != null && !policySkipFilter.contains(serviceName)) {

			// get remaining service attributes which are needed to make query
			// to Khoj cache
			String serviceVersion = getFirst(protocolHeaders,HeaderElements.SERVICE_VERSION);
			String serviceEnv = getFirst(protocolHeaders, HeaderElements.SERVICE_ENV);
			String consumerId = getFirst(protocolHeaders, HeaderElements.CONSUMER_ID);

			// get Service's KhojData using KhojClient,
			// 'SERVICE' discovery strategy will be used irrespective of client
			// or server side interceptors
			KhojClient khojClient = KhojClient.getInstance();
			khojData = khojClient.getKhojData(discoveryStrategy.name(),
					serviceName, serviceVersion, serviceEnv, consumerId);

			// if khoj data is null, then service is not registered
			// populate dummy khoj data with default policies and QoSes
			if(khojData == null) {
				khojData = getDummyKhojData(serviceName, serviceEnv, serviceVersion);
			}
		}

		return khojData;
	}

	@Override
	public KhojData getDummyKhojData(String serviceName, String serviceEnv,
			String serviceVersion) {
		KhojData dummyKhojData = KhojClient.getInstance().getDummyKhojData(serviceName, serviceEnv, serviceVersion);
		return dummyKhojData;
	}
	
	@Override
	public <T> void executePolicy(KhojData khojData,
			Map<String, T> protocolHeaders,
			DiscoveryStrategy discoveryStrategy, FlowType flowType,
			String policyDefContext, String policyDefType) {

		// get service's policies which are to be executed
		List<PolicyData> policies = getExecutablePolicies(protocolHeaders,
				khojData, flowType.name(), policyDefContext, policyDefType);
		
		String serviceName = khojData.getServiceName();
		String serviceVersion = khojData.getServiceVersion();
		String serviceEnv = khojData.getServiceEnv();
		
		// if no policies to be executed then return
		if (policies == null || policies.isEmpty()) {
			LOGGER.debug("no polices to be executed for service '"
					+ serviceName + "' [ " + serviceVersion + ", " + serviceEnv
					+ " ]' in " + flowType.name() + " flow at "
					+ policyDefContext + " side");
			return;
		}

		// if no QoSes to be compared against then return
		List<QoSData> qosParameters = khojData.getQosList();
		if (qosParameters == null || qosParameters.isEmpty()) {
			LOGGER.debug("no QoSes were found for service '" + serviceName
					+ "' [ " + serviceVersion + ", " + serviceEnv + " ]' in "
					+ flowType.name() + " flow at " + policyDefContext
					+ " side");
			return;
		}

		// Populate policy context & Execute policies in sequentially
		PolicyContext reqPolicyContext = populatePolicyContext(khojData,
				protocolHeaders, flowType.name());
		boolean violations = false;
		for (PolicyData policyData : policies) {
			PolicyDefinition policyDef=policyData.getPolicyDefinition();
			LOGGER.debug("executing " + policyDef.getPolicyName());

			PolicyContext resPolicyContext = null;

			try {
				resPolicyContext = (PolicyContext) PolicyManager.executePolicy(
						policyDef, reqPolicyContext);
			} catch (Exception ex) {
				PolicyExceptionUtil.raisePolicyEvaluationException(policyDef,
						ex);
			}

			// if no exception, then check for violations
			handlePolicyExecutionResponse(policyData, resPolicyContext,
					khojData);
		}

		// if no violation, then log the happy message
		if (violations) {
			LOGGER.debug("All polcies for service '" + serviceName + "' [ "
					+ serviceVersion + ", " + serviceEnv + " ]' in "
					+ flowType.name() + " flow at " + policyDefContext
					+ " side executed successfully with no violations");
			violations = false;
		}

	}

	/**
	 * Returns the list of policy data to be executed
	 * 
	 * <br>
	 * <b>NOTE:</b> This applies only in the cases where request is coming
	 * through ESBs
	 * 
	 * @param policies
	 * @return
	 */
	private <T> List<PolicyData> getExecutablePolicies(
			Map<String, T> protocolHeaders, KhojData khojData, String flowType,
			String policyDefContext, String policyDefType) {

		// first get, CONSUMER/SERVICE context policies
		List<PolicyData> policies = khojData.getPolicyData(flowType,
				policyDefContext, policyDefType);
		
		// if 'SERVICE' context, 
		// then also add 'ESB_OR_SERVICE' context policies if conditions met 
		if (!ContextType.CONSUMER.name().equalsIgnoreCase(policyDefContext)) {

			String thruEsbServiceVersion = getFirst(protocolHeaders,
					HeaderElements.THROUGH_ESB_SERVICE_VERSION);

			/*
			 * Add ESB_OR_SERVICE context policies when: 
			 * 1. request came directly to SERVICE, or 
			 * 2. version change happened in MediationInSequence
			 * 
			 * NOTE: if version change didn't happen in MediationInSequence,
			 * then 'ESB_OR_SERVICE' context 'SLA' type of policies will be
			 * executed in SLA in/out Sequence only in ESB
			 */

			if (!khojData.getServiceVersion().equalsIgnoreCase(
					thruEsbServiceVersion)) {
				policies.addAll(khojData.getPolicyData(flowType,
						"ESB_OR_SERVICE", policyDefType));
			}
		}
		return policies;
	}

	// abstract methods which have been implemented by different sub-classes in
	// different ways

	/**
	 * Populates the policy context (based on flowType) with appropriate values
	 * available in <br>
	 * khojData, and protocolHeaders
	 * 
	 * @param khojData
	 *            service's KhojData present in KhojCache
	 * @param protocolHeaders
	 *            service & request/response specific attributes
	 * @param flowType
	 *            either REQUEST or RESPONSE
	 * @return
	 */
	protected abstract <T> PolicyContext populatePolicyContext(
			KhojData khojData, Map<String, T> protocolHeaders, String flowType);

	/**
	 * Checks whether policy specified in policyDef has been violated , <br>
	 * and if yes, then logs the violation and raise
	 * {@link PolicyViolationException}
	 * 
	 * @param <T>
	 * 
	 * @param policyDef
	 *            policy which was executed
	 * @param resPolicyContext
	 *            policy context containing actions context and values context
	 *            as a result of policy execution
	 */
	protected <T> void handlePolicyExecutionResponse(
			PolicyData policyData, PolicyContext resPolicyContext,
			KhojData khojData) {

		PolicyDefinition policyDefinition = policyData.getPolicyDefinition();
		Map<PolicyTerms, String> valueContext = new HashMap<PolicyTerms, String>();
		valueContext.put(PolicyTerms.ASSUMPTION_EXPECTED_VALUE,
				resPolicyContext.getExpectedValues());
		valueContext.put(PolicyTerms.ASSUMPTION_ACTUAL_VALUE,
				resPolicyContext.getActualValues());
		boolean hardViolation = false;

		// Get Allow action
		Action allowAction = null;
		boolean allow = true;
		if ((allowAction = resPolicyContext.getAction(ActionType.ALLOW,
				ActionStatus.FAIL)) != null) {
			allow = false;
			hardViolation = true;
		} else {
			allowAction = resPolicyContext.getAction(ActionType.ALLOW,
					ActionStatus.SUCCESS);
		}

		// Get Deny action
		Action denyAction = null;
		boolean deny = false;

		if ((denyAction = resPolicyContext.getAction(ActionType.DENY,
				ActionStatus.SUCCESS)) != null) {
			deny = true;
			hardViolation = true;
		} else {
			denyAction = resPolicyContext.getAction(ActionType.DENY,
					ActionStatus.FAIL);
		}

		// Get ALERT action
		Action alertAction = null;
		boolean alert = false;
		if ((alertAction = resPolicyContext.getAction(ActionType.ALERT,
				ActionStatus.SUCCESS)) != null) {
			alert = true;
		} else {
			alertAction = resPolicyContext.getAction(ActionType.ALERT,
					ActionStatus.FAIL);
		}

		if (!allow || deny || alert) {

			//violations = true;
			// adding audit logging for violation
			String auditString = AuditUtil.getAuditLogTokens(
					LoggingConstant.SERVICE_NAME,
					resPolicyContext.getServiceName(),
					LoggingConstant.SERVICE_VERSION,
					resPolicyContext.getServiceVersion(),
					LoggingConstant.SERVICE_ENV,
					resPolicyContext.getServiceEnv(),
					LoggingConstant.CONSUMER_ID,
					resPolicyContext.getConsumerId(),
					LoggingConstant.CONSUMER_GUID,
					resPolicyContext.getRequestGUID(),
					LoggingConstant.POLICY_TYPE, policyDefinition.getType(),
					LoggingConstant.POLICY_NAME,
					policyDefinition.getPolicyName(),
					LoggingConstant.Audit.EXPECTED_VALUES,
					resPolicyContext.getExpectedValues(),
					LoggingConstant.Audit.ACTUAL_VALUES,
					resPolicyContext.getActualValues());

			AuditLogger.logAudit(LoggingConstant.Audit.VIOLATION_TAG, null,
					AuditUtil.getAuditLogTokensStream(auditString,
							LoggingConstant.TRANSACTION_TYPE_SERVICE));

			Action errorAction = allowAction != null ? allowAction
					: denyAction != null ? denyAction
							: alertAction != null ? alertAction : null;

			// Gathering data with policy name in case of violation
			 try {
				AlertCachePopulator.INSTANCE.gatherAlertData(khojData,policyData);
			} catch (Exception e) {
				LOGGER.debug("Can't collect values of Violation. ALerts may not be generated",e);
			}
			// if only alert action is present, then no need to raise exception
			
			if (errorAction != alertAction) {
				PolicyExceptionUtil.raisePolicyViolationException(
						policyDefinition, errorAction, hardViolation);
			}
		}
	}

	// Utility methods used within sub-classes

	/**
	 * Gets the first element from protocol header list for a specific key.
	 * 
	 * @param headers
	 * @param key
	 * @return
	 */
	public <T> String getFirst(Map<String, T> headers, String key) {
		String val = null;
		if (headers != null && !headers.isEmpty()) {
			List<String> vals = (List<String>) headers.get(key);
			if (vals != null && vals.size() > 0) {
				val = vals.get(0);
			}
		}
		return val;
	}

	/**
	 * Returns policy context populated with service & service-version-related
	 * parameters
	 * 
	 * @param khojData
	 *            service-specific KhojData
	 * @return
	 */
	protected PolicyContext populateServiceDetail(KhojData khojData) {

		PolicyContext policyContext = new PolicyContext();

		// service & service-version-related parameters
		policyContext.setServiceName(khojData.getServiceName());
		policyContext.setServiceEnv(khojData.getServiceEnv());
		policyContext.setServiceUsageType(khojData.getServiceUsageType());
		policyContext.setServiceUsageDomain(khojData.getServiceUsageDomain());
		policyContext.setServiceCategory(khojData.getServiceCategory());
		policyContext.setServiceOwner(khojData.getServiceOwner());
		policyContext.setServiceVersion(khojData.getServiceVersion());
		policyContext.setServiceEndpointUrl(khojData.getServiceEndpointUrl());
		policyContext.setServiceContractUrl(khojData.getServiceContractUrl());
		policyContext.setServiceEsbProxyUrl(khojData.getServiceEsbProxyUrl());
		policyContext.setSubscribedConsumers(khojData.getSubscribedConsumers());
		
		return policyContext;
	}

	/**
	 * Calculates service execution time statistics and, Sets these values in
	 * policy context
	 * 
	 * @param serviceInTime
	 * @param serviceOutTime
	 * @param clientInTime
	 * @param clientOutTime
	 */
	protected void setClientResponseTimes(long serviceInTime,
			long serviceOutTime, long clientInTime, long clientOutTime,
			PolicyContext policyContext) {
		// calculate response time and network latency
		String roundTripTime = String.valueOf(clientOutTime - clientInTime);
		String serviceResponseTime = String.valueOf(serviceOutTime
				- serviceInTime);
		String networkLatency = String.valueOf((clientOutTime - clientInTime)
				- (serviceOutTime - serviceInTime));

		// log time-stamps
		LOGGER.debug("Client-Out-Time       : " + clientOutTime);
		LOGGER.debug("Service-In-Time       : " + serviceInTime);
		LOGGER.debug("Service-Out-Time      : " + serviceOutTime);
		LOGGER.debug("Client-In-Time        : " + clientInTime);
		LOGGER.debug("Round Trip time   : " + roundTripTime);
		LOGGER.debug("Service Response time : " + serviceResponseTime);
		LOGGER.debug("Network Latency       : " + networkLatency);

		policyContext.setRequestNetworkLatency(networkLatency);
		policyContext.setRequestRoundTripTime(roundTripTime);
		policyContext.setRequestResponseTime(serviceResponseTime);
	}
	
	
	
	
	/**
	 * Fetches SAORI time-stamp value from transport headers, default value is zero 
	 * 
	 * @param protocolHeaders
	 * @param timestampIdentifier
	 * @return
	 */
	protected <T> long getTimestamp(Map<String, T> protocolHeaders, String timestampIdentifier) {
		String temp = (String) getFirst(protocolHeaders, timestampIdentifier);
		try {
			if(SOAStringUtil.isBlank(temp)) {
				return 0;
			}
			else {
				return Long.parseLong(temp);
			}
		}
		catch(NumberFormatException e) {
			LOGGER.error(timestampIdentifier + " not a number at soa client side, using default value 0", e);
		}
		return 0;
	}
	
}