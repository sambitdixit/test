package com.walmart.platform.soa.policy.alert.notification;

import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.walmart.platform.soa.common.util.IPUtil;
import com.walmart.platform.soa.policy.constants.PolicyAlertConstants;

/**
 * This class is responsible for sending Alert Notifications (e-mail) to the
 * service owner, in case violation exceeds threshold
 * 
 * @author sdikshi
 * @author smenon2
 * @since 4.1.1
 */
public enum PolicyAlertNotificationSender {
	INSTANCE;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(PolicyAlertNotificationSender.class);

	private static final String hostNode = IPUtil.getHostName();
	
	
	/**
	 * Beautifies time from milliseconds to readable date format
	 * @param string
	 * @return
	 */
	private String convertTimetoDate(long string) {
		SimpleDateFormat sdf = new SimpleDateFormat("MMM dd,yyyy HH:mm");
		Date resultdate = new Date(string);
		return sdf.format(resultdate);
	}

	/**
	 * Creates body of the message to be send, adding required data
	 * @param alertNotification
	 * @return
	 */
	private String generateMessage(PolicyAlertNotification alertNotification) {
		StringBuilder sb = new StringBuilder();
		sb.append("Alert raised as VIOLATION COUNT EXCEEDED MAX at node "
				+ hostNode + " :\n\n");
		sb.append("Service        		: " + alertNotification.getSerName() + "\n");
		sb.append("Version        		: " + alertNotification.getSerVer() + "\n");
		sb.append("Environment    		: " + alertNotification.getSerEnv() + "\n");
		sb.append("Policy Name    		: " + alertNotification.getPolicyName()
				+ "\n");
		sb.append("Time                	: "
				+ convertTimetoDate(alertNotification.getTime()) + "\n");
		sb.append("Max  Threshold		: " + alertNotification.getMaxLimit()
				+ "\n");
		sb.append("Occured Violations	: " + alertNotification.getReachedValue()
				+ "\n");
		return sb.toString();
	}

	/**
	 * Sends the email notification
	 * @param alertNotification
	 */
	public void sendMailNotification(
			final PolicyAlertNotification alertNotification) {

		String to = alertNotification.getSerOwner();

		Properties properties = System.getProperties();
		properties.setProperty(PolicyAlertConstants.MAIL_SMTP,
				PolicyAlertConstants.MAIL_HOST);

		Session session = Session.getDefaultInstance(properties);

		try {
			MimeMessage message = new MimeMessage(session);
			message.addRecipient(Message.RecipientType.TO, new InternetAddress(
					to));

			message.setSubject("Policy Violation Limit excedded");
			message.setText(generateMessage(alertNotification));
			
			message.setFrom(new InternetAddress("soari@email.wal-mart.com","SOARI-POLICY-ENGINE"));
			Transport.send(message);
		} catch (MessagingException errorMessage) {
			LOGGER.error("Unable to send Mail to owner = " + to, errorMessage);
		} catch (UnsupportedEncodingException errorMessage) {
			LOGGER.error("Unable to send Mail to owner, Problem while setting from address", errorMessage);
		}
	}

	/**
	 * Extracts data from the key & asks for alert to be generated
	 * @param message
	 * @param maxAllowed
	 * @param actual
	 * @param serOwner
	 * @param time
	 */
	public void raiseAlert(String message, int maxAllowed, int actual,
			String serOwner,String policyName, long time) {

		String keySeperator = PolicyAlertConstants.CACHE_KEY_SEPARATOR;
		String[] serviceInfo = message.split(keySeperator);
		if (serviceInfo.length == 3) {

			
			LOGGER.debug(policyName + " violated for ServiceName:" + serviceInfo[0]+ " Version:" + serviceInfo[1]+" Environment:" + serviceInfo[2]+" Max Limit was:" + maxAllowed+" reached:" + actual);  
			LOGGER.debug("sending mail to: "+serOwner);
			/*  System.out.print(policyName + " violated for ");
			  System.out.print("ServiceName:" + serviceInfo[0]);
			  System.out.print(" Version:" + serviceInfo[1]);
			  System.out.print(" Environment:" + serviceInfo[2]);
			  System.out.print(" Max Limit was:" + maxAllowed);
			  System.out.println(" reached:" + actual);
			  System.out.println("sending mail to: "+serOwner);*/
			 

			PolicyAlertNotification alertNot = getAlert(serviceInfo,
					maxAllowed, actual, serOwner, policyName, time);
			sendMailNotification(alertNot);
		}
	}

	/**
	 * Create alert notification object
	 * @param serviceInfo
	 * @param maxAllowed
	 * @param actual
	 * @param serOwner
	 * @param time
	 * @return
	 */
	private PolicyAlertNotification getAlert(String[] serviceInfo,
			int maxAllowed, int actual, String serOwner,String polName, long time) {
		PolicyAlertNotification alertNot = new PolicyAlertNotification();

		alertNot.setSerName(serviceInfo[0]);
		alertNot.setSerVer(serviceInfo[1]);
		alertNot.setSerEnv(serviceInfo[2]);
		
		alertNot.setPolicyName(polName);
		alertNot.setMaxLimit(maxAllowed);
		alertNot.setReachedValue(actual);

		alertNot.setSerOwner(serOwner);
		alertNot.setTime(time);
		return alertNot;
	}
}
