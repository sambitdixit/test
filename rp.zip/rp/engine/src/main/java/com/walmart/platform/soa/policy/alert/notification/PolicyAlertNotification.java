package com.walmart.platform.soa.policy.alert.notification;


/**
 * @author smenon2
 * @since 4.1.1
 */
public class PolicyAlertNotification {

	String serName;
	String serVer;
	String serEnv;
	String policyName;
	String serOwner;
	int maxLimit;
	int reachedValue;
	long time;
	
	public long getTime() {
		return time;
	}
	public void setTime(long time) {
		this.time = time;
	}
	public String getSerName() {
		return serName;
	}
	public void setSerName(String serName) {
		this.serName = serName;
	}
	public String getSerVer() {
		return serVer;
	}
	public void setSerVer(String serVer) {
		this.serVer = serVer;
	}
	
	public String getSerEnv() {
		return serEnv;
	}
	public void setSerEnv(String serEnv) {
		this.serEnv = serEnv;
	}
	public String getPolicyName() {
		return policyName;
	}
	public void setPolicyName(String policyName) {
		this.policyName = policyName;
	}
	public String getSerOwner() {
		return serOwner;
	}
	public void setSerOwner(String serOwner) {
		this.serOwner = serOwner;
	}
	
	public int getMaxLimit() {
		return maxLimit;
	}
	public void setMaxLimit(int maxLimit) {
		this.maxLimit = maxLimit;
	}
	public int getReachedValue() {
		return reachedValue;
	}
	public void setReachedValue(int reachedValue) {
		this.reachedValue = reachedValue;
	}
	
	@Override
	public String toString() {
		return "AlertNotification [serName=" + serName + ", serVer=" + serVer
				+ ", serEnv=" + serEnv + ", policyName=" + policyName
				+ ", serOwner=" + serOwner + ", maxLimit=" + maxLimit
				+ ", reachedValue=" + reachedValue + ", time=" + time + "]";
	}
	
	
	
}
