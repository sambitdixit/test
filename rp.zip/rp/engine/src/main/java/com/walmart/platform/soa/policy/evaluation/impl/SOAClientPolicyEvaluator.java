package com.walmart.platform.soa.policy.evaluation.impl;

import java.util.Map;

import com.walmart.platform.soa.common.HeaderElements;
import com.walmart.platform.soa.common.HeaderElements.FlowType;
import com.walmart.platform.soa.policy.evaluation.context.impl.PolicyContext;
import com.walmart.platform.soa.service.khoj.client.KhojData;
import com.walmart.platform.soa.service.khoj.client.QoSData;

/**
 * Policy Evaluator for (SOA) client-side policy in/out Interceptors to execute
 * both SLA & SECURITY type of policies <br>
 * <br>
 * 
 * 
 * This Evaluator provides its own implementation of abstract methods from
 * {@link AbstractPolicyEvaluator} and, also adds few private utility methods
 * 
 * 
 * @author msing37
 * @author sdikshi
 * 
 */
public final class SOAClientPolicyEvaluator extends AbstractPolicyEvaluator {

	@Override
	public <T> PolicyContext populatePolicyContext(KhojData khojData,
			Map<String, T> protocolHeaders, String flowType) {

		PolicyContext policyContext = populateServiceDetail(khojData);

		policyContext.setRequestIPAddress(getFirst(protocolHeaders,HeaderElements.CONSUMER_IP));
		policyContext.setRequestGUID(getFirst(protocolHeaders,HeaderElements.CONSUMER_GUID));
		policyContext.setConsumerId(getFirst(protocolHeaders,HeaderElements.CONSUMER_ID));
		policyContext.setConsumerSourceId(getFirst(protocolHeaders,HeaderElements.CONSUMER_SOURCE_ID));
		policyContext.setRequestResponseStatusCode(getFirst(protocolHeaders,HeaderElements.HTTP_STATUS_CODE));

		// put QoS data in policy's context
		for (QoSData qos : khojData.getQosList()) {
			policyContext.setAssumptionContext(qos.getName(), qos.getValue());
		}

		// in case of service-response at client-side, set round-trip time and
		// network latency time
		if (FlowType.RESPONSE.name().equals(flowType)) {
			setSOAClientSideResponseTimes(protocolHeaders, policyContext);
		} else {
			// do request flow processing i.e. PolicyOutInterceptor
		}

		return policyContext;
	}

	/**
	 * Extracts the service response time and network latency and sets these
	 * values into policyContext
	 * 
	 * @param protocolHeaders
	 *            Map containing client & service's side in/out time-stamps
	 * @param policyContext
	 *            policy execution context
	 */
	protected <T> void setSOAClientSideResponseTimes(
			Map<String, T> protocolHeaders, PolicyContext policyContext) {

		// fetch time-stamps from header
		long serviceInTime = getTimestamp(protocolHeaders, HeaderElements.SERVICE_IN_TIMESTAMP);
		long serviceOutTime = getTimestamp(protocolHeaders, HeaderElements.SERVICE_OUT_TIMESTAMP);
		long clientInTime = getTimestamp(protocolHeaders, HeaderElements.CONSUMER_IN_TIMESTAMP);
		long clientOutTime = getTimestamp(protocolHeaders, HeaderElements.CONSUMER_OUT_TIMESTAMP);

		setClientResponseTimes(serviceInTime, serviceOutTime, clientInTime,
				clientOutTime, policyContext);
	}
}


