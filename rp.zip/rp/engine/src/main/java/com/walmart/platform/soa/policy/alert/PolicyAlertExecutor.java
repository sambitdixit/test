package com.walmart.platform.soa.policy.alert;

import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.walmart.platform.kernel.exception.layers.base.PlatformRuntimeException;
import com.walmart.platform.soa.common.util.ExecutorServiceShutdownHook;
import com.walmart.platform.soa.policy.alert.cache.AlertCachePopulator;
import com.walmart.platform.soa.policy.alert.cache.AlertCacheValue;
import com.walmart.platform.soa.policy.alert.notification.PolicyAlertNotificationSender;
import com.walmart.platform.soa.policy.constants.PolicyAlertConstants;
import com.walmart.platform.soa.service.khoj.client.PolicyData;

/**
 * Used to generate Alerts if values exceeds corresponding threshold. This is
 * done using a separate Thread which is woken up at an interval specified in
 * the policy.
 * 
 * @author sdikshi
 * @author smenon2
 * @since 4.1.1
 */
public final class PolicyAlertExecutor {

	private static final Logger LOGGER = LoggerFactory.getLogger(PolicyAlertExecutor.class);

	private static PolicyAlertExecutor self = new PolicyAlertExecutor();

	private ScheduledExecutorService pool = null;
	private final long refreshInterval = PolicyAlertConstants.ALERT_REFRESH_INTERVAL;
	private final long startInterval = PolicyAlertConstants.ALERT_START_INTERVAL;

	private PolicyAlertExecutor() {
		try {
			int corePoolSize = Runtime.getRuntime().availableProcessors() + 1;
			this.pool = new ScheduledThreadPoolExecutor(corePoolSize);
			this.pool.scheduleWithFixedDelay(new PolicyScheduler(),startInterval, refreshInterval, TimeUnit.MILLISECONDS);
			ExecutorServiceShutdownHook.getInstance().addToShutdownHook("soa-policy-alert-pool", this.pool);
		} catch (Exception e) {
			LOGGER.error("Error in PolicyAlertHandler()", e);
		}
	}

	/**
	 * Method to access Singleton instance of class
	 * 
	 * @return
	 */
	public static PolicyAlertExecutor getInstance() {
		return self;
	}

	

	private class PolicyScheduler implements Runnable {
		/**
		 * run the schedule task
		 */
		public void run() {
			/**
			 * Wakes up every second and checks, which {serName,serEnv,serVer}
			 * has to be checked for raising alert.
			 */
			long curMilliTime = System.currentTimeMillis();
			Map<String, Map<String, AlertCacheValue>> cache = AlertCachePopulator.INSTANCE
					.getCahce();
			Iterator<Entry<String, Map<String, AlertCacheValue>>> cacheEntry = cache
					.entrySet().iterator();

			while (cacheEntry.hasNext()) {
				Entry<String, Map<String, AlertCacheValue>> alertCacheEntry = cacheEntry
						.next();

				Map<String, AlertCacheValue> alertCacheListValue = alertCacheEntry
						.getValue();
				String key = alertCacheEntry.getKey();

				Iterator<Entry<String, AlertCacheValue>> alertCacheListValueEntry = alertCacheListValue
						.entrySet().iterator();
				while (alertCacheListValueEntry.hasNext()) {
					AlertCacheValue value = alertCacheListValueEntry.next()
							.getValue();
					if (curMilliTime > value.getWindowExpireTime()) {
						Runnable worker = new PolicyAlertEvaluator(key, value,curMilliTime);
						pool.execute(worker);
					}
				}
			}
		}
	}

	/**
	 * checks if Alert is to be raised for an entry in cache. Different alerts
	 * are to be raised using different threads.
	 * 
	 * @author smenon2
	 * @since 4.0.7
	 * 
	 */
	private class PolicyAlertEvaluator implements Runnable {
		String key;
		AlertCacheValue alertVal;
		long currentTime;
		PolicyAlertNotificationSender alertSender;

		public PolicyAlertEvaluator(String key, AlertCacheValue alertVal,
				long currentTime) {
			this.key = key;
			this.alertVal = alertVal;
			this.currentTime = currentTime;
			this.alertSender = PolicyAlertNotificationSender.INSTANCE;
		}

		@Override
		public void run() {
			try {
				/*
				 * calculate - the total number of request, the total number of
				 * violation, average response time & request per consumerId.
				 */
				PolicyData pd = alertVal.getPolicyData();
				String withinPeriodSrt = pd.getPolicyDefinition()
						.getAlertThreshold().getWithinPeriod();
				int withinPeriod = Integer.parseInt(withinPeriodSrt);

				long nextCheck = currentTime + withinPeriod;
				alertVal.setWindowExpireTime(nextCheck);
				String thresholdStr = alertVal.getPolicyData()
						.getPolicyDefinition().getAlertThreshold().getTotal();
				int threshold = Integer.parseInt(thresholdStr);
				if (alertVal.getViolationCount() > threshold) {
					int limit = alertVal.getViolationCount();
					synchronized (alertVal) {
						alertVal.setViolationCount(0);
					}
					alertSender.raiseAlert(key, threshold, limit, alertVal
							.getServiceOwner(), alertVal.getPolicyData()
							.getName(), currentTime);
				} else {
					synchronized (alertVal) {
						alertVal.setViolationCount(0);
					}
				}

			} catch (Exception e) {
				throw new PlatformRuntimeException(e);
			}
		}

	}
}
