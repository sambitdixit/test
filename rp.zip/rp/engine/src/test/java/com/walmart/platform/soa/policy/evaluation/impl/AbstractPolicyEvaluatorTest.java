package com.walmart.platform.soa.policy.evaluation.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.testng.AssertJUnit;
import org.testng.annotations.Test;

import com.walmart.platform.soa.common.HeaderElements;
import com.walmart.platform.soa.common.HeaderElements.DiscoveryStrategy;
import com.walmart.platform.soa.common.HeaderElements.FlowType;
import com.walmart.platform.soa.policy.definition.model.PolicyDefinition;
import com.walmart.platform.soa.policy.evaluation.context.impl.PolicyContext;
import com.walmart.platform.soa.policy.exception.PolicyViolationException;
import com.walmart.platform.soa.service.khoj.client.KhojData;
import com.walmart.platform.soa.service.khoj.client.KhojDirectory;
import com.walmart.platform.soa.service.khoj.client.PolicyData;
import com.walmart.platform.soa.service.khoj.client.QoSData;



/**
 * Test cases for {@link AbstractPolicyEvaluator} 
 * 
 * @author msing37
 *
 */
public class AbstractPolicyEvaluatorTest {

	AbstractPolicyEvaluator abstractPolicyEvaluator = new ServerPolicyEvaluator();


	@Test
	public void testGetKhojData() {

		// test for genuine service-name
		Map<String, List<String>> headers = PolicyEvaluationTestUtil.getProtocolHeaders();
		AssertJUnit.assertNotNull(abstractPolicyEvaluator.getKhojData(headers, DiscoveryStrategy.SERVICE));

		// test for null service-name
		headers.put(HeaderElements.SERVICE_NAME, null);
		AssertJUnit.assertNull(abstractPolicyEvaluator.getKhojData(headers, DiscoveryStrategy.SERVICE));

		// test for all registry service names
		for(String serviceName : KhojDirectory.getInstance().getRegistryServiceName()) {
			headers.put(HeaderElements.SERVICE_NAME, Arrays.asList(new String[]{serviceName}));
			AssertJUnit.assertNull(abstractPolicyEvaluator.getKhojData(headers, DiscoveryStrategy.SERVICE));
		}

	}

	@Test
	public void testExecutePolicy() throws Exception {
		Map<String, List<String>> headers = PolicyEvaluationTestUtil.getProtocolHeaders();

		// test for null polices 
		KhojData khojData = new KhojData();
		abstractPolicyEvaluator.executePolicy(PolicyEvaluationTestUtil.getKhojData(), headers, DiscoveryStrategy.SERVICE, FlowType.REQUEST, "SERVICE", "SLA");

		// test for empty policies
		khojData.setPolicyList(new ArrayList<PolicyData>());
		abstractPolicyEvaluator.executePolicy(PolicyEvaluationTestUtil.getKhojData(), headers, DiscoveryStrategy.SERVICE, FlowType.REQUEST, "SERVICE", "SLA");

		// test for null QoS
		khojData = PolicyEvaluationTestUtil.getKhojData();
		khojData.setQosList(null);
		abstractPolicyEvaluator.executePolicy(PolicyEvaluationTestUtil.getKhojData(), headers, DiscoveryStrategy.SERVICE, FlowType.REQUEST, "SERVICE", "SLA");

		// test for empty QoS
		khojData.setQosList(new ArrayList<QoSData>());
		abstractPolicyEvaluator.executePolicy(PolicyEvaluationTestUtil.getKhojData(), headers, DiscoveryStrategy.SERVICE, FlowType.REQUEST, "SERVICE", "SLA");

	}

	@Test(expectedExceptions=PolicyViolationException.class)
	public void testHandlePolicyExecutionResponse() throws Exception {
		KhojData khojdata = PolicyEvaluationTestUtil.getKhojData();

	    PolicyDefinition policyDefinition = PolicyEvaluationTestUtil.getPolicyDefinition();
			PolicyData pd = new PolicyData();
			pd.setPolicyDefinition(policyDefinition);

		    policyDefinition.setPolicyId("1");
		    policyDefinition.setPolicyName("Allowed_Content_Type_Policy");
		    PolicyContext resPosPolicyContext = PolicyEvaluationTestUtil.getPositiveResponsePolicyContext();
		    abstractPolicyEvaluator.handlePolicyExecutionResponse(pd, resPosPolicyContext, khojdata);
		    
		    PolicyContext resNegPolicyContext = PolicyEvaluationTestUtil.getNegativeResponsePolicyContext();
		    abstractPolicyEvaluator.handlePolicyExecutionResponse(pd, resNegPolicyContext, khojdata);
		  }

	@Test
	public void testPopulateServiceDetail() throws Exception {
		PolicyContext policyContext = abstractPolicyEvaluator.populateServiceDetail(PolicyEvaluationTestUtil.getKhojData());
		System.out.println(policyContext);
	}


	@Test
	public void testSetHTTPClientSideResponseTimes() {
		PolicyContext policyContext = new PolicyContext();
		abstractPolicyEvaluator.setClientResponseTimes(1003, 1006, 1000, 1010, policyContext);
	}


	@Test
	public void testGetFirst() {
		System.out.println(abstractPolicyEvaluator.getFirst(PolicyEvaluationTestUtil.getProtocolHeaders(), HeaderElements.SERVICE_IN_TIMESTAMP));
	}

}