package com.walmart.platform.soa.policy.evaluation.context.impl;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class PolicyContextTest {
	
	PolicyContext context; 
	
	@BeforeClass
	public void init(){
		context = new PolicyContext();
		System.out.println(context.toString());
	}
	
	//Service related policy context below...
	
	@Test
	public void serviceEndpointUrlTest(){
		context.setServiceEndpointUrl("http://localhost/dummyendpointurl");
		Assert.assertEquals(context.getServiceEndpointUrl(),"http://localhost/dummyendpointurl");
	}
	
	@Test
	public void serviceContractUrlTest(){
		context.setServiceContractUrl("http://localhost/dummycontracturl");
		Assert.assertEquals(context.getServiceContractUrl(),"http://localhost/dummycontracturl");
	}
	
	@Test
	public void serviceEsbProxyUrlTest(){
		context.setServiceEsbProxyUrl("http://localhost/dummyesbproxyurl");
		Assert.assertEquals(context.getServiceEsbProxyUrl(),"http://localhost/dummyesbproxyurl");
	}
	
	@Test
	public void serviceNameTest(){
		context.setServiceName("Dummy-Service");
		Assert.assertEquals(context.getServiceName(),"Dummy-Service");
	}
	
	@Test
	public void serviceVersionTest(){
		context.setServiceVersion("Dummy-Service-Version");
		Assert.assertEquals(context.getServiceVersion(),"Dummy-Service-Version");
	}
	
	@Test
	public void serviceUsageTypeTest(){
		context.setServiceUsageType("Dummy-Usage-Type");
		Assert.assertEquals(context.getServiceUsageType(),"Dummy-Usage-Type");
	}
	
	@Test
	public void serviceUsageDomainTest(){
		context.setServiceUsageDomain("Dummy-Usage-Domain");
		Assert.assertEquals(context.getServiceUsageDomain(),"Dummy-Usage-Domain");
	}
	
	@Test
	public void serviceCategory(){
		context.setServiceCategory("Dummy-Service-Category");
		Assert.assertEquals(context.getServiceCategory(),"Dummy-Service-Category");
	}
	
	@Test
	public void serviceOwnerTest(){
		context.setServiceOwner("Dummy-Service-Owner");
		Assert.assertEquals(context.getServiceOwner(),"Dummy-Service-Owner");
	}
	
	//Consumer related policy context data below...
	
	@Test
	public void consumerIdTest(){
		context.setConsumerId("123");
		Assert.assertEquals(context.getConsumerId(), "123");
	}
	
	@Test
	public void RequestIPAddressTest(){
		context.setRequestIPAddress("127.0.0.1");
		Assert.assertEquals(context.getRequestIPAddress(), "127.0.0.1");
	}
	
	@Test
	public void consumerTypeTest(){
		context.setConsumerType("Dummy-Type");
		Assert.assertEquals(context.getConsumerType(), "Dummy-Type");
	}
	
	//Request related policy context..
	
	@Test
	public void requestDataSizeTest(){
		context.setRequestDataSize("1000");
		Assert.assertEquals(context.getRequestDataSize(), "1000");
	}
	
	@Test
	public void requestUrlLengthTest(){
		context.setRequestUrlLength("32");
		Assert.assertEquals(context.getRequestUrlLength(), "32");
	}
	
	@Test
	public void requestResponseTimeTest(){
		context.setRequestResponseTime("5000");
		Assert.assertEquals(context.getRequestResponseTime(), "5000");
	}
	
	@Test
	public void requestHttpVerbTest(){
		context.setRequestHttpVerb("HttpVerbGET");
		Assert.assertEquals(context.getRequestHttpVerb(), "HttpVerbGET");
	}
	
	@Test
	public void requestHttpUriTest(){
		context.setRequestHttpUri("http://localhost");
		Assert.assertEquals(context.getRequestHttpUri(), "http://localhost");
	}
	
	@Test
	public void requestContentTypeTest(){
		context.setRequestContentType("application/xml");
		Assert.assertEquals(context.getRequestContentType(), "application/xml");
	}
	
	@Test
	public void requestAcceptTypeTest(){
		context.setRequestAcceptType("application/xml");
		Assert.assertEquals(context.getRequestAcceptType(), "application/xml");
	}
	
	@Test
	public void requestErrorCountTest(){
		context.setRequestErrorCount("10");
		Assert.assertEquals(context.getRequestErrorCount(), "10");
	}
}
