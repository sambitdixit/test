package com.walmart.platform.soa.policy.evaluation.examples;

import java.io.IOException;
import java.net.URL;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.walmart.platform.soa.policy.common.impl.PolicyProvider;
import com.walmart.platform.soa.policy.definition.model.Action;
import com.walmart.platform.soa.policy.definition.model.ActionType;
import com.walmart.platform.soa.policy.definition.model.PolicyDefinition;
import com.walmart.platform.soa.policy.enums.ActionStatus;
import com.walmart.platform.soa.policy.evaluation.context.IPolicyContext;
import com.walmart.platform.soa.policy.evaluation.context.impl.PolicyContext;
import com.walmart.platform.soa.policy.evaluation.util.PolicyManager;

public class ScatterGatherPolicyTest {
	PolicyDefinition policy;

	@BeforeClass
	public void setup() {
		URL url = ScatterGatherPolicyTest.class.getClassLoader()
				.getResource("policies/ScatterGatherPolicy.xml");
		String policyDef = null;
		try {
			policyDef = PolicyProvider.instance().readPolicyFileAsString(
					url.getFile());
			policy = PolicyManager.loadPolicy(policyDef);
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	@Test
	public void testScatterGatherPositive() {

		Assert.assertNotNull(policy);
		PolicyContext ctx = new PolicyContext();
		ctx.setRequestHttpUri("/service/book-service-SG/v4568567795.456/bookstoreSG/books");
		ctx.setRequestHttpVerb("POST");
		IPolicyContext rctx = null;
		for (int i = 0; i < 1; i++) {
			long st = System.currentTimeMillis();
			rctx = PolicyManager.executePolicy(policy, ctx);
			long et = System.currentTimeMillis();
			System.out
					.println("Execution Time testApplicationJsonContentType=="
							+ (et - st));
		}
		Action scatterGather = rctx.getAction(ActionType.SCATTER_GATHER, ActionStatus.SUCCESS);
		Assert.assertNotNull(scatterGather);
		
		for(String requestPayloadPath: rctx.getActionValueAsMap(scatterGather).get("json_request_payload_path").split(";")) {
			System.out.println(requestPayloadPath);
		}
		System.out.println(rctx.getActionValueAsMap(scatterGather));
	}

	@Test
	public void testScatterGatherNegative() {
		Assert.assertNotNull(policy);
		PolicyContext ctx = new PolicyContext();
		ctx.setRequestHttpUri("/service/book-service-SG/bookstoreSG/books");
		ctx.setRequestHttpVerb("POST");
		IPolicyContext rctx = PolicyManager.executePolicy(policy, ctx);
		Action allowed = rctx.getAction(ActionType.SCATTER_GATHER, ActionStatus.FAIL);
		Assert.assertNotNull(allowed);
	}

}