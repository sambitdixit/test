package com.walmart.platform.soa.policy.alert;

import java.util.ArrayList;
import java.util.List;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.walmart.platform.soa.policy.alert.cache.AlertCachePopulator;
import com.walmart.platform.soa.policy.definition.model.AlertThreshold;
import com.walmart.platform.soa.policy.definition.model.PolicyDefinition;
import com.walmart.platform.soa.policy.exception.PolicyViolationException;
import com.walmart.platform.soa.service.khoj.client.KhojData;
import com.walmart.platform.soa.service.khoj.client.PolicyData;

public class PolicyAlertTest {

	private PolicyData addAlertPolicy(String total, String withinPeriod,String policyName){
		PolicyData pd = new PolicyData();
		pd.setName(policyName);
		
		PolicyDefinition policyDefinition = new PolicyDefinition();
		AlertThreshold value = new AlertThreshold();
		value.setTotal(total);
		value.setWithinPeriod(withinPeriod);
		policyDefinition.setAlertThreshold(value );
		policyDefinition.setPolicyName(policyName);
		pd.setPolicyDefinition(policyDefinition );
		
		return pd;
	}
	private KhojData getKhojData(String serName, String serEnv, String serVer){
		KhojData serviceInfoData = new KhojData();

		serviceInfoData.setServiceEnv(serEnv);
		serviceInfoData.setServiceName(serName);
		serviceInfoData.setServiceVersion(serVer);
		serviceInfoData.setServiceOwner("smenon@walmartlabs.com");
		
		List<PolicyData> alertPolicyList = new ArrayList<PolicyData>();
		
		PolicyData pdP= addAlertPolicy("5","8000","Alert generate Policy");
		PolicyData pdN= addAlertPolicy("500","5000","Non Alert generate Policy");
		
		alertPolicyList.add(pdN);
		alertPolicyList.add(pdP);
		
		return serviceInfoData;
	}
	
	@BeforeClass
	public void startPolicyAlertExecutor() throws Exception{	
		PolicyAlertExecutor.getInstance();
	}
	
	
	@Test//(enabled=false)
	public void testPolicyAlertGenertation() throws Exception {

		AlertCachePopulator policyCachePopulator = AlertCachePopulator.INSTANCE;
		KhojData serviceInfoData = getKhojData("Alert Test Service","dev","1.0.1");
		
		PolicyData pdP= addAlertPolicy("5","8000","Alert generate Policy");
		PolicyData pdN= addAlertPolicy("500","5000","Non Alert generate Policy");
		
		int NoOfRequest = 10;
		for (int i = 0; i < NoOfRequest; i++) {
			try {
				policyCachePopulator.gatherAlertData(serviceInfoData, pdP);// will generate mail
				policyCachePopulator.gatherAlertData(serviceInfoData, pdN);// will generate mail
				
			} catch (PolicyViolationException p) {
				// Expected : Do nothing	
			}
			Thread.sleep(100);
		}

		//Thread.sleep(5000);// Waiting for mail to be sent
	}
}
