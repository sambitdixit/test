package com.walmart.platform.soa.policy.evaluation.examples;

import java.util.HashMap;
import java.util.Map;

import org.mvel2.MVEL;
import org.mvel2.optimizers.OptimizerFactory;

public class MvelTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Person person = new Person();
		person.setName("1");
		OptimizerFactory.setDefaultOptimizer("reflective");
		Object s = MVEL.compileExpression("name contains '1' && name == '2'");
		Object s1 = MVEL.compileExpression("val = '2'");
		
		
		long st = System.currentTimeMillis();
		for (int i = 0; i < 1; i++) {
			Object result = MVEL.executeExpression(s, person);
			Boolean b = new Boolean("" + result);
			System.out.println("result==" + result + "b==" + b);
			
			Object result1 = MVEL.executeExpression(s1, person,new HashMap<String, String>());
			System.out.println("result1==" + result1 + ", person.getVal==" + person.getVal());
			
			Map<String, String> vars = new HashMap<String, String>();
			vars.put("name", "123");
			Object s2 = MVEL.compileExpression("'123,345' contains name");
			Object result2 = MVEL.executeExpression(s2,vars);
			System.out.println("result2==" + result2);
			
			
		}
		long et = System.currentTimeMillis();
		
		System.out.println("time taken for 100000 == " + (et - st) / 100000000 + "ms");
	}

	public static class Person {
		private String name;
		private String val;

		public void setName(String name) {
			this.name = name;
		}

		public String getName() {
			return this.name;
		}

		public String getVal() {
			return val;
		}

		public void setVal(String val) {
			this.val = val;
		}
	}
}
