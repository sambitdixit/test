package com.walmart.platform.soa.policy.evaluation.util;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.walmart.platform.soa.policy.evaluation.util.SecuritySLAManager;

public class SecuritySLAManagerTest {

	@Test
	  public void testForXmlTag() {
		  String s = "<xml>test</xml>";
		  String r = SecuritySLAManager.cleanXSS(s);
		  Assert.assertNotNull(r);
		  System.out.println("Result::" + r);
	  }
	  
	  @Test
	  public void testForBrackets() {
		  String s = "(test)";
		  String r = SecuritySLAManager.cleanXSS(s);
		  Assert.assertNotNull(r);
		  System.out.println("Result::" + r);
	  }
	  
	  @Test
	  public void testForEvals() {
		  String s = "eval(javascript.document)";
		  String r = SecuritySLAManager.cleanXSS(s);
		  Assert.assertNotNull(r);
		  System.out.println("Result::" + r);
	  }
}
