package com.walmart.platform.soa.policy.evaluation.impl;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;

import com.walmart.platform.soa.common.HeaderElements;
import com.walmart.platform.soa.policy.common.IPolicyProvider;
import com.walmart.platform.soa.policy.common.impl.PolicyProvider;
import com.walmart.platform.soa.policy.definition.model.Action;
import com.walmart.platform.soa.policy.definition.model.ActionType;
import com.walmart.platform.soa.policy.definition.model.PolicyDefinition;
import com.walmart.platform.soa.policy.enums.ActionStatus;
import com.walmart.platform.soa.policy.evaluation.context.impl.PolicyContext;
import com.walmart.platform.soa.service.khoj.client.KhojData;
import com.walmart.platform.soa.service.khoj.client.PolicyData;
import com.walmart.platform.soa.service.khoj.client.QoSData;


/**
 * @author sgarim1
 * @author msing37
 * 
 *
 */
public class PolicyEvaluationTestUtil {

	public static KhojData getKhojData() throws Exception {

		KhojData khojData = new KhojData();

		khojData.setServiceApplicationId("soari-registry-app");
		khojData.setServiceEnv("dev");
		khojData.setServiceName("book-service");
		khojData.setServiceUsageType("INTERNAL");
		khojData.setServiceUsageDomain("B2B");
		khojData.setServiceCategory("BIZ");
		khojData.setServiceOwner("msingh4@walmartlabs.com");
		khojData.setServiceVersion("1.0.0");
		khojData.setServiceEndpointUrl("localhots:63000");
		khojData.setServiceContractUrl("local://bookstore");
		khojData.setServiceEsbProxyUrl("locahost:8280");

		khojData.setQosList(getQosList());

		khojData.setPolicyList(getPolicies());
	
		return khojData;
	}

	public static Map<String, String> getResponseHeaders() {

		Map<String, String> responseHeaders = new HashMap<String, String>();

		responseHeaders.put(HeaderElements.CONSUMER_IN_TIMESTAMP, "1001");
		responseHeaders.put(HeaderElements.SERVICE_IN_TIMESTAMP,  "1003");
		responseHeaders.put(HeaderElements.SERVICE_OUT_TIMESTAMP, "1005");
		responseHeaders.put(HeaderElements.CONSUMER_OUT_TIMESTAMP, "1010");

		responseHeaders.put(HeaderElements.SERVICE_NAME, "Book-Service");
		responseHeaders.put(HeaderElements.SERVICE_VERSION, "1.0.0");
		responseHeaders.put(HeaderElements.SERVICE_ENV, "dev");

		responseHeaders.put(HeaderElements.CONSUMER_ID, "100");
		responseHeaders.put(HeaderElements.CONSUMER_IP, "127.0.0.1");
		responseHeaders.put(HeaderElements.CONSUMER_GUID, "1010-random-string");
		responseHeaders.put(HeaderElements.CONSUMER_TYPE, "random-consumer");

		return responseHeaders;
	}

	public static Map<String, List<String>> getProtocolHeaders() {

		Map<String, List<String>> protocolHeaders = new HashMap<String, List<String>>();

		protocolHeaders.put(HeaderElements.CONSUMER_IN_TIMESTAMP, Arrays.asList(new String [] {"1001"}));
		protocolHeaders.put(HeaderElements.SERVICE_IN_TIMESTAMP,  Arrays.asList(new String [] {"1003"}));
		protocolHeaders.put(HeaderElements.SERVICE_OUT_TIMESTAMP, Arrays.asList(new String [] {"1005"}));
		protocolHeaders.put(HeaderElements.CONSUMER_OUT_TIMESTAMP, Arrays.asList(new String [] {"1010"}));

		protocolHeaders.put(HeaderElements.SERVICE_NAME, Arrays.asList(new String [] {"Book-Service"}));
		protocolHeaders.put(HeaderElements.SERVICE_VERSION, Arrays.asList(new String [] {"1.0.0"}));
		protocolHeaders.put(HeaderElements.SERVICE_ENV, Arrays.asList(new String [] {"dev"}));

		protocolHeaders.put(HeaderElements.CONSUMER_ID, Arrays.asList(new String [] {"100"}));
		protocolHeaders.put(HeaderElements.CONSUMER_IP, Arrays.asList(new String [] {"127.0.0.1"}));
		protocolHeaders.put(HeaderElements.CONSUMER_GUID, Arrays.asList(new String [] {"1010-random-string"}));
		protocolHeaders.put(HeaderElements.CONSUMER_TYPE, Arrays.asList(new String [] {"random-consumer"}));

		protocolHeaders.put(HeaderElements.CONTENT_TYPE, Arrays.asList(new String [] {"application/json"}));
		protocolHeaders.put(HeaderElements.CONTENT_LENGTH, Arrays.asList(new String [] {"150"}));

		protocolHeaders.put(HeaderElements.ACCEPT, Arrays.asList(new String [] {"application/json"}));
		protocolHeaders.put(HeaderElements.HTTP_REQUEST_METHOD, Arrays.asList(new String [] {"GET"}));
		protocolHeaders.put(HeaderElements.HTTP_REQUEST_URI, Arrays.asList(new String [] {"localhost:8080"}));

		return protocolHeaders;
	}

	public static List<QoSData> getQosList() throws JsonParseException, JsonMappingException, IOException {
		List<QoSData> qosData = new ArrayList<QoSData>();

		qosData.add(getQoS("QOS_ALLOWED_CONTENT_TYPES", "SLA", "application/json,application/xml"));
		qosData.add(getQoS("QOS_ALLOWED_HTTP_VERBS", "SLA", "GET,POST"));
		qosData.add(getQoS("QOS_MAX_DATA_SIZE", "SLA", "2048"));
		qosData.add(getQoS("QOS_MAX_RESPONSE_TIME", "SLA", "5000"));
		qosData.add(getQoS("QOS_MAX_URL_LENGTH", "SLA", "200"));
		qosData.add(getQoS("QOS_MAX_NETWORK_LATENCY", "SLA", "2000"));
		qosData.add(getQoS("QOS_MAX_ROUND_TRIP_TIME", "SLA", "5000"));

		return qosData;
	}

	private static QoSData getQoS(String name, String type, String value) {
		QoSData qos = new QoSData();
		qos.setName(name);
		qos.setType(type);
		qos.setValue(value);
		return qos;
	}

	public static List<PolicyData> getPolicies() throws IOException {
		List<PolicyData> policies = new ArrayList<PolicyData>();
		URL url = PolicyEvaluationTestUtil.class.getClassLoader()
				.getResource("policies_eval");
		File policyDir = new File(url.getFile());

		PolicyProvider instance = PolicyProvider.instance();
		for(File policyFie : policyDir.listFiles()) {
			String policyString = instance.readPolicyFileAsString(policyFie.getAbsolutePath());
			PolicyDefinition pd = instance.getPolicyDefinition(policyString);
			PolicyData pData = getPolicy(pd.getContext().name(), pd.getFlow().name(), pd.getPolicyName(), policyString, "SLA");
			policies.add(pData);
		}

		return policies;
	}
	
	public static List<PolicyData> getAlertPoliciesPolicies() throws IOException {
		List<PolicyData> alertPolicies = new ArrayList<PolicyData>();
		URL url = PolicyEvaluationTestUtil.class.getClassLoader()
				.getResource("policies_eval");
		File policyDir = new File(url.getFile());

		PolicyProvider instance = PolicyProvider.instance();
		for(File policyFie : policyDir.listFiles()) {
			String policyString = instance.readPolicyFileAsString(policyFie.getAbsolutePath());
			PolicyDefinition pd = instance.getPolicyDefinition(policyString);
			PolicyData pData = getPolicy(pd.getContext().name(), pd.getFlow().name(), pd.getPolicyName(), policyString, "SLA");
			PolicyDefinition pDefination = pData.getPolicyDefinition();
			if(pDefination.getAlertThreshold() != null){
				alertPolicies.add(pData);
			}
		}

		return alertPolicies;
	}

	private static PolicyData getPolicy(String context, String flow, String name, String policyString, String type) {
		PolicyData pd = new PolicyData();
		pd.setContext(context);
		pd.setFlow(flow);
		pd.setName(name);
		IPolicyProvider policyProvider = PolicyProvider.instance();
		pd.setPolicyDefinition(policyProvider.getPolicyDefinition(policyString));
		pd.setType(type);

		return pd;
	}

	public static PolicyDefinition getPolicyDefinition() throws Exception {
		return getPolicies().get(0).getPolicyDefinition();
	}

	public static PolicyContext getNegativeResponsePolicyContext() {
		
		PolicyContext resPolicyContext = new PolicyContext();
		
		resPolicyContext.setActualValues("REQUEST_CONTENT_TYPE:POST");
		resPolicyContext.setExpectedValues("QOS_ALLOWED_CONTENT_TYPES:PUT");
		resPolicyContext.setActionContext(ActionType.ALLOW.name() +"."+ ActionStatus.FAIL.name(), getAction(ActionType.ALLOW));
		resPolicyContext.setActionContext(ActionType.ALERT.name() +"."+ ActionStatus.FAIL.name(), getAction(ActionType.ALERT));
		resPolicyContext.setActionContext(ActionType.DENY.name() + "."+ActionStatus.FAIL.name(), getAction(ActionType.DENY));
		resPolicyContext.setServiceOwner("smenon@walmartlabs.com");
		
		return resPolicyContext;
	}
	
	public static PolicyContext getPositiveResponsePolicyContext() {
		
		PolicyContext resPolicyContext = new PolicyContext();
		
		resPolicyContext.setActualValues("REQUEST_CONTENT_TYPE:POST");
		resPolicyContext.setExpectedValues("QOS_ALLOWED_CONTENT_TYPES:POST");
		resPolicyContext.setActionContext(ActionType.ALLOW.name() + ActionStatus.SUCCESS.name(), getAction(ActionType.ALLOW));
		resPolicyContext.setActionContext(ActionType.ALERT.name() + ActionStatus.SUCCESS.name(), getAction(ActionType.ALERT));
		resPolicyContext.setActionContext(ActionType.DENY.name() + ActionStatus.SUCCESS.name(), getAction(ActionType.DENY));
		
		return resPolicyContext;
	}
	
	private static Action getAction(ActionType actionType) {
		Action action = new Action();
		action.setType(actionType);
		return action;
	}
}
