package com.walmart.platform.soa.policy.evaluation.examples;

import java.io.IOException;
import java.net.URL;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.walmart.platform.soa.policy.common.impl.PolicyProvider;
import com.walmart.platform.soa.policy.definition.model.Action;
import com.walmart.platform.soa.policy.definition.model.ActionType;
import com.walmart.platform.soa.policy.definition.model.PolicyDefinition;
import com.walmart.platform.soa.policy.enums.ActionStatus;
import com.walmart.platform.soa.policy.evaluation.context.IPolicyContext;
import com.walmart.platform.soa.policy.evaluation.context.impl.PolicyContext;
import com.walmart.platform.soa.policy.evaluation.util.PolicyManager;

public class MaxUrlLengthPolicyTest {
	PolicyDefinition policy;

	@BeforeClass
	public void setup() {
		URL url = MaxUrlLengthPolicyTest.class.getClassLoader().getResource("policies/MaxUrlLengthPolicy.xml");
		String policyDef = null;
		try {
			policyDef = PolicyProvider.instance().readPolicyFileAsString(url.getFile());
			policy = PolicyManager.loadPolicy(policyDef);
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	@Test
	public void testLessThanMaxUrlLength() {
		Assert.assertNotNull(policy);
		PolicyContext ctx = new PolicyContext();
		ctx.setAssumptionContext("QOS_MAX_URL_LENGTH","100");
		ctx.setRequestUrlLength("10");
		IPolicyContext rctx = PolicyManager.executePolicy(policy, ctx);
		Action allowed = rctx.getAction(ActionType.ALLOW, ActionStatus.SUCCESS);
		Assert.assertNotNull(allowed);
		Assert.assertTrue(Boolean.valueOf(allowed.getValue()));
	}

	@Test
	public void testMoreThanMaxUrlLength() {
		Assert.assertNotNull(policy);
		PolicyContext ctx = new PolicyContext();
		ctx.setAssumptionContext("QOS_MAX_URL_LENGTH","100");
		ctx.setRequestUrlLength("1000");
		IPolicyContext rctx = PolicyManager.executePolicy(policy, ctx);
		Action allowed = rctx.getAction(ActionType.ALLOW, ActionStatus.FAIL);
		Assert.assertNotNull(allowed);
		Assert.assertTrue(Boolean.valueOf(allowed.getValue()));
	}
	
}