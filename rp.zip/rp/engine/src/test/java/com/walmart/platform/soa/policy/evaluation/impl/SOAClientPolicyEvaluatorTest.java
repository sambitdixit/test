package com.walmart.platform.soa.policy.evaluation.impl;

import org.junit.Assert;
import org.testng.annotations.Test;

import com.walmart.platform.soa.common.HeaderElements.FlowType;


/**
 * Test cases for SOA client-side policy evaluator 
 * 
 * @author msing37
 *
 */
public class SOAClientPolicyEvaluatorTest {
	
	@Test
	public void testRequestFlowPopulatePolicyContext() throws Exception {

		Assert.assertNotNull(new SOAClientPolicyEvaluator().populatePolicyContext(PolicyEvaluationTestUtil.getKhojData(), PolicyEvaluationTestUtil.getProtocolHeaders(), FlowType.REQUEST.name()));
	}
	
	@Test
	public void testResponseFlowPopulatePolicyContext() throws Exception {

		Assert.assertNotNull(new SOAClientPolicyEvaluator().populatePolicyContext(PolicyEvaluationTestUtil.getKhojData(), PolicyEvaluationTestUtil.getProtocolHeaders(), FlowType.RESPONSE.name()));
	}
}
