package com.walmart.platform.soa.policy.evaluation.examples;

import java.io.IOException;
import java.net.URL;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.walmart.platform.soa.policy.common.impl.PolicyProvider;
import com.walmart.platform.soa.policy.definition.model.Action;
import com.walmart.platform.soa.policy.definition.model.ActionType;
import com.walmart.platform.soa.policy.definition.model.PolicyDefinition;
import com.walmart.platform.soa.policy.enums.ActionStatus;
import com.walmart.platform.soa.policy.evaluation.context.IPolicyContext;
import com.walmart.platform.soa.policy.evaluation.context.impl.PolicyContext;
import com.walmart.platform.soa.policy.evaluation.util.PolicyManager;

public class DenyServicePolicyTest {
	PolicyDefinition policy;

	@BeforeClass
	public void setup() {
		URL url = DenyServicePolicyTest.class.getClassLoader().getResource(
				"policies/DenyServicePolicy.xml");
		String policyDef = null;
		try {
			policyDef = PolicyProvider.instance().readPolicyFileAsString(
					url.getFile());
			policy = PolicyManager.loadPolicy(policyDef);
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	@Test
	public void testDenyServicePositive() {

		Assert.assertNotNull(policy);
		PolicyContext ctx = new PolicyContext();
		IPolicyContext rctx = null;
		long st = System.currentTimeMillis();
		ctx.setConsumerId("111");
		ctx.setAssumptionContext("QOS_INVALID_CONSUMER_ID", "23984U8923ASDF");
		rctx = PolicyManager.executePolicy(policy, ctx);
		long et = System.currentTimeMillis();
		System.out.println("Execution Time testApplicationJsonContentType=="
				+ (et - st));
		Action denied = rctx.getAction(ActionType.DENY, ActionStatus.FAIL);
		Assert.assertNotNull(denied);
		Assert.assertTrue(Boolean.valueOf(denied.getValue()));
	}

	@Test
	public void testDenyServiceNegative() {
		Assert.assertNotNull(policy);
		PolicyContext ctx = new PolicyContext();
		ctx.setConsumerId("113");
		ctx.setAssumptionContext("QOS_INVALID_CONSUMER_ID", "113");
		IPolicyContext rctx = PolicyManager.executePolicy(policy, ctx);
		Action denied = rctx.getAction(ActionType.DENY, ActionStatus.SUCCESS);
		Assert.assertNotNull(denied);
		Assert.assertTrue(Boolean.valueOf(denied.getValue()));
	}

}