package com.walmart.platform.soa.policy.evaluation.util;

import java.io.IOException;
import java.net.URL;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.walmart.platform.soa.policy.common.IPolicyProvider;
import com.walmart.platform.soa.policy.common.impl.PolicyProvider;
import com.walmart.platform.soa.policy.definition.model.PolicyDefinition;
import com.walmart.platform.soa.policy.evaluation.context.IPolicyContext;
import com.walmart.platform.soa.policy.evaluation.context.impl.PolicyContext;
import com.walmart.platform.soa.policy.evaluation.util.PolicyManager;

/**
 * @author msing37
 *
 */
public class PolicyManagerTest {

	
	/**
	 * Tests for happy flow of loading policy from String
	 */
	@Test
	public void loadPolicy(){
		URL url = this.getClass().getClassLoader()
				.getResource("policies/ThrottlePolicy.xml");
		String policyDef = null;
		PolicyDefinition policy = null;
		try {
			policyDef = PolicyProvider.instance().readPolicyFileAsString(url.getFile());
			Assert.assertNotNull(policyDef);
			policy = PolicyManager.loadPolicy(policyDef);
		} catch (IOException e) {
			e.printStackTrace();
			Assert.fail();
		}
		System.out.println("" + policy);
		Assert.assertNotNull(policy);
	}
	
	
	/**
	 * Tests for happy flow of loading policy from byte [] 
	 */
	@Test
	public void loadBytePolicy(){
		URL url = this.getClass().getClassLoader()
				.getResource("policies/ThrottlePolicy.xml");
		byte[] policyDef = null;
		PolicyDefinition policy = null;
		try {
			policyDef = PolicyProvider.instance().readPolicyFileAsByteArray(url.getFile());
			Assert.assertNotNull(policyDef);
			policy = PolicyManager.loadPolicy(policyDef);
		} catch (IOException e) {
			e.printStackTrace();
			Assert.fail();
		}
		System.out.println("" + policy);
		Assert.assertNotNull(policy);
	}
	
	
	/**
	 * Tests for happy flow of policy execution
	 */
	@Test 
	public void excutePolicy(){
		URL url = this.getClass().getClassLoader()
				.getResource("policies/MaxDataSizePolicy.xml");
		String policyDef = null;
		PolicyContext ctx = new PolicyContext();
		ctx.setAssumptionContext("QOS_MAX_DATA_SIZE", "1000");
		ctx.setRequestDataSize("100");
		IPolicyContext context = null;
		try {
			policyDef = PolicyProvider.instance().readPolicyFileAsString(url.getFile());			
			context = PolicyManager.executePolicy(policyDef, ctx);
		} catch (IOException e) {
			e.printStackTrace();
			Assert.fail();
		}
		System.out.println("" + context);
		Assert.assertNotNull(context);
	}
	
	
	/**
	 * Tests for the rules having multiple assumptions
	 */
	@Test 
	public void testExcuteMultipleAssumptions(){
		URL url = this.getClass().getClassLoader()
				.getResource("policies/MultipleAssumptionsPolicy.xml");
		String policyDef = null;
		PolicyContext ctx = new PolicyContext();
		ctx.setAssumptionContext("QOS_MAX_RESPONSE_TIME", "1000");
		ctx.setAssumptionContext("QOS_MAX_DATA_SIZE", "5000");
		ctx.setRequestDataSize("1000");
		ctx.setRequestResponseTime("200");
		IPolicyContext context = null;
		try {
			policyDef = PolicyProvider.instance().readPolicyFileAsString(url.getFile());	
			IPolicyProvider policyProvider = PolicyProvider.instance();
			PolicyDefinition policyDefinition = policyProvider.getPolicyDefinition(policyDef);
			long st = System.currentTimeMillis();//System.nanoTime();
			context = PolicyManager.executePolicy(policyDefinition, ctx);
			long et = System.currentTimeMillis();//System.nanoTime();
			System.out.println(et - st);
		} catch (IOException e) {
			e.printStackTrace();
			Assert.fail();
		}
		
		Assert.assertNotNull(context);
		System.out.println("" + context.getActualValues());
		System.out.println("" + context.getExpectedValues());
	}
	
	
}
