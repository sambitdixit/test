package com.walmart.platform.soa.policy.evaluation.context.impl;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotNull;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.walmart.platform.soa.policy.common.IPolicyProvider;
import com.walmart.platform.soa.policy.common.impl.PolicyProvider;
import com.walmart.platform.soa.policy.definition.model.Action;
import com.walmart.platform.soa.policy.definition.model.ActionType;
import com.walmart.platform.soa.policy.definition.model.PolicyDefinition;

public class AbstractPolicyContextTest {
	
	TestPolicyContext context;
	Action action;
	Map<String, String> assumptionContext;
	
	private static final ClassLoader CLASS_LOADER = AbstractPolicyContextTest.class.getClassLoader();
	private static final IPolicyProvider POLICY_PROVIDER = PolicyProvider.instance();
	
	@BeforeClass
	public void init(){
		context = new TestPolicyContext();
		action = new Action();
		assumptionContext = new HashMap<String, String>();
		assumptionContext.put("1","Blah");
	}
	
	@Test
	public void getActionContextByKeyTest(){
		context.setActionContext("1", action);
		assertNotNull(context.getActionContext("1"));
	}
	
	@Test
	public void getActionContextTest(){
		assertNotNull(context.getActionContext());
	}
	
	@Test
	public void getActionAllowTest(){
		assertNotNull(context.getActionAllow());
	}
	
	@Test 
	void getAssumptionContextTest(){
		context.setAssumptionContext(assumptionContext);
		assertNotNull(context.getAssumptionContext());
	}
	
	@Test 
	void getAssuptionContextByKeyTest(){
		context.setAssumptionContext("1", "dummy");
		assertEquals(context.getAssumptionContext("1"), "dummy");
	}
	
	@Test
	public void getExecutionStatusTest(){
		context.setExecutionStatus(false);
		assertEquals(context.getExecutionStatus(), false);
	}
	
	@Test
	public void getActionAlertTest(){
		assertNotNull(context.getActionAlert());
	}
	
	@Test
	public void getActionDenyTest(){
		assertNotNull(context.getActionDeny());
	}
	
	@Test
	public void getActionRouteVersionTest(){
		assertNotNull(context.getActionRouteVersion());
	}
	
	@Test
	public void getActionRouteUrlTest(){
		assertNotNull(context.getActionRouteUrl());
	}
	
	@Test
	public void getActionThrottleTest(){
		assertNotNull(context.getActionThrottle());
	}

    @Test
    public void testSetAssumptionContext() {
        // not much to verify
        context.setAssumptionContext(null);
        context.setAssumptionContext(new HashMap<String, String>());
    }

    @Test
    public void testGetActionDeny() {
        Action denyAction = new Action();
        denyAction.setType(ActionType.DENY);
        context.setActionContext(ActionType.DENY.name(), denyAction);
        assertNotNull(context.getActionDeny());
    }
    
    @Test
    public void testGetActionValueAsMap() {
    	
		String policyDef = null;
		PolicyDefinition policy = null;
		Map<String, String> valueMap = null;
		
		// scatter-gather properties
		try {
			
			policyDef = POLICY_PROVIDER.readPolicyFileAsString(CLASS_LOADER.getResource("policies/ScatterGatherPolicy.xml").getFile());
			Assert.assertNotNull(policyDef);
			policy = POLICY_PROVIDER.getPolicyDefinition(policyDef);
			Assert.assertNotNull(policy);
			valueMap = context.getActionValueAsMap(policy.getRule().get(0).getThen().getAction().get(0));
			System.out.println(valueMap);
			String spilitPath = valueMap.get("json_request_payload_path");
			System.out.println(spilitPath);
		} 
		catch (IOException e) {
			e.printStackTrace();
		}
		
		try {
			policyDef = POLICY_PROVIDER.readPolicyFileAsString(CLASS_LOADER.getResource("policies/AllowedContentTypePolicy.xml").getFile());
			Assert.assertNotNull(policyDef);
			policy = POLICY_PROVIDER.getPolicyDefinition(policyDef);
			Assert.assertNotNull(policy);
			valueMap = context.getActionValueAsMap(policy.getRule().get(0).getThen().getAction().get(0));
			System.out.println(valueMap);
		} 
		catch (IOException e) {
			e.printStackTrace();
		}
		
    }
}

class TestPolicyContext extends AbstractPolicyContext{
	
}