package com.walmart.platform.soa.policy.evaluation.examples;

import java.io.IOException;
import java.net.URL;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.walmart.platform.soa.policy.common.impl.PolicyProvider;
import com.walmart.platform.soa.policy.definition.model.Action;
import com.walmart.platform.soa.policy.definition.model.ActionType;
import com.walmart.platform.soa.policy.definition.model.PolicyDefinition;
import com.walmart.platform.soa.policy.enums.ActionStatus;
import com.walmart.platform.soa.policy.evaluation.context.IPolicyContext;
import com.walmart.platform.soa.policy.evaluation.context.impl.PolicyContext;
import com.walmart.platform.soa.policy.evaluation.util.PolicyManager;

public class VersionMediationPolicyTest {
	PolicyDefinition policy;

	@BeforeClass
	public void setup() {
		URL url = VersionMediationPolicyTest.class.getClassLoader().getResource(
				"policies/VersionMediationPolicy.xml");
		String policyDef = null;
		try {
			policyDef = PolicyProvider.instance().readPolicyFileAsString(url.getFile());
			policy = PolicyManager.loadPolicy(policyDef);
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	@Test
	public void testValidRoute() {
		Assert.assertNotNull(policy);
		PolicyContext ctx = new PolicyContext();
		ctx.setServiceVersion("1.0.0");
		IPolicyContext rctx = PolicyManager.executePolicy(policy, ctx);
		Action routeVersion = rctx.getAction(ActionType.ROUTE_VERSION, ActionStatus.SUCCESS);
		Assert.assertNotNull(routeVersion);
		Assert.assertEquals(routeVersion.getValue(),"2.0.0");
	}

}