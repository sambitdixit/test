package com.walmart.platform.soa.policy.alert;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledThreadPoolExecutor;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.walmart.platform.soa.policy.alert.cache.AlertCachePopulator;
import com.walmart.platform.soa.policy.definition.model.AlertThreshold;
import com.walmart.platform.soa.policy.definition.model.PolicyDefinition;
import com.walmart.platform.soa.service.khoj.client.KhojData;
import com.walmart.platform.soa.service.khoj.client.PolicyData;

public class PolicyAlertParellThreadsTest {

	ScheduledExecutorService pool;
	
	@BeforeClass
	public void startThreadPool(){
		PolicyAlertExecutor.getInstance();
		pool = new ScheduledThreadPoolExecutor(10);
	}
	
	@Test//(enabled = false)
	public void testAlertGeneration() throws InterruptedException{
		
		pool.execute(new testThreads());
		Thread.sleep(2000);// to remove 1st second lag
		
		for(int i=0;i<1000;i++){
			pool.execute(new testThreads());
		}
		
		Thread.sleep(5000);// Should send mail
		
		System.out.println("\nslept for 5 sec \n");
		
		for(int i=0;i<25;i++){
			pool.execute(new testThreads());
		}
		Thread.sleep(5000);// Should'nt send mail
	}
	
	
	/** Class which sends multiple request's to Alert module**/
	private class testThreads implements Runnable{
		PolicyData pdP1,pdP2;
		
		private testThreads(){ 
			pdP1= addAlertPolicy("50","5000","Parell Thread Alert Test Policy - 1");
			pdP2= addAlertPolicy("10000","6000","Parell Thread Alert Test Policy - 2");
		}
		
		public PolicyData addAlertPolicy(String total, String withinPeriod,String policyName){
			PolicyData pd = new PolicyData();
			pd.setName(policyName);
			
			PolicyDefinition policyDefinition = new PolicyDefinition();
			AlertThreshold value = new AlertThreshold();
			value.setTotal(total);
			value.setWithinPeriod(withinPeriod);
			policyDefinition.setAlertThreshold(value );
			policyDefinition.setPolicyName(policyName);
			pd.setPolicyDefinition(policyDefinition );
			
			return pd;
		}
		
		public KhojData getKhojData(String serName, String serEnv, String serVer){
			
			KhojData serviceInfoData = new KhojData();
			serviceInfoData.setServiceEnv(serEnv);
			serviceInfoData.setServiceName(serName);
			serviceInfoData.setServiceVersion(serVer);
			serviceInfoData.setServiceOwner("smenon@walmartlabs.com");
			
			List<PolicyData> alertPolicyList = new ArrayList<PolicyData>();
			alertPolicyList.add(pdP1);
			alertPolicyList.add(pdP2);
			
			return serviceInfoData;
		}
		
		@Override
		public void run() {
			AlertCachePopulator policyCachePopulator = AlertCachePopulator.INSTANCE;
			KhojData serviceInfoData = getKhojData("Parell Thread Alert Test Service","qa","2.0.0");
			policyCachePopulator.gatherAlertData(serviceInfoData, pdP1);// will generate mail
			policyCachePopulator.gatherAlertData(serviceInfoData, pdP2);// wont generate mail
		}
		
	}
}
