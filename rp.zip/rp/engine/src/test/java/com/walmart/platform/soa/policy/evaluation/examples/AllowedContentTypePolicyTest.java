package com.walmart.platform.soa.policy.evaluation.examples;

import java.io.IOException;
import java.net.URL;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.walmart.platform.soa.policy.common.impl.PolicyProvider;
import com.walmart.platform.soa.policy.definition.model.Action;
import com.walmart.platform.soa.policy.definition.model.ActionType;
import com.walmart.platform.soa.policy.definition.model.PolicyDefinition;
import com.walmart.platform.soa.policy.enums.ActionStatus;
import com.walmart.platform.soa.policy.evaluation.context.IPolicyContext;
import com.walmart.platform.soa.policy.evaluation.context.impl.PolicyContext;
import com.walmart.platform.soa.policy.evaluation.util.PolicyManager;

public class AllowedContentTypePolicyTest {
	PolicyDefinition policy;

	@BeforeClass
	public void setup() {
		URL url = AllowedContentTypePolicyTest.class.getClassLoader()
				.getResource("policies/AllowedContentTypePolicy.xml");
		String policyDef = null;
		try {
			policyDef = PolicyProvider.instance().readPolicyFileAsString(
					url.getFile());
			policy = PolicyManager.loadPolicy(policyDef);
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	@Test
	public void testApplicationJsonContentType() {

		Assert.assertNotNull(policy);
		PolicyContext ctx = new PolicyContext();
		ctx.setAssumptionContext("QOS_ALLOWED_CONTENT_TYPES",
				"application/json,application/xml,text/xml");
		ctx.setRequestContentType("application/json");
		IPolicyContext rctx = null;
		for (int i = 0; i < 100; i++) {
			long st = System.currentTimeMillis();
			rctx = PolicyManager.executePolicy(policy, ctx);
			long et = System.currentTimeMillis();
			System.out
					.println("Execution Time testApplicationJsonContentType=="
							+ (et - st));
		}
		Action allowed = rctx.getAction(ActionType.ALLOW, ActionStatus.SUCCESS);
		Assert.assertNotNull(allowed);
		Assert.assertTrue(Boolean.valueOf(allowed.getValue()));
	}

	@Test
	public void testApplicationXmlContentType() {
		Assert.assertNotNull(policy);
		PolicyContext ctx = new PolicyContext();
		ctx.setAssumptionContext("QOS_ALLOWED_CONTENT_TYPES",
				"application/json,application/xml,text/xml");
		ctx.setRequestContentType("application/xml");
		IPolicyContext rctx = PolicyManager.executePolicy(policy, ctx);
		Action allowed = rctx.getAction(ActionType.ALLOW, ActionStatus.SUCCESS);
		Assert.assertNotNull(allowed);
		Assert.assertTrue(Boolean.valueOf(allowed.getValue()));
	}

}