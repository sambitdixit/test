package com.walmart.platform.soa.policy.evaluation.examples;

import java.io.IOException;
import java.net.URL;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.walmart.platform.soa.policy.common.impl.PolicyProvider;
import com.walmart.platform.soa.policy.definition.model.Action;
import com.walmart.platform.soa.policy.definition.model.ActionType;
import com.walmart.platform.soa.policy.definition.model.PolicyDefinition;
import com.walmart.platform.soa.policy.enums.ActionStatus;
import com.walmart.platform.soa.policy.evaluation.context.IPolicyContext;
import com.walmart.platform.soa.policy.evaluation.context.impl.PolicyContext;
import com.walmart.platform.soa.policy.evaluation.util.PolicyManager;

public class AllowedHttpVerbsPolicyTest {
	PolicyDefinition policy;

	@BeforeClass
	public void setup() {
		URL url = AllowedHttpVerbsPolicyTest.class.getClassLoader().getResource("policies/AllowedHttpVerbsPolicy.xml");
		String policyDef = null;
		try {
			policyDef = PolicyProvider.instance().readPolicyFileAsString(url.getFile());
			policy = PolicyManager.loadPolicy(policyDef);
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	@Test
	public void testAllowedPOST() {
		Assert.assertNotNull(policy);
		PolicyContext ctx = new PolicyContext();
		ctx.setAssumptionContext("QOS_ALLOWED_HTTP_VERBS","POST,PUT,GET,DELETE");
		//Either one verb at a time.
		ctx.setRequestHttpVerb("POST");
		IPolicyContext rctx = PolicyManager.executePolicy(policy, ctx);
		Action allowed = rctx.getAction(ActionType.ALLOW, ActionStatus.SUCCESS);
		Assert.assertNotNull(allowed);
		Assert.assertTrue(Boolean.valueOf(allowed.getValue()));
		
	}

	@Test
	public void testAllowedGET() {
		Assert.assertNotNull(policy);
		PolicyContext ctx = new PolicyContext();
		ctx.setAssumptionContext("QOS_ALLOWED_HTTP_VERBS","POST,PUT,GET,DELETE");
		//Either one verb at a time. 
		ctx.setRequestHttpVerb("GET");
		IPolicyContext rctx = PolicyManager.executePolicy(policy, ctx);
		Action allowed = rctx.getAction(ActionType.ALLOW, ActionStatus.SUCCESS);
		Assert.assertNotNull(allowed);
		Assert.assertTrue(Boolean.valueOf(allowed.getValue()));
	}
	
	@Test
	public void testNotAllowedGET() {
		Assert.assertNotNull(policy);
		PolicyContext ctx = new PolicyContext();
		ctx.setAssumptionContext("QOS_ALLOWED_HTTP_VERBS","POST,PUT,DELETE");
		//Either one verb at a time. 
		ctx.setRequestHttpVerb("GET");
		IPolicyContext rctx = PolicyManager.executePolicy(policy, ctx);
		Action allowed = rctx.getAction(ActionType.ALLOW, ActionStatus.FAIL);
		Assert.assertTrue(Boolean.valueOf(allowed.getValue()));
		System.out.println("HttpErrorCode== " + allowed.getHttpcode());
		Assert.assertEquals(allowed.getHttpcode(), Integer.valueOf(200));
	}
	
}