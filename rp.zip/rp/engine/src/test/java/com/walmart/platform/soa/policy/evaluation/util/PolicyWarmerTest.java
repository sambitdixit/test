package com.walmart.platform.soa.policy.evaluation.util;

import org.junit.Assert;
import org.testng.annotations.Test;

import com.walmart.platform.soa.policy.evaluation.util.PolicyWarmer;

public class PolicyWarmerTest {

  @Test(enabled=false)
  public void warmup() {
    boolean isWarmedUp = PolicyWarmer.instance().isWarmedUp();
    Assert.assertTrue(isWarmedUp);
    System.out.println("Policy Warmed up = " + isWarmedUp);
  }
  
  
}
