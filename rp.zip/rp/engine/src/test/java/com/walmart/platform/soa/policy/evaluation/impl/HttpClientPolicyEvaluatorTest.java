package com.walmart.platform.soa.policy.evaluation.impl;

import java.util.Map;

import org.testng.Assert;
import org.testng.AssertJUnit;
import org.testng.annotations.Test;

import com.walmart.platform.soa.common.HeaderElements;
import com.walmart.platform.soa.common.HeaderElements.DiscoveryStrategy;
import com.walmart.platform.soa.common.HeaderElements.FlowType;
import com.walmart.platform.soa.service.khoj.client.KhojDirectory;


/**
 * Test cases for HTTP client-side policy evaluator
 * 
 * @author msing37
 *
 */
public class HttpClientPolicyEvaluatorTest {


	HttpClientPolicyEvaluator httpClientPolicyEvaluator = HttpClientPolicyEvaluator.getInstance();
	
	@Test
	public void testForGetKhojData() {
		// test for genuine service-name
		Map<String, String> headers = PolicyEvaluationTestUtil.getResponseHeaders();
		AssertJUnit.assertNotNull(httpClientPolicyEvaluator.getKhojData(headers, DiscoveryStrategy.SERVICE));
		
		// test for null service-name
		headers.put(HeaderElements.SERVICE_NAME, null);
		AssertJUnit.assertNull(httpClientPolicyEvaluator.getKhojData(headers, DiscoveryStrategy.SERVICE));
		
		// test for all registry service names
		for(String serviceName : KhojDirectory.getInstance().getRegistryServiceName()) {
			headers.put(HeaderElements.SERVICE_NAME, serviceName);
			AssertJUnit.assertNull(httpClientPolicyEvaluator.getKhojData(headers, DiscoveryStrategy.SERVICE));
		}
	}

	@Test
	public void testRequestFlowPopulatePolicyContext() throws Exception {

		Assert.assertNotNull(httpClientPolicyEvaluator.populatePolicyContext(PolicyEvaluationTestUtil.getKhojData(), PolicyEvaluationTestUtil.getResponseHeaders(), FlowType.REQUEST.name()));
	}
	
	@Test
	public void testResponseFlowPopulatePolicyContext() throws Exception {

		Assert.assertNotNull(httpClientPolicyEvaluator.populatePolicyContext(PolicyEvaluationTestUtil.getKhojData(), PolicyEvaluationTestUtil.getResponseHeaders(), FlowType.RESPONSE.name()));
	}
}
