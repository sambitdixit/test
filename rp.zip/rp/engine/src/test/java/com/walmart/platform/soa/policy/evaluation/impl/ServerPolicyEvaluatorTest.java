package com.walmart.platform.soa.policy.evaluation.impl;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.walmart.platform.soa.common.HeaderElements.FlowType;


/**
 * Test cases for server-side policy evaluator 
 * 
 * @author msing37
 *
 */
public class ServerPolicyEvaluatorTest {

	@Test
	public void testRequestFlowPopulatePolicyContext() throws Exception {

		Assert.assertNotNull(new ServerPolicyEvaluator().populatePolicyContext(PolicyEvaluationTestUtil.getKhojData(), PolicyEvaluationTestUtil.getProtocolHeaders(), FlowType.REQUEST.name()));
	}
	
	@Test
	public void testResponseFlowPopulatePolicyContext() throws Exception {

		Assert.assertNotNull(new ServerPolicyEvaluator().populatePolicyContext(PolicyEvaluationTestUtil.getKhojData(), PolicyEvaluationTestUtil.getProtocolHeaders(), FlowType.RESPONSE.name()));
	}
}
