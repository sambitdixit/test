package com.walmart.platform.soa.policy.evaluation.examples;

import java.io.IOException;
import java.net.URL;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.walmart.platform.soa.policy.common.impl.PolicyProvider;
import com.walmart.platform.soa.policy.definition.model.Action;
import com.walmart.platform.soa.policy.definition.model.ActionType;
import com.walmart.platform.soa.policy.definition.model.PolicyDefinition;
import com.walmart.platform.soa.policy.enums.ActionStatus;
import com.walmart.platform.soa.policy.evaluation.context.IPolicyContext;
import com.walmart.platform.soa.policy.evaluation.context.impl.PolicyContext;
import com.walmart.platform.soa.policy.evaluation.util.PolicyManager;

public class ResponseStatusPolicyTest {
	PolicyDefinition policy;

	@BeforeClass
	public void setup() {
		URL url = ResponseStatusPolicyTest.class.getClassLoader()
				.getResource("policies/ResponseStatusPolicy.xml");
		String policyDef = null;
		try {
			policyDef = PolicyProvider.instance().readPolicyFileAsString(
					url.getFile());
			policy = PolicyManager.loadPolicy(policyDef);
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	@Test
	public void testRespseCodeVALID() {

		Assert.assertNotNull(policy);
		PolicyContext ctx = new PolicyContext();
		ctx.setAssumptionContext("QOS_INVALID_RESPONSE_STATUS_CODES",
				"404,500");
		ctx.setRequestResponseStatusCode("404");
		IPolicyContext rctx = null;
		for (int i = 0; i < 100; i++) {
			long st = System.currentTimeMillis();
			rctx = PolicyManager.executePolicy(policy, ctx);
			long et = System.currentTimeMillis();
			System.out
					.println("Execution Time testApplicationJsonContentType=="
							+ (et - st));
		}
		Action allowed = rctx.getAction(ActionType.DENY, ActionStatus.SUCCESS);
		Assert.assertNotNull(allowed);
		Assert.assertTrue(Boolean.valueOf(allowed.getValue()));
	}

	
	@Test
	public void testRespoonseCodeINVALID() {
		Assert.assertNotNull(policy);
		PolicyContext ctx = new PolicyContext();
		ctx.setAssumptionContext("QOS_INVALID_RESPONSE_STATUS_CODES",
				"404,500");
		ctx.setRequestResponseStatusCode("200");
		IPolicyContext rctx = PolicyManager.executePolicy(policy, ctx);
		Action allowed = rctx.getAction(ActionType.DENY, ActionStatus.FAIL);
		Assert.assertNotNull(allowed);
		Assert.assertTrue(Boolean.valueOf(allowed.getValue()));
	}

}