package com.walmart.platform.soa.policy.evaluation.examples;

import java.io.IOException;
import java.net.URL;

import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.walmart.platform.soa.policy.common.impl.PolicyProvider;
import com.walmart.platform.soa.policy.definition.model.Action;
import com.walmart.platform.soa.policy.definition.model.ActionType;
import com.walmart.platform.soa.policy.definition.model.PolicyDefinition;
import com.walmart.platform.soa.policy.enums.ActionStatus;
import com.walmart.platform.soa.policy.evaluation.context.IPolicyContext;
import com.walmart.platform.soa.policy.evaluation.context.impl.PolicyContext;
import com.walmart.platform.soa.policy.evaluation.util.PolicyManager;

public class ThrottlePolicyTest {
	PolicyDefinition policy;

	@BeforeMethod
	public void setup() {
		URL url = ThrottlePolicyTest.class.getClassLoader().getResource("policies/ThrottlePolicy.xml");
		String policyDef = null;
		try {
			policyDef = PolicyProvider.instance().readPolicyFileAsString(url.getFile());
			policy = PolicyManager.loadPolicy(policyDef);
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	@Test
	public void testGoldCustomerThrottle() {
		Assert.assertNotNull(policy);
		PolicyContext ctx = new PolicyContext();
		ctx.setConsumerId("1001");
		ctx.setServiceName(null);
		IPolicyContext rctx = PolicyManager.executePolicy(policy, ctx);
		Action throttle = rctx.getAction(ActionType.THROTTLE_DENY, ActionStatus.SUCCESS);
		Assert.assertNotNull(throttle);
	}

	@Test
	public void testSilverCustomerThrottle() {
		Assert.assertNotNull(policy);
		PolicyContext ctx = new PolicyContext();
		ctx.setConsumerId("1003");
		IPolicyContext rctx = PolicyManager.executePolicy(policy, ctx);
		Action throttle = rctx.getAction(ActionType.THROTTLE_DENY, ActionStatus.SUCCESS);
		Assert.assertNotNull(throttle);
	}
	
	@Test
	public void testBronzeCustomerThrottle() {
		Assert.assertNotNull(policy);
		PolicyContext ctx = new PolicyContext();
		ctx.setConsumerId("1005");
		IPolicyContext rctx = PolicyManager.executePolicy(policy, ctx);
		Action throttle = rctx.getAction(ActionType.THROTTLE_ALERT, ActionStatus.SUCCESS);
		Assert.assertNotNull(throttle);
	}
}