package com.walmart.platform.soa.policy.evaluation.examples;

import java.io.IOException;
import java.net.URL;

import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.walmart.platform.soa.policy.common.impl.PolicyProvider;
import com.walmart.platform.soa.policy.definition.model.Action;
import com.walmart.platform.soa.policy.definition.model.ActionType;
import com.walmart.platform.soa.policy.definition.model.PolicyDefinition;
import com.walmart.platform.soa.policy.enums.ActionStatus;
import com.walmart.platform.soa.policy.evaluation.context.IPolicyContext;
import com.walmart.platform.soa.policy.evaluation.context.impl.PolicyContext;
import com.walmart.platform.soa.policy.evaluation.util.PolicyManager;

public class MaxErrorAlertPolicyTest {
	PolicyDefinition policy;

	@BeforeMethod
	public void setup() {
		URL url = MaxErrorAlertPolicyTest.class.getClassLoader().getResource("policies/MaxErrorAlertPolicy.xml");
		String policyDef = null;
		try {
			policyDef = PolicyProvider.instance().readPolicyFileAsString(url.getFile());
			policy = PolicyManager.loadPolicy(policyDef);
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	@Test
	public void testLessThanMaxErrorAlert() {
		Assert.assertNotNull(policy);
		PolicyContext ctx = new PolicyContext();
		ctx.setAssumptionContext("QOS_MAX_ERROR_ALERT","10");
		ctx.setRequestErrorCount("5");
		IPolicyContext rctx = PolicyManager.executePolicy(policy, ctx);
		Action alert = rctx.getAction(ActionType.ALERT, ActionStatus.FAIL);
		Assert.assertNotNull(alert);
		Assert.assertTrue(Boolean.valueOf(alert.getValue()));
	}

	@Test
	public void testMoreThanMaxErrorAlert() {
		Assert.assertNotNull(policy);
		PolicyContext ctx = new PolicyContext();
		ctx.setAssumptionContext("QOS_MAX_ERROR_ALERT","10");
		ctx.setRequestErrorCount("11");
		IPolicyContext rctx = PolicyManager.executePolicy(policy, ctx);
		Action alert = rctx.getAction(ActionType.ALERT, ActionStatus.SUCCESS);
		Assert.assertNotNull(alert);
		Assert.assertTrue(Boolean.valueOf(alert.getValue()));
		
	}
	
}