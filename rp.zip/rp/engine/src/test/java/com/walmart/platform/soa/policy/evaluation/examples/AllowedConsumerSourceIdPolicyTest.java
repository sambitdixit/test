package com.walmart.platform.soa.policy.evaluation.examples;

import java.io.IOException;
import java.net.URL;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.walmart.platform.soa.policy.common.impl.PolicyProvider;
import com.walmart.platform.soa.policy.definition.model.Action;
import com.walmart.platform.soa.policy.definition.model.ActionType;
import com.walmart.platform.soa.policy.definition.model.PolicyDefinition;
import com.walmart.platform.soa.policy.enums.ActionStatus;
import com.walmart.platform.soa.policy.evaluation.context.IPolicyContext;
import com.walmart.platform.soa.policy.evaluation.context.impl.PolicyContext;
import com.walmart.platform.soa.policy.evaluation.util.PolicyManager;

public class AllowedConsumerSourceIdPolicyTest {
	PolicyDefinition policy;

	@BeforeClass
	public void setup() {
		URL url = AllowedConsumerSourceIdPolicyTest.class.getClassLoader()
				.getResource("policies/AllowedConsumerSourceIdPolicy.xml");
		String policyDef = null;
		try {
			policyDef = PolicyProvider.instance().readPolicyFileAsString(
					url.getFile());
			policy = PolicyManager.loadPolicy(policyDef);
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	@Test
	public void testAllowedConsumerSourceId() {

		Assert.assertNotNull(policy);
		PolicyContext ctx = new PolicyContext();
		ctx.setAssumptionContext("QOS_ALLOWED_CONSUMER_SOURCE_ID",
				"wm.com.page.checkout");
		ctx.setConsumerSourceId("wm.com.page.checkout");
		IPolicyContext rctx = null;
		for (int i = 0; i < 100; i++) {
			long st = System.currentTimeMillis();
			rctx = PolicyManager.executePolicy(policy, ctx);
			long et = System.currentTimeMillis();
			System.out
					.println("Execution Time testAllowedConsumerSourceId=="
							+ (et - st));
		}
		Action allowed = rctx.getAction(ActionType.ALLOW, ActionStatus.SUCCESS);
		Assert.assertNotNull(allowed);
		Assert.assertTrue(Boolean.valueOf(allowed.getValue()));
	}

}