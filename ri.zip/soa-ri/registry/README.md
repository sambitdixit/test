#SOARI - Registry & Policy Application

```
HostUrl = "http://localhost:8080/registry-app/services"

Header parameters :

		headers.put(HeaderElements.CONSUMER_ID, <consumer id>);
		headers.put(HeaderElements.SERVICE_VERSION, <service version>);
		headers.put(HeaderElements.SERVICE_ENV, <environment>);
		headers.put(HeaderElements.CONSUMER_AUTH_TOKEN, <oauth token>);
		headers.put(HeaderElements.CONSUMER_IN_TIMESTAMP, <system time>);

```

##Policy API Specification

###1.Get Available Policies
```
Description - This API is used to retrieve details of all available Policies

URL - {HostUrl}/policy
Example - http://localhost:8080/registry-app/services/policy

Request/Header parameters - 

Errors -
Validation errors-
Internal errors- 
1.DAO error has occurred while retrieving entities.
2.A mapping error has occurred.
3.An unexpected error has occurred at business layer
4.An unexpected error has occurred at service layer.

Sample Request - 
 URL- http://localhost:8080/registry-app/services/policy
 
headers
WM_CONSUMER.IP: 10.10.0.20
WM_CONSUMER.INTIMESTAMP: 1357160555
WM_CONSUMER.ID: 10
WM_SVC.VERSION: 1.0
WM_IFX.CLIENT_TYPE: INTERNAL
WM_SVC.ENV: DEV
WM_SEC.AUTH_TOKEN: xyz
WM_QOS.CORRELATION_ID: 97c678d0-551f-11e2-bcfd-0800200c9a66

Sample Response - 
{
	"status":"OK",
	"header":{"headerAttributes":{}},
	"errors":[],
	"payload":
	{
		"policies":
		 [
			{
				"createdBy":"soari_registry_app",
				"createdAt":1357163963678,
				"modifiedBy":null,
				"modifiedAt":null,
				"id":"627ff271-be25-4585-845b-2b1e66eb1d09",
				"status":"ACTIVE",
				"resourceUri":null,
				"name":"TEST_POLICY1357163954912",
				"url":"TEST_POLICY_URL",
				"version":"TEST_POLICY_VERSION1",
				"serviceVersions":[]
			},
			{
				"createdBy":"soari_registry_app",
				"createdAt":1357163969459,
				"modifiedBy":null,
				"modifiedAt":null,
				"id":"2ee288af-e51d-421c-8b1c-3a3c39b66a8f",
				"status":"ACTIVE",
				"resourceUri":null,
				"name":"TEST_POLICY1357163969272",
				"url":"TEST_POLICY_URL",
				"version":"TEST_POLICY_VERSION1",
				"serviceVersions":[]
			}
			}
		]
	}
}
```

###2.Get Policy By ID
```
Description - This API is used to retrieve Policy details for given Policy ID

URL - {HostUrl}/policy/{policyId}
Example - http://localhost:8080/registry-app/services/policy/627ff271-be25-4585-845b-2b1e66eb1d09

Request/Header parameters - 

Errors - 
Validation errors-
1.Invalid policy id.
Internal errors- 
1.DAO error has occurred while retrieving entity by id.
2.A mapping error has occurred.
3.An unexpected error has occurred at business layer
4.An unexpected error has occurred at service layer.


Sample Request - 

Sample Response - 
{"status":"OK","header":{"headerAttributes":{}},"errors":[],"payload":{"createdBy":"soari_registry_app","createdAt":1357163963678,"modifiedBy":null,"modifiedAt":null,"id":"627ff271-be25-4585-845b-2b1e66eb1d09","status":"ACTIVE","resourceUri":null,"name":"TEST_POLICY1357163954912","url":"TEST_POLICY_URL","version":"TEST_POLICY_VERSION1","serviceVersions":[]}}

Error Response-
<ServiceResponse><status>FAIL</status><errors><error><code>500</code><field>field_1</field><description>com.walmart.platform.kernel.exception.layers.business.BusinessException: A mapping exception has occured</description><info>com.walmart.platform.kernel.exception.layers.service.ServiceException: com.walmart.platform.kernel.exception.layers.business.BusinessException: A mapping exception has occured\n\tat com.walmart.platform.soari.registry.server.common.exception.handler.impl.ExceptionHandlerImpl.handleServiceException(ExceptionHandlerImpl.java:103)\n\tat com.walmart.platform.soari.registry.service.impl.PolicyServiceImpl.getPolicy(PolicyServiceImpl.java:86)\n\tat sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)\nCaused by: com.walmart.platform.kernel.exception.layers.business.BusinessException: A mapping exception has occured\n\tat com.walmart.platform.soari.registry.server.common.exception.handler.impl.ExceptionHandlerImpl.handleBusinessException(ExceptionHandlerImpl.java:41)\n\tat com.walmart.platform.soari.registry.server.common.exception.handler.impl.ExceptionHandlerImpl.handleBusinessException(ExceptionHandlerImpl.java:71)\n\tat com.walmart.platform.soari.registry.server.common.exception.handler.impl.ExceptionHandlerImpl.handleBusinessException(ExceptionHandlerImpl.java:87)\n</info><severity>ERROR</severity><category>APPLICATION</category></error></errors><header><headerAttributes/></header></ServiceResponse>
```

###3.Add a Policy
```
Description - This API is used to add/create a Policy 

URL - {HostUrl}/policy
Example - http://localhost:8080/registry-app/services/policy

Request/Header parameters - 

Errors - 
Validation errors-
1.Policy already exists
Internal errors- 
1.DAO error has occurred while retrieving entities by matching name.
2.DAO error has occurred while retrieving entity by id.
3.DAO error has occurred while persisting an entity
4.A mapping error has occurred.
5.An unexpected error has occurred at business layer
6.An unexpected error has occurred at service layer.

Sample Request - 
{
  "header": 
  {
      "headerAttributes": {}
  },
  "payload": 
  {
        "status": "ACTIVE",
        "name": "TEST_POLICY_200",
        "url": "TEST_POLICY_URL_200",
        "version": "2.0.0"
   }
}

Sample Response -
{
  "status": "OK",
  "header": {
    "headerAttributes": {}
  },
  "errors": [(0)],
  "payload": {
  "createdBy": "soari_registry_app",
  "createdAt": 1357165571823,
  "modifiedBy": null,
  "modifiedAt": null,
  "id": "ad3c754d-30d4-4343-b515-4748e1443d37",
  "status": "ACTIVE",
  "resourceUri": null,
  "name": "TEST_POLICY_200",
  "url": "TEST_POLICY_URL_200",
  "version": "2.0.0",
  "serviceVersions": [(0)]
  }
}
```

###4.Update a Policy
```
Description - This API is used to update a Policy. If Policy doesn't exists then createa a new Policy. 

URL - {HostUrl}/policy

Request/Header parameters - 

Errors - 
Validation errors-
1.Policy already exists.
Internal errors- 
1.DAO error has occurred while retrieving entities by matching name.
2.DAO error has occurred while retrieving entity by id.
3.DAO error has occurred while persisting an entity
4.A mapping error has occurred.
5.An unexpected error has occurred at business layer
6.An unexpected error has occurred at service layer.

Sample Request - 
ServiceRequest [header=ServiceHeader [headerAttributes=null], payload=Policy[active=true,name=TEST_POLICY1356053711911,url=<null>,version=TEST_POLICY_VERSION1,serviceVersions=[],createdBy=soari_registry_app,createdAt=2012-12-20 17:35:11.848,modifiedBy=<null>,modifiedAt=<null>,id=7703ea4c-eaf8-4b0f-b96b-8c27d12bc6c4,status=ACTIVE,resourceUri=<null>]]
ServiceRequest<Policy> updatePolicyReq = new ServiceRequest<Policy>(
					new ServiceHeader(), policyToUpdate);
ServiceResponse<Policy> updatePolicyResp = policyServiceClient.updatePolicy(updateReq);

Sample Response -
ServiceResponse [status=OK, header=ServiceHeader [headerAttributes={}], errors=[], payload=Policy[active=true,name=TEST_POLICY1356053711911,url=<null>,version=TEST_POLICY_VERSION1,serviceVersions=[],createdBy=soari_registry_app,createdAt=2012-12-20 17:35:11.848,modifiedBy=<null>,modifiedAt=<null>,id=7703ea4c-eaf8-4b0f-b96b-8c27d12bc6c4,status=ACTIVE,resourceUri=<null>]]
```

###5.Delete a Policy
```
Description - This API is used to delete a Policy by ID
              Policy status is changed to 'DELETED'

URL - {HostUrl}/policy/{policyId}

Request/Header parameters - 

Errors - 
Validation errors-
1.Policy not found.
Internal errors- 
1.DAO error has occurred while retrieving entity by id.
2.DAO error has occurred while persisting an entity
3.A mapping error has occurred.
4.An unexpected error has occurred at business layer
5.An unexpected error has occurred at service layer.

Sample Request - 
ServiceResponse<Policy> deletePolicyResponse = policyServiceClient
					.deletePolicy(policyId);


Sample Response - 
ServiceResponse [status=OK, header=ServiceHeader [headerAttributes={}], errors=[], payload=null]
```

##Registry API Specification

###1.Get Available Services
```
Description - This API is used to retrieve details of all available Services

URL - {HostUrl}/registry

Request/Header parameters - 

Errors - 
Validation errors-
Internal errors- 
1.DAO error has occurred while retrieving entities.
2.A mapping error has occurred.
3.An unexpected error has occurred at business layer
4.An unexpected error has occurred at service layer.

Sample Request - 
ServiceResponse<ServiceList> getServicesResp = registryServiceClient
					.getServices();


Sample Response - 
ServiceResponse [status=OK, header=ServiceHeader [headerAttributes={}], errors=[], payload=ServiceList[services=[Service[category=<null>,description=TEST_SERVICE_DESCRIPTION,owner=TEST_SERVICE_OWNER,name=TEST_SERVICE_NAME1356056585739,applicationId=TEST_SERVICE_APPLICATION_ID,domain=<null>,usage=<null>,serviceVersions=[],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:05.77,modifiedBy=soari_registry_app,modifiedAt=2012-12-20 18:23:05.817,id=0ee88939-ab43-4642-9685-69ffce0b4019,status=DELETED,resourceUri=<null>], Service[category=<null>,description=TEST_SERVICE_DESCRIPTION,owner=TEST_SERVICE_OWNER,name=TEST_SERVICE_NAME1356056589302,applicationId=TEST_SERVICE_APPLICATION_ID,domain=<null>,usage=<null>,serviceVersions=[],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:09.364,modifiedBy=<null>,modifiedAt=<null>,id=1b643071-4584-41b6-abda-081161f21046,status=ACTIVE,resourceUri=<null>], Service[category=<null>,description=TEST_SERVICE_DESCRIPTION,owner=TEST_SERVICE_OWNER,name=TEST_SERVICE_NAME1356056588270,applicationId=TEST_SERVICE_APPLICATION_ID,domain=<null>,usage=<null>,serviceVersions=[],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:08.302,modifiedBy=<null>,modifiedAt=<null>,id=21fd8507-2c32-441d-9306-16f83e35c62e,status=ACTIVE,resourceUri=<null>], Service[category=<null>,description=TEST_SERVICE_DESCRIPTION,owner=TEST_SERVICE_OWNER,name=TEST_SERVICE_NAME1356056589380,applicationId=TEST_SERVICE_APPLICATION_ID,domain=<null>,usage=<null>,serviceVersions=[],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:09.427,modifiedBy=<null>,modifiedAt=<null>,id=2640629d-b628-41d5-bab2-7536a7267f1b,status=ACTIVE,resourceUri=<null>], Service[category=<null>,description=TEST_SERVICE_DESCRIPTION,owner=TEST_SERVICE_OWNER,name=TEST_SERVICE_NAME1356056584098,applicationId=TEST_SERVICE_APPLICATION_ID,domain=<null>,usage=<null>,serviceVersions=[ServiceVersion[activationEndDate=Thu Dec 20 18:23:04 PST 2012,activationStartDate=Thu Dec 20 18:23:04 PST 2012,availabilityTier=<null>,urls=[],environment=DEV,publicationDate=Thu Dec 20 18:23:04 PST 2012,serVersion=1.0.0,qasParameters=[],policies=[],service=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:04.192,modifiedBy=<null>,modifiedAt=<null>,id=d2334719-8afb-469e-b0ca-3b0170ada751,status=ACTIVE,resourceUri=<null>], ServiceVersion[activationEndDate=Thu Dec 20 18:23:04 PST 2012,activationStartDate=Thu Dec 20 18:23:04 PST 2012,availabilityTier=<null>,urls=[],environment=DEV,publicationDate=Thu Dec 20 18:23:04 PST 2012,serVersion=2.0.0,qasParameters=[],policies=[],service=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:04.286,modifiedBy=<null>,modifiedAt=<null>,id=1b6e4c3e-c37a-40a0-b4b0-18f000b78108,status=ACTIVE,resourceUri=<null>]],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:04.177,modifiedBy=<null>,modifiedAt=<null>,id=27c799f8-747c-4513-8655-03d3eb1edcc7,status=ACTIVE,resourceUri=<null>], Service[category=<null>,description=TEST_SERVICE_DESCRIPTION,owner=TEST_SERVICE_OWNER,name=TEST_SERVICE_NAME1356056588442,applicationId=TEST_SERVICE_APPLICATION_ID,domain=<null>,usage=<null>,serviceVersions=[ServiceVersion[activationEndDate=Thu Dec 20 18:23:08 PST 2012,activationStartDate=Thu Dec 20 18:23:08 PST 2012,availabilityTier=<null>,urls=[],environment=DEV,publicationDate=Thu Dec 20 18:23:08 PST 2012,serVersion=1.0.0,qasParameters=[],policies=[],service=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:08.505,modifiedBy=<null>,modifiedAt=<null>,id=965ad330-5dad-414c-be59-559ff96b43b0,status=ACTIVE,resourceUri=<null>]],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:08.505,modifiedBy=<null>,modifiedAt=<null>,id=28c997de-6b11-4053-b640-3895d6ce00ce,status=ACTIVE,resourceUri=<null>], Service[category=<null>,description=TEST_SERVICE_DESCRIPTION,owner=TEST_SERVICE_OWNER,name=TEST_SERVICE_NAME1356056586770,applicationId=TEST_SERVICE_APPLICATION_ID,domain=<null>,usage=<null>,serviceVersions=[ServiceVersion[activationEndDate=Thu Dec 20 18:23:06 PST 2012,activationStartDate=Thu Dec 20 18:23:06 PST 2012,availabilityTier=<null>,urls=[],environment=DEV,publicationDate=Thu Dec 20 18:23:06 PST 2012,serVersion=1.0.0,qasParameters=[QaSParameter[paramName=TEST_SERVICE_PARAMETER_NAME1356056586770,paramValue=TEST_SERVICE_PARAMETER_VALUE,parentParamId=<null>,serviceVersion=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:06.817,modifiedBy=<null>,modifiedAt=<null>,id=9ee5248c-4546-4eb9-889f-f3f45b6c5d71,status=ACTIVE,resourceUri=<null>]],policies=[],service=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:06.817,modifiedBy=soari_registry_app,modifiedAt=2012-12-20 18:23:06.895,id=996e662c-54ef-41c9-b303-975f786542af,status=DELETED,resourceUri=<null>]],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:06.817,modifiedBy=<null>,modifiedAt=<null>,id=29d0802f-3e9e-4d5b-9e87-72b569121084,status=ACTIVE,resourceUri=<null>], Service[category=<null>,description=TEST_SERVICE_DESCRIPTION,owner=TEST_SERVICE_OWNER,name=TEST_SERVICE_NAME1356056586974,applicationId=TEST_SERVICE_APPLICATION_ID,domain=<null>,usage=<null>,serviceVersions=[ServiceVersion[activationEndDate=Thu Dec 20 18:23:06 PST 2012,activationStartDate=Thu Dec 20 18:23:06 PST 2012,availabilityTier=<null>,urls=[],environment=DEV,publicationDate=Thu Dec 20 18:23:06 PST 2012,serVersion=1.0.0,qasParameters=[QaSParameter[paramName=TEST_SERVICE_PARAMETER_NAME1356056586974,paramValue=TEST_SERVICE_PARAMETER_VALUE,parentParamId=<null>,serviceVersion=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:07.02,modifiedBy=soari_registry_app,modifiedAt=2012-12-20 18:23:07.099,id=28a7c6d6-8df0-44fb-af80-04754fc48d5f,status=DELETED,resourceUri=<null>]],policies=[],service=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:07.02,modifiedBy=<null>,modifiedAt=<null>,id=3de0d8b1-7089-4eb8-8750-8aea4a2b35bd,status=ACTIVE,resourceUri=<null>]],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:07.02,modifiedBy=<null>,modifiedAt=<null>,id=3acda707-66d6-456e-a36b-30adf8807f85,status=ACTIVE,resourceUri=<null>], Service[category=<null>,description=TEST_SERVICE_DESCRIPTION,owner=TEST_SERVICE_OWNER,name=TEST_SERVICE_NAME1356056585208,applicationId=TEST_SERVICE_APPLICATION_ID,domain=<null>,usage=<null>,serviceVersions=[ServiceVersion[activationEndDate=Thu Dec 20 18:23:05 PST 2012,activationStartDate=Thu Dec 20 18:23:05 PST 2012,availabilityTier=<null>,urls=[],environment=DEV,publicationDate=Thu Dec 20 18:23:05 PST 2012,serVersion=1.0.0,qasParameters=[QaSParameter[paramName=TEST_SERVICE_PARAMETER_NAME1356056585208,paramValue=TEST_SERVICE_PARAMETER_VALUE,parentParamId=<null>,serviceVersion=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:05.302,modifiedBy=<null>,modifiedAt=<null>,id=0bb589a2-af2f-4b42-b428-8c58ae48a1d6,status=ACTIVE,resourceUri=<null>]],policies=[Policy[active=true,name=TEST_POLICY1356056585364,url=<null>,version=TEST_POLICY_VERSION1,serviceVersions=[],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:05.395,modifiedBy=<null>,modifiedAt=<null>,id=bae4863d-d40f-437f-8493-57ebc28b43b5,status=ACTIVE,resourceUri=<null>]],service=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:05.302,modifiedBy=<null>,modifiedAt=<null>,id=bec1aeb6-f355-412c-a111-5f22d015849d,status=ACTIVE,resourceUri=<null>]],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:05.302,modifiedBy=<null>,modifiedAt=<null>,id=4b034b61-13f9-4a8d-ba29-1ee208900581,status=ACTIVE,resourceUri=<null>], Service[category=<null>,description=TEST_SERVICE_DESCRIPTION,owner=TEST_SERVICE_OWNER,name=TEST_SERVICE_NAME1356056584958,applicationId=TEST_SERVICE_APPLICATION_ID,domain=<null>,usage=<null>,serviceVersions=[ServiceVersion[activationEndDate=Thu Dec 20 18:23:04 PST 2012,activationStartDate=Thu Dec 20 18:23:04 PST 2012,availabilityTier=<null>,urls=[],environment=DEV,publicationDate=Thu Dec 20 18:23:04 PST 2012,serVersion=1.0.0,qasParameters=[QaSParameter[paramName=TEST_SERVICE_PARAMETER_NAME1356056584958,paramValue=TEST_SERVICE_PARAMETER_VALUE,parentParamId=<null>,serviceVersion=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:05.036,modifiedBy=<null>,modifiedAt=<null>,id=bb0aa7c0-293b-4e1d-856c-82bc4f58d34b,status=ACTIVE,resourceUri=<null>]],policies=[],service=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:05.036,modifiedBy=<null>,modifiedAt=<null>,id=c558706e-4425-4a5e-b743-1e67319a44c0,status=ACTIVE,resourceUri=<null>]],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:05.036,modifiedBy=<null>,modifiedAt=<null>,id=4ea5a21c-642c-4eff-92e2-47116a42db1b,status=ACTIVE,resourceUri=<null>], Service[category=<null>,description=TEST_SERVICE_DESCRIPTION,owner=TEST_SERVICE_OWNER,name=TEST_SERVICE_NAME1356056570911,applicationId=TEST_SERVICE_APPLICATION_ID,domain=<null>,usage=<null>,serviceVersions=[],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:01.958,modifiedBy=<null>,modifiedAt=<null>,id=539493eb-5b34-4b71-a6ff-93b93b082573,status=ACTIVE,resourceUri=<null>], Service[category=<null>,description=TEST_SERVICE_DESCRIPTION,owner=TEST_SERVICE_OWNER,name=TEST_SERVICE_NAME1356056587208,applicationId=TEST_SERVICE_APPLICATION_ID,domain=<null>,usage=<null>,serviceVersions=[ServiceVersion[activationEndDate=Thu Dec 20 18:23:07 PST 2012,activationStartDate=Thu Dec 20 18:23:07 PST 2012,availabilityTier=<null>,urls=[],environment=DEV,publicationDate=Thu Dec 20 18:23:07 PST 2012,serVersion=1.0.0,qasParameters=[QaSParameter[paramName=TEST_SERVICE_PARAMETER_NAME1356056587208,paramValue=TEST_SERVICE_PARAMETER_VALUE,parentParamId=<null>,serviceVersion=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:07.27,modifiedBy=<null>,modifiedAt=<null>,id=79ad88a9-0cea-4bb5-a613-23d2c7f3322f,status=ACTIVE,resourceUri=<null>]],policies=[Policy[active=true,name=TEST_POLICY1356056587302,url=<null>,version=TEST_POLICY_VERSION1,serviceVersions=[],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:07.349,modifiedBy=<null>,modifiedAt=<null>,id=662f8a10-1f04-464b-a23a-b628548f8817,status=ACTIVE,resourceUri=<null>]],service=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:07.27,modifiedBy=<null>,modifiedAt=<null>,id=170e3a82-8065-4efc-8a91-d0e1263de55b,status=ACTIVE,resourceUri=<null>]],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:07.27,modifiedBy=<null>,modifiedAt=<null>,id=8e46af22-b051-48da-9689-adca79c5d3e6,status=ACTIVE,resourceUri=<null>], Service[category=<null>,description=TEST_SERVICE_DESCRIPTION,owner=TEST_SERVICE_OWNER,name=TEST_SERVICE_NAME1356056588786,applicationId=TEST_SERVICE_APPLICATION_ID,domain=<null>,usage=<null>,serviceVersions=[ServiceVersion[activationEndDate=Thu Dec 20 18:23:08 PST 2012,activationStartDate=Thu Dec 20 18:23:08 PST 2012,availabilityTier=<null>,urls=[],environment=DEV,publicationDate=Thu Dec 20 18:23:08 PST 2012,serVersion=1.0.0,qasParameters=[QaSParameter[paramName=TEST_SERVICE_PARAMETER_NAME1356056588786,paramValue=TEST_SERVICE_PARAMETER_VALUE,parentParamId=<null>,serviceVersion=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:08.849,modifiedBy=<null>,modifiedAt=<null>,id=f6d30f14-6c96-4295-b332-6045dd14b046,status=ACTIVE,resourceUri=<null>]],policies=[Policy[active=true,name=TEST_POLICY1356056588895,url=<null>,version=TEST_POLICY_VERSION1,serviceVersions=[],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:08.974,modifiedBy=<null>,modifiedAt=<null>,id=6d400c99-8b8c-4053-93a1-40b52f261a4d,status=ACTIVE,resourceUri=<null>], Policy[active=true,name=TEST_POLICY1356056589067,url=<null>,version=TEST_POLICY_VERSION1,serviceVersions=[],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:09.083,modifiedBy=<null>,modifiedAt=<null>,id=4ce4ac33-c78c-424e-abfd-368cca80227b,status=ACTIVE,resourceUri=<null>]],service=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:08.849,modifiedBy=<null>,modifiedAt=<null>,id=b311cdde-2494-48ba-98d2-7fb1beba3947,status=ACTIVE,resourceUri=<null>]],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:08.849,modifiedBy=<null>,modifiedAt=<null>,id=90d4eec3-eadf-49fe-9ae6-c146bb115ee0,status=ACTIVE,resourceUri=<null>], Service[category=<null>,description=TEST_SERVICE_DESCRIPTION,owner=TEST_SERVICE_OWNER,name=TEST_SERVICE_NAME1356056588192,applicationId=TEST_SERVICE_APPLICATION_ID,domain=<null>,usage=<null>,serviceVersions=[],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:08.224,modifiedBy=<null>,modifiedAt=<null>,id=93a57cb5-885e-41f2-9841-d1122e093d88,status=ACTIVE,resourceUri=<null>], Service[category=<null>,description=TEST_SERVICE_DESCRIPTION,owner=TEST_SERVICE_OWNER,name=TEST_SERVICE_NAME1356056584630,applicationId=TEST_SERVICE_APPLICATION_ID,domain=<null>,usage=<null>,serviceVersions=[ServiceVersion[activationEndDate=Thu Dec 20 18:23:04 PST 2012,activationStartDate=Thu Dec 20 18:23:04 PST 2012,availabilityTier=<null>,urls=[],environment=DEV,publicationDate=Thu Dec 20 18:23:04 PST 2012,serVersion=1.0.0,qasParameters=[QaSParameter[paramName=TEST_SERVICE_PARAMETER_NAME1356056584630,paramValue=TEST_SERVICE_PARAMETER_VALUE,parentParamId=<null>,serviceVersion=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:04.739,modifiedBy=<null>,modifiedAt=<null>,id=6bba534a-75e0-4714-89d7-b181e9d51e22,status=ACTIVE,resourceUri=<null>], QaSParameter[paramName=TEST_SERVICE_PARAMETER_NAME1356056584786,paramValue=TEST_SERVICE_PARAMETER_VALUE,parentParamId=<null>,serviceVersion=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:04.864,modifiedBy=<null>,modifiedAt=<null>,id=ddb73465-156b-4f57-a47a-e54cbe06315b,status=ACTIVE,resourceUri=<null>]],policies=[],service=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:04.739,modifiedBy=<null>,modifiedAt=<null>,id=2e988aac-a1be-47f6-b2e9-c0c69ef88a92,status=ACTIVE,resourceUri=<null>]],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:04.739,modifiedBy=<null>,modifiedAt=<null>,id=a7409c6f-a06f-4158-bca3-4fbf070eaddc,status=ACTIVE,resourceUri=<null>], Service[category=<null>,description=TEST_SERVICE_DESCRIPTION,owner=TEST_SERVICE_OWNER,name=TEST_SERVICE_NAME1356056585630,applicationId=TEST_SERVICE_APPLICATION_ID,domain=<null>,usage=<null>,serviceVersions=[ServiceVersion[activationEndDate=Thu Dec 20 18:23:05 PST 2012,activationStartDate=Thu Dec 20 18:23:05 PST 2012,availabilityTier=<null>,urls=[],environment=DEV,publicationDate=Thu Dec 20 18:23:05 PST 2012,serVersion=1.0.0,qasParameters=[QaSParameter[paramName=TEST_SERVICE_PARAMETER_NAME,paramValue=TEST_SERVICE_PARAMETER_VALUE,parentParamId=<null>,serviceVersion=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:05.692,modifiedBy=<null>,modifiedAt=<null>,id=db2f3aae-66d2-46a9-a196-36ad1e44c54f,status=ACTIVE,resourceUri=<null>]],policies=[],service=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:05.692,modifiedBy=<null>,modifiedAt=<null>,id=681fdb70-7762-4e0e-a251-8d1344f84777,status=ACTIVE,resourceUri=<null>]],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:05.692,modifiedBy=<null>,modifiedAt=<null>,id=ab1664e1-c6b0-4e1f-8cce-ad1267f191c9,status=ACTIVE,resourceUri=<null>], Service[category=<null>,description=TEST_SERVICE_DESCRIPTION,owner=TEST_SERVICE_OWNER,name=TEST_SERVICE_NAME1356056583317,applicationId=TEST_SERVICE_APPLICATION_ID,domain=<null>,usage=<null>,serviceVersions=[],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:03.411,modifiedBy=<null>,modifiedAt=<null>,id=bd012606-8efe-47a6-a2a7-6bc036795bd8,status=ACTIVE,resourceUri=<null>], Service[category=<null>,description=TEST_SERVICE_DESCRIPTION,owner=TEST_SERVICE_OWNER,name=TEST_SERVICE_NAME1356056584380,applicationId=TEST_SERVICE_APPLICATION_ID,domain=<null>,usage=<null>,serviceVersions=[ServiceVersion[activationEndDate=Thu Dec 20 18:23:04 PST 2012,activationStartDate=Thu Dec 20 18:23:04 PST 2012,availabilityTier=<null>,urls=[],environment=DEV,publicationDate=Thu Dec 20 18:23:04 PST 2012,serVersion=1.0.0,qasParameters=[],policies=[],service=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:04.427,modifiedBy=<null>,modifiedAt=<null>,id=139c73d9-05c5-4dc1-96ef-2caad6beb3d5,status=ACTIVE,resourceUri=<null>]],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:04.427,modifiedBy=<null>,modifiedAt=<null>,id=cd4fcf8b-975b-4b28-83a7-9b0ba6a59068,status=ACTIVE,resourceUri=<null>], Service[category=<null>,description=TEST_SERVICE_DESCRIPTION,owner=TEST_SERVICE_OWNER,name=TEST_SERVICE_NAME1356056585536,applicationId=TEST_SERVICE_APPLICATION_ID,domain=<null>,usage=<null>,serviceVersions=[ServiceVersion[activationEndDate=Thu Dec 20 18:23:05 PST 2012,activationStartDate=Thu Dec 20 18:23:05 PST 2012,availabilityTier=<null>,urls=[],environment=DEV,publicationDate=Thu Dec 20 18:23:05 PST 2012,serVersion=1.0.0,qasParameters=[],policies=[],service=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:05.567,modifiedBy=<null>,modifiedAt=<null>,id=8d106aa1-effd-4531-974d-910a563c1c09,status=ACTIVE,resourceUri=<null>]],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:05.567,modifiedBy=<null>,modifiedAt=<null>,id=e4717707-84ff-47fe-abdb-cc517fc11bbd,status=ACTIVE,resourceUri=<null>], Service[category=<null>,description=TEST_SERVICE_DESCRIPTION,owner=TEST_SERVICE_OWNER,name=TEST_SERVICE_NAME1356056588614,applicationId=TEST_SERVICE_APPLICATION_ID,domain=<null>,usage=<null>,serviceVersions=[ServiceVersion[activationEndDate=Thu Dec 20 18:23:08 PST 2012,activationStartDate=Thu Dec 20 18:23:08 PST 2012,availabilityTier=<null>,urls=[],environment=DEV,publicationDate=Thu Dec 20 18:23:08 PST 2012,serVersion=1.0.0,qasParameters=[QaSParameter[paramName=TEST_SERVICE_PARAMETER_NAME1356056588614,paramValue=TEST_SERVICE_PARAMETER_VALUE,parentParamId=<null>,serviceVersion=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:08.677,modifiedBy=<null>,modifiedAt=<null>,id=a017d6be-9535-4e20-92e2-de0c5a115841,status=ACTIVE,resourceUri=<null>]],policies=[],service=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:08.677,modifiedBy=<null>,modifiedAt=<null>,id=a6949f54-8cf9-47dc-bf3c-86f804c5024a,status=ACTIVE,resourceUri=<null>]],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:08.677,modifiedBy=<null>,modifiedAt=<null>,id=fec8a93d-e4ba-4159-b8c4-57cfe7b2af1e,status=ACTIVE,resourceUri=<null>]]]]

```

###2.Get Services by application ID
```
Description - This API is used to retrieve details of Services by application id.

URL - {HostUrl}/registry/app-service/{applicationId}

Request/Header parameters - 

Errors - 
Validation errors-
1.Invalid application id.
Internal errors- 
1.DAO error has occurred while retrieving Services by application id.
2.A mapping error has occurred.
3.An unexpected error has occurred at business layer
4.An unexpected error has occurred at service layer.


Sample Request - 
ServiceResponse<ServiceList> services = registryServiceClient.getServicesByApplicationId(applicationId)

Sample Response -
ServiceResponse [status=OK, header=ServiceHeader [headerAttributes={}], errors=[], payload=ServiceList[services=[Service[category=<null>,description=TEST_SERVICE_DESCRIPTION,owner=TEST_SERVICE_OWNER,name=TEST_SERVICE_NAME1356056585739,applicationId=TEST_SERVICE_APPLICATION_ID,domain=<null>,usage=<null>,serviceVersions=[],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:05.77,modifiedBy=soari_registry_app,modifiedAt=2012-12-20 18:23:05.817,id=0ee88939-ab43-4642-9685-69ffce0b4019,status=DELETED,resourceUri=<null>], Service[category=<null>,description=TEST_SERVICE_DESCRIPTION,owner=TEST_SERVICE_OWNER,name=TEST_SERVICE_NAME1356056589302,applicationId=TEST_SERVICE_APPLICATION_ID,domain=<null>,usage=<null>,serviceVersions=[],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:09.364,modifiedBy=<null>,modifiedAt=<null>,id=1b643071-4584-41b6-abda-081161f21046,status=ACTIVE,resourceUri=<null>], Service[category=<null>,description=TEST_SERVICE_DESCRIPTION,owner=TEST_SERVICE_OWNER,name=TEST_SERVICE_NAME1356056588270,applicationId=TEST_SERVICE_APPLICATION_ID,domain=<null>,usage=<null>,serviceVersions=[],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:08.302,modifiedBy=<null>,modifiedAt=<null>,id=21fd8507-2c32-441d-9306-16f83e35c62e,status=ACTIVE,resourceUri=<null>], Service[category=<null>,description=TEST_SERVICE_DESCRIPTION,owner=TEST_SERVICE_OWNER,name=TEST_SERVICE_NAME1356056589380,applicationId=TEST_SERVICE_APPLICATION_ID,domain=<null>,usage=<null>,serviceVersions=[],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:09.427,modifiedBy=<null>,modifiedAt=<null>,id=2640629d-b628-41d5-bab2-7536a7267f1b,status=ACTIVE,resourceUri=<null>], Service[category=<null>,description=TEST_SERVICE_DESCRIPTION,owner=TEST_SERVICE_OWNER,name=TEST_SERVICE_NAME1356056584098,applicationId=TEST_SERVICE_APPLICATION_ID,domain=<null>,usage=<null>,serviceVersions=[ServiceVersion[activationEndDate=Thu Dec 20 18:23:04 PST 2012,activationStartDate=Thu Dec 20 18:23:04 PST 2012,availabilityTier=<null>,urls=[],environment=DEV,publicationDate=Thu Dec 20 18:23:04 PST 2012,serVersion=1.0.0,qasParameters=[],policies=[],service=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:04.192,modifiedBy=<null>,modifiedAt=<null>,id=d2334719-8afb-469e-b0ca-3b0170ada751,status=ACTIVE,resourceUri=<null>], ServiceVersion[activationEndDate=Thu Dec 20 18:23:04 PST 2012,activationStartDate=Thu Dec 20 18:23:04 PST 2012,availabilityTier=<null>,urls=[],environment=DEV,publicationDate=Thu Dec 20 18:23:04 PST 2012,serVersion=2.0.0,qasParameters=[],policies=[],service=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:04.286,modifiedBy=<null>,modifiedAt=<null>,id=1b6e4c3e-c37a-40a0-b4b0-18f000b78108,status=ACTIVE,resourceUri=<null>]],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:04.177,modifiedBy=<null>,modifiedAt=<null>,id=27c799f8-747c-4513-8655-03d3eb1edcc7,status=ACTIVE,resourceUri=<null>], Service[category=<null>,description=TEST_SERVICE_DESCRIPTION,owner=TEST_SERVICE_OWNER,name=TEST_SERVICE_NAME1356056588442,applicationId=TEST_SERVICE_APPLICATION_ID,domain=<null>,usage=<null>,serviceVersions=[ServiceVersion[activationEndDate=Thu Dec 20 18:23:08 PST 2012,activationStartDate=Thu Dec 20 18:23:08 PST 2012,availabilityTier=<null>,urls=[],environment=DEV,publicationDate=Thu Dec 20 18:23:08 PST 2012,serVersion=1.0.0,qasParameters=[],policies=[],service=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:08.505,modifiedBy=<null>,modifiedAt=<null>,id=965ad330-5dad-414c-be59-559ff96b43b0,status=ACTIVE,resourceUri=<null>]],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:08.505,modifiedBy=<null>,modifiedAt=<null>,id=28c997de-6b11-4053-b640-3895d6ce00ce,status=ACTIVE,resourceUri=<null>], Service[category=<null>,description=TEST_SERVICE_DESCRIPTION,owner=TEST_SERVICE_OWNER,name=TEST_SERVICE_NAME1356056586770,applicationId=TEST_SERVICE_APPLICATION_ID,domain=<null>,usage=<null>,serviceVersions=[ServiceVersion[activationEndDate=Thu Dec 20 18:23:06 PST 2012,activationStartDate=Thu Dec 20 18:23:06 PST 2012,availabilityTier=<null>,urls=[],environment=DEV,publicationDate=Thu Dec 20 18:23:06 PST 2012,serVersion=1.0.0,qasParameters=[QaSParameter[paramName=TEST_SERVICE_PARAMETER_NAME1356056586770,paramValue=TEST_SERVICE_PARAMETER_VALUE,parentParamId=<null>,serviceVersion=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:06.817,modifiedBy=<null>,modifiedAt=<null>,id=9ee5248c-4546-4eb9-889f-f3f45b6c5d71,status=ACTIVE,resourceUri=<null>]],policies=[],service=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:06.817,modifiedBy=soari_registry_app,modifiedAt=2012-12-20 18:23:06.895,id=996e662c-54ef-41c9-b303-975f786542af,status=DELETED,resourceUri=<null>]],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:06.817,modifiedBy=<null>,modifiedAt=<null>,id=29d0802f-3e9e-4d5b-9e87-72b569121084,status=ACTIVE,resourceUri=<null>], Service[category=<null>,description=TEST_SERVICE_DESCRIPTION,owner=TEST_SERVICE_OWNER,name=TEST_SERVICE_NAME1356056586974,applicationId=TEST_SERVICE_APPLICATION_ID,domain=<null>,usage=<null>,serviceVersions=[ServiceVersion[activationEndDate=Thu Dec 20 18:23:06 PST 2012,activationStartDate=Thu Dec 20 18:23:06 PST 2012,availabilityTier=<null>,urls=[],environment=DEV,publicationDate=Thu Dec 20 18:23:06 PST 2012,serVersion=1.0.0,qasParameters=[QaSParameter[paramName=TEST_SERVICE_PARAMETER_NAME1356056586974,paramValue=TEST_SERVICE_PARAMETER_VALUE,parentParamId=<null>,serviceVersion=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:07.02,modifiedBy=soari_registry_app,modifiedAt=2012-12-20 18:23:07.099,id=28a7c6d6-8df0-44fb-af80-04754fc48d5f,status=DELETED,resourceUri=<null>]],policies=[],service=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:07.02,modifiedBy=<null>,modifiedAt=<null>,id=3de0d8b1-7089-4eb8-8750-8aea4a2b35bd,status=ACTIVE,resourceUri=<null>]],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:07.02,modifiedBy=<null>,modifiedAt=<null>,id=3acda707-66d6-456e-a36b-30adf8807f85,status=ACTIVE,resourceUri=<null>], Service[category=<null>,description=TEST_SERVICE_DESCRIPTION,owner=TEST_SERVICE_OWNER,name=TEST_SERVICE_NAME1356056585208,applicationId=TEST_SERVICE_APPLICATION_ID,domain=<null>,usage=<null>,serviceVersions=[ServiceVersion[activationEndDate=Thu Dec 20 18:23:05 PST 2012,activationStartDate=Thu Dec 20 18:23:05 PST 2012,availabilityTier=<null>,urls=[],environment=DEV,publicationDate=Thu Dec 20 18:23:05 PST 2012,serVersion=1.0.0,qasParameters=[QaSParameter[paramName=TEST_SERVICE_PARAMETER_NAME1356056585208,paramValue=TEST_SERVICE_PARAMETER_VALUE,parentParamId=<null>,serviceVersion=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:05.302,modifiedBy=<null>,modifiedAt=<null>,id=0bb589a2-af2f-4b42-b428-8c58ae48a1d6,status=ACTIVE,resourceUri=<null>]],policies=[Policy[active=true,name=TEST_POLICY1356056585364,url=<null>,version=TEST_POLICY_VERSION1,serviceVersions=[],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:05.395,modifiedBy=<null>,modifiedAt=<null>,id=bae4863d-d40f-437f-8493-57ebc28b43b5,status=ACTIVE,resourceUri=<null>]],service=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:05.302,modifiedBy=<null>,modifiedAt=<null>,id=bec1aeb6-f355-412c-a111-5f22d015849d,status=ACTIVE,resourceUri=<null>]],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:05.302,modifiedBy=<null>,modifiedAt=<null>,id=4b034b61-13f9-4a8d-ba29-1ee208900581,status=ACTIVE,resourceUri=<null>], Service[category=<null>,description=TEST_SERVICE_DESCRIPTION,owner=TEST_SERVICE_OWNER,name=TEST_SERVICE_NAME1356056584958,applicationId=TEST_SERVICE_APPLICATION_ID,domain=<null>,usage=<null>,serviceVersions=[ServiceVersion[activationEndDate=Thu Dec 20 18:23:04 PST 2012,activationStartDate=Thu Dec 20 18:23:04 PST 2012,availabilityTier=<null>,urls=[],environment=DEV,publicationDate=Thu Dec 20 18:23:04 PST 2012,serVersion=1.0.0,qasParameters=[QaSParameter[paramName=TEST_SERVICE_PARAMETER_NAME1356056584958,paramValue=TEST_SERVICE_PARAMETER_VALUE,parentParamId=<null>,serviceVersion=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:05.036,modifiedBy=<null>,modifiedAt=<null>,id=bb0aa7c0-293b-4e1d-856c-82bc4f58d34b,status=ACTIVE,resourceUri=<null>]],policies=[],service=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:05.036,modifiedBy=<null>,modifiedAt=<null>,id=c558706e-4425-4a5e-b743-1e67319a44c0,status=ACTIVE,resourceUri=<null>]],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:05.036,modifiedBy=<null>,modifiedAt=<null>,id=4ea5a21c-642c-4eff-92e2-47116a42db1b,status=ACTIVE,resourceUri=<null>], Service[category=<null>,description=TEST_SERVICE_DESCRIPTION,owner=TEST_SERVICE_OWNER,name=TEST_SERVICE_NAME1356056570911,applicationId=TEST_SERVICE_APPLICATION_ID,domain=<null>,usage=<null>,serviceVersions=[],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:01.958,modifiedBy=<null>,modifiedAt=<null>,id=539493eb-5b34-4b71-a6ff-93b93b082573,status=ACTIVE,resourceUri=<null>], Service[category=<null>,description=TEST_SERVICE_DESCRIPTION,owner=TEST_SERVICE_OWNER,name=TEST_SERVICE_NAME1356056587208,applicationId=TEST_SERVICE_APPLICATION_ID,domain=<null>,usage=<null>,serviceVersions=[ServiceVersion[activationEndDate=Thu Dec 20 18:23:07 PST 2012,activationStartDate=Thu Dec 20 18:23:07 PST 2012,availabilityTier=<null>,urls=[],environment=DEV,publicationDate=Thu Dec 20 18:23:07 PST 2012,serVersion=1.0.0,qasParameters=[QaSParameter[paramName=TEST_SERVICE_PARAMETER_NAME1356056587208,paramValue=TEST_SERVICE_PARAMETER_VALUE,parentParamId=<null>,serviceVersion=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:07.27,modifiedBy=<null>,modifiedAt=<null>,id=79ad88a9-0cea-4bb5-a613-23d2c7f3322f,status=ACTIVE,resourceUri=<null>]],policies=[Policy[active=true,name=TEST_POLICY1356056587302,url=<null>,version=TEST_POLICY_VERSION1,serviceVersions=[],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:07.349,modifiedBy=<null>,modifiedAt=<null>,id=662f8a10-1f04-464b-a23a-b628548f8817,status=ACTIVE,resourceUri=<null>]],service=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:07.27,modifiedBy=<null>,modifiedAt=<null>,id=170e3a82-8065-4efc-8a91-d0e1263de55b,status=ACTIVE,resourceUri=<null>]],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:07.27,modifiedBy=<null>,modifiedAt=<null>,id=8e46af22-b051-48da-9689-adca79c5d3e6,status=ACTIVE,resourceUri=<null>], Service[category=<null>,description=TEST_SERVICE_DESCRIPTION,owner=TEST_SERVICE_OWNER,name=TEST_SERVICE_NAME1356056588786,applicationId=TEST_SERVICE_APPLICATION_ID,domain=<null>,usage=<null>,serviceVersions=[ServiceVersion[activationEndDate=Thu Dec 20 18:23:08 PST 2012,activationStartDate=Thu Dec 20 18:23:08 PST 2012,availabilityTier=<null>,urls=[],environment=DEV,publicationDate=Thu Dec 20 18:23:08 PST 2012,serVersion=1.0.0,qasParameters=[QaSParameter[paramName=TEST_SERVICE_PARAMETER_NAME1356056588786,paramValue=TEST_SERVICE_PARAMETER_VALUE,parentParamId=<null>,serviceVersion=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:08.849,modifiedBy=<null>,modifiedAt=<null>,id=f6d30f14-6c96-4295-b332-6045dd14b046,status=ACTIVE,resourceUri=<null>]],policies=[Policy[active=true,name=TEST_POLICY1356056588895,url=<null>,version=TEST_POLICY_VERSION1,serviceVersions=[],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:08.974,modifiedBy=<null>,modifiedAt=<null>,id=6d400c99-8b8c-4053-93a1-40b52f261a4d,status=ACTIVE,resourceUri=<null>], Policy[active=true,name=TEST_POLICY1356056589067,url=<null>,version=TEST_POLICY_VERSION1,serviceVersions=[],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:09.083,modifiedBy=<null>,modifiedAt=<null>,id=4ce4ac33-c78c-424e-abfd-368cca80227b,status=ACTIVE,resourceUri=<null>]],service=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:08.849,modifiedBy=<null>,modifiedAt=<null>,id=b311cdde-2494-48ba-98d2-7fb1beba3947,status=ACTIVE,resourceUri=<null>]],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:08.849,modifiedBy=<null>,modifiedAt=<null>,id=90d4eec3-eadf-49fe-9ae6-c146bb115ee0,status=ACTIVE,resourceUri=<null>], Service[category=<null>,description=TEST_SERVICE_DESCRIPTION,owner=TEST_SERVICE_OWNER,name=TEST_SERVICE_NAME1356056588192,applicationId=TEST_SERVICE_APPLICATION_ID,domain=<null>,usage=<null>,serviceVersions=[],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:08.224,modifiedBy=<null>,modifiedAt=<null>,id=93a57cb5-885e-41f2-9841-d1122e093d88,status=ACTIVE,resourceUri=<null>], Service[category=<null>,description=TEST_SERVICE_DESCRIPTION,owner=TEST_SERVICE_OWNER,name=TEST_SERVICE_NAME1356056584630,applicationId=TEST_SERVICE_APPLICATION_ID,domain=<null>,usage=<null>,serviceVersions=[ServiceVersion[activationEndDate=Thu Dec 20 18:23:04 PST 2012,activationStartDate=Thu Dec 20 18:23:04 PST 2012,availabilityTier=<null>,urls=[],environment=DEV,publicationDate=Thu Dec 20 18:23:04 PST 2012,serVersion=1.0.0,qasParameters=[QaSParameter[paramName=TEST_SERVICE_PARAMETER_NAME1356056584630,paramValue=TEST_SERVICE_PARAMETER_VALUE,parentParamId=<null>,serviceVersion=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:04.739,modifiedBy=<null>,modifiedAt=<null>,id=6bba534a-75e0-4714-89d7-b181e9d51e22,status=ACTIVE,resourceUri=<null>], QaSParameter[paramName=TEST_SERVICE_PARAMETER_NAME1356056584786,paramValue=TEST_SERVICE_PARAMETER_VALUE,parentParamId=<null>,serviceVersion=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:04.864,modifiedBy=<null>,modifiedAt=<null>,id=ddb73465-156b-4f57-a47a-e54cbe06315b,status=ACTIVE,resourceUri=<null>]],policies=[],service=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:04.739,modifiedBy=<null>,modifiedAt=<null>,id=2e988aac-a1be-47f6-b2e9-c0c69ef88a92,status=ACTIVE,resourceUri=<null>]],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:04.739,modifiedBy=<null>,modifiedAt=<null>,id=a7409c6f-a06f-4158-bca3-4fbf070eaddc,status=ACTIVE,resourceUri=<null>], Service[category=<null>,description=TEST_SERVICE_DESCRIPTION,owner=TEST_SERVICE_OWNER,name=TEST_SERVICE_NAME1356056585630,applicationId=TEST_SERVICE_APPLICATION_ID,domain=<null>,usage=<null>,serviceVersions=[ServiceVersion[activationEndDate=Thu Dec 20 18:23:05 PST 2012,activationStartDate=Thu Dec 20 18:23:05 PST 2012,availabilityTier=<null>,urls=[],environment=DEV,publicationDate=Thu Dec 20 18:23:05 PST 2012,serVersion=1.0.0,qasParameters=[QaSParameter[paramName=TEST_SERVICE_PARAMETER_NAME,paramValue=TEST_SERVICE_PARAMETER_VALUE,parentParamId=<null>,serviceVersion=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:05.692,modifiedBy=<null>,modifiedAt=<null>,id=db2f3aae-66d2-46a9-a196-36ad1e44c54f,status=ACTIVE,resourceUri=<null>]],policies=[],service=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:05.692,modifiedBy=<null>,modifiedAt=<null>,id=681fdb70-7762-4e0e-a251-8d1344f84777,status=ACTIVE,resourceUri=<null>]],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:05.692,modifiedBy=<null>,modifiedAt=<null>,id=ab1664e1-c6b0-4e1f-8cce-ad1267f191c9,status=ACTIVE,resourceUri=<null>], Service[category=<null>,description=TEST_SERVICE_DESCRIPTION,owner=TEST_SERVICE_OWNER,name=TEST_SERVICE_NAME1356056583317,applicationId=TEST_SERVICE_APPLICATION_ID,domain=<null>,usage=<null>,serviceVersions=[],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:03.411,modifiedBy=<null>,modifiedAt=<null>,id=bd012606-8efe-47a6-a2a7-6bc036795bd8,status=ACTIVE,resourceUri=<null>], Service[category=<null>,description=TEST_SERVICE_DESCRIPTION,owner=TEST_SERVICE_OWNER,name=TEST_SERVICE_NAME1356056584380,applicationId=TEST_SERVICE_APPLICATION_ID,domain=<null>,usage=<null>,serviceVersions=[ServiceVersion[activationEndDate=Thu Dec 20 18:23:04 PST 2012,activationStartDate=Thu Dec 20 18:23:04 PST 2012,availabilityTier=<null>,urls=[],environment=DEV,publicationDate=Thu Dec 20 18:23:04 PST 2012,serVersion=1.0.0,qasParameters=[],policies=[],service=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:04.427,modifiedBy=<null>,modifiedAt=<null>,id=139c73d9-05c5-4dc1-96ef-2caad6beb3d5,status=ACTIVE,resourceUri=<null>]],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:04.427,modifiedBy=<null>,modifiedAt=<null>,id=cd4fcf8b-975b-4b28-83a7-9b0ba6a59068,status=ACTIVE,resourceUri=<null>], Service[category=<null>,description=TEST_SERVICE_DESCRIPTION,owner=TEST_SERVICE_OWNER,name=TEST_SERVICE_NAME1356056585536,applicationId=TEST_SERVICE_APPLICATION_ID,domain=<null>,usage=<null>,serviceVersions=[ServiceVersion[activationEndDate=Thu Dec 20 18:23:05 PST 2012,activationStartDate=Thu Dec 20 18:23:05 PST 2012,availabilityTier=<null>,urls=[],environment=DEV,publicationDate=Thu Dec 20 18:23:05 PST 2012,serVersion=1.0.0,qasParameters=[],policies=[],service=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:05.567,modifiedBy=<null>,modifiedAt=<null>,id=8d106aa1-effd-4531-974d-910a563c1c09,status=ACTIVE,resourceUri=<null>]],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:05.567,modifiedBy=<null>,modifiedAt=<null>,id=e4717707-84ff-47fe-abdb-cc517fc11bbd,status=ACTIVE,resourceUri=<null>], Service[category=<null>,description=TEST_SERVICE_DESCRIPTION,owner=TEST_SERVICE_OWNER,name=TEST_SERVICE_NAME1356056588614,applicationId=TEST_SERVICE_APPLICATION_ID,domain=<null>,usage=<null>,serviceVersions=[ServiceVersion[activationEndDate=Thu Dec 20 18:23:08 PST 2012,activationStartDate=Thu Dec 20 18:23:08 PST 2012,availabilityTier=<null>,urls=[],environment=DEV,publicationDate=Thu Dec 20 18:23:08 PST 2012,serVersion=1.0.0,qasParameters=[QaSParameter[paramName=TEST_SERVICE_PARAMETER_NAME1356056588614,paramValue=TEST_SERVICE_PARAMETER_VALUE,parentParamId=<null>,serviceVersion=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:08.677,modifiedBy=<null>,modifiedAt=<null>,id=a017d6be-9535-4e20-92e2-de0c5a115841,status=ACTIVE,resourceUri=<null>]],policies=[],service=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:08.677,modifiedBy=<null>,modifiedAt=<null>,id=a6949f54-8cf9-47dc-bf3c-86f804c5024a,status=ACTIVE,resourceUri=<null>]],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:08.677,modifiedBy=<null>,modifiedAt=<null>,id=fec8a93d-e4ba-4159-b8c4-57cfe7b2af1e,status=ACTIVE,resourceUri=<null>]]]]

```

###3.Add a Service
```
Description - This API is used to add/create a Service

URL - {HostUrl}/registry/service

Request/Header parameters - 

Errors - 
Validation errors-
1.Service already exists.
Internal errors-
1.DAO error has occurred while retrieving entity by name.
2.DAO error has occurred while retrieving entity by id.
3.DAO error has occurred while persisting an entity
2.A mapping error has occurred.
3.An unexpected error has occurred at business layer
4.An unexpected error has occurred at service layer.


Sample Request - 
ServiceRequest [header=ServiceHeader [headerAttributes=null], payload=Service[category=DATA,description=TEST_SERVICE_DESCRIPTION,owner=TEST_SERVICE_OWNER,name=TEST_SERVICE_NAME1356056570911,applicationId=TEST_SERVICE_APPLICATION_ID,domain=B2B,usage=INTERNAL,serviceVersions=[],createdBy=<null>,createdAt=<null>,modifiedBy=<null>,modifiedAt=<null>,id=<null>,status=ACTIVE,resourceUri=<null>]]
ServiceRequest<Service> createServiceRequest = 
	new ServiceRequest<Service>(new ServiceHeader(), service);
ServiceResponse<Service> createServiceResponse = registryServiceClient
					.addService(createServiceRequest);


Sample Response - 
ServiceResponse [status=OK, header=ServiceHeader [headerAttributes={}], errors=[], payload=Service[category=DATA,description=TEST_SERVICE_DESCRIPTION,owner=TEST_SERVICE_OWNER,name=TEST_SERVICE_NAME1356056570911,applicationId=TEST_SERVICE_APPLICATION_ID,domain=B2B,usage=INTERNAL,serviceVersions=[],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:01.958,modifiedBy=<null>,modifiedAt=<null>,id=539493eb-5b34-4b71-a6ff-93b93b082573,status=ACTIVE,resourceUri=<null>]]


```

###4.Update a Service by ID
```
Description - This API is used to update a Service. If Service doesn't exists then creates a new Service.

URL - {HostUrl}/registry/service

Request/Header parameters - 

Errors - 
Validation errors-
1.Service already exists.

Internal errors-
1.DAO error has occurred while retrieving entity by name.
2.DAO error has occurred while retrieving entity by id.
3.DAO error has occurred while persisting an entity
2.A mapping error has occurred.
3.An unexpected error has occurred at business layer
4.An unexpected error has occurred at service layer.

Sample Request - 
ServiceRequest [header=ServiceHeader [headerAttributes=null], payload=Service[category=DATA,description=TEST_SERVICE_DESCRIPTION,owner=TEST_SERVICE_OWNER,name=NEW_NAME_1356056589974,applicationId=TEST_SERVICE_APPLICATION_ID,domain=B2B,usage=INTERNAL,serviceVersions=[],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:10.036,modifiedBy=<null>,modifiedAt=<null>,id=42d7bbfd-d66b-4e07-a324-c0cb4804b83d,status=ACTIVE,resourceUri=<null>]]
ServiceRequest<Service> updateServiceReq = new ServiceRequest<Service>(
					new ServiceHeader(), service);
			
ServiceResponse<Service> updateServiceRes = registryServiceClient
					.updateService(updateRequest);


Sample Response - 
ServiceResponse [status=OK, header=ServiceHeader [headerAttributes={}], errors=[], payload=Service[category=DATA,description=TEST_SERVICE_DESCRIPTION,owner=TEST_SERVICE_OWNER,name=NEW_NAME_1356056589974,applicationId=TEST_SERVICE_APPLICATION_ID,domain=B2B,usage=INTERNAL,serviceVersions=[],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:10.036,modifiedBy=<null>,modifiedAt=<null>,id=42d7bbfd-d66b-4e07-a324-c0cb4804b83d,status=ACTIVE,resourceUri=<null>]]

```

###5.Delete a Service by ID
```
Description - This API is used to delete a Service for given serviceId.
              Service status is changed to 'DELETED'

URL - {HostUrl}/registry/service/{serviceId}

Request/Header parameters - 

Errors -
Validation errors-
1.Invalid service id.
2.Service not found.

Internal errors-
1.DAO error has occurred while retrieving entity by id.
2.DAO error has occurred while persisting an entity
3.An unexpected error has occurred at business layer
4.An unexpected error has occurred at service layer.
 

Sample Request - 
ServiceResponse<Service> deleteServiceResp = registryServiceClient
					.deleteService(serviceId);
	
Sample Response -
ServiceResponse [status=OK, header=ServiceHeader [headerAttributes={}], errors=[], payload=null]

```

###7.Find Services by matching service name
```
Description - This API is used to retrieve details of Services matching the given name 
        
URL - {HostUrl}/registry/search/{serviceName}

Request/Header parameters - 

Errors - 
Validation errors-
1.Invalid service name.

Internal errors-
1.DAO error has occurred while retrieving entities by matching name.
2.A mapping error has occurred.
3.An unexpected error has occurred at business layer
4.An unexpected error has occurred at service layer.
 
Sample Request - 
ServiceResponse<ServiceList> findResp = registryServiceClient
					.findServices(serviceName);


Sample Response -
ServiceResponse [status=OK, header=ServiceHeader [headerAttributes={}], errors=[], payload=ServiceList[services=[Service[category=<null>,description=TEST_SERVICE_DESCRIPTION,owner=TEST_SERVICE_OWNER,name=TEST_SERVICE_NAME1356056585739,applicationId=TEST_SERVICE_APPLICATION_ID,domain=<null>,usage=<null>,serviceVersions=[],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:05.77,modifiedBy=soari_registry_app,modifiedAt=2012-12-20 18:23:05.817,id=0ee88939-ab43-4642-9685-69ffce0b4019,status=DELETED,resourceUri=<null>], Service[category=<null>,description=TEST_SERVICE_DESCRIPTION,owner=TEST_SERVICE_OWNER,name=TEST_SERVICE_NAME1356056589302,applicationId=TEST_SERVICE_APPLICATION_ID,domain=<null>,usage=<null>,serviceVersions=[],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:09.364,modifiedBy=<null>,modifiedAt=<null>,id=1b643071-4584-41b6-abda-081161f21046,status=ACTIVE,resourceUri=<null>], Service[category=<null>,description=TEST_SERVICE_DESCRIPTION,owner=TEST_SERVICE_OWNER,name=TEST_SERVICE_NAME1356056588270,applicationId=TEST_SERVICE_APPLICATION_ID,domain=<null>,usage=<null>,serviceVersions=[],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:08.302,modifiedBy=<null>,modifiedAt=<null>,id=21fd8507-2c32-441d-9306-16f83e35c62e,status=ACTIVE,resourceUri=<null>], Service[category=<null>,description=TEST_SERVICE_DESCRIPTION,owner=TEST_SERVICE_OWNER,name=TEST_SERVICE_NAME1356056589380,applicationId=TEST_SERVICE_APPLICATION_ID,domain=<null>,usage=<null>,serviceVersions=[],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:09.427,modifiedBy=<null>,modifiedAt=<null>,id=2640629d-b628-41d5-bab2-7536a7267f1b,status=ACTIVE,resourceUri=<null>], Service[category=<null>,description=TEST_SERVICE_DESCRIPTION,owner=TEST_SERVICE_OWNER,name=TEST_SERVICE_NAME1356056584098,applicationId=TEST_SERVICE_APPLICATION_ID,domain=<null>,usage=<null>,serviceVersions=[ServiceVersion[activationEndDate=Thu Dec 20 18:23:04 PST 2012,activationStartDate=Thu Dec 20 18:23:04 PST 2012,availabilityTier=<null>,urls=[],environment=DEV,publicationDate=Thu Dec 20 18:23:04 PST 2012,serVersion=1.0.0,qasParameters=[],policies=[],service=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:04.192,modifiedBy=<null>,modifiedAt=<null>,id=d2334719-8afb-469e-b0ca-3b0170ada751,status=ACTIVE,resourceUri=<null>], ServiceVersion[activationEndDate=Thu Dec 20 18:23:04 PST 2012,activationStartDate=Thu Dec 20 18:23:04 PST 2012,availabilityTier=<null>,urls=[],environment=DEV,publicationDate=Thu Dec 20 18:23:04 PST 2012,serVersion=2.0.0,qasParameters=[],policies=[],service=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:04.286,modifiedBy=<null>,modifiedAt=<null>,id=1b6e4c3e-c37a-40a0-b4b0-18f000b78108,status=ACTIVE,resourceUri=<null>]],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:04.177,modifiedBy=<null>,modifiedAt=<null>,id=27c799f8-747c-4513-8655-03d3eb1edcc7,status=ACTIVE,resourceUri=<null>], Service[category=<null>,description=TEST_SERVICE_DESCRIPTION,owner=TEST_SERVICE_OWNER,name=TEST_SERVICE_NAME1356056588442,applicationId=TEST_SERVICE_APPLICATION_ID,domain=<null>,usage=<null>,serviceVersions=[ServiceVersion[activationEndDate=Thu Dec 20 18:23:08 PST 2012,activationStartDate=Thu Dec 20 18:23:08 PST 2012,availabilityTier=<null>,urls=[],environment=DEV,publicationDate=Thu Dec 20 18:23:08 PST 2012,serVersion=1.0.0,qasParameters=[],policies=[],service=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:08.505,modifiedBy=<null>,modifiedAt=<null>,id=965ad330-5dad-414c-be59-559ff96b43b0,status=ACTIVE,resourceUri=<null>]],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:08.505,modifiedBy=<null>,modifiedAt=<null>,id=28c997de-6b11-4053-b640-3895d6ce00ce,status=ACTIVE,resourceUri=<null>], Service[category=<null>,description=TEST_SERVICE_DESCRIPTION,owner=TEST_SERVICE_OWNER,name=TEST_SERVICE_NAME1356056586770,applicationId=TEST_SERVICE_APPLICATION_ID,domain=<null>,usage=<null>,serviceVersions=[ServiceVersion[activationEndDate=Thu Dec 20 18:23:06 PST 2012,activationStartDate=Thu Dec 20 18:23:06 PST 2012,availabilityTier=<null>,urls=[],environment=DEV,publicationDate=Thu Dec 20 18:23:06 PST 2012,serVersion=1.0.0,qasParameters=[QaSParameter[paramName=TEST_SERVICE_PARAMETER_NAME1356056586770,paramValue=TEST_SERVICE_PARAMETER_VALUE,parentParamId=<null>,serviceVersion=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:06.817,modifiedBy=<null>,modifiedAt=<null>,id=9ee5248c-4546-4eb9-889f-f3f45b6c5d71,status=ACTIVE,resourceUri=<null>]],policies=[],service=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:06.817,modifiedBy=soari_registry_app,modifiedAt=2012-12-20 18:23:06.895,id=996e662c-54ef-41c9-b303-975f786542af,status=DELETED,resourceUri=<null>]],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:06.817,modifiedBy=<null>,modifiedAt=<null>,id=29d0802f-3e9e-4d5b-9e87-72b569121084,status=ACTIVE,resourceUri=<null>], Service[category=<null>,description=TEST_SERVICE_DESCRIPTION,owner=TEST_SERVICE_OWNER,name=TEST_SERVICE_NAME1356056586974,applicationId=TEST_SERVICE_APPLICATION_ID,domain=<null>,usage=<null>,serviceVersions=[ServiceVersion[activationEndDate=Thu Dec 20 18:23:06 PST 2012,activationStartDate=Thu Dec 20 18:23:06 PST 2012,availabilityTier=<null>,urls=[],environment=DEV,publicationDate=Thu Dec 20 18:23:06 PST 2012,serVersion=1.0.0,qasParameters=[QaSParameter[paramName=TEST_SERVICE_PARAMETER_NAME1356056586974,paramValue=TEST_SERVICE_PARAMETER_VALUE,parentParamId=<null>,serviceVersion=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:07.02,modifiedBy=soari_registry_app,modifiedAt=2012-12-20 18:23:07.099,id=28a7c6d6-8df0-44fb-af80-04754fc48d5f,status=DELETED,resourceUri=<null>]],policies=[],service=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:07.02,modifiedBy=<null>,modifiedAt=<null>,id=3de0d8b1-7089-4eb8-8750-8aea4a2b35bd,status=ACTIVE,resourceUri=<null>]],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:07.02,modifiedBy=<null>,modifiedAt=<null>,id=3acda707-66d6-456e-a36b-30adf8807f85,status=ACTIVE,resourceUri=<null>], Service[category=<null>,description=TEST_SERVICE_DESCRIPTION,owner=TEST_SERVICE_OWNER,name=TEST_SERVICE_NAME1356056585208,applicationId=TEST_SERVICE_APPLICATION_ID,domain=<null>,usage=<null>,serviceVersions=[ServiceVersion[activationEndDate=Thu Dec 20 18:23:05 PST 2012,activationStartDate=Thu Dec 20 18:23:05 PST 2012,availabilityTier=<null>,urls=[],environment=DEV,publicationDate=Thu Dec 20 18:23:05 PST 2012,serVersion=1.0.0,qasParameters=[QaSParameter[paramName=TEST_SERVICE_PARAMETER_NAME1356056585208,paramValue=TEST_SERVICE_PARAMETER_VALUE,parentParamId=<null>,serviceVersion=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:05.302,modifiedBy=<null>,modifiedAt=<null>,id=0bb589a2-af2f-4b42-b428-8c58ae48a1d6,status=ACTIVE,resourceUri=<null>]],policies=[Policy[active=true,name=TEST_POLICY1356056585364,url=<null>,version=TEST_POLICY_VERSION1,serviceVersions=[],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:05.395,modifiedBy=<null>,modifiedAt=<null>,id=bae4863d-d40f-437f-8493-57ebc28b43b5,status=ACTIVE,resourceUri=<null>]],service=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:05.302,modifiedBy=<null>,modifiedAt=<null>,id=bec1aeb6-f355-412c-a111-5f22d015849d,status=ACTIVE,resourceUri=<null>]],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:05.302,modifiedBy=<null>,modifiedAt=<null>,id=4b034b61-13f9-4a8d-ba29-1ee208900581,status=ACTIVE,resourceUri=<null>], Service[category=<null>,description=TEST_SERVICE_DESCRIPTION,owner=TEST_SERVICE_OWNER,name=TEST_SERVICE_NAME1356056584958,applicationId=TEST_SERVICE_APPLICATION_ID,domain=<null>,usage=<null>,serviceVersions=[ServiceVersion[activationEndDate=Thu Dec 20 18:23:04 PST 2012,activationStartDate=Thu Dec 20 18:23:04 PST 2012,availabilityTier=<null>,urls=[],environment=DEV,publicationDate=Thu Dec 20 18:23:04 PST 2012,serVersion=1.0.0,qasParameters=[QaSParameter[paramName=TEST_SERVICE_PARAMETER_NAME1356056584958,paramValue=TEST_SERVICE_PARAMETER_VALUE,parentParamId=<null>,serviceVersion=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:05.036,modifiedBy=<null>,modifiedAt=<null>,id=bb0aa7c0-293b-4e1d-856c-82bc4f58d34b,status=ACTIVE,resourceUri=<null>]],policies=[],service=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:05.036,modifiedBy=<null>,modifiedAt=<null>,id=c558706e-4425-4a5e-b743-1e67319a44c0,status=ACTIVE,resourceUri=<null>]],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:05.036,modifiedBy=<null>,modifiedAt=<null>,id=4ea5a21c-642c-4eff-92e2-47116a42db1b,status=ACTIVE,resourceUri=<null>], Service[category=<null>,description=TEST_SERVICE_DESCRIPTION,owner=TEST_SERVICE_OWNER,name=TEST_SERVICE_NAME1356056570911,applicationId=TEST_SERVICE_APPLICATION_ID,domain=<null>,usage=<null>,serviceVersions=[],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:01.958,modifiedBy=<null>,modifiedAt=<null>,id=539493eb-5b34-4b71-a6ff-93b93b082573,status=ACTIVE,resourceUri=<null>], Service[category=<null>,description=TEST_SERVICE_DESCRIPTION,owner=TEST_SERVICE_OWNER,name=TEST_SERVICE_NAME1356056587208,applicationId=TEST_SERVICE_APPLICATION_ID,domain=<null>,usage=<null>,serviceVersions=[ServiceVersion[activationEndDate=Thu Dec 20 18:23:07 PST 2012,activationStartDate=Thu Dec 20 18:23:07 PST 2012,availabilityTier=<null>,urls=[],environment=DEV,publicationDate=Thu Dec 20 18:23:07 PST 2012,serVersion=1.0.0,qasParameters=[QaSParameter[paramName=TEST_SERVICE_PARAMETER_NAME1356056587208,paramValue=TEST_SERVICE_PARAMETER_VALUE,parentParamId=<null>,serviceVersion=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:07.27,modifiedBy=<null>,modifiedAt=<null>,id=79ad88a9-0cea-4bb5-a613-23d2c7f3322f,status=ACTIVE,resourceUri=<null>]],policies=[Policy[active=true,name=TEST_POLICY1356056587302,url=<null>,version=TEST_POLICY_VERSION1,serviceVersions=[],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:07.349,modifiedBy=<null>,modifiedAt=<null>,id=662f8a10-1f04-464b-a23a-b628548f8817,status=ACTIVE,resourceUri=<null>]],service=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:07.27,modifiedBy=<null>,modifiedAt=<null>,id=170e3a82-8065-4efc-8a91-d0e1263de55b,status=ACTIVE,resourceUri=<null>]],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:07.27,modifiedBy=<null>,modifiedAt=<null>,id=8e46af22-b051-48da-9689-adca79c5d3e6,status=ACTIVE,resourceUri=<null>], Service[category=<null>,description=TEST_SERVICE_DESCRIPTION,owner=TEST_SERVICE_OWNER,name=TEST_SERVICE_NAME1356056588786,applicationId=TEST_SERVICE_APPLICATION_ID,domain=<null>,usage=<null>,serviceVersions=[ServiceVersion[activationEndDate=Thu Dec 20 18:23:08 PST 2012,activationStartDate=Thu Dec 20 18:23:08 PST 2012,availabilityTier=<null>,urls=[],environment=DEV,publicationDate=Thu Dec 20 18:23:08 PST 2012,serVersion=1.0.0,qasParameters=[QaSParameter[paramName=TEST_SERVICE_PARAMETER_NAME1356056588786,paramValue=TEST_SERVICE_PARAMETER_VALUE,parentParamId=<null>,serviceVersion=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:08.849,modifiedBy=<null>,modifiedAt=<null>,id=f6d30f14-6c96-4295-b332-6045dd14b046,status=ACTIVE,resourceUri=<null>]],policies=[Policy[active=true,name=TEST_POLICY1356056588895,url=<null>,version=TEST_POLICY_VERSION1,serviceVersions=[],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:08.974,modifiedBy=<null>,modifiedAt=<null>,id=6d400c99-8b8c-4053-93a1-40b52f261a4d,status=ACTIVE,resourceUri=<null>], Policy[active=true,name=TEST_POLICY1356056589067,url=<null>,version=TEST_POLICY_VERSION1,serviceVersions=[],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:09.083,modifiedBy=<null>,modifiedAt=<null>,id=4ce4ac33-c78c-424e-abfd-368cca80227b,status=ACTIVE,resourceUri=<null>]],service=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:08.849,modifiedBy=<null>,modifiedAt=<null>,id=b311cdde-2494-48ba-98d2-7fb1beba3947,status=ACTIVE,resourceUri=<null>]],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:08.849,modifiedBy=<null>,modifiedAt=<null>,id=90d4eec3-eadf-49fe-9ae6-c146bb115ee0,status=ACTIVE,resourceUri=<null>], Service[category=<null>,description=TEST_SERVICE_DESCRIPTION,owner=TEST_SERVICE_OWNER,name=TEST_SERVICE_NAME1356056588192,applicationId=TEST_SERVICE_APPLICATION_ID,domain=<null>,usage=<null>,serviceVersions=[],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:08.224,modifiedBy=<null>,modifiedAt=<null>,id=93a57cb5-885e-41f2-9841-d1122e093d88,status=ACTIVE,resourceUri=<null>], Service[category=<null>,description=TEST_SERVICE_DESCRIPTION,owner=TEST_SERVICE_OWNER,name=TEST_SERVICE_NAME1356056584630,applicationId=TEST_SERVICE_APPLICATION_ID,domain=<null>,usage=<null>,serviceVersions=[ServiceVersion[activationEndDate=Thu Dec 20 18:23:04 PST 2012,activationStartDate=Thu Dec 20 18:23:04 PST 2012,availabilityTier=<null>,urls=[],environment=DEV,publicationDate=Thu Dec 20 18:23:04 PST 2012,serVersion=1.0.0,qasParameters=[QaSParameter[paramName=TEST_SERVICE_PARAMETER_NAME1356056584630,paramValue=TEST_SERVICE_PARAMETER_VALUE,parentParamId=<null>,serviceVersion=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:04.739,modifiedBy=<null>,modifiedAt=<null>,id=6bba534a-75e0-4714-89d7-b181e9d51e22,status=ACTIVE,resourceUri=<null>], QaSParameter[paramName=TEST_SERVICE_PARAMETER_NAME1356056584786,paramValue=TEST_SERVICE_PARAMETER_VALUE,parentParamId=<null>,serviceVersion=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:04.864,modifiedBy=<null>,modifiedAt=<null>,id=ddb73465-156b-4f57-a47a-e54cbe06315b,status=ACTIVE,resourceUri=<null>]],policies=[],service=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:04.739,modifiedBy=<null>,modifiedAt=<null>,id=2e988aac-a1be-47f6-b2e9-c0c69ef88a92,status=ACTIVE,resourceUri=<null>]],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:04.739,modifiedBy=<null>,modifiedAt=<null>,id=a7409c6f-a06f-4158-bca3-4fbf070eaddc,status=ACTIVE,resourceUri=<null>], Service[category=<null>,description=TEST_SERVICE_DESCRIPTION,owner=TEST_SERVICE_OWNER,name=TEST_SERVICE_NAME1356056585630,applicationId=TEST_SERVICE_APPLICATION_ID,domain=<null>,usage=<null>,serviceVersions=[ServiceVersion[activationEndDate=Thu Dec 20 18:23:05 PST 2012,activationStartDate=Thu Dec 20 18:23:05 PST 2012,availabilityTier=<null>,urls=[],environment=DEV,publicationDate=Thu Dec 20 18:23:05 PST 2012,serVersion=1.0.0,qasParameters=[QaSParameter[paramName=TEST_SERVICE_PARAMETER_NAME,paramValue=TEST_SERVICE_PARAMETER_VALUE,parentParamId=<null>,serviceVersion=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:05.692,modifiedBy=<null>,modifiedAt=<null>,id=db2f3aae-66d2-46a9-a196-36ad1e44c54f,status=ACTIVE,resourceUri=<null>]],policies=[],service=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:05.692,modifiedBy=<null>,modifiedAt=<null>,id=681fdb70-7762-4e0e-a251-8d1344f84777,status=ACTIVE,resourceUri=<null>]],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:05.692,modifiedBy=<null>,modifiedAt=<null>,id=ab1664e1-c6b0-4e1f-8cce-ad1267f191c9,status=ACTIVE,resourceUri=<null>], Service[category=<null>,description=TEST_SERVICE_DESCRIPTION,owner=TEST_SERVICE_OWNER,name=TEST_SERVICE_NAME1356056583317,applicationId=TEST_SERVICE_APPLICATION_ID,domain=<null>,usage=<null>,serviceVersions=[],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:03.411,modifiedBy=<null>,modifiedAt=<null>,id=bd012606-8efe-47a6-a2a7-6bc036795bd8,status=ACTIVE,resourceUri=<null>], Service[category=<null>,description=TEST_SERVICE_DESCRIPTION,owner=TEST_SERVICE_OWNER,name=TEST_SERVICE_NAME1356056584380,applicationId=TEST_SERVICE_APPLICATION_ID,domain=<null>,usage=<null>,serviceVersions=[ServiceVersion[activationEndDate=Thu Dec 20 18:23:04 PST 2012,activationStartDate=Thu Dec 20 18:23:04 PST 2012,availabilityTier=<null>,urls=[],environment=DEV,publicationDate=Thu Dec 20 18:23:04 PST 2012,serVersion=1.0.0,qasParameters=[],policies=[],service=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:04.427,modifiedBy=<null>,modifiedAt=<null>,id=139c73d9-05c5-4dc1-96ef-2caad6beb3d5,status=ACTIVE,resourceUri=<null>]],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:04.427,modifiedBy=<null>,modifiedAt=<null>,id=cd4fcf8b-975b-4b28-83a7-9b0ba6a59068,status=ACTIVE,resourceUri=<null>], Service[category=<null>,description=TEST_SERVICE_DESCRIPTION,owner=TEST_SERVICE_OWNER,name=TEST_SERVICE_NAME1356056585536,applicationId=TEST_SERVICE_APPLICATION_ID,domain=<null>,usage=<null>,serviceVersions=[ServiceVersion[activationEndDate=Thu Dec 20 18:23:05 PST 2012,activationStartDate=Thu Dec 20 18:23:05 PST 2012,availabilityTier=<null>,urls=[],environment=DEV,publicationDate=Thu Dec 20 18:23:05 PST 2012,serVersion=1.0.0,qasParameters=[],policies=[],service=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:05.567,modifiedBy=<null>,modifiedAt=<null>,id=8d106aa1-effd-4531-974d-910a563c1c09,status=ACTIVE,resourceUri=<null>]],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:05.567,modifiedBy=<null>,modifiedAt=<null>,id=e4717707-84ff-47fe-abdb-cc517fc11bbd,status=ACTIVE,resourceUri=<null>], Service[category=<null>,description=TEST_SERVICE_DESCRIPTION,owner=TEST_SERVICE_OWNER,name=TEST_SERVICE_NAME1356056588614,applicationId=TEST_SERVICE_APPLICATION_ID,domain=<null>,usage=<null>,serviceVersions=[ServiceVersion[activationEndDate=Thu Dec 20 18:23:08 PST 2012,activationStartDate=Thu Dec 20 18:23:08 PST 2012,availabilityTier=<null>,urls=[],environment=DEV,publicationDate=Thu Dec 20 18:23:08 PST 2012,serVersion=1.0.0,qasParameters=[QaSParameter[paramName=TEST_SERVICE_PARAMETER_NAME1356056588614,paramValue=TEST_SERVICE_PARAMETER_VALUE,parentParamId=<null>,serviceVersion=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:08.677,modifiedBy=<null>,modifiedAt=<null>,id=a017d6be-9535-4e20-92e2-de0c5a115841,status=ACTIVE,resourceUri=<null>]],policies=[],service=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 18:23:08.677,modifiedBy=<null>,modifiedAt=<null>,id=a6949f54-8cf9-47dc-bf3c-86f804c5024a,status=ACTIVE,resourceUri=<null>]],createdBy=soari_registry_app,createdAt=2012-12-20 18:23:08.677,modifiedBy=<null>,modifiedAt=<null>,id=fec8a93d-e4ba-4159-b8c4-57cfe7b2af1e,status=ACTIVE,resourceUri=<null>]]]]

```

###8.Get Service Version details by Service ID and Version
```
Description - This API is used to retrieve details of Service Version for given Service ID and Version 
        
URL - {HostUrl}/registry/version/{serviceId}/{serviceVersion}

Request/Header parameters - 

Errors - 
Validation error-
1.Invalid service id.
2.Invalid service version number.

Internal errors-
1.DAO error has occurred while retrieving service version by version number.
2.A mapping error has occurred.
3.An unexpected error has occurred at business layer
4.An unexpected error has occurred at service layer.

Sample Request - 
ServiceResponse<ServiceVersion> getResp = 
registryServiceClient.getServiceVersion(serviceId,serviceVersionNumber));


Sample Response - 
ServiceResponse [status=OK, header=ServiceHeader [headerAttributes={}], errors=[], payload=ServiceVersion[activationEndDate=Thu Dec 20 19:02:35 PST 2012,activationStartDate=Thu Dec 20 19:02:35 PST 2012,availabilityTier=<null>,urls=[],environment=DEV,publicationDate=Thu Dec 20 19:02:35 PST 2012,serVersion=1.0.0,qasParameters=[],policies=[],service=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 19:02:35.581,modifiedBy=<null>,modifiedAt=<null>,id=bbdb6d7a-7e45-48e1-bd70-dc5ff93bd544,status=ACTIVE,resourceUri=<null>]]
```

###9.Create a Service Version for given Service ID
```
Description - This API is used to add/create a Service Version for given Service ID
        
URL - {HostUrl}/registry/version/{serviceId}

Request/Header parameters - 

Errors - 
Validation error-
1.Invalid service id.
2.Invalid service version number.
3.Service not found.
4.Service version already exists.

Internal errors-
1.DAO error has occurred while retrieving entity by id.
2.DAO error has occurred while retrieving service version by version number.
3.DAO error has occurred while persisting an entity
4.A mapping error has occurred.
5.An unexpected error has occurred at business layer
6.An unexpected error has occurred at service layer.

Sample Request - 
ServiceRequest [header=ServiceHeader [headerAttributes=null], payload=ServiceVersion[activationEndDate=Thu Dec 20 19:02:30 PST 2012,activationStartDate=Thu Dec 20 19:02:30 PST 2012,availabilityTier=TIER1,urls=[com.walmart.platform.soari.registry.common.dto.Url@1b7a261, com.walmart.platform.soari.registry.common.dto.Url@105c9a1, com.walmart.platform.soari.registry.common.dto.Url@f877e9],environment=DEV,publicationDate=Thu Dec 20 19:02:30 PST 2012,serVersion=2.0.0,qasParameters=[],policies=[],service=<null>,createdBy=<null>,createdAt=<null>,modifiedBy=<null>,modifiedAt=<null>,id=<null>,status=ACTIVE,resourceUri=<null>]]

ServiceRequest<ServiceVersion> addServiceVersionReq = 
	new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion);
			
ServiceResponse<ServiceVersion> addServiceVersionRes = 	registryServiceClient.addServiceVersion(service.getId(), addServiceVersionReq);


Sample Response - 
ServiceResponse [status=OK, header=ServiceHeader [headerAttributes={}], errors=[], payload=ServiceVersion[activationEndDate=Thu Dec 20 19:02:30 PST 2012,activationStartDate=Thu Dec 20 19:02:30 PST 2012,availabilityTier=TIER1,urls=[com.walmart.platform.soari.registry.common.dto.Url@c7c57c, com.walmart.platform.soari.registry.common.dto.Url@17689bc, com.walmart.platform.soari.registry.common.dto.Url@14cbc58],environment=DEV,publicationDate=Thu Dec 20 19:02:30 PST 2012,serVersion=2.0.0,qasParameters=[],policies=[],service=<null>,createdBy=<null>,createdAt=<null>,modifiedBy=<null>,modifiedAt=<null>,id=<null>,status=ACTIVE,resourceUri=<null>]]
```

###10.Update a Service Version for given Service Version ID
```
Description - This API is used to update a Service Version for given Service id.
              Create Service version if doesn't exists. 
        
URL - {HostUrl}/registry/version/{serviceId}

Request/Header parameters - 

Errors - 
Validation error-
1.Invalid service id.
2.Invalid service version number.
3.Service version already exists.

Internal errors-
1.DAO error has occurred while retrieving entity by id.
2.DAO error has occurred while retrieving service version by version number.
3.DAO error has occurred while persisting an entity
4.A mapping error has occurred.
5.An unexpected error has occurred at business layer
6.An unexpected error has occurred at service layer.

Sample Request - 
ServiceRequest [header=ServiceHeader [headerAttributes=null], payload=ServiceVersion[activationEndDate=Thu Dec 20 19:02:37 PST 2012,activationStartDate=Thu Dec 20 19:02:37 PST 2012,availabilityTier=TIER1,urls=[com.walmart.platform.soari.registry.common.dto.Url@117225f, com.walmart.platform.soari.registry.common.dto.Url@1d195ca, com.walmart.platform.soari.registry.common.dto.Url@c1121e],environment=DEV,publicationDate=Thu Dec 20 19:02:37 PST 2012,serVersion=2.0.0,qasParameters=[QaSParameter[paramName=TEST_SERVICE_PARAMETER_NAME1356058957612,paramValue=TEST_SERVICE_PARAMETER_VALUE,parentParamId=<null>,serviceVersion=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 19:02:37.737,modifiedBy=<null>,modifiedAt=<null>,id=dae04f12-cb1d-4a04-b058-c1ad95bed111,status=ACTIVE,resourceUri=<null>]],policies=[],service=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 19:02:37.737,modifiedBy=<null>,modifiedAt=<null>,id=7a96429d-42f4-49fe-a13f-78212ac25c16,status=ACTIVE,resourceUri=<null>]]

ServiceRequest<ServiceVersion> updateServiceVersionReq = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion);

ServiceResponse<ServiceVersion> updateServiceVersionRes = registryServiceClient
					.updateServiceVersion(serviceId,updateServiceVersionReq);


Sample Response - 
ServiceResponse [status=OK, header=ServiceHeader [headerAttributes={}], errors=[], payload=ServiceVersion[activationEndDate=Thu Dec 20 19:02:37 PST 2012,activationStartDate=Thu Dec 20 19:02:37 PST 2012,availabilityTier=TIER1,urls=[com.walmart.platform.soari.registry.common.dto.Url@cba8e1, com.walmart.platform.soari.registry.common.dto.Url@bc6e09, com.walmart.platform.soari.registry.common.dto.Url@dc362d],environment=DEV,publicationDate=Thu Dec 20 19:02:37 PST 2012,serVersion=2.0.0,qasParameters=[QaSParameter[paramName=TEST_SERVICE_PARAMETER_NAME1356058957612,paramValue=TEST_SERVICE_PARAMETER_VALUE,parentParamId=<null>,serviceVersion=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 19:02:37.737,modifiedBy=<null>,modifiedAt=<null>,id=dae04f12-cb1d-4a04-b058-c1ad95bed111,status=ACTIVE,resourceUri=<null>]],policies=[],service=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 19:02:37.737,modifiedBy=<null>,modifiedAt=<null>,id=7a96429d-42f4-49fe-a13f-78212ac25c16,status=ACTIVE,resourceUri=<null>]]
Update QaS res= ServiceResponse [status=OK, header=ServiceHeader [headerAttributes={}], errors=[], payload=QaSParameter[paramName=TEST_SERVICE_PARAMETER_NAME1356058958784,paramValue=TEST_SERVICE_PARAMETER_VALUE,parentParamId=<null>,serviceVersion=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 19:02:38.753,modifiedBy=<null>,modifiedAt=<null>,id=b15f1272-2e9c-41ce-b158-3eb8c7a4a4ac,status=ACTIVE,resourceUri=<null>]]
```

###11.Delete a Service Version by versionId
```
Description - This API is used to delete a Service Version by given Service Version ID
        
URL - {HostUrl}/registry/version/{versionId}

Request/Header parameters - 

Errors - 
Validation error-
1.Invalid service version id.
2.Service version not found

Internal errors-
1.DAO error has occurred while retrieving entity by id.
2.DAO error has occurred while persisting an entity
3.An unexpected error has occurred at business layer
4.An unexpected error has occurred at service layer.

Sample Request - 
ServiceResponse<ServiceVersion> deleteServiceVersionResp = registryServiceClient
					.deleteServiceVersion(serviceVersionId);


Sample Response -
ServiceResponse [status=OK, header=ServiceHeader [headerAttributes={}], errors=[], payload=null] 
```

###12.Get ServiceVersion Policies by serviceVersionId
```
Description - This API is used to get details of Policies applied on ServiceVersion for given                                           serviceVersionId
        
URL - {HostUrl}/registry/policy/{serviceVersionId}

Request/Header parameters - 

Errors - 
Validation error-
1.Invalid service version id.
2.Service version not found

Internal errors-
1.DAO error has occurred while retrieving entity by id.
2.A mapping error has occurred.
3.An unexpected error has occurred at business layer
4.An unexpected error has occurred at service layer.

Sample Request - 
ServiceResponse<PolicyList> getPoliciesResp = 
registryServiceClient.getServiceVersionPolicies(serviceVersionId));


Sample Response - 
ServiceResponse [status=OK, header=ServiceHeader [headerAttributes={}], errors=[], payload=PolicyList[policies=[Policy[active=true,name=TEST_POLICY1356058956081,url=<null>,version=TEST_POLICY_VERSION1,serviceVersions=[],createdBy=soari_registry_app,createdAt=2012-12-20 19:02:36.112,modifiedBy=<null>,modifiedAt=<null>,id=aaab5aef-93b4-45f3-9501-d8df700567c7,status=ACTIVE,resourceUri=<null>], Policy[active=true,name=TEST_POLICY1356058955940,url=<null>,version=TEST_POLICY_VERSION1,serviceVersions=[],createdBy=soari_registry_app,createdAt=2012-12-20 19:02:35.987,modifiedBy=<null>,modifiedAt=<null>,id=1835b11e-a08a-43a3-8494-bf418884f113,status=ACTIVE,resourceUri=<null>]]]]
```

###13.Add Policy to ServiceVersion by given serviceVersionId and policyId
```
Description - This API is used to add Policy by given policyId to ServiceVersion for given serviceVersionId    
URL - {HostUrl}/registry/policy/{serviceVersionId}/{policyId}

Request/Header parameters - 

Errors - 
Validation error-
1.Invalid service version id.
2.Service version not found
3.Invalid policy id.
4.Policy not found.

Internal errors-
1.DAO error has occurred while retrieving entity by id.
2.DAO error has occurred while persisting an entity
3.A mapping error has occurred.
4.An unexpected error has occurred at business layer
5.An unexpected error has occurred at service layer.

Sample Request - 
ServiceRequest [header=ServiceHeader [headerAttributes=null], payload=Policy[active=true,name=TEST_POLICY1356058952034,url=<null>,version=TEST_POLICY_VERSION1,serviceVersions=[],createdBy=<null>,createdAt=<null>,modifiedBy=<null>,modifiedAt=<null>,id=<null>,status=ACTIVE,resourceUri=<null>]]

ServiceRequest<Policy> addPolicyReq = new ServiceRequest<Policy>(
					new ServiceHeader(), policy);

ServiceResponse<Policy> addPolicyResp = policyServiceClient
					.addPolicy(addPolicyReq);


Sample Response - 
ServiceResponse [status=OK, header=ServiceHeader [headerAttributes={}], errors=[], payload=Policy[active=true,name=TEST_POLICY1356058952034,url=<null>,version=TEST_POLICY_VERSION1,serviceVersions=[],createdBy=soari_registry_app,createdAt=2012-12-20 19:02:32.08,modifiedBy=<null>,modifiedAt=<null>,id=0c06e504-c0eb-44c5-85ef-163ee6d02e9c,status=ACTIVE,resourceUri=<null>]]
```

###14.Remove a Policy from ServiceVersion by given serviceVersionId and policyId
```
Description - This API is used to disable/remove a Policy by given policyId from ServiceVersion for given serviceVersionId    
URL - {HostUrl}/registry/policy/{serviceVersionId}/{policyId}

Request/Header parameters - 

Errors - 
Validation error-
1.Invalid service version id.
2.Service version not found
3.Invalid policy id.
4.Policy not found.

Internal errors-
1.DAO error has occurred while retrieving entity by id.
2.DAO error has occurred while persisting an entity
3.A mapping error has occurred.
4.An unexpected error has occurred at business layer
5.An unexpected error has occurred at service layer.

Sample Request - 
ServiceResponse<ServiceVersion> deleteServiceVersionPolicyResp = registryServiceClient.deleteServiceVersionPolicy(serviceVersionId,
							policyId);

Sample Response -
ServiceResponse [status=OK, header=ServiceHeader [headerAttributes={}], errors=[], payload=ServiceVersion[activationEndDate=Thu Dec 20 19:02:34 PST 2012,activationStartDate=Thu Dec 20 19:02:34 PST 2012,availabilityTier=<null>,urls=[],environment=DEV,publicationDate=Thu Dec 20 19:02:34 PST 2012,serVersion=1.0.0,qasParameters=[QaSParameter[paramName=TEST_SERVICE_PARAMETER_NAME1356058954518,paramValue=TEST_SERVICE_PARAMETER_VALUE,parentParamId=<null>,serviceVersion=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 19:02:34.581,modifiedBy=<null>,modifiedAt=<null>,id=531a50de-a425-448a-8dca-130865ea2a86,status=ACTIVE,resourceUri=<null>]],policies=[Policy[active=true,name=TEST_POLICY1356058954596,url=<null>,version=TEST_POLICY_VERSION1,serviceVersions=[],createdBy=soari_registry_app,createdAt=2012-12-20 19:02:34.643,modifiedBy=<null>,modifiedAt=<null>,id=2c63b8e0-24ef-437b-9b84-c704b4773d3f,status=ACTIVE,resourceUri=<null>]],service=<null>,createdBy=soari_registry_app,createdAt=2012-12-2 
```

###15.Get QaS Parameters for ServiceVersion by serviceVersionId
```
Description - This API is used to get details of QaS parameters for ServiceVersion by given serviceVersionId    
URL - {HostUrl}/registry/qas/{serviceVersionId}

Request/Header parameters - 

Errors - 
Validation error-
1.Invalid service version id.

Internal errors-
1.DAO error has occurred while retrieving entity by id.
2.A mapping error has occurred.
3.An unexpected error has occurred at business layer
4.An unexpected error has occurred at service layer.

Sample Request - 

Sample Response -
Get QaS res= ServiceResponse [status=OK, header=ServiceHeader [headerAttributes={}], errors=[], payload=QaSParameterList[qasParameters=[QaSParameter[paramName=TEST_SERVICE_PARAMETER_NAME1356060794436,paramValue=TEST_SERVICE_PARAMETER_VALUE,parentParamId=<null>,serviceVersion=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 19:33:14.514,modifiedBy=<null>,modifiedAt=<null>,id=f682b0be-0c16-4ca4-872c-0febc75e9dd9,status=ACTIVE,resourceUri=<null>]]]]
```

###16.Add QaS Parameter for ServiceVersion by serviceVersionId
```
Description - This API is used to add a QaS Parameter for ServiceVersion by given serviceVersionId    
URL - {HostUrl}/registry//qas/{serviceVersionId}

Request/Header parameters - 

Errors - 
Validation error-
1.Invalid service version id.
2.Invalid QaS name.
3.Service version not found
4.QaS already exists

Internal errors-
1.DAO error has occurred while retrieving entity by id.
2.DAO error has occurred while retrieving entity by name.
3.DAO error has occurred while persisting an entity
3.A mapping error has occurred.
4.An unexpected error has occurred at business layer
5.An unexpected error has occurred at service layer.

Sample Request - 
ServiceRequest<QaSParameter> addQaSParameterReq = new ServiceRequest<QaSParameter>(new ServiceHeader(), additionalQaSParameter);

ServiceResponse<QaSParameter> addQaSParameterResp = registryServiceClient.addServiceVersionParameter(serviceVersionId,
							addQaSParameterReq);


Sample Response -
ServiceResponse [status=OK, header=ServiceHeader [headerAttributes={}], errors=[], payload=QaSParameter[paramName=TEST_SERVICE_PARAMETER_NAME1356058951393,paramValue=TEST_SERVICE_PARAMETER_VALUE,parentParamId=<null>,serviceVersion=<null>,createdBy=soari_registry_app,createdAt=2012-12-20 19:02:31.455,modifiedBy=<null>,modifiedAt=<null>,id=ad556d35-96ca-4da0-9467-60419b2ed718,status=ACTIVE,resourceUri=<null>]]
```

###17.Update QaS Parameter for a ServiceVersion by qasParamId
```
Description - This API is used to update QaS Parameter for ServiceVersion by given serviceVersionId.
	      Create/Add QaS parameter if it doesn't exists.

URL - {HostUrl}/registry/qas/{serviceVersionId}

Request/Header parameters - 

Errors - 
Validation error-
2.Invalid QaS name.
4.QaS already exists

Internal errors-
1.DAO error has occurred while retrieving entity by id.
2.DAO error has occurred while retrieving entity by name.
3.DAO error has occurred while persisting an entity
4.A mapping error has occurred.
5.An unexpected error has occurred at business layer
6.An unexpected error has occurred at service layer.

Sample Request - 
ServiceRequest<QaSParameter> updateQaSParameterReq = new ServiceRequest<QaSParameter>(new ServiceHeader(), qasParameterToUpdate);

ServiceResponse<QaSParameter> updateQaSParameterResp = registryServiceClient.updateServiceVersionParameter(serviceVersionId, updateQaSParameterReq);


Sample Response - 
```

###18.Delete QaS Parameter for a ServiceVersion by qasParamId
```
Description - This API is used to delete a QaS Parameter of a ServiceVersion by given qasParamId

URL - {HostUrl}/registry/qas/{qasParamId}

Request/Header parameters - 

Errors - 
Validation error-
1.Invalid QaS id.
2.QaS not found

Internal errors-
1.DAO error has occurred while retrieving entity by id.
3.DAO error has occurred while persisting an entity
4.A mapping error has occurred.
5.An unexpected error has occurred at business layer
6.An unexpected error has occurred at service layer.

Sample Request - 
ServiceResponse<QaSParameter> deleteQaSParameterResp = registryServiceClient.deleteServiceVersionParameter(qasParameterId);


Sample Response -
ServiceResponse [status=OK, header=ServiceHeader [headerAttributes={}], errors=[], payload=null] 
 
```

##Sample Resources

###1. Policy
	
```
Field		Type		Mandatory	Posible values
-------------------------------------------------------------
id			UUID		Auto		Auto generated   
name		String		Yes		Name of the Policy
version		String 		Yes		Policy version
policyData	String		No		Policy data
createdBy	String		No		UserID string		
createdAt	Timestamp	No		Timestamp			
modifiedBy	String		No		UserID string		
modifiedAt	Timestamp	No		Timestamp			
status 		String		Yes		ACTIVE, INACTIVE,DELETED	

```

###2. Service
	
```
Field			Type			Required		Posible values
------------------------------------------------------------------------------------------
category		String				Yes		BIZ, UTIL, PROC, INFRA, DATA
description		String				No		Some brief description about the service
owner			String				No		Email Address of service owner
name			String				Yes		Name of the Service
applicationId	String				Yes		Unique ApplicationId to which Service belongs
domain			String				Yes		B2C, B2B, B2E
usage			String				Yes		INTERNAL, EXTERNAL
serviceVersions List<ServiceVersion>No		List of ServiceVersion objects for the service
id				UUID				Auto	Auto generated   
createdBy		String				No		UserID string		
createdAt		Timestamp			No		Timestamp			
modifiedBy		String				No		UserID string		
modifiedAt		Timestamp			No		Timestamp			
status 			String				Yes		ACTIVE, INACTIVE,DELETED	

```

###3. ServiceVersion
	
```
Field				Type		Required				Posible values
------------------------------------------------------------------------------------------------
activationEndDate	Timestamp			No			Timestamp
activationStartDate	Timestamp			No			Timestamp
availabilityTier	String				No			TIER1, TIER2, TIER3, SDC, NDC, EDC
urls				List<Url>			Yes			List of Url objects
environment			String				Yes			DEV, QAT, ST, SIT, PROD
publicationDate		Timestamp			Yes			Timestamp
serVersion			String				Yes			Service version number
qasParameters		List<QaSParameter>	No			List of QaS parameter objects for service version
policies			List<Policy>		No			List of Policy obejcts for the service version
id					UUID				Auto		Auto generated   
createdBy			String				No			UserID string		
createdAt			Timestamp			No			Timestamp			
modifiedBy			String				No			UserID string		
modifiedAt			Timestamp			No			Timestamp			
status 				String				Yes			ACTIVE, INACTIVE,DELETED	

```

###4. QaSParameter
	
```
Field			Type		Posible values
----------------------------------------------------------------------
paramName		String		Name of QaS parameter
paramValue		String		Value of QaS parameter
parentParamId	String		Id of parent QaS parameter
id				UUID		Auto generated   
createdBy		String		UserID string		
createdAt		Timestamp	Timestamp			
modifiedBy		String		UserID string		
modifiedAt		Timestamp	Timestamp			
status 			String		ACTIVE, INACTIVE,DELETED	
```

###5. Url
	
```
Field		Type		Mandatory		Posible values
-------------------------------------------------------------------------------------------
url			String		Yes				Value of url
type		String		Yes				ENDPOINT, ENDPOINT_ALTERNATE, ESB_PROXY, CONTRACT
id			UUID		Auto			Auto generated   
createdBy	String		No				UserID string		
createdAt	Timestamp	No				Timestamp			
modifiedBy	String		No				UserID string		
modifiedAt	Timestamp	No				Timestamp			
status 		String		Yes				ACTIVE, INACTIVE,DELETED	
```