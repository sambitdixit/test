package com.walmart.platform.soari.registry.notification;

import java.io.Serializable;

import javax.jms.JMSException;
import javax.jms.Session;

import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.jms.core.JmsTemplate;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.walmart.platform.soari.registry.notification.NotificationRequest;
import com.walmart.platform.soari.registry.notification.publisher.MessagePublisher;

public class MessagePublisherTest {

	NotificationRequest request;
	@Mock
	JmsTemplate template;

	@BeforeClass
	public void init() {
		MockitoAnnotations.initMocks(this);
		request = new NotificationRequest();
		request.setAvailaibilityTier("Availaibility-Tier");
		request.setEsbReference("Esb-Reference");
		request.setId("1");
		request.setData(new Serializable() {});
	}

	@Test
	public void publishRequestTest() throws JMSException {

		MessagePublisher publisher = new MessagePublisher();

		// when(request.getAvailaibilityTier()).thenReturn("AVAILABILITY_TIER");
		// when(request.getEsbReference()).thenReturn("ESB_REFERENCE");
		// when(request.getId()).thenReturn("1");
		// when(request.getData()).thenReturn(mock(Serializable.class));
		//
		// //not able to mock JmsTemplate...even if it gets mocked, not able to
		// call "when(methodcall).thenReturn() on it..
		//

		//
		// when(template.getConnectionFactory()).thenReturn(mock(JMSConnectionFactory.class));
		// when(template.getDefaultDestinationName()).thenReturn("Destination");
		// when(template.getDeliveryMode()).thenReturn(1);
		// when(template.getReceiveTimeout()).thenReturn((long) 1000);

		// when(messageCreator.createMessage(session)).thenReturn(mock(Message.class));
		
		publisher.setProducerTemplate(template);
		
		// Mockito.spy(template);
		
		publisher.publishRequest(request);
	}
}