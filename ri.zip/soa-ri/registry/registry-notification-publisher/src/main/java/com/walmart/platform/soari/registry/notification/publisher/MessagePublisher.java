package com.walmart.platform.soari.registry.notification.publisher;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.ObjectMessage;
import javax.jms.Session;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;

import com.walmart.platform.soari.registry.notification.NotificationConstants;
import com.walmart.platform.soari.registry.notification.NotificationRequest;

/**
 *
 */
public class MessagePublisher {

	private static final Logger LOGGER = LoggerFactory.getLogger(MessagePublisher.class);

	private JmsTemplate producerTemplate;

	/**
	 * @param template
	 *            the template to set
	 */
	public void setProducerTemplate(JmsTemplate template) {
		this.producerTemplate = template;
	}

    /**
     *
     * @param request
     */
	public void publishRequest(final NotificationRequest request) {
        /**
         *
         */
		producerTemplate.send(new MessageCreator() {
            /**
             *
             * @param session
             * @return
             * @throws JMSException
             */
			public Message createMessage(Session session) throws JMSException {
			    LOGGER.debug("Start of MessagePublisher publishRequest");
				ObjectMessage msg = session.createObjectMessage();
				msg.setStringProperty(NotificationConstants.SELECTOR.name(),request.getAvailaibilityTier() + "-" + request.getEsbReference());
				LOGGER.debug("Message Selector=> {}", msg.getStringProperty(NotificationConstants.SELECTOR.name()));
				msg.setStringProperty(NotificationConstants.CACHE_KEY.name(),request.getId());
				msg.setObject(request);
				LOGGER.debug("Publishing request --> {}", request);
				LOGGER.debug("End of MessagePublisher publishRequest");
				return msg;
			}
		});
	}
}
