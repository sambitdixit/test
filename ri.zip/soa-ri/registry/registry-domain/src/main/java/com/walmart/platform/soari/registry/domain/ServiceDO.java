package com.walmart.platform.soari.registry.domain;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.hibernate.annotations.Type;

import com.walmart.platform.soari.registry.common.enums.EntityType;

/**
 * The persistent class for the SERVICE_MASTER database table.
 * 
 */
@Entity
@Table(name = "SERVICE")
public class ServiceDO extends EntityDO implements Serializable {
	/**
	 * class version id for serialization
	 */
	private static final long serialVersionUID = 1L;

	@NotNull(message = "DAO_VALIDATE_SERVICE_CATEGORY_NOT_NULL")
	@Size(min = 1, max = 128, message = "DAO_VALIDATE_SERVICE_CATEGORY_NOT_NULL")
	@Column(name = "CATEGORY", nullable = false, length = 36)
	private String category;

	@NotNull(message = "DAO_VALIDATE_SERVICE_DESRIPTION_NOT_NULL")
	@Size(min = 1, max = 128, message = "DAO_VALIDATE_SERVICE_DESRIPTION_SIZE")
	@Column(name = "DESCRIPTION", length = 128)
	private String description;

	@NotNull(message = "DAO_VALIDATE_SERVICE_OWNER_NOT_NULL")
	@Size(min = 1, max = 128, message = "DAO_VALIDATE_SERVICE_OWNER_SIZE")
	@Column(name = "OWNER", nullable = false, length = 128)
	private String owner;

	@NotNull(message = "DAO_VALIDATE_SERVICE_NAME_NOT_NULL")
	@Size(min = 1, max = 128, message = "DAO_VALIDATE_SERVICE_NAME_SIZE")
	@Column(name = "NAME", nullable = false, length = 128)
	private String name;

	@NotNull(message = "DAO_VALIDATE_SERVICE_ARTIFACTID_MANDATORY")
	@Size(min = 1, max = 128, message = "DAO_VALIDATE_SERVICE_ARTIFACTID_MANDATORY")
	@Column(name = "APPLICATION_ID", length = 128)
	private String applicationId;

	@NotNull(message = "DAO_VALIDATE_SERVICE_DOMAIN_NOT_NULL")
	@Size(min = 1, max = 128, message = "DAO_VALIDATE_SERVICE_DOMAIN_NOT_NULL")
	@Column(name = "SRV_DOMAIN", nullable = false, length = 36)
	private String domain;

	@NotNull(message = "DAO_VALIDATE_SERVICE_USAGE_NOT_NULL")
	@Size(min = 1, max = 128, message = "DAO_VALIDATE_SERVICE_USAGE_NOT_NULL")
	@Column(name = "SRV_USAGE", nullable = false, length = 36)
	private String usage;

	@Column(name = "ENVIRONMENT", length = 36)
	@NotNull(message = "DAO_VALIDATE_SERVICE_ENV_NOT_NULL")
	@Size(min = 1, max = 36, message = "DAO_VALIDATE_SERVICE_ENV_SIZE")
	private String environment;
	
	@Column(name = "NOTIFICATION_REQUESTED")
	@Type(type = "org.hibernate.type.NumericBooleanType")
	private Boolean notificationRequested = Boolean.FALSE;
	
	@ElementCollection
	@CollectionTable(name="SERVICE_NOTIFICATION_CHANGE", joinColumns=@JoinColumn(name="SERVICE_ID"))
	@Column(name = "CHANGE_TYPE")
	private Set<String> notificationFor = new HashSet<String>(0);
	
	/*@ManyToMany(fetch = FetchType.EAGER)
	@JoinTable(name = "SERVICE_NOTIFICATION_TYPES", joinColumns = { @JoinColumn(name = "SERVICE_ID")},inverseJoinColumns = {@JoinColumn(name = "NOTIFICATION_DESTINATION_ID")})
	@Column(name = "NOTIFICATION_DESTINATION_ID")
	private Set<NotificationDestinationDO> notificationTypes = new HashSet<NotificationDestinationDO>(0);*/
	@ElementCollection
	@CollectionTable(name="SERVICE_NOTIFICATION_TYPE", joinColumns=@JoinColumn(name="SERVICE_ID"))
	@Column(name = "NOTIFICATION_TYPE")
	private Set<String> notificationTypes = new HashSet<String>(0);

	@OneToMany(fetch = FetchType.EAGER, mappedBy = "service", cascade = CascadeType.ALL, orphanRemoval = true)
	@org.hibernate.annotations.Cascade({ org.hibernate.annotations.CascadeType.ALL })
	private Set<ServiceVersionDO> serviceVersions = new HashSet<ServiceVersionDO>(
			0);

	@Column(name = "JIRA_PROJECT", length = 36)
	private String jiraProject;
	
	/**
	 * no-arg constructor
	 */
	public ServiceDO() {
		this.setEntityType(EntityType.SERVICE);
	}
	
	/**
	 * getter for application id
	 * @return
	 */
	public String getApplicationId() {
		return applicationId;
	}

	
	/**
	 * @return the category
	 */
	public String getCategory() {
		return category;
	}

	/**
	 * @param category the category to set
	 */
	public void setCategory(String category) {
		this.category = category;
	}

	/**
	 * setter for application id
	 * @param applicationId
	 */
	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}

	
	/**
	 * @return the domain
	 */
	public String getDomain() {
		return domain;
	}

	/**
	 * @param domain the domain to set
	 */
	public void setDomain(String domain) {
		this.domain = domain;
	}

	/**
	 * getter for service versions
	 * @return
	 */
	public Set<ServiceVersionDO> getServiceVersions() {
		return serviceVersions;
	}

	/**
	 * @return the usage
	 */
	public String getUsage() {
		return usage;
	}

	/**
	 * @param usage the usage to set
	 */
	public void setUsage(String usage) {
		this.usage = usage;
	}

	/**
	 * setter for service versions
	 * @param serviceVersions
	 */
	public void setServiceVersions(Set<ServiceVersionDO> serviceVersions) {
		this.serviceVersions = serviceVersions;
	}

	/**
	 * service description accessor
	 * @return
	 */
	public String getDescription() {
		return this.description;
	}

	/**
	 * service description mutator
	 * @param description
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * getter for service owner
	 * @return
	 */
	public String getOwner() {
		return this.owner;
	}

	/**
	 * setter for service owner
	 * @param owner
	 */
	public void setOwner(String owner) {
		this.owner = owner;
	}

	/**
	 * accessor for service name
	 * @return
	 */
	public String getName() {
		return name;
	}

	/**
	 * mutator for service name
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * adds service version
	 * @param serviceVersionDO
	 */
	public void addServiceVersion(ServiceVersionDO serviceVersionDO) {
		if (!this.serviceVersions.contains(serviceVersionDO)) {
			this.serviceVersions.add(serviceVersionDO);
			serviceVersionDO.setService(this);
		}

	}

	/**
	 * removes service version
	 * @param serviceVersionDO
	 */
	public void removeServiceVersion(ServiceVersionDO serviceVersionDO) {
		this.serviceVersions.remove(serviceVersionDO);
	}

	/**
	 * @return the environment
	 */
	public String getEnvironment() {
		return environment;
	}

	/**
	 * @param environment the environment to set
	 */
	public void setEnvironment(String environment) {
		this.environment = environment;
	}

	/**
	 * @return the notificationRequested
	 */
	public Boolean getNotificationRequested() {
		return notificationRequested;
	}

	/**
	 * @param notificationRequested the notificationRequested to set
	 */
	public void setNotificationRequested(Boolean notificationRequested) {
		this.notificationRequested = notificationRequested;
	}

	/**
	 * @return the notificationFor
	 */
	public Set<String> getNotificationFor() {
		return notificationFor;
	}

	/**
	 * @param notificationFor the notificationFor to set
	 */
	public void setNotificationFor(Set<String> notificationFor) {
		this.notificationFor = notificationFor;
	}

	
	/**
	 * @return the notificationTypes
	 */
	public Set<String> getNotificationTypes() {
		return notificationTypes;
	}

	/**
	 * @param notificationTypes the notificationTypes to set
	 */
	public void setNotificationTypes(
			Set<String> notificationTypes) {
		this.notificationTypes = notificationTypes;
	}

	/**
	 * @return the jiraProject
	 */
	public String getJiraProject() {
		return jiraProject;
	}

	/**
	 * @param jiraProject the jiraProject to set
	 */
	public void setJiraProject(String jiraProject) {
		this.jiraProject = jiraProject;
	}

	/**
	 * overridden hashCode() method
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result
				+ ((applicationId == null) ? 0 : applicationId.hashCode());
		result = prime * result
				+ ((category == null) ? 0 : category.hashCode());
		result = prime * result
				+ ((description == null) ? 0 : description.hashCode());
		result = prime * result
				+ ((environment == null) ? 0 : environment.hashCode());
		result = prime * result
				+ ((notificationRequested == null) ? 0 : notificationRequested.hashCode());
		result = prime * result + ((domain == null) ? 0 : domain.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((owner == null) ? 0 : owner.hashCode());
		result = prime * result + ((usage == null) ? 0 : usage.hashCode());
		return result;
	}

	/**
	 * overridden equals() method
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null || getClass() != obj.getClass()) {
			return false;
		}
		ServiceDO other = (ServiceDO) obj;
		return isEquals(other);
	}

	private boolean isEquals(ServiceDO rhs) {

		return new EqualsBuilder().append(this.getId(), rhs.getId())
				.append(this.getStatus(), rhs.getStatus())
				.append(this.category, rhs.category)
				.append(this.description, rhs.description)
				.append(this.owner, rhs.owner).append(this.name, rhs.name)
				.append(this.applicationId, rhs.applicationId)
				.append(this.domain, rhs.domain).append(this.usage, rhs.usage)
				.append(this.environment, rhs.environment)
				.append(this.notificationRequested, rhs.notificationRequested)
				.isEquals();
	}

}