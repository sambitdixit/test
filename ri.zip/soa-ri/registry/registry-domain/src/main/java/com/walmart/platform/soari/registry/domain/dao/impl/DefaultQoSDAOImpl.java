
package com.walmart.platform.soari.registry.domain.dao.impl;

import java.text.MessageFormat;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.walmart.platform.kernel.exception.layers.dao.DataAccessException;
import com.walmart.platform.soari.registry.domain.DefaultQoSDO;
import com.walmart.platform.soari.registry.domain.dao.api.DefaultQoSDAO;
import com.walmart.platform.soari.registry.domain.dao.api.QoSDAO;
import com.walmart.platform.soari.registry.domain.repository.DefaultQoSRepository;
import com.walmart.platform.soari.registry.domain.repository.QoSRepository;
import com.walmart.platform.soari.registry.server.common.exception.ExceptionHandler;
import com.walmart.platform.soari.registry.domain.util.Timed;
import com.walmart.platform.soari.registry.server.common.util.CommonConstants;

@Service("DefaultQosDAO")
@Timed
public class DefaultQoSDAOImpl implements DefaultQoSDAO {

	private static final Logger LOG = LoggerFactory.getLogger(DefaultQoSDAOImpl.class);

	@Autowired
	private DefaultQoSRepository qosRepository;
	
	@Autowired
	private ExceptionHandler exceptionHandler;

	@Override
	public List<DefaultQoSDO> findAll() throws DataAccessException {
		LOG.debug("Executing findAll()");
		List<DefaultQoSDO> result = null;
		try {
			result = qosRepository.findAll();
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding all QOS", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public List<DefaultQoSDO> findAll(Sort sort) throws DataAccessException {
		LOG.debug("Executing findAll(Sort sort)");
		List<DefaultQoSDO> result = null;
		try {
			result = qosRepository.findAll(sort);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding all ordered QOS", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public List<DefaultQoSDO> save(Iterable<? extends DefaultQoSDO> qos)
			throws DataAccessException {
		LOG.debug("Executing save(Iterable<? extends DefaultQoSDO> qoss");
		List<DefaultQoSDO> result = null;
		try {
			result = qosRepository.save(qos);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "persisitng QOS", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public Page<DefaultQoSDO> findAll(Pageable pageable)
			throws DataAccessException {
		LOG.debug("Executing findAll(Pageable pageable)");
		Page<DefaultQoSDO> result = null;
		try {
			result = qosRepository.findAll(pageable);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding pageable QOS", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public DefaultQoSDO save(DefaultQoSDO qos) throws DataAccessException {
		LOG.debug("Executing save(DefaultQoSDO qos)");
		DefaultQoSDO result = null;
		try {
			result = qosRepository.save(qos);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "persisitng QOS", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public DefaultQoSDO findOne(String id) throws DataAccessException {
		LOG.debug("Executing findOne(String id)");
		DefaultQoSDO result = null;
		try {
			result = qosRepository.findOne(id);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding QOS by id", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public void delete(String id) throws DataAccessException {
		LOG.debug("Executing delete(String id)");
		try {
			qosRepository.delete(id);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "deleting QOS by id", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
	}

	@Override
	public void delete(DefaultQoSDO qos) throws DataAccessException {
		LOG.debug("Executing delete(DefaultQoSDO qos)");
		try {
			qosRepository.delete(qos);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "deleting QOS", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
	}

	@Override
	public void delete(Iterable<? extends DefaultQoSDO> qoss)
			throws DataAccessException {
		LOG.debug("Executing delete(Iterable<? extends DefaultQoSDO> qoss)");
		try {
			qosRepository.delete(qoss);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "deleting QOS", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
	}

	@Override
	public List<DefaultQoSDO> findByMatchingName(String name)
			throws DataAccessException {
		LOG.debug("Executing findByMatchingName()");
		List<DefaultQoSDO> result = null;
		try {
			String search = "%"+name+"%";
			result = qosRepository.findByMatchingName(search.toLowerCase());
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding QOS by matching name", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public List<DefaultQoSDO> findByName(String name) throws DataAccessException {
		LOG.debug("Executing findByName()");
		List<DefaultQoSDO> result = null;
		try {
			result = qosRepository.findByName(name.toLowerCase());
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding QOS by name", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}
	
	@Override
	public List<DefaultQoSDO> findByMatchingStatus(String status) throws DataAccessException {
		LOG.debug("Executing findByMatchingStatus()");
		List<DefaultQoSDO> result = null;
		try {
			String search = "%"+status+"%";
			result = qosRepository.findByMatchingStatus(search.toUpperCase());
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding QOS by matching status", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}
	
	@Override
	public List<DefaultQoSDO> findByStatus(List<String> status) throws DataAccessException {
		LOG.debug("Executing findByMatchingStatus()");
		List<DefaultQoSDO> result = null;
		try {
			result = qosRepository.findByStatus(status);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding QOS by status", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public List<DefaultQoSDO> findByMatchingEnv(String env)
			throws DataAccessException {
		LOG.debug("Executing findByMatchingStatus()");
		List<DefaultQoSDO> result = null;
		try {
			String search = "%"+env+"%";
			result = qosRepository.findByMatchingEnv(search.toUpperCase());
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding QOS by matching status", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public List<DefaultQoSDO> findByMatchingCategory(String cat)
			throws DataAccessException {
		LOG.debug("Executing findByMatchingStatus()");
		List<DefaultQoSDO> result = null;
		try {
			String search = "%"+cat+"%";
			result = qosRepository.findByMatchingCategory(search.toUpperCase());
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding QOS by matching status", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}	
}
