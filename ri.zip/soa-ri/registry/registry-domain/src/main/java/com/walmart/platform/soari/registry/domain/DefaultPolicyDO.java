package com.walmart.platform.soari.registry.domain;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.Lob;
import javax.persistence.ManyToMany;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.apache.commons.lang.builder.EqualsBuilder;

import com.walmart.platform.soari.registry.common.enums.EntityType;

/**
 * The persistent class for the POLICY database table.
 * 
 */
@Entity
@Table(name = "DEFAULT_POLICY")
public class DefaultPolicyDO  implements Serializable {
	
	/**
	 * class version id for serialization
	 */
	private static final long serialVersionUID = 1L;
	
	/** The id. */
	@Id
	@Column(name = "ID", nullable = false, length = 36)
	private String id;

	@NotNull(message = "DAO_VALIDATE_DEFAULT_POLICY_NAME_NOT_NULL")
	@Size(min = 1, max = 128, message = "DAO_VALIDATE_DEFAULT_POLICY_NAME_SIZE")
	@Column(name = "NAME", nullable = false, length = 128)
	private String name;

	@NotNull(message = "DAO_VALIDATE_DEFAULT_POLICY_DESCRIPTION_NOT_NULL")
	@Size(min = 1, max = 64, message = "DAO_VALIDATE_DEFAULT_POLICY_DESCRIPTION_SIZE")
	@Column(name = "DESCRIPTION", nullable = false, length = 128)
	private String description;

	@NotNull(message = "DAO_VALIDATE_DEFAULT_POLICY_TYPE_NOT_NULL")
	@Size(min = 1, max = 64, message = "DAO_VALIDATE_DEFAULT_POLICY_TYPE_NOT_NULL")
	@Column(name = "TYPE", length = 36, nullable = false)
	private String type;
	
	@Column(name = "DATA")
	@Lob
	@Basic(fetch = FetchType.LAZY)
	private String data;
	
	@Column(name = "EXEC_ORDER")
	private Integer order;

	@Column(name = "FLOW", length = 36)
	private String flow;
	
	@Column(name = "CONTEXT", length = 36)
	private String context;
	
	@Column(name = "STATUS", length = 36)
	private String status;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * On create.
	 */
	@PrePersist
	void onCreate() {
		this.setId(UUID.randomUUID().toString().replace("-", ""));
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id=id;
	}
	
	/**
	 * getter for Name
	 * @return
	 */
	public String getName() {
		return this.name;
	}

	/**
	 * setter for name
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	
	/**
	 * @return the data
	 */
	public String getData() {
		return data;
	}

	/**
	 * @param data the data to set
	 */
	public void setData(String data) {
		this.data = data;
	}

	
	/**
	 * @return the order
	 */
	public Integer getOrder() {
		return order;
	}

	/**
	 * @param order the order to set
	 */
	public void setOrder(Integer order) {
		this.order = order;
	}

	
	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * @return the flow
	 */
	public String getFlow() {
		return flow;
	}

	/**
	 * @param flow the flow to set
	 */
	public void setFlow(String flow) {
		this.flow = flow;
	}

	/**
	 * @return the context
	 */
	public String getContext() {
		return context;
	}

	/**
	 * @param context the context to set
	 */
	public void setContext(String context) {
		this.context = context;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DefaultPolicyDO other = (DefaultPolicyDO) obj;
		if (context == null) {
			if (other.context != null)
				return false;
		} else if (!context.equals(other.context))
			return false;
		if (data == null) {
			if (other.data != null)
				return false;
		} else if (!data.equals(other.data))
			return false;
		if (description == null) {
			if (other.description != null)
				return false;
		} else if (!description.equals(other.description))
			return false;
		if (flow == null) {
			if (other.flow != null)
				return false;
		} else if (!flow.equals(other.flow))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (order == null) {
			if (other.order != null)
				return false;
		} else if (!order.equals(other.order))
			return false;
		if (status == null) {
			if (other.status != null)
				return false;
		} else if (!status.equals(other.status))
			return false;
		if (type == null) {
			if (other.type != null)
				return false;
		} else if (!type.equals(other.type))
			return false;
		return true;
	}

	/*private boolean isEquals(DefaultPolicyDO rhs) {
		return new EqualsBuilder()
				.append(this.getId(), rhs.getId())
				.append(this.name, rhs.name)
				.append(this.description, rhs.description)
				.append(this.type, rhs.type)
				.append(this.order, rhs.order)
				.append(this.flow, rhs.flow).isEquals();
	}*/

	@Override
	public String toString() {
		return "DefaultPolicyDO [id=" + id + ", name=" + name
				+ ", description=" + description + ", type=" + type + ", data="
				+ data + ", order=" + order + ", flow=" + flow + ", context="
				+ context + ", status=" + status + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((context == null) ? 0 : context.hashCode());
		result = prime * result + ((data == null) ? 0 : data.hashCode());
		result = prime * result
				+ ((description == null) ? 0 : description.hashCode());
		result = prime * result + ((flow == null) ? 0 : flow.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((order == null) ? 0 : order.hashCode());
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		result = prime * result + ((type == null) ? 0 : type.hashCode());
		return result;
	}
	
}