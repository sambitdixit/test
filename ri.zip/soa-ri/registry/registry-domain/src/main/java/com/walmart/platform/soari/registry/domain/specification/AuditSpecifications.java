package com.walmart.platform.soari.registry.domain.specification;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.jpa.domain.Specification;

import com.walmart.platform.soa.common.util.SOAStringUtil;
import com.walmart.platform.soari.registry.domain.AuditDO;
import com.walmart.platform.soari.registry.domain.EntityDO;

/**
 * A class which is used to create Specification objects which are used to
 * create JPA criteria queries for Service information.
 * 
 * @author Sanjay Bonde
 */
public class AuditSpecifications {

	/**
	 * Creates a specification used to find Services whose details matches the
	 * given search term. This search is case insensitive.
	 * 
	 * @param searchTerm
	 * @return
	 */
	public static Specification<AuditDO> buildSearchPredicate(final String entityId) {

		return new Specification<AuditDO>() {
			@Override
			public Predicate toPredicate(
					Root<AuditDO> auditRoot,
					CriteriaQuery<?> query, CriteriaBuilder cb) {
				Predicate predicate = cb.conjunction();
				// Add perdicate for status
				if (!SOAStringUtil.isBlank(entityId)) {
					/*predicate.getExpressions().add(
							cb.equal(
									auditRoot.<EntityDO> get(
											"entity").<String> get("id"),
											entityId));*/
					predicate.getExpressions().add(
							cb.equal(
									auditRoot.<String> get(
											"entityId"),
											entityId));
				}
				return predicate;
			}

		};
	}
}