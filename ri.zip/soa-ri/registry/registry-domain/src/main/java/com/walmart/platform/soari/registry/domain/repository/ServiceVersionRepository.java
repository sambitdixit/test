package com.walmart.platform.soari.registry.domain.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.walmart.platform.kernel.exception.layers.dao.DataAccessException;
import com.walmart.platform.soari.registry.domain.ServiceVersionDO;

@Repository(value="serviceVersionRepository")
public interface ServiceVersionRepository extends JpaRepository<ServiceVersionDO, String>, JpaSpecificationExecutor<ServiceVersionDO>{
	
	/**
	 * Fetches list of {@link ServiceVersion} for service having identifier as 'serviceId' and version as 'serviceVersion'
	 * 
	 * @param serviceId Identifier for the service to be matched
	 * @param serviceVersion version of the service to be matched
	 * @return list of matching {@link ServiceVersion}
	 * @throws DataAccessException
	 */
	@Query("from ServiceVersionDO version where version.serVersion =:serviceVersion and version.service.id = :serviceId")
	List<ServiceVersionDO> findServiceVersion(@Param("serviceId") String serviceId, @Param("serviceVersion") String serviceVersion) throws DataAccessException;
	
	/**
	 * Fetches list of {@link ServiceVersion} for service versions having Availability Tier as 'availabilityTier'
	 * 
	 * @param availabilityTier 
	 * @return list of matching {@link ServiceVersion}
	 * @throws DataAccessException
	 */
	@Query("from ServiceVersionDO version where upper(version.availabilityTier) =:availabilityTier")
	List<ServiceVersionDO> findByAvailabilityTier(@Param("availabilityTier") String availabilityTier) throws DataAccessException;
	
	/**
	 * Fetches list of {@link ServiceVersion} for services having ESB References as 'esbReference'
	 * 
	 * @param esbReference I
	 * @return list of matching {@link ServiceVersion}
	 * @throws DataAccessException
	 */
	@Query("from ServiceVersionDO version where upper(version.esbReference) =:esbReference")
	List<ServiceVersionDO> findByESBReference(@Param("esbReference") String esbReference) throws DataAccessException;
}
