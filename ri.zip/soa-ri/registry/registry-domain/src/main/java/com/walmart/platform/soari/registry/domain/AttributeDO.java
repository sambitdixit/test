package com.walmart.platform.soari.registry.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Embeddable
public class AttributeDO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Column(name = "NAME", length = 128, nullable = false)
	@NotNull(message ="DAO_VALIDATE_SERVICE_VERSION_ATTRIBUTE_NAME_NOT_NULL")
	@Size(min = 1, max = 128, message = "DAO_VALIDATE_SERVICE_VERSION_ATTRIBUTE_NAME_SIZE")
	private String name;
	
	@Column(name = "VALUE", length = 128, nullable = false)
	@NotNull(message ="DAO_VALIDATE_SERVICE_VERSION_ATTRIBUTE_VALUE_NOT_NULL")
	@Size(min = 1, max = 128, message = "DAO_VALIDATE_SERVICE_VERSION_ATTRIBUTE_VALUE_SIZE")
	private String value;
	
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the value
	 */
	public String getValue() {
		return value;
	}

	/**
	 * @param value the value to set
	 */
	public void setValue(String value) {
		this.value = value;
	}
	
}
