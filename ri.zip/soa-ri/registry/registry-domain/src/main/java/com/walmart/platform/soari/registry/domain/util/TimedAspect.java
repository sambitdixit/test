package com.walmart.platform.soari.registry.domain.util;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.Assert;

@Aspect
public class TimedAspect {
	
	private static final Logger LOG = LoggerFactory.getLogger(TimedAspect.class);
	
	@Around(value = "@annotation( com.walmart.platform.soari.registry.domain.util.Timed) && @annotation(timed)", argNames = "timed")
	static Object timeMethod(final ProceedingJoinPoint pjp, final Timed timed)
			throws Throwable {
		return time(pjp, timed);
	}

	@Around("within(@ com.walmart.platform.soari.registry.domain.util.Timed *) && @target(timed)")
	static Object timeClass(final ProceedingJoinPoint pjp, final Timed timed)
			throws Throwable {
		return time(pjp, timed);
	}
	
	private static Object time(final ProceedingJoinPoint pjp, final Timed timed)
			throws Throwable {

		Assert.notNull(pjp);
		Assert.notNull(timed);

		final Signature signature = pjp.getSignature();
		LOG.debug("");
		final String longString = "[" + signature.toLongString() + "]";
		LOG.debug(">>>> started " + longString);

		final long startTimeMs = System.currentTimeMillis();

		try {
			return pjp.proceed();
		} finally {

			final long timeTakenMs = System.currentTimeMillis() - startTimeMs;
			LOG.debug("<<<< completed " + longString);
			LOG.debug("<<<<  (took "
					+ timeTakenMs + "ms)");
			LOG.debug("");

		}
	}
}