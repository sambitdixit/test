package com.walmart.platform.soari.registry.domain.dao.impl;

import java.text.MessageFormat;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.walmart.platform.kernel.exception.layers.dao.DataAccessException;
import com.walmart.platform.soari.registry.domain.AuditDO;
import com.walmart.platform.soari.registry.domain.dao.api.AuditDAO;
import com.walmart.platform.soari.registry.domain.repository.AuditRepository;
import com.walmart.platform.soari.registry.domain.specification.AuditSpecifications;
import com.walmart.platform.soari.registry.domain.util.Timed;
import com.walmart.platform.soari.registry.server.common.exception.ExceptionHandler;
import com.walmart.platform.soari.registry.server.common.util.CommonConstants;

@Service("auditDAO")
@Timed
public class AuditDAOImpl implements AuditDAO {

	private static final Logger LOG = LoggerFactory
			.getLogger(AuditDAOImpl.class);

	@Autowired
	private AuditRepository auditRepository;

	@Autowired
	private ExceptionHandler exceptionHandler;

	@Override
	public List<AuditDO> findAll() throws DataAccessException {

		LOG.debug("Executing findAll()");

		List<AuditDO> result = null;
		try {
			result = auditRepository.findAll();
		} catch (Exception t) {
			String errorMessage = MessageFormat.format(
					CommonConstants.EXCEPTION_MESSAGE,
					"finding all RegistryPolicyAudits", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public List<AuditDO> findAll(Sort sort) throws DataAccessException {
		LOG.debug("Executing findAll(Sort sort)");
		List<AuditDO> result = null;
		try {
			result = auditRepository.findAll(sort);
		} catch (Exception t) {
			String errorMessage = MessageFormat.format(
					CommonConstants.EXCEPTION_MESSAGE,
					"finding all ordered RegistryPolicyAudits", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public List<AuditDO> save(Iterable<? extends AuditDO> registryPolicyAudits)
			throws DataAccessException {
		LOG.debug("Executing save(Iterable<? extends RegistryPolicyAuditDO> registryPolicyAudits");
		List<AuditDO> result = null;
		try {
			result = auditRepository.save(registryPolicyAudits);
		} catch (Exception t) {
			String errorMessage = MessageFormat.format(
					CommonConstants.EXCEPTION_MESSAGE,
					"persisitng RegistryPolicyAudits", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public Page<AuditDO> findAll(Pageable pageable) throws DataAccessException {
		LOG.debug("Executing findAll(Pageable pageable)");
		Page<AuditDO> result = null;
		try {
			result = auditRepository.findAll(pageable);
		} catch (Exception t) {
			String errorMessage = MessageFormat.format(
					CommonConstants.EXCEPTION_MESSAGE,
					"finding pageable RegistryPolicyAudits", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public AuditDO save(AuditDO registryPolicyAudit) throws DataAccessException {
		LOG.debug("Executing save(RegistryPolicyAuditDO registryPolicyAudit)");
		AuditDO result = null;
		try {
			result = auditRepository.save(registryPolicyAudit);
		} catch (Exception t) {
			String errorMessage = MessageFormat.format(
					CommonConstants.EXCEPTION_MESSAGE, "persisitng Policy",
					t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public AuditDO findOne(String id) throws DataAccessException {
		LOG.debug("Executing findOne(String id)");
		AuditDO result = null;
		try {
			result = auditRepository.findOne(id);
		} catch (Exception t) {
			String errorMessage = MessageFormat.format(
					CommonConstants.EXCEPTION_MESSAGE,
					"finding RegistryPolicyAudit by id", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public void delete(String id) throws DataAccessException {
		LOG.debug("Executing delete(String id)");
		try {
			auditRepository.delete(id);
		} catch (Exception t) {
			String errorMessage = MessageFormat.format(
					CommonConstants.EXCEPTION_MESSAGE,
					"deleting RegistryPolicyAudit by id", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
	}

	@Override
	public void delete(AuditDO registryPolicyAudit) throws DataAccessException {
		LOG.debug("Executing delete(RegistryPolicyAuditDO registryPolicyAudit)");
		try {
			auditRepository.delete(registryPolicyAudit);
		} catch (Exception t) {
			String errorMessage = MessageFormat.format(
					CommonConstants.EXCEPTION_MESSAGE,
					"deleting RegistryPolicyAudit", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
	}

	@Override
	public void delete(Iterable<? extends AuditDO> registryPolicyAudits)
			throws DataAccessException {
		LOG.debug("Executing delete(Iterable<? extends RegistryPolicyAuditDO> registryPolicyAudits)");
		try {
			auditRepository.delete(registryPolicyAudits);
		} catch (Exception t) {
			String errorMessage = MessageFormat.format(
					CommonConstants.EXCEPTION_MESSAGE,
					"deleting RegistryPolicyAudits", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
	}

	@Override
	public List<AuditDO> findByEntity(String entityId, Integer fetchCount) throws DataAccessException {
		LOG.debug("Executing delete(Iterable<? extends RegistryPolicyAuditDO> registryPolicyAudits)");
		List<AuditDO> result = null;
		try {
			PageRequest request =
					new PageRequest(0, fetchCount, Sort.Direction.DESC, "modifiedAt");
			Page<AuditDO> page = auditRepository.findAll(AuditSpecifications.buildSearchPredicate(entityId), request);
			return page.getContent();
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "deleting RegistryPolicyAudits", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

}
