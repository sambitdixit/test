package com.walmart.platform.soari.registry.domain.dao.api;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import com.walmart.platform.kernel.exception.layers.dao.DataAccessException;
import com.walmart.platform.soari.registry.domain.ServiceVersionDO;

public interface ServiceVersionDAO {
	List<ServiceVersionDO> findAll() throws DataAccessException;

	List<ServiceVersionDO> findAll(Sort sort) throws DataAccessException;

	List<ServiceVersionDO> save(
			Iterable<? extends ServiceVersionDO> serviceVersions)
			throws DataAccessException;

	Page<ServiceVersionDO> findAll(Pageable pageable)
			throws DataAccessException;

	ServiceVersionDO save(ServiceVersionDO serviceVersion)
			throws DataAccessException;

	ServiceVersionDO saveAndFlush(ServiceVersionDO serviceVersion)
			throws DataAccessException;

	ServiceVersionDO findOne(String id) throws DataAccessException;

	void delete(String id) throws DataAccessException;

	void delete(ServiceVersionDO serviceVersion) throws DataAccessException;

	void delete(Iterable<? extends ServiceVersionDO> serviceVersions)
			throws DataAccessException;

	List<ServiceVersionDO> findServiceVersion(String serviceId,
			String serviceVersion) throws DataAccessException;

	List<ServiceVersionDO> findByAvailabilityTier(String availabilityTier)
			throws DataAccessException;

	List<ServiceVersionDO> findByESBReference(String esbReference)
			throws DataAccessException;
}
