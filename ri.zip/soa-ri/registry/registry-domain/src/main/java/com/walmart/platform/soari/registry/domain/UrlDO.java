package com.walmart.platform.soari.registry.domain;

import java.io.Serializable;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import javax.persistence.Version;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * An entity class to represent url string and type
 * @author sbonde
 *
 */
@Entity
@Table(name = "URL")
public class UrlDO implements Serializable {
	
	/**
	 * class version id for serialization
	 */
	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@Column(name = "ID", nullable = false, length = 36)
	private String id;

	@NotNull(message = "VALIDATE_URL_NOT_NULL")
	@Size(min = 1, max = 256, message = "VALIDATE_URL_SIZE")
	@Column(name = "URL_VALUE", nullable = false, length = 256)
	private String url;

	@NotNull(message = "VALIDATE_URL_TYPE_NOT_NULL")
	@Size(min = 1, max = 36, message = "VALIDATE_URL_TYPE_NOT_NULL")
	@Column(name = "TYPE")
	private String type;

	@Version
	@Column(name = "VERSION", nullable = false, length = 36)
	private Integer version;
	
	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	/**
	 * On create.
	 */
	@PrePersist
	void onCreate() {
		this.setId(UUID.randomUUID().toString());
	}

	/**
	 * @return the version
	 */
	public Integer getVersion() {
		return version;
	}

	/**
	 * @param version the version to set
	 */
	public void setVersion(Integer version) {
		this.version = version;
	}

	
}
