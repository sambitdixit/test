package com.walmart.platform.soari.registry.domain;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.persistence.Version;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.walmart.platform.soari.registry.common.enums.EntityType;
import com.walmart.platform.soari.registry.domain.validation.EntityValidator;

/**
 * The Class BaseEntity.
 */
@Entity
@Table(name = "ENTITY")
@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
public abstract class EntityDO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The created by. */
	@Column(name = "CREATED_BY", nullable = false, length = 128, insertable = true, updatable = false)
	private String createdBy;

	/** The created at. */
	@Column(name = "CREATED_AT", nullable = false, insertable = true, updatable = false)
	private Timestamp createdAt;

	/** The modified by. */
	@Column(name = "MODIFIED_BY", nullable = true, length = 128)
	private String modifiedBy;

	/** The modified at. */
	@Column(name = "MODIFIED_AT")
	private Timestamp modifiedAt;

	@Transient
	private EntityType entityType;
	
	/**
	 * 
	 * @return
	 */
	public EntityType getEntityType() {
		return entityType;
	}

	/**
	 * 
	 * @param entityType
	 */
	public void setEntityType(EntityType entityType) {
		this.entityType = entityType;
	}

	@Version
	@Column(name = "VERSION", nullable = false, length = 36)
	private Integer version;
	
	/** The id. */
	@Id
	@Column(name = "ID", nullable = false, length = 36)
	private String id;

	/** The status. */
	/*@NotNull(message = "DAO_VALIDATE_STATUS_NOT_NULL")
	@JoinColumn(name = "STATUS")
	@ManyToOne
	private Status status;*/
	
	@NotNull(message = "DAO_VALIDATE_STATUS_NOT_NULL")
	@Size(min = 1, max = 36, message = "DAO_VALIDATE_STATUS_NOT_NULL")
	@Column(name = "STATUS")
	private String status;


	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * Gets the created by.
	 * 
	 * @return the created by
	 */
	public String getCreatedBy() {
		return this.createdBy;
	}

	/**
	 * Sets the created by.
	 * 
	 * @param createdBy
	 *            the new created by
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * Gets the created at.
	 * 
	 * @return the created at
	 */
	public Timestamp getCreatedAt() {
		return this.createdAt;
	}

	/**
	 * Sets the created at.
	 * 
	 * @param createdAt
	 *            the new created at
	 */
	public void setCreatedAt(Timestamp createdAt) {
		this.createdAt = createdAt;
	}

	/**
	 * Gets the modified by.
	 * 
	 * @return the modified by
	 */
	public String getModifiedBy() {
		return this.modifiedBy;
	}

	/**
	 * Sets the modified by.
	 * 
	 * @param modifiedBy
	 *            the new modified by
	 */
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	/**
	 * Gets the modified at.
	 * 
	 * @return the modified at
	 */
	public Timestamp getModifiedAt() {
		return this.modifiedAt;
	}

	/**
	 * Sets the modified at.
	 * 
	 * @param modifiedAt
	 *            the new modified at
	 */
	public void setModifiedAt(Timestamp modifiedAt) {
		this.modifiedAt = modifiedAt;
	}

	/**
	 * On create.
	 */
	@PrePersist
	void onCreate() {
		this.setId(UUID.randomUUID().toString().replace("-", ""));
		if (this.getCreatedBy() == null) {
			this.setCreatedBy("soari_registry_app");
		}
		this.setCreatedAt(new Timestamp(System.currentTimeMillis()));
		EntityValidator.validateEntity(this);
	}

	/**
	 * On update.
	 */
	@PreUpdate
	void onUpdate() {
		if (this.getModifiedBy() == null) {
			this.setModifiedBy("soari_registry_app");
		}
		this.setModifiedAt(new Timestamp(System.currentTimeMillis()));
		EntityValidator.validateEntity(this);
	}

	/**
	 * Gets the id.
	 * 
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * Sets the id.
	 * 
	 * @param id
	 *            the new id
	 */
	public void setId(String id) {
		this.id = id;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((entityType == null) ? 0 : entityType.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof EntityDO)) {
			return false;
		}
		EntityDO other = (EntityDO) obj;
		if (entityType != other.entityType) {
			return false;
		}
		if (id == null) {
			if (other.id != null) {
				return false;
			}
		} else if (!id.equals(other.id)) {
			return false;
		}
		if (status == null) {
			if (other.status != null) {
				return false;
			}
		} else if (!status.equals(other.status)) {
			return false;
		}
		return true;
	}

	/**
	 * @return the version
	 */
	public Integer getVersion() {
		return version;
	}

	/**
	 * @param version the version to set
	 */
	public void setVersion(Integer version) {
		this.version = version;
	}

}