package com.walmart.platform.soari.registry.domain.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.walmart.platform.kernel.exception.layers.dao.DataAccessException;
import com.walmart.platform.soari.registry.common.enums.RegistryPolicyCodeType;
import com.walmart.platform.soari.registry.domain.RegistryPolicyCode;

@Repository
public interface RegistryPolicyCodeRepository extends JpaRepository<RegistryPolicyCode, String>{
	
	/**
	 * Fetches list of {@link RegistryPolicyCode} with type as 'type'
	 * and code as 'code'
	 * 
	 * @param type {@link RegistryPolicyCode}'s type to matched
	 * @param code {@link RegistryPolicyCode}'s code to matched
	 * @return list of matching {@link RegistryPolicyCode}
	 * @throws DataAccessException
	 */
	@Query("from RegistryPolicyCode a where a.type =:type and a.code = :code")
	List<RegistryPolicyCode> find(@Param("type") RegistryPolicyCodeType type, @Param("code") String code) throws DataAccessException;
	
	/**
	 * Fetches list of {@link RegistryPolicyCode} with type as 'type'
	 * 
	 * @param type {@link RegistryPolicyCode}'s type to matched
	 * @return list of matching {@link RegistryPolicyCode}
	 * @throws DataAccessException
	 */
	@Query("from RegistryPolicyCode a where a.type =:type")
	List<RegistryPolicyCode> findByType(@Param("type") RegistryPolicyCodeType type) throws DataAccessException;
}
