package com.walmart.platform.soari.registry.domain.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.walmart.platform.kernel.exception.layers.dao.DataAccessException;
import com.walmart.platform.soari.registry.domain.ServiceDO;

@Repository(value="serviceRepository")
public interface ServiceRepository extends JpaRepository<ServiceDO, String>, JpaSpecificationExecutor<ServiceDO>{
	String NAME = "name";
	
	/**
	 * 
	 * @param name
	 * @return
	 * @throws DataAccessException
	 */
	@Query("from ServiceDO service where lower(service.name) like :name and service.status <>'DELETED'")
	List<ServiceDO> findByMatchingName(@Param(NAME) String name) throws DataAccessException;
	
	/**
	 * 
	 * @param name
	 * @return
	 * @throws DataAccessException
	 */
	@Query("from ServiceDO service where lower(service.name) = :name ")
	List<ServiceDO> findByName(@Param(NAME) String name) throws DataAccessException;
	
	/**
	 * 
	 * @param name
	 * @param environment
	 * @return
	 * @throws DataAccessException
	 */
	@Query("from ServiceDO service where lower(service.name) = :name and lower(service.environment) = :environment")
	List<ServiceDO> find(@Param(NAME) String name, @Param("environment") String environment) throws DataAccessException;

	/**
	 * @param name
	 * @param environment
	 * @param applicationId
	 * @return
	 * @throws DataAccessException
	 */
	@Query("from ServiceDO service where (lower(service.name) = :name and lower(service.environment) = :environment) or (lower(service.applicationId) = :applicationId and lower(service.environment) = :environment)")
	List<ServiceDO> findDuplicate(@Param(NAME) String name, @Param("environment") String environment, @Param("applicationId") String applicationId) throws DataAccessException;
	
	/**
	 * @param environment
	 * @return
	 * @throws DataAccessException
	 */
	@Query("from ServiceDO service where lower(service.environment) = :environment")
	List<ServiceDO> findByEnvironment(@Param("environment") String environment) throws DataAccessException;
	
	/**
	 * @param applicationId
	 * @return
	 * @throws DataAccessException
	 */
	@Query("from ServiceDO service where lower(service.applicationId) = :applicationId and service.status <>'DELETED'")
	List<ServiceDO> findByApplicationId(@Param("applicationId") String applicationId) throws DataAccessException;
	
	/**
	 * @param search
	 * @return
	 * @throws DataAccessException
	 */
	@Query("from ServiceDO service where service.category = :search and service.status <>'DELETED'")
	List<ServiceDO> findByCategory(@Param("search")String search) throws DataAccessException;
	
	/**
	 * @param description
	 * @return
	 * @throws DataAccessException
	 */
	@Query("from ServiceDO service where lower(service.description) like :description and service.status <>'DELETED'")
	List<ServiceDO> findByMatchingDescription(@Param("description")String description) throws DataAccessException;
	
	/**
	 * @param owner
	 * @return
	 * @throws DataAccessException
	 */
	@Query("from ServiceDO service where lower(service.owner) like :owner and service.status <>'DELETED'")
	List<ServiceDO> findByMatchingOwner(@Param("owner")String owner) throws DataAccessException;
	
	/**
	 * @param domain
	 * @return
	 * @throws DataAccessException
	 */
	@Query("from ServiceDO service where service.domain = :domain and service.status <>'DELETED'")
	List<ServiceDO> findByDomain(@Param("domain")String domain) throws DataAccessException;
	
	/**
	 * @param usage
	 * @return
	 * @throws DataAccessException
	 */
	@Query("from ServiceDO service where service.usage = :usage and service.status <>'DELETED'")
	List<ServiceDO> findByUsage(@Param("usage")String usage) throws DataAccessException;
	
	/**
	 * @param status
	 * @return
	 * @throws DataAccessException
	 */
	@Query("from ServiceDO service where service.status in :status")
	List<ServiceDO> findByStatus(@Param("status")List<String> status) throws DataAccessException;
	
	/**
	 * @param qosId
	 * @return
	 * @throws DataAccessException
	 */
	@Query("select s from ServiceDO s where s.id in (select service from ServiceVersionDO service_version where service_version.id in (select pk.serviceVersion.id from ServiceVersionQoS service_version_qos where service_version_qos.pk.qos.id = :qosId))")
	//@Query("from ServiceDO as service inner join service.serviceVersions as version inner join version.serviceVersionQos as versionQoS with versionQoS.pk.qos.id =:qosId")
	List<ServiceDO> findByQoSId(@Param("qosId")String qosId) throws DataAccessException;
	
	/**
	 * @param policyId
	 * @return
	 * @throws DataAccessException
	 */
	@Query("from ServiceDO as service inner join service.serviceVersions version inner join version.policies policy with policy.id =:policyId")
	List<ServiceDO> findByPolicyId(@Param("policyId")String policyId) throws DataAccessException;
	
	@Query("select service.environment, count(*) from ServiceDO service group by service.environment")
	List<Object[]> findServiceCountPerEnvironment() throws DataAccessException;

	@Query("select environment, category, count(*) from ServiceDO group by environment, category")
	List<Object[]> findCategoryCountPerEnvironment() throws DataAccessException;

	@Query("select applicationId, name, count(*) from ServiceDO group by applicationId, name")
	List<Object[]> findEnvironmentCountForService() throws DataAccessException;

	@Query("select year(service.createdAt), month(service.createdAt), count(*) from ServiceDO service group by year(service.createdAt), month(service.createdAt)")
	List<Object[]> findServiceCountPerMonth() throws DataAccessException;
}
