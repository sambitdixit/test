package com.walmart.platform.soari.registry.domain.dao.impl;

import java.text.MessageFormat;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.walmart.platform.kernel.exception.layers.dao.DataAccessException;
import com.walmart.platform.soari.registry.domain.NotificationDestinationDO;
import com.walmart.platform.soari.registry.domain.dao.api.NotificationDestinationDAO;
import com.walmart.platform.soari.registry.domain.repository.NotificationDestinationRepository;
import com.walmart.platform.soari.registry.server.common.exception.ExceptionHandler;
import com.walmart.platform.soari.registry.domain.util.Timed;
import com.walmart.platform.soari.registry.server.common.util.CommonConstants;

@Service("notificationDestinationDAO")
@Timed
public class NotificationDestinationDAOImpl implements NotificationDestinationDAO {

	private static final Logger LOG = LoggerFactory.getLogger(NotificationDestinationDAOImpl.class);

	@Autowired
	private NotificationDestinationRepository notificationDestinationRepository;

	@Autowired
	private ExceptionHandler exceptionHandler;
	
	@Override
	public List<NotificationDestinationDO> findAll() throws DataAccessException {
		LOG.debug("Executing findAll()");
		List<NotificationDestinationDO> result = null;
		try {
			result = notificationDestinationRepository.findAll();
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding all NotificationDestinationDOs", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public List<NotificationDestinationDO> findAll(Sort sort) throws DataAccessException {
		LOG.debug("Executing findAll(Sort sort)");
		List<NotificationDestinationDO> result = null;
		try {
			result = notificationDestinationRepository.findAll(sort);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding all ordered NotificationDestinationDOs", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public List<NotificationDestinationDO> save(Iterable<? extends NotificationDestinationDO> notificationDestinations)
			throws DataAccessException {
		LOG.debug("Executing save(Iterable<? extends NotificationDestinationDO> notificationDestinations");
		List<NotificationDestinationDO> result = null;
		try {
			result = notificationDestinationRepository.save(notificationDestinations);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "persisitng NotificationDestinationDOs", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public Page<NotificationDestinationDO> findAll(Pageable pageable)
			throws DataAccessException {
		LOG.debug("Executing findAll(Pageable pageable)");
		Page<NotificationDestinationDO> result = null;
		try {
			result = notificationDestinationRepository.findAll(pageable);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding pageable NotificationDestinationDOs", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public NotificationDestinationDO save(NotificationDestinationDO notificationDestination) throws DataAccessException {
		LOG.debug("Executing save(NotificationDestinationDO notificationDestination)");
		NotificationDestinationDO result = null;
		try {
			result = notificationDestinationRepository.save(notificationDestination);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "persisitng NotificationDestination", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public NotificationDestinationDO findOne(String id) throws DataAccessException {
		LOG.debug("Executing findOne(String id)");
		NotificationDestinationDO result = null;
		try {
			result = notificationDestinationRepository.findOne(id);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding NotificationDestination by id", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public void delete(String id) throws DataAccessException {
		LOG.debug("Executing delete(String id)");
		try {
			notificationDestinationRepository.delete(id);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "deleting NotificationDestination by id", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
	}

	@Override
	public void delete(NotificationDestinationDO notificationDestination) throws DataAccessException {
		LOG.debug("Executing delete(NotificationDestinationDO notificationDestination)");
		try {
			notificationDestinationRepository.delete(notificationDestination);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "deleting NotificationDestination", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
	}

	@Override
	public void delete(Iterable<? extends NotificationDestinationDO> notificationDestinations)
			throws DataAccessException {
		LOG.debug("Executing delete(Iterable<? extends NotificationDestinationDO> notificationDestinations)");
		try {
			notificationDestinationRepository.delete(notificationDestinations);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "deleting NotificationDestinationDOs", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
	}

	@Override
	public List<NotificationDestinationDO> findByName(String name) throws DataAccessException {
		LOG.debug("Executing findByName()");
		List<NotificationDestinationDO> result = null;
		try {
			result = notificationDestinationRepository.findByName(name.toLowerCase());
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding NotificationDestinations by name", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}
	
	@Override
	public List<NotificationDestinationDO> findByStatus(List<String> status) throws DataAccessException {
		LOG.debug("Executing findByMatchingStatus()");
		List<NotificationDestinationDO> result = null;
		try {
			result = notificationDestinationRepository.findByStatus(status);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding NotificationDestinations by status", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public List<NotificationDestinationDO> findByMatchingName(String name)
			throws DataAccessException {
		LOG.debug("Executing findByMatchingName()");
		List<NotificationDestinationDO> result = null;
		try {
			String search = "%"+name+"%";
			result = notificationDestinationRepository.findByMatchingName(search.toLowerCase());
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding NotificationDestinations by matching name", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

}
