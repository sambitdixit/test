package com.walmart.platform.soari.registry.domain.dao;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.repository.query.Param;

import com.walmart.platform.kernel.exception.layers.dao.DataAccessException;

public interface GenericDAO<T> {
	Page<T> findAll(Pageable pageable) throws DataAccessException;
	T save(T entity) throws DataAccessException;
	T findOne(String id) throws DataAccessException;
	boolean exists(String id) throws DataAccessException;
	long count() throws DataAccessException;
	void delete(String id) throws DataAccessException;
	void delete(T entity) throws DataAccessException;
	void delete(Iterable<? extends T> entities) throws DataAccessException;
	void deleteAll() throws DataAccessException;
	List<T> findAll() throws DataAccessException;
	List<T> findAll(Sort sort) throws DataAccessException;
	List<T> save(Iterable<? extends T> entities) throws DataAccessException;
	void flush() throws DataAccessException;
	T saveAndFlush(T entity) throws DataAccessException;
	void deleteInBatch(Iterable<T> entities) throws DataAccessException;
	List<T> findByIds(@Param("ids") List<String> ids) throws DataAccessException;
	T findByName(@Param("name") String name) throws DataAccessException;
	List<T> findByMatchingName(@Param("name") String name) throws DataAccessException;
}
