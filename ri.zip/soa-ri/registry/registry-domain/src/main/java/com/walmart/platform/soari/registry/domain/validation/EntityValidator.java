package com.walmart.platform.soari.registry.domain.validation;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;

import org.springframework.stereotype.Service;

import com.walmart.platform.soari.registry.server.common.error.ErrorCode;
import com.walmart.platform.soari.registry.server.common.exception.RegistryDataAccessException;

@Service("entityValidator")
public class EntityValidator {
	
    private static Validator validator = Validation.buildDefaultValidatorFactory().getValidator();
	
    /**
     * NOTE: removed RegistryDataAccessException from throws since it is unchecked exception
     * @param entity
     */
	public static<T> void validateEntity(T entity)  {
	    Set<ConstraintViolation<T>> constraintViolations = validator.validate(entity);
	    if(constraintViolations == null || constraintViolations.isEmpty()) {
	    	return;
	    }
	    List<ErrorCode> errorCodes = new ArrayList<ErrorCode>(0);
	    StringBuffer errorMsg = new StringBuffer();
	    for(ConstraintViolation<T> constraintViolation : constraintViolations) {
	    	String message = constraintViolation.getMessage();
	    	errorMsg.append(constraintViolation.getMessageTemplate());
	    	ErrorCode errorCode = ErrorCode.getErrorCode(message);
	    	if(errorCode == null) {
	    		errorCode = ErrorCode.DAO_CONSTRAINT_VIOLATION_EXCEPTION;
	    	}
	    	errorCodes.add(errorCode);
	    }
	    throw new RegistryDataAccessException(errorCodes, errorMsg.toString());
	}

	/**
	 * NOTE: removed RegistryDataAccessException from throws since it is unchecked exception
	 * @param entities
 	 */
	public static<T> void validateEntities(Iterable<? extends T> entities) {
		for(T entity : entities) {
			validateEntity(entity);
		}
	}
	
}