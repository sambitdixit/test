package com.walmart.platform.soari.registry.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.walmart.platform.soari.registry.common.enums.EntityType;

/**
 * The persistent class for the CONSUMER database table.
 * 
 */
@Entity
@Table(name = "SUBSCRIPTION")
//@DiscriminatorValue("SUBSCRIPTION")
public class SubscriptionDO extends EntityDO{
	
	/**
	 * class version id for serialization
	 */
	private static final long serialVersionUID = 1L;

	@JoinColumn(name = "SERV_VERSION_ID", nullable = false)
	@NotNull(message = "DAO_VALIDATE_SUBSCRIPTION_VERSION_NOT_NULL")
	@ManyToOne
	private ServiceVersionDO serviceVersion;
	
	@NotNull(message = "DAO_VALIDATE_SUBSCRIPTION_COMMUNICATION_TYPE_NOT_NULL")
	@Size(min = 1, max = 36, message = "DAO_VALIDATE_SUBSCRIPTION_COMMUNICATION_TYPE_NOT_NULL")
	@Column(name = "COMMUNICATION_TYPE", length = 36, nullable = false)
	private String communicationType;
	
	@JoinColumn(name = "CONSUMER_ID", nullable = false)
	@NotNull(message = "DAO_VALIDATE_SUBSCRIPTION_CONSUMER_NOT_NULL")
	@ManyToOne
	private ConsumerDO consumer;
	
	/**
	 * no-arg constructor
	 */
	public SubscriptionDO() {
		this.setEntityType(EntityType.SUBSCRIPTION);
	}

	/**
	 * @return the serviceVersion
	 */
	public ServiceVersionDO getServiceVersion() {
		return serviceVersion;
	}

	/**
	 * @param serviceVersion the serviceVersion to set
	 */
	public void setServiceVersion(ServiceVersionDO serviceVersion) {
		this.serviceVersion = serviceVersion;
	}

	
	/**
	 * @return the communicationType
	 */
	public String getCommunicationType() {
		return communicationType;
	}

	/**
	 * @param communicationType the communicationType to set
	 */
	public void setCommunicationType(String communicationType) {
		this.communicationType = communicationType;
	}

	/**
	 * @return the consumer
	 */
	public ConsumerDO getConsumer() {
		return consumer;
	}

	/**
	 * @param consumer the consumer to set
	 */
	public void setConsumer(ConsumerDO consumer) {
		this.consumer = consumer;
	}

	/**
	 * overridden hashCode() method
	 */
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result
				+ ((communicationType == null) ? 0 : communicationType.hashCode());
		result = prime * result
				+ ((consumer == null) ? 0 : consumer.hashCode());
		result = prime * result
				+ ((serviceVersion == null) ? 0 : serviceVersion.hashCode());
		return result;
	}

	/**
	 * overridden equals() method
	 */
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		SubscriptionDO other = (SubscriptionDO) obj;
		if (communicationType == null) {
			if (other.communicationType != null) {
				return false;
			}
		} 
		else if (!communicationType.equals(other.communicationType)) {
			return false;
		}
		if (consumer == null) {
			if (other.consumer != null) {
				return false;
			}
		} 
		else if (!consumer.equals(other.consumer)) {
			return false;
		}
		if (serviceVersion == null) {
			if (other.serviceVersion != null) {
				return false;
			}
		} 
		else if (!serviceVersion.equals(other.serviceVersion)) {
			return false;
		}
		return true;
	}

	

}
