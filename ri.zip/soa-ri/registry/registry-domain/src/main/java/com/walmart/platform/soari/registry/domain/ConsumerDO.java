package com.walmart.platform.soari.registry.domain;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.walmart.platform.soari.registry.common.enums.EntityType;

/**
 * The persistent class for the CONSUMER database table.
 * 
 */
@Entity
@Table(name = "CONSUMER")
public class ConsumerDO extends EntityDO implements Serializable {
	
	/**
	 * class version id for serialization
	 */
	private static final long serialVersionUID = 1L;

	@NotNull(message = "DAO_VALIDATE_CONSUMER_ID_NOT_NULL")
	@Size(min = 1, max = 64, message = "DAO_VALIDATE_CONSUMER_ID_SIZE")
	@Column(name = "CONSUMER_ID", nullable = false, length = 128)
	private String consumerId;

	@OneToMany(fetch = FetchType.EAGER, mappedBy = "consumer", cascade = CascadeType.ALL, orphanRemoval = true)
	@org.hibernate.annotations.Cascade({ org.hibernate.annotations.CascadeType.ALL })
	private Set<SubscriptionDO> subscriptions = new HashSet<SubscriptionDO>(0);

	/**
	 * no-arg Constructor
	 */
	public ConsumerDO() {
		this.setEntityType(EntityType.CONSUMER);
	}

	/**
	 * @return the consumerId
	 */
	public String getConsumerId() {
		return consumerId;
	}

	/**
	 * @param consumerId
	 *            the consumerId to set
	 */
	public void setConsumerId(String consumerId) {
		this.consumerId = consumerId;
	}

	/**
	 * Adds the subscription to consumer
	 * 
	 * @param subscription
	 */
	public void addSubscription(SubscriptionDO subscription) {
		if (!this.subscriptions.contains(subscription)) {
			this.subscriptions.add(subscription);
			subscription.setConsumer(this);
		}

	}

	/**
	 * @return the subscriptions
	 */
	public Set<SubscriptionDO> getSubscriptions() {
		return subscriptions;
	}

	/**
	 * removes the subscription from consumer
	 * @param subscription
	 */
	public void removeSubscription(SubscriptionDO subscription) {
		if (subscriptions.contains(subscription)) {
			this.subscriptions.remove(subscription);
		}
	}

	/**
	 * over-ridden hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result
				+ ((consumerId == null) ? 0 : consumerId.hashCode());
		return result;
	}

	/**
	 * over-ridden equals method 
	 * 
	 * @param obj Object to compared 
	 */
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		ConsumerDO other = (ConsumerDO) obj;
		if (consumerId == null) {
			if (other.consumerId != null) {
				return false;
			}
		} 
		else if (!consumerId.equals(other.consumerId)) {
			return false;
		}
		return true;
	}

}