package com.walmart.platform.soari.registry.domain.dao.api;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import com.walmart.platform.kernel.exception.layers.dao.DataAccessException;
import com.walmart.platform.soari.registry.domain.DefaultPolicyDO;

public interface DefaultPolicyDAO {
	List<DefaultPolicyDO> findAll() throws DataAccessException;

	List<DefaultPolicyDO> findAll(Sort sort) throws DataAccessException;

	List<DefaultPolicyDO> save(Iterable<? extends DefaultPolicyDO> policies)
			throws DataAccessException;

	Page<DefaultPolicyDO> findAll(Pageable pageable)
			throws DataAccessException;

	DefaultPolicyDO save(DefaultPolicyDO policy) throws DataAccessException;

	DefaultPolicyDO findOne(String id) throws DataAccessException;

	void delete(String id) throws DataAccessException;

	void delete(DefaultPolicyDO policy) throws DataAccessException;

	void delete(Iterable<? extends DefaultPolicyDO> policies)
			throws DataAccessException;

	List<DefaultPolicyDO> findByMatchingName(String name)
			throws DataAccessException;

	List<DefaultPolicyDO> findByName(String name) throws DataAccessException;
	List<DefaultPolicyDO> findByStatus(List<String> status) throws DataAccessException;
}
