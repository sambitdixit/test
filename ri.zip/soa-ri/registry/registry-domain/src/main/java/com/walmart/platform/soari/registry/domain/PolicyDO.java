package com.walmart.platform.soari.registry.domain;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.Lob;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.apache.commons.lang.builder.EqualsBuilder;

import com.walmart.platform.soari.registry.common.enums.EntityType;

/**
 * The persistent class for the POLICY database table.
 * 
 */
@Entity
@Table(name = "POLICY")
public class PolicyDO extends EntityDO implements Serializable {
	
	/**
	 * class version id for serialization
	 */
	private static final long serialVersionUID = 1L;

	@NotNull(message = "DAO_VALIDATE_POLICY_NAME_NOT_NULL")
	@Size(min = 1, max = 64, message = "DAO_VALIDATE_POLICY_NAME_SIZE")
	@Column(name = "NAME", nullable = false, length = 128)
	private String name;

	@NotNull(message = "DAO_VALIDATE_POLICY_DESCRIPTION_NOT_NULL")
	@Size(min = 1, max = 64, message = "DAO_VALIDATE_POLICY_DESCRIPTION_SIZE")
	@Column(name = "DESCRIPTION", nullable = false, length = 128)
	private String description;

	@NotNull(message = "DAO_VALIDATE_POLICY_TYPE_NOT_NULL")
	@Size(min = 1, max = 64, message = "DAO_VALIDATE_POLICY_TYPE_NOT_NULL")
	@Column(name = "TYPE", length = 36, nullable = false)
	private String type;
	
	@Column(name = "DATA")
	@Lob
	@Basic(fetch = FetchType.LAZY)
	private String data;

	@ManyToMany(fetch = FetchType.LAZY)
	@JoinTable(name = "SERVICE_VERSION_POLICY", joinColumns = { @JoinColumn(name = "POLICY_ID") }, inverseJoinColumns = { @JoinColumn(name = "SRV_VERSION_ID") })
	private Set<ServiceVersionDO> serviceVersions = new HashSet<ServiceVersionDO>(0);
	
	@Column(name = "EXEC_ORDER")
	private Integer order;

	@Column(name = "FLOW", length = 36)
	private String flow;
	
	@Column(name = "CONTEXT", length = 36)
	private String context;

	/**
	 * no-arg constructor
	 */
	public PolicyDO() {
		this.setEntityType(EntityType.POLICY);
	}

	/**
	 * getter for Name
	 * @return
	 */
	public String getName() {
		return this.name;
	}

	/**
	 * setter for name
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * getter for service versions
	 * @return
	 */
	public Set<ServiceVersionDO> getServiceVersions() {
		return this.serviceVersions;
	}

	/**
	 * setter for service versions
	 * @param serviceVersions
	 */
	public void setServiceVersions(
			Set<ServiceVersionDO> serviceVersions) {
		this.serviceVersions = serviceVersions;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	
	/**
	 * @return the data
	 */
	public String getData() {
		return data;
	}

	/**
	 * @param data the data to set
	 */
	public void setData(String data) {
		this.data = data;
	}

	
	/**
	 * @return the order
	 */
	public Integer getOrder() {
		return order;
	}

	/**
	 * @param order the order to set
	 */
	public void setOrder(Integer order) {
		this.order = order;
	}

	
	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * @return the flow
	 */
	public String getFlow() {
		return flow;
	}

	/**
	 * @param flow the flow to set
	 */
	public void setFlow(String flow) {
		this.flow = flow;
	}

	/**
	 * @return the context
	 */
	public String getContext() {
		return context;
	}

	/**
	 * @param context the context to set
	 */
	public void setContext(String context) {
		this.context = context;
	}

	/**
	 * overridden equals method
	 */
	@Override
	public boolean equals(final Object rhs) {
		if (!(rhs instanceof PolicyDO)) {
			return false;
		}
		if(!getClass().equals(rhs.getClass()) || hashCode() != rhs.hashCode()) {
			return false;
		}else {
			return isEquals((PolicyDO)rhs);
		}
	}

	private boolean isEquals(PolicyDO rhs) {
		return new EqualsBuilder()
				.append(this.getId(), rhs.getId())
				.append(this.name, rhs.name)
				.append(this.description, rhs.description)
				.append(this.type, rhs.type)
				.append(this.order, rhs.order)
				.append(this.flow, rhs.flow).isEquals();
	}

	/**
	 * overridden toString() method
	 */
	@Override
	public String toString() {
		return "Policy = ["+this.getId() + " : " + this.name + " : "+this.description+"]";
	}

	/**
	 * overridden hashCode() method
	 */
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((description == null) ? 0 : description.hashCode());
		result = prime * result + ((type == null) ? 0 : type.hashCode());
		result = prime * result + ((order == null) ? 0 : order.hashCode());
		result = prime * result + ((flow == null) ? 0 : flow.hashCode());
		return result;
	}
	
}