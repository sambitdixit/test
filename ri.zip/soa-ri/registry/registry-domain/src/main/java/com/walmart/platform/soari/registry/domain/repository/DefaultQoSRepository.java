package com.walmart.platform.soari.registry.domain.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.walmart.platform.kernel.exception.layers.dao.DataAccessException;
import com.walmart.platform.soari.registry.domain.DefaultQoSDO;;

@Repository(value="DefaultqosRepository")
public interface DefaultQoSRepository extends JpaRepository<DefaultQoSDO, String>{
	
	/**
	 * Fetches list of QoS with name similar (%name%) to 'name'
	 * 
	 * @param name QoS name to be matched against
	 * @return list of matching QoS
	 * @throws DataAccessException
	 */
	@Query("from DefaultQoSDO qos where lower(qos.name) like :name and qos.status <>'DELETED'")
	List<DefaultQoSDO> findByMatchingName(@Param("name") String name) throws DataAccessException;
	
	/**
	 * Fetches list of QoS having name as 'name'
	 * 
	 * @param name QoS name to be matched against
	 * @return list of matching QoS
	 * @throws DataAccessException
	 */
	@Query("from DefaultQoSDO qos where lower(qos.name) = :name")
	List<DefaultQoSDO> findByName(@Param("name") String name) throws DataAccessException;
	
	/**
	 * Fetches list of QoS with status similar (%name%) to 'status'
	 * 
	 * @param status QoS status to be matched against
	 * @return list of matching QoS
	 * @throws DataAccessException
	 */
	@Query("from DefaultQoSDO qos where qos.status like :status")
	List<DefaultQoSDO> findByMatchingStatus(@Param("status") String status) throws DataAccessException;
	
	/**
	 * Fetches list of QoS with their status present in 'status'
	 * 
	 * @param status QoS status to be matched against
	 * @return list of matching QoS
	 * @throws DataAccessException
	 */
	@Query("from DefaultQoSDO qos where qos.status in :status")
	List<DefaultQoSDO> findByStatus(@Param("status") List<String> status) throws DataAccessException;
	
	/**
	 * Fetches list of QoS with status similar (%name%) to 'status'
	 * 
	 * @param status QoS status to be matched against
	 * @return list of matching QoS
	 * @throws DataAccessException
	 */
	@Query("from DefaultQoSDO qos where qos.environment like :environment")
	List<DefaultQoSDO> findByMatchingEnv(@Param("environment") String status) throws DataAccessException;
	
	/**
	 * Fetches list of QoS with status similar (%name%) to 'status'
	 * 
	 * @param status QoS status to be matched against
	 * @return list of matching QoS
	 * @throws DataAccessException
	 */
	@Query("from DefaultQoSDO qos where qos.category like :category")
	List<DefaultQoSDO> findByMatchingCategory(@Param("category") String status) throws DataAccessException;
}
