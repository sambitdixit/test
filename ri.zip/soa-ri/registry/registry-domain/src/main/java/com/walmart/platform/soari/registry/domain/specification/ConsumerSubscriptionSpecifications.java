package com.walmart.platform.soari.registry.domain.specification;

import java.util.Map;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.jpa.domain.Specification;

import com.walmart.platform.soa.common.util.SOAStringUtil;
import com.walmart.platform.soari.registry.domain.ConsumerDO;
import com.walmart.platform.soari.registry.domain.ServiceDO;
import com.walmart.platform.soari.registry.domain.ServiceVersionDO;
import com.walmart.platform.soari.registry.domain.SubscriptionDO;

public class ConsumerSubscriptionSpecifications {

	public static Specification<SubscriptionDO> buildSubscriptionSearchPredicate(final Map<String, String> search) {

		return new Specification<SubscriptionDO>() {
			@Override
			public Predicate toPredicate(Root<SubscriptionDO> subscription,CriteriaQuery<?> query, CriteriaBuilder cb) {
				String consumerId = search.get("consumerId");
				String communicationType = search.get("communicationType");
				String subscriptonStatus = search.get("subscriptonStatus");
				String serviceVersion = search.get("serVersion");
				String serviceName = search.get("name");
				String serviceEnv = search.get("environment");
				Predicate predicate = cb.conjunction();
				if (!SOAStringUtil.isBlank(communicationType)) {
					predicate.getExpressions().add(cb.equal(subscription.<String> get("communicationType"),communicationType.toUpperCase()));
				}
				if (!SOAStringUtil.isBlank(subscriptonStatus)) {
					predicate.getExpressions().add(cb.equal(subscription.<String> get("status"),subscriptonStatus.toUpperCase()));
				}
				if (!SOAStringUtil.isBlank(consumerId)) {
					predicate.getExpressions().add(cb.equal(subscription.<ConsumerDO> get("consumer").<String> get("consumerId"),consumerId));
				}
				if (!SOAStringUtil.isBlank(serviceName)) {
					predicate.getExpressions().add(cb.like(cb.lower(subscription.<ServiceVersionDO> get("serviceVersion").<ServiceDO> get("service").<String> get("name")),like(serviceName)));
				}
				if (!SOAStringUtil.isBlank(serviceEnv)) {
					predicate.getExpressions().add(cb.like(cb.lower(subscription.<ServiceVersionDO> get("serviceVersion").<ServiceDO> get("service").<String> get("environment")),like(serviceEnv)));
				}
				if (!SOAStringUtil.isBlank(serviceVersion)) {
					predicate.getExpressions().add(cb.equal(subscription.<ServiceVersionDO> get("serviceVersion").<String> get("serVersion"),serviceVersion));
				}
				
				return predicate;
			}
		};
	}

	private static String like(final String searchTerm) {
		StringBuilder pattern = new StringBuilder();
		pattern.append("%");
		pattern.append(searchTerm.toLowerCase());
		pattern.append("%");
		return pattern.toString();
	}
}
