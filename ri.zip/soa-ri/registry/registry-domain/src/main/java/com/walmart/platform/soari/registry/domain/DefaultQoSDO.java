package com.walmart.platform.soari.registry.domain;

import java.io.Serializable;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.walmart.platform.soari.registry.common.enums.EntityType;

@Entity
@Table(name = "DEFAULT_QOS_PARAM")
public class DefaultQoSDO implements Serializable  {
	
	private static final long serialVersionUID = 1L;
	
	/** The id. */
	@Id
	@Column(name = "ID", nullable = false, length = 36)
	private String id;

	@NotNull(message = "DAO_VALIDATE_DEFAULT_QOS_PARAM_NAME_NOT_NULL")
	@Size(min = 1, max = 128, message = "DAO_VALIDATE_DEFAULT_QOS_PARAM_NAME_SIZE")
	@Column(name = "NAME", nullable = false, length = 128)
	private String name;

	@NotNull(message = "DAO_VALIDATE_DEFAULT_QOS_PARAM_DESCRIPTION_NOT_NULL")
	@Size(min = 1, max = 256, message = "DAO_VALIDATE_DEFAULT_QOS_PARAM_DESCRIPTION_SIZE")
	@Column(name = "DESCRIPTION", nullable = false, length = 256)
	private String description;

	@NotNull(message = "DAO_VALIDATE_DEFAULT_QOS_PARAM_TYPE_NOT_NULL")
	@Size(min = 1, max = 36, message = "DAO_VALIDATE_DEFAULT_QOS_PARAM_TYPE_NOT_NULL")
	@Column(name = "TYPE", length = 36, nullable = false)
	private String type;
	
	@NotNull(message = "DAO_VALIDATE_DEFAULT_QOS_PARAM_VALUE_NOT_NULL")
	@Size(min = 1, max = 128, message = "DAO_VALIDATE_DEFAULT_QOS_PARAM_VALUE_NOT_NULL")
	@Column(name = "VALUE", length = 128, nullable = false)
	private String value;
	
	@NotNull(message = "DAO_VALIDATE_DEFAULT_QOS_PARAM_ENVIRONMENT_NOT_NULL")
	@Size(min = 1, max = 32, message = "DAO_VALIDATE_DEFAULT_QOS_PARAM_ENVIRONMENT_NOT_NULL")
	@Column(name = "ENVIRONMENT", length = 32, nullable = false)
	private String environment;
	
	@NotNull(message = "DAO_VALIDATE_DEFAULT_QOS_PARAM_CATEGORY_NOT_NULL")
	@Size(min = 1, max = 8, message = "DAO_VALIDATE_DEFAULT_QOS_PARAM_CATEGORY_NOT_NULL")
	@Column(name = "CATEGORY", length = 8, nullable = false)
	private String category;
	
	@NotNull(message = "DAO_VALIDATE_DEFAULT_QOS_PARAM_STATUS_NOT_NULL")
	@Size(min = 1, max = 16, message = "DAO_VALIDATE_DEFAULT_QOS_PARAM_STATUS_NOT_NULL")
	@Column(name = "STATUS", length = 16, nullable = false)
	private String status;
	
	/**
	 * no-arg constructor
	 */
//	public DefaultQoSDO() {
//		this.setEntityType(EntityType.DEFAULT_QoS);
//	}
	
	/**
	 * On create.
	 */
	@PrePersist
	void onCreate() {
		this.setId(UUID.randomUUID().toString().replace("-", ""));
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getEnvironment() {
		return environment;
	}

	public void setEnvironment(String environment) {
		this.environment = environment;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result
				+ ((category == null) ? 0 : category.hashCode());
		result = prime * result
				+ ((description == null) ? 0 : description.hashCode());
		result = prime * result
				+ ((environment == null) ? 0 : environment.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		result = prime * result + ((type == null) ? 0 : type.hashCode());
		result = prime * result + ((value == null) ? 0 : value.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		DefaultQoSDO other = (DefaultQoSDO) obj;
		if (category == null) {
			if (other.category != null)
				return false;
		} else if (!category.equals(other.category))
			return false;
		if (description == null) {
			if (other.description != null)
				return false;
		} else if (!description.equals(other.description))
			return false;
		if (environment == null) {
			if (other.environment != null)
				return false;
		} else if (!environment.equals(other.environment))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (status == null) {
			if (other.status != null)
				return false;
		} else if (!status.equals(other.status))
			return false;
		if (type == null) {
			if (other.type != null)
				return false;
		} else if (!type.equals(other.type))
			return false;
		if (value == null) {
			if (other.value != null)
				return false;
		} else if (!value.equals(other.value))
			return false;
		return true;
	}

	

}
