package com.walmart.platform.soari.registry.domain.dao.impl;

import java.text.MessageFormat;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.walmart.platform.kernel.exception.layers.dao.DataAccessException;
import com.walmart.platform.soari.registry.domain.SubscriptionDO;
import com.walmart.platform.soari.registry.domain.dao.api.SubscriptionDAO;
import com.walmart.platform.soari.registry.domain.repository.SubscriptionRepository;
import com.walmart.platform.soari.registry.domain.specification.ConsumerSubscriptionSpecifications;
import com.walmart.platform.soari.registry.domain.util.Timed;
import com.walmart.platform.soari.registry.domain.util.DomainUtil;
import com.walmart.platform.soari.registry.server.common.exception.ExceptionHandler;
import com.walmart.platform.soari.registry.server.common.util.CommonConstants;

@Service("subscriptionDAO")
@Timed
public class SubscriptionDAOImpl implements SubscriptionDAO {

	private static final Logger LOG = LoggerFactory.getLogger(SubscriptionDAOImpl.class);

	@Autowired
	private SubscriptionRepository subscriptionRepository;
	
	@Autowired
	private ExceptionHandler exceptionHandler;

	@Override
	public List<SubscriptionDO> findAll() throws DataAccessException {
		LOG.debug("Executing findAll()");
		List<SubscriptionDO> result = null;
		try {
			result = subscriptionRepository.findAll();
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding all Subscriptions", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public List<SubscriptionDO> findAll(Sort sort) throws DataAccessException {
		LOG.debug("Executing findAll(Sort sort)");
		List<SubscriptionDO> result = null;
		try {
			result = subscriptionRepository.findAll(sort);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding all ordered Subscriptions", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public List<SubscriptionDO> save(Iterable<? extends SubscriptionDO> subscriptions)
			throws DataAccessException {
		LOG.debug("Executing save(Iterable<? extends SubscriptionDO> subscriptions");
		List<SubscriptionDO> result = null;
		try {
			result = subscriptionRepository.save(subscriptions);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "persisitng Subscriptions", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public Page<SubscriptionDO> findAll(Pageable pageable)
			throws DataAccessException {
		LOG.debug("Executing findAll(Pageable pageable)");
		Page<SubscriptionDO> result = null;
		try {
			result = subscriptionRepository.findAll(pageable);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding pageable Subscriptions", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public SubscriptionDO save(SubscriptionDO subscription) throws DataAccessException {
		LOG.debug("Executing save(SubscriptionDO subscription)");
		SubscriptionDO result = null;
		try {
			result = subscriptionRepository.save(subscription);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "persisitng Subscription", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public SubscriptionDO findOne(String id) throws DataAccessException {
		LOG.debug("Executing findOne(String id)");
		SubscriptionDO result = null;
		try {
			result = subscriptionRepository.findOne(id);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding Subscription by id", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public void delete(String id) throws DataAccessException {
		LOG.debug("Executing delete(String id)");
		try {
			subscriptionRepository.delete(id);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "deleting Subscription by id", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
	}

	@Override
	public void delete(SubscriptionDO subscription) throws DataAccessException {
		LOG.debug("Executing delete(SubscriptionDO subscription)");
		try {
			subscriptionRepository.delete(subscription);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "deleting Subscription", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
	}

	@Override
	public void delete(Iterable<? extends SubscriptionDO> subscriptions)
			throws DataAccessException {
		LOG.debug("Executing delete(Iterable<? extends SubscriptionDO> subscriptions)");
		try {
			subscriptionRepository.delete(subscriptions);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "deleting Subscriptions", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
	}

	@Override
	public List<SubscriptionDO> findByStatus(List<String> status) throws DataAccessException {
		LOG.debug("Executing findByMatchingStatus()");
		List<SubscriptionDO> result = null;
		try {
			result = subscriptionRepository.findByStatus(status);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding Subscriptions by status", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}
	
	@Override
	public List<SubscriptionDO> search(Map<String, String> search) throws DataAccessException {
		LOG.debug("Executing search()");
		List<SubscriptionDO> result = null;
		try {
			result = subscriptionRepository.findAll(ConsumerSubscriptionSpecifications.buildSubscriptionSearchPredicate(search));
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "searching Subscriptions by status", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}
	@Override
	public String findSubscriptionCountPerEnvironment() throws DataAccessException {
		List<Object[]> rows = subscriptionRepository.findSubscriptionCountPerEnvironment();
		return DomainUtil.buildCountPerEnvironmentResult(rows, "subscriptionsPerEnvironment");
	}
	
	@Override
	public String findConsumerSubscriptionCountPerEnvironment() throws DataAccessException {
		List<Object[]> rows = subscriptionRepository.findConsumerSubscriptionCountPerEnvironment();
			return DomainUtil.buildCountPerEnvironmentResult(rows, "consumerSubscriptionsPerEnvironment", "consumer", "subscriptionCount");
	}
	
	@Override
	public String findConsumerCountPerEnvironment() throws DataAccessException {
		List<Object[]> rows = subscriptionRepository.findConsumerCountPerEnvironment();
		return DomainUtil.buildCountPerEnvironmentResult(rows, "consumersPerEnvironment");
	}

	@Override
	public String findSubscriptionCountPerService() throws DataAccessException {
		List<Object[]> rows = subscriptionRepository.findSubscriptionCountPerService();
		return DomainUtil.buildCountPerEnvironmentResult(rows, "subscriptionsPerService", "service", "subscriptionCount");
	}
	
	@Override
	public String findServiceCountPerConsumer() throws DataAccessException {
		List<Object[]> rows = subscriptionRepository.findServiceCountPerConsumer();
		return DomainUtil.buildConsumerServiceCountPerEnvironmentResult(rows, "servicesPerConsumer", "consumer", "serviceCount");
	}
	
}
