package com.walmart.platform.soari.registry.domain.dao.impl;

import java.text.DateFormatSymbols;
import java.text.MessageFormat;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.walmart.platform.kernel.exception.layers.dao.DataAccessException;
import com.walmart.platform.soari.registry.domain.ServiceDO;
import com.walmart.platform.soari.registry.domain.dao.api.ServiceDAO;
import com.walmart.platform.soari.registry.domain.repository.ServiceRepository;
import com.walmart.platform.soari.registry.domain.specification.ServiceSpecifications;
import com.walmart.platform.soari.registry.server.common.exception.ExceptionHandler;
import com.walmart.platform.soari.registry.domain.util.Timed;
import com.walmart.platform.soari.registry.domain.util.DomainUtil;
import com.walmart.platform.soari.registry.server.common.util.CommonConstants;

@Service("serviceDAO")
@Timed
public class ServiceDAOImpl implements ServiceDAO {

	private static final Logger LOG = LoggerFactory.getLogger(ServiceDAOImpl.class);

	@Autowired
	private ServiceRepository serviceRepository;
	
	@Autowired
	private ExceptionHandler exceptionHandler;
	
	@Override
	public List<ServiceDO> findAll() throws DataAccessException {
		LOG.debug("Executing findAll()");
		List<ServiceDO> result = null;
		try {
			result = serviceRepository.findAll();
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding all Services", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public List<ServiceDO> findByStatus(List<String> status) throws DataAccessException {
		LOG.debug("Executing findByStatus()");
		List<ServiceDO> result = null;
		try {
			result = serviceRepository.findByStatus(status);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding all Services", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public List<ServiceDO> findByApplicationId(String applicationId) throws DataAccessException {
		LOG.debug("Executing findByApplicationId()");
		List<ServiceDO> result = null;
		try {
			result = serviceRepository.findByApplicationId(applicationId.toLowerCase());
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding Application Services", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public List<ServiceDO> findAll(Sort sort) throws DataAccessException {
		LOG.debug("Executing findAll(Sort sort)");
		List<ServiceDO> result = null;
		try {
			result = serviceRepository.findAll(sort);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding all ordered Services", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public List<ServiceDO> save(Iterable<? extends ServiceDO> services)
			throws DataAccessException {
		LOG.debug("Executing save(Iterable<? extends ServiceDO> services");
		List<ServiceDO> result = null;
		try {
			result = serviceRepository.save(services);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "persisitng Services", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public Page<ServiceDO> findAll(Pageable pageable)
			throws DataAccessException {
		LOG.debug("Executing findAll(Pageable pageable)");
		Page<ServiceDO> result = null;
		try {
			result = serviceRepository.findAll(pageable);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding pageable Services", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public ServiceDO save(ServiceDO service) throws DataAccessException {
		LOG.debug("Executing save(ServiceDO service)");
		ServiceDO result = null;
		try {
			result = serviceRepository.save(service);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "persisitng Service", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public ServiceDO findOne(String id) throws DataAccessException {
		LOG.debug("Executing findOne(String id)");
		ServiceDO result = null;
		try {
			result = serviceRepository.findOne(id);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding Service by id", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public void delete(String id) throws DataAccessException {
		LOG.debug("Executing delete(String id)");
		try {
			serviceRepository.delete(id);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "deleting Service by id", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
	}

	@Override
	public void delete(ServiceDO service) throws DataAccessException {
		LOG.debug("Executing delete(ServiceDO service)");
		try {
			serviceRepository.delete(service);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "deleting Service", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
	}

	@Override
	public void delete(Iterable<? extends ServiceDO> services)
			throws DataAccessException {
		LOG.debug("Executing delete(Iterable<? extends ServiceDO> services)");
		try {
			serviceRepository.delete(services);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "deleting Services", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
	}

	@Override
	public List<ServiceDO> findByMatchingName(String search)
			throws DataAccessException {
		LOG.debug("Executing findByMatchingName()");
		List<ServiceDO> result = null;
		try {
			String searchLike = "%"+search+"%";
			result = serviceRepository.findByMatchingName(searchLike.toLowerCase());
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding Services by matching name", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}
	
	@Override
	public List<ServiceDO> findByCategory(String search) throws DataAccessException {
		LOG.debug("Executing findByCategory()");
		List<ServiceDO> result = null;
		try {
			result = serviceRepository.findByCategory(search.toUpperCase());
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding Services by matching category", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}
	
	@Override
	public List<ServiceDO> findByMatchingDescription(String search) throws DataAccessException {
		LOG.debug("Executing findByMatchingDescription()");
		List<ServiceDO> result = null;
		try {
			String searchLike = "%"+search+"%";
			result = serviceRepository.findByMatchingDescription(searchLike.toLowerCase());
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding Services by matching description", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}
	
	@Override
	public List<ServiceDO> findByMatchingOwner(String search) throws DataAccessException {
		LOG.debug("Executing findByMatchingOwner()");
		List<ServiceDO> result = null;
		try {
			String searchLike = "%"+search+"%";
			result = serviceRepository.findByMatchingOwner(searchLike.toLowerCase());
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding Services by matching owner", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}
	
	@Override
	public List<ServiceDO> findByDomain(String search) throws DataAccessException {
		LOG.debug("Executing findByDomain()");
		List<ServiceDO> result = null;
		try {
			result = serviceRepository.findByDomain(search.toUpperCase());
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding Services by matching domain", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}
	
	@Override
	public List<ServiceDO> findByUsage(String search) throws DataAccessException {
		LOG.debug("Executing findByUsage()");
		List<ServiceDO> result = null;
		try {
			result = serviceRepository.findByUsage(search.toUpperCase());
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding Services by matching usage", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}
	
	@Override
	public List<ServiceDO> findByName(String name) throws DataAccessException {
		LOG.debug("Executing findByName()");
		List<ServiceDO> result = null;
		try {
			result = serviceRepository.findByName(name.toLowerCase());
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding Services by name", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public List<ServiceDO> findByEnvironment(String environment) throws DataAccessException {
		LOG.debug("Executing findByEnvironment()");
		List<ServiceDO> result = null;
		try {
			result = serviceRepository.findByEnvironment(environment.toLowerCase());
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding Services by environment", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public ServiceDO find(String name, String environment) throws DataAccessException {
		LOG.debug("Executing find(String name, String environment)");
		List<ServiceDO> result = null;
		try {
			String env = (environment == null?CommonConstants.getRunOnEnv():environment);
			result = serviceRepository.find(name.toLowerCase(), env.toLowerCase());
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding Services by name and environment", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result != null && !result.isEmpty() ? result.get(0):null;
	}

	@Override
	public List<ServiceDO> findDuplicate(String name, String environment, String applicationId) throws DataAccessException {
		LOG.debug("Executing findDuplicate(String name, String environment, String applicationId)");
		List<ServiceDO> result = null;
		try {
			String env = (environment == null?CommonConstants.getRunOnEnv():environment);
			String appId = (applicationId != null?applicationId.toLowerCase():applicationId);
			result = serviceRepository.findDuplicate(name.toLowerCase(), env.toLowerCase(), appId);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding Services by name and environment", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public List<ServiceDO> findByQoSId(String qosId) throws DataAccessException {
		LOG.debug("Executing findByQoSId()");
		List<ServiceDO> result = null;
		try {
			result = serviceRepository.findByQoSId(qosId);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding Services by qosId", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public List<ServiceDO> findByPolicyId(String policyId) throws DataAccessException {
		LOG.debug("Executing findByPolicyId()");
		List<ServiceDO> result = null;
		try {
			result = serviceRepository.findByPolicyId(policyId);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding Services by policyId", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public List<ServiceDO> search(
			final Map<String, String> search) throws DataAccessException {
		LOG.debug("Executing search()");
		List<ServiceDO> result = null;
		try {
			result = serviceRepository.findAll(ServiceSpecifications.buildPartialSearchPredicate(search));
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "searching services", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public ServiceDO searchOne(Map<String, String> search) throws DataAccessException {
		LOG.debug("Executing search()");
		ServiceDO result = null;
		try {
			result = serviceRepository.findOne(ServiceSpecifications.buildPartialSearchPredicate(search));
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "searching service", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}
	
	@Override
	public String findServiceCountPerEnvironment() throws DataAccessException {
		List<Object[]> rows = serviceRepository.findServiceCountPerEnvironment();
		return DomainUtil.buildCountPerEnvironmentResult(rows, "servicesPerEnvironment");
	}
	
	@Override
	public String findCategoryCountPerEnvironment() throws DataAccessException {
		List<Object[]> rows = serviceRepository.findCategoryCountPerEnvironment();
		return DomainUtil.buildCountPerEnvironmentResult(rows, "categoriesPerEnvironment", "environment", "categories", "category");
	}

	@Override
	public String findEnvironmentCountForService() throws DataAccessException {
		List<Object[]> rows = serviceRepository.findEnvironmentCountForService();
		StringBuilder sb = new StringBuilder();
		Iterator<Object[]> iter = rows.iterator();
		while(iter.hasNext()) {
			Object[] row = iter.next();
			String applicationId = String.valueOf(row[0]);
			String name = String.valueOf(row[1]);
			String envCount = String.valueOf(row[2]);
			sb.append("{");
			sb.append("\"applicationId\":\""+applicationId+"\",");
			sb.append("\"name\":\""+name+"\",");
			sb.append("\"count\":\""+envCount+"\"");
			sb.append("}");
			if(iter.hasNext()) {
				sb.append(",");	
			}
		}
		String result = sb.toString();
		return (result!=null && !result.isEmpty())?"{\"environmentCount\" : ["+result+"]}":"";
	}

	@Override
	public String findServiceCountPerMonth() throws DataAccessException {
		List<Object[]> rows = serviceRepository.findServiceCountPerMonth();
		StringBuilder sb = new StringBuilder();
		Map<String, Map<String, String>> dateMap = new HashMap<String, Map<String, String>>(0);
		for(Object[] row : rows) {
			String year = String.valueOf(row[0]);
			String month = String.valueOf(row[1]);
			String count = String.valueOf(row[2]);
			Map<String, String> categoryMap = dateMap.get(year);
			if(categoryMap == null) {
				categoryMap = new HashMap<String, String>(0);
				dateMap.put(year, categoryMap);
			}
			categoryMap.put(month, count);
		}
		Iterator<String> iter = dateMap.keySet().iterator();
		while(iter.hasNext()) {
			String year = iter.next();
			sb.append("{\"year\":\""+year+"\"");
			Map<String, String> monthMap = dateMap.get(year);
			if(monthMap != null && !monthMap.isEmpty()) {
				sb.append(",\"months\":[");
				Iterator<String> monthIter = monthMap.keySet().iterator();
				while(monthIter.hasNext()) {
					sb.append("{");
					String month = monthIter.next();
					sb.append("\"index\":\""+month+"\",");
					sb.append("\"month\":\""+(new DateFormatSymbols().getMonths()[Integer.valueOf(month)-1])+"\",");
					sb.append("\"count\":\""+monthMap.get(month)+"\"");
					sb.append("}");
					if(monthIter.hasNext()) {
						sb.append(",");
					}
				}
				sb.append("]");
			}
			sb.append("}");
			if(iter.hasNext()) {
				sb.append(",");
			}
		}
		String result = sb.toString();
		return (result!=null && !result.isEmpty())?"{\"servicesPerMonth\" : ["+result+"]}":"";
	}

}
