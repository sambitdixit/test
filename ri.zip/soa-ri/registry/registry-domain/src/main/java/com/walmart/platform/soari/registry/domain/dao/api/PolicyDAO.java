package com.walmart.platform.soari.registry.domain.dao.api;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import com.walmart.platform.kernel.exception.layers.dao.DataAccessException;
import com.walmart.platform.soari.registry.domain.PolicyDO;

public interface PolicyDAO {
	List<PolicyDO> findAll() throws DataAccessException;

	List<PolicyDO> findAll(Sort sort) throws DataAccessException;

	List<PolicyDO> save(Iterable<? extends PolicyDO> policies)
			throws DataAccessException;

	Page<PolicyDO> findAll(Pageable pageable)
			throws DataAccessException;

	PolicyDO save(PolicyDO policy) throws DataAccessException;

	PolicyDO findOne(String id) throws DataAccessException;

	void delete(String id) throws DataAccessException;

	void delete(PolicyDO policy) throws DataAccessException;

	void delete(Iterable<? extends PolicyDO> policies)
			throws DataAccessException;

	List<PolicyDO> findByMatchingName(String name)
			throws DataAccessException;

	List<PolicyDO> findByName(String name) throws DataAccessException;
	List<PolicyDO> findByStatus(List<String> status) throws DataAccessException;
}
