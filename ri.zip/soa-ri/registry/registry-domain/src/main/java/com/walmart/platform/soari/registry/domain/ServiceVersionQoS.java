package com.walmart.platform.soari.registry.domain;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.AssociationOverride;
import javax.persistence.AssociationOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.walmart.platform.soari.registry.domain.validation.EntityValidator;

@Entity
@Table(name = "SERVICE_VERSION_QOS")
@AssociationOverrides({
		@AssociationOverride(name = "pk.serviceVersion", 
			joinColumns = @JoinColumn(name = "SRV_VERSION_ID")),
		@AssociationOverride(name = "pk.qos", 
			joinColumns = @JoinColumn(name = "QOS_ID")) })
public class ServiceVersionQoS implements Serializable{

	/**
	 * class version id for serialization
	 */
	private static final long serialVersionUID = 1L;
	
	@EmbeddedId
	private ServiceVersionQoSId pk = new ServiceVersionQoSId();
	//@Transient
	@NotNull(message = "DAO_VALIDATE_QOS_VALUE_NOT_NULL")
	@Size(min=1, max = 128, message = "DAO_VALIDATE_QOS_VALUE_SIZE")
	@Column(name = "QOS_VALUE", nullable = false, length = 128)
	private String qosValue;
	
	/** The created by. */
	@Column(name = "CREATED_BY", nullable = false, length = 128, insertable = true, updatable = false)
	private String createdBy;

	/** The created at. */
	@Column(name = "CREATED_AT", nullable = false, insertable = true, updatable = false)
	private Timestamp createdAt;

	/** The modified by. */
	@Column(name = "MODIFIED_BY", nullable = true, length = 128, insertable = false, updatable = true)
	private String modifiedBy;

	/** The modified at. */
	@Column(name = "MODIFIED_AT", nullable = true, insertable = false, updatable = true)
	private Timestamp modifiedAt;
	
	/**
	 * On create.
	 */
	@PrePersist
	void onCreate() {
		if (this.getCreatedBy() == null) {
			this.setCreatedBy("soari_registry_app");
		}
		this.setCreatedAt(new Timestamp(System.currentTimeMillis()));
		EntityValidator.validateEntity(this);
	}

	/**
	 * On update.
	 */
	@PreUpdate
	void onUpdate() {
		if (this.getModifiedBy() == null) {
			this.setModifiedBy("soari_registry_app");
		}
		this.setModifiedAt(new Timestamp(System.currentTimeMillis()));
		EntityValidator.validateEntity(this);
	}
	
	/**
	 * @return the pk
	 */
	public ServiceVersionQoSId getPk() {
		return pk;
	}
	/**
	 * @param pk the pk to set
	 */
	public void setPk(ServiceVersionQoSId pk) {
		this.pk = pk;
	}
	/**
	 * @return the qosValue
	 */
	public String getQosValue() {
		return qosValue;
	}
	/**
	 * @param qosValue the qosValue to set
	 */
	public void setQosValue(String qosValue) {
		this.qosValue = qosValue;
	}
	
	/**
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}
	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	/**
	 * @return the createdAt
	 */
	public Timestamp getCreatedAt() {
		return createdAt;
	}
	/**
	 * @param createdAt the createdAt to set
	 */
	public void setCreatedAt(Timestamp createdAt) {
		this.createdAt = createdAt;
	}
	/**
	 * @return the modifiedBy
	 */
	public String getModifiedBy() {
		return modifiedBy;
	}
	/**
	 * @param modifiedBy the modifiedBy to set
	 */
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	/**
	 * @return the modifiedAt
	 */
	public Timestamp getModifiedAt() {
		return modifiedAt;
	}
	/**
	 * @param modifiedAt the modifiedAt to set
	 */
	public void setModifiedAt(Timestamp modifiedAt) {
		this.modifiedAt = modifiedAt;
	}
	@Transient
	public ServiceVersionDO getServiceVersion() {
		return getPk().getServiceVersion();
	}
 
	public void setServiceVersion(ServiceVersionDO serviceVersion) {
		getPk().setServiceVersion(serviceVersion);
	}
 
	@Transient
	public QoSDO getQos() {
		return getPk().getQos();
	}
 
	public void setQos(QoSDO qos) {
		getPk().setQos(qos);
	}
	
	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
 		ServiceVersionQoS that = (ServiceVersionQoS) o;
 
		if (getPk() != null ? !getPk().equals(that.getPk())
				: that.getPk() != null) {
			return false;
		}
		return true;
	}
 
	@Override
	public int hashCode() {
		return (getPk() != null ? getPk().hashCode() : 0);
	}
}
