package com.walmart.platform.soari.registry.domain;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.apache.commons.lang.builder.EqualsBuilder;
import com.walmart.platform.soari.registry.common.enums.EntityType;

/**
 * The persistent class for the SERVICE_VERSION database table.
 * 
 */
@Entity
@Table(name = "SERVICE_VERSION")
public class ServiceVersionDO extends EntityDO implements Serializable {
	/**
	 * class version id for serialization
	 */
	private static final long serialVersionUID = 1L;

	@Column(name = "ACTIVATION_END_DATE")
	private Timestamp activationEndDate;

	@Column(name = "ACTIVATION_START_DATE")
	private Timestamp activationStartDate;

	@Column(name = "AVAILABILITY_TIER", length = 128)
	private String availabilityTier;

	@Column(name = "ESB_REFERENCE", length = 128)
	private String esbReference;

	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL, orphanRemoval = true)
	@JoinTable(name = "SERVICE_VERSION_URL", joinColumns = { @JoinColumn(name = "SRV_VERSION_ID") }, inverseJoinColumns = { @JoinColumn(name = "URL_ID") })
	private Set<UrlDO> urls = new HashSet<UrlDO>(0);

	@Column(name = "ENVIRONMENT", length = 36)
	private String environment;

	@Column(name = "PUBLICATION_DATE")
	private Timestamp publicationDate;

	@NotNull(message = "DAO_VALIDATE_SERVICE_VERSION_NUMBER_NOT_NULL")
	@Column(name = "SERV_VERSION", nullable = false, length = 64)
	@Pattern(regexp = "^((([1-9]{0,1})\\d).(([1-9]{0,1})\\d).(([1-9]{0,1})\\d))", message = "DAO_VALIDATE_SERVICE_VERSION_NUMBER_INVALID")
	private String serVersion;

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "pk.serviceVersion", cascade = CascadeType.ALL, orphanRemoval = true)
	@org.hibernate.annotations.Cascade({ org.hibernate.annotations.CascadeType.ALL })
	private Set<ServiceVersionQoS> serviceVersionQos = new HashSet<ServiceVersionQoS>(
			0);

	// bi-directional many-to-many association to Policy
	@ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@org.hibernate.annotations.Cascade({ org.hibernate.annotations.CascadeType.ALL })
	@JoinTable(name = "SERVICE_VERSION_POLICY", joinColumns = { @JoinColumn(name = "SRV_VERSION_ID") }, inverseJoinColumns = { @JoinColumn(name = "POLICY_ID") })
	private Set<PolicyDO> policies = new HashSet<PolicyDO>(0);

	// bi-directional many-to-one association to Service
	@JoinColumn(name = "SERVICE_ID", nullable = false)
	@NotNull(message = "DAO_VALIDATE_SERVICE_VERSION_SERVICE_NOT_NULL")
	@ManyToOne
	private ServiceDO service;

	@ElementCollection
	@CollectionTable(name = "SERVICE_VERSION_ATTR", joinColumns = @JoinColumn(name = "SRC_VERSION_ID"))
	private Set<AttributeDO> attributes = new HashSet<AttributeDO>(
			0);

	public ServiceVersionDO() {
		this.setEntityType(EntityType.SRVC_VERSION);
	}

	public Timestamp getActivationEndDate() {
		return this.activationEndDate;
	}

	public void setActivationEndDate(Timestamp activationEndDate) {
		this.activationEndDate = activationEndDate;
	}

	public Timestamp getActivationStartDate() {
		return this.activationStartDate;
	}

	public void setActivationStartDate(Timestamp activationStartDate) {
		this.activationStartDate = activationStartDate;
	}

	public String getAvailabilityTier() {
		return availabilityTier;
	}

	public void setAvailabilityTier(String availabilityTier) {
		this.availabilityTier = availabilityTier;
	}

	public String getEsbReference() {
		return esbReference;
	}

	public void setEsbReference(String esbReference) {
		this.esbReference = esbReference;
	}

	public String getEnvironment() {
		return environment;
	}

	public void setEnvironment(String environment) {
		this.environment = environment;
	}

	public Timestamp getPublicationDate() {
		return this.publicationDate;
	}

	public void setPublicationDate(Timestamp publicationDate) {
		this.publicationDate = publicationDate;
	}

	public String getSerVersion() {
		return serVersion;
	}

	public void setSerVersion(String serVersion) {
		this.serVersion = serVersion;
	}

	public Set<PolicyDO> getPolicies() {
		return this.policies;
	}

	public void setPolicies(Set<PolicyDO> policies) {
		this.policies = policies;
	}

	public ServiceDO getService() {
		return this.service;
	}

	public Set<UrlDO> getUrls() {
		return urls;
	}

	public void setUrls(Set<UrlDO> urls) {
		this.urls = urls;
	}

	public void setService(ServiceDO service) {
		if (this.service != service) {
			this.service = service;
			if (service != null && !service.getServiceVersions().contains(this)) {
				service.getServiceVersions().add(this);
			}
		}
	}

	public void addPolicy(PolicyDO policy) {
		if (!this.policies.contains(policy)) {
			this.policies.add(policy);
		}
	}

	public void removePolicy(PolicyDO policy) {
		if (this.policies.contains(policy)) {
			this.policies.remove(policy);
		}
	}

	public void addServiceVersionQoS(ServiceVersionQoS serviceVersionQoS) {
		if (!this.serviceVersionQos.contains(serviceVersionQoS)) {
			this.serviceVersionQos.add(serviceVersionQoS);
		}
	}

	public void removeServiceVersionQoS(ServiceVersionQoS serviceVersionQoS) {
		if (this.serviceVersionQos.contains(serviceVersionQoS)) {
			this.serviceVersionQos.remove(serviceVersionQoS);
		}
	}

	/**
	 * @return the serviceVersionQos
	 */
	public Set<ServiceVersionQoS> getServiceVersionQos() {
		return serviceVersionQos;
	}

	/**
	 * @param serviceVersionQos
	 *            the serviceVersionQos to set
	 */
	public void setServiceVersionQos(Set<ServiceVersionQoS> serviceVersionQos) {
		this.serviceVersionQos = serviceVersionQos;
	}

	/**
	 * @return the attributes
	 */
	public Set<AttributeDO> getAttributes() {
		return attributes;
	}

	/**
	 * @param attributes the attributes to set
	 */
	public void setAttributes(Set<AttributeDO> attributes) {
		this.attributes = attributes;
	}

	@Override
	public boolean equals(final Object rhs) {
		if (this == rhs) {
			return true;
		}
		if (rhs == null || getClass() != rhs.getClass()) {
			return false;
		}
		ServiceVersionDO other = (ServiceVersionDO) rhs;
		return isEquals(other);
	}

	private boolean isEquals(ServiceVersionDO rhs) {
		return new EqualsBuilder().append(this.getId(), rhs.getId())
				.append(this.getStatus(), rhs.getStatus())
				.append(this.activationEndDate, rhs.activationEndDate)
				.append(this.activationStartDate, rhs.activationStartDate)
				.append(this.availabilityTier, rhs.availabilityTier)
				.append(this.environment, rhs.environment)
				.append(this.publicationDate, rhs.publicationDate)
				.append(this.getStatus(), rhs.getStatus())
				.append(this.serVersion, rhs.serVersion)
				.append(this.service, rhs.service).isEquals();
	}

	@Override
	public int hashCode() {
		int result;
		result = (this.getId() != null ? this.getId().hashCode() : 0);
		result = 31 * result
				+ (this.getStatus() != null ? this.getStatus().hashCode() : 0);
		result = 31
				* result
				+ (activationEndDate != null ? activationEndDate.hashCode() : 0);
		result = 31
				* result
				+ (activationStartDate != null ? activationStartDate.hashCode()
						: 0);
		result = 31 * result
				+ (availabilityTier != null ? availabilityTier.hashCode() : 0);
		result = 31 * result
				+ (environment != null ? environment.hashCode() : 0);
		result = 31 * result
				+ (publicationDate != null ? publicationDate.hashCode() : 0);
		result = 31 * result
				+ (this.getStatus() != null ? this.getStatus().hashCode() : 0);
		result = 31 * result + (serVersion != null ? serVersion.hashCode() : 0);
		result = 31 * result + (service != null ? service.hashCode() : 0);

		return result;
	}
}