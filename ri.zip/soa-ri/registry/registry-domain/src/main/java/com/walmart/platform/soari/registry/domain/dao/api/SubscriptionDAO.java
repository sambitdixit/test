package com.walmart.platform.soari.registry.domain.dao.api;

import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import com.walmart.platform.kernel.exception.layers.dao.DataAccessException;
import com.walmart.platform.soari.registry.domain.SubscriptionDO;

public interface SubscriptionDAO {
	List<SubscriptionDO> findAll() throws DataAccessException;

	List<SubscriptionDO> findAll(Sort sort) throws DataAccessException;

	List<SubscriptionDO> save(Iterable<? extends SubscriptionDO> subscriptions)
			throws DataAccessException;

	Page<SubscriptionDO> findAll(Pageable pageable)
			throws DataAccessException;
	SubscriptionDO findOne(String id) throws DataAccessException;
	SubscriptionDO save(SubscriptionDO subscription) throws DataAccessException;
	void delete(String id) throws DataAccessException;
	void delete(SubscriptionDO subscription) throws DataAccessException;
	void delete(Iterable<? extends SubscriptionDO> subscriptions)
			throws DataAccessException;

	List<SubscriptionDO> findByStatus(List<String> status) throws DataAccessException;
	List<SubscriptionDO> search(Map<String, String> search) throws DataAccessException;
	String findSubscriptionCountPerEnvironment() throws DataAccessException;
	String findConsumerSubscriptionCountPerEnvironment() throws DataAccessException;
	String findConsumerCountPerEnvironment() throws DataAccessException;
	String findSubscriptionCountPerService() throws DataAccessException;
	String findServiceCountPerConsumer() throws DataAccessException;
}
