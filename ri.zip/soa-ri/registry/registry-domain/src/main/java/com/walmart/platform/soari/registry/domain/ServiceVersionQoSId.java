package com.walmart.platform.soari.registry.domain;

import java.io.Serializable;

import javax.persistence.Embeddable;
import javax.persistence.ManyToOne;
import javax.validation.constraints.NotNull;

@Embeddable
public class ServiceVersionQoSId implements Serializable{
	
	/**
	 * class version id for serialization
	 */
	private static final long serialVersionUID = 1L;
	
	@ManyToOne
	@NotNull
	private ServiceVersionDO serviceVersion;
	@ManyToOne
	@NotNull
	private QoSDO qos;
	/**
	 * @return the serviceVersion
	 */
	public ServiceVersionDO getServiceVersion() {
		return serviceVersion;
	}
	/**
	 * @param serviceVersion the serviceVersion to set
	 */
	public void setServiceVersion(ServiceVersionDO serviceVersion) {
		this.serviceVersion = serviceVersion;
	}
	/**
	 * @return the qos
	 */
	public QoSDO getQos() {
		return qos;
	}
	/**
	 * @param qos the qos to set
	 */
	public void setQos(QoSDO qos) {
		this.qos = qos;
	}
	
	/**
	 * overridden equals() method
	 */
	public boolean equals(Object o) {
        if (this == o) {
        	return true;
        }
        if (o == null || getClass() != o.getClass()) {
        	return false;
        }
 
        ServiceVersionQoSId that = (ServiceVersionQoSId) o;
 
        if (serviceVersion != null ? !serviceVersion.equals(that.serviceVersion) : that.serviceVersion != null) {
        	return false;
        }
        if (qos != null ? !qos.equals(that.qos) : that.qos != null) {
            return false;
        }
        return true;
    }
 
    /**
     * overridden hashCode() method
     */
	public int hashCode() {
        int result;
        result = (serviceVersion != null ? serviceVersion.hashCode() : 0);
        result = 31 * result + (qos != null ? qos.hashCode() : 0);
        return result;
    }
}
