package com.walmart.platform.soari.registry.domain;

import java.io.Serializable;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import javax.persistence.Version;

import com.walmart.platform.soari.registry.common.enums.RegistryPolicyCodeType;

@Entity
@Table(name = "REGISTRY_POLICY_CODE")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "TYPE", discriminatorType = DiscriminatorType.STRING)
public class RegistryPolicyCode implements Serializable {

	/**
	 * class version id for serialization
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "ID", length = 36)
	private String id;

	@Version
	@Column(name = "VERSION", nullable = false, length = 36)
	private Integer version;

	@Enumerated(EnumType.STRING)
	@Column(name = "TYPE", length = 36, nullable = false, insertable = false, updatable = false)
	private RegistryPolicyCodeType type;

	@Column(name = "CODE", length = 36, nullable = false)
	private String code;

	@Column(name = "DESCRIPTION", length = 128, nullable = false)
	private String description;
	
	/**
	 * no-arg constructor
	 */
	public RegistryPolicyCode() {
	}

	/**
	 * On create.
	 */
	@PrePersist
	void onCreate() {
		this.setId(UUID.randomUUID().toString().replace("-", ""));
	}
	
	/**
	 * getter for id of {@link RegistryPolicyCode}
	 * @return
	 */
	public String getId() {
		return id;
	}

	/**
	 * setter for {@link RegistryPolicyCode} id
	 * @param id
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * getter for trype of {@link RegistryPolicyCode}
	 * @return
	 */
	public RegistryPolicyCodeType getType() {
		return type;
	}

	/**
	 * setter for type of {@link RegistryPolicyCode}
	 * @param type
	 */
	public void setType(RegistryPolicyCodeType type) {
		this.type = type;
	}

	/**
	 * getter for code of {@link RegistryPolicyCode}
	 * @return
	 */
	public String getCode() {
		return code;
	}

	/**
	 * setter for code of {@link RegistryPolicyCode}
	 * @param code
	 */
	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * getter for description of {@link RegistryPolicyCode}
	 * @return
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * setter for description of {@link RegistryPolicyCode}
	 * @param description
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * overridden hashCode() method
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((code == null) ? 0 : code.hashCode());
		result = prime * result
				+ ((description == null) ? 0 : description.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((type == null) ? 0 : type.hashCode());
		return result;
	}

	/**
	 * overridden equals() method
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof RegistryPolicyCode)) {
			return false;
		}
		RegistryPolicyCode other = (RegistryPolicyCode) obj;
		if (code == null) {
			if (other.code != null) {
				return false;
			}
		} else if (!code.equals(other.code)) {
			return false;
		}
		if (description == null) {
			if (other.description != null) {
				return false;
			}
		} else if (!description.equals(other.description)) {
			return false;
		}
		if (id == null) {
			if (other.id != null) {
				return false;
			}
		} else if (!id.equals(other.id)) {
			return false;
		}
		if (type != other.type) {
			return false;
		}
		return true;
	}

	/**
	 * @return the version
	 */
	public Integer getVersion() {
		return version;
	}

	/**
	 * @param version
	 *            the version to set
	 */
	public void setVersion(Integer version) {
		this.version = version;
	}

}
