package com.walmart.platform.soari.registry.domain.specification;

import java.util.List;
import java.util.Map;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.jpa.domain.Specification;

import com.walmart.platform.soa.common.util.SOAStringUtil;
import com.walmart.platform.soari.registry.domain.ServiceDO;

/**
 * A class which is used to create Specification objects which are used to
 * create JPA criteria queries for Service information.
 * 
 * @author Sanjay Bonde
 */
public class ServiceSpecifications {

	private static String getLowerCasePattern(final String searchTerm) {
		return searchTerm.trim().toLowerCase();
	}

	private static String getLikePattern(final String searchTerm) {
		StringBuilder pattern = new StringBuilder();
		pattern.append("%");
		pattern.append(searchTerm.toLowerCase());
		pattern.append("%");
		return pattern.toString();
	}

	/**
	 * Creates a specification used to find Services whose details matches the
	 * given search term. This search is case insensitive.
	 * 
	 * @param searchTerm
	 * @return
	 */
	public static Specification<ServiceDO> buildPartialSearchPredicate(
			final Map<String, String> search) {

		return new Specification<ServiceDO>() {
			@Override
			public Predicate toPredicate(
					Root<ServiceDO> registryPolicyCodeRoot,
					CriteriaQuery<?> query, CriteriaBuilder cb) {
				Predicate predicate = cb.conjunction();
				
				String name = search.get("name");
				String status = search.get("status");
				String category = search.get("category");
				String description = search.get("description");
				String owner = search.get("owner");
				String domain = search.get("domain");
				String usage = search.get("usage");
				String environment = search.get("environment");
				String applicationId = search.get("applicationId");

				// Add perdicate for name
				if (!SOAStringUtil.isBlank(name)) {
					predicate.getExpressions().add(
							cb.like(cb.lower(registryPolicyCodeRoot
									.<String> get("name")),
									getLikePattern(name)));
				}
				if (!SOAStringUtil.isBlank(applicationId)) {
					predicate.getExpressions().add(
							cb.like(cb.lower(registryPolicyCodeRoot
									.<String> get("applicationId")),applicationId));
				}
				
				// Add perdicate for status
				if (!SOAStringUtil.isBlank(status)) {
					predicate.getExpressions().add(
							cb.equal(
									registryPolicyCodeRoot.<String> get(
											"status"),
									status.toUpperCase()));
				}
				// Add perdicate for category
				/*if (!SOAStringUtil.isBlank(category)) {
					predicate.getExpressions().add(
							cb.equal(registryPolicyCodeRoot
									.<ServiceCategory> get("category")
									.<String> get(CODE), category
									.toUpperCase()));
				}*/
				if (!SOAStringUtil.isBlank(category)) {
					predicate.getExpressions().add(
							cb.equal(registryPolicyCodeRoot
									.<String> get("category"), category
									.toUpperCase()));
				}
				// Add perdicate for description
				if (!SOAStringUtil.isBlank(description)) {
					predicate.getExpressions().add(
							cb.like(cb.lower(registryPolicyCodeRoot
									.<String> get("description")),
									getLikePattern(description)));
				}
				// Add perdicate for owner
				if (!SOAStringUtil.isBlank(owner)) {
					predicate.getExpressions().add(
							cb.like(cb.lower(registryPolicyCodeRoot
									.<String> get("owner")),
									getLikePattern(owner)));
				}
				// Add perdicate for domain
				if (!SOAStringUtil.isBlank(domain)) {
					predicate
							.getExpressions()
							.add(cb.equal(registryPolicyCodeRoot
									.<String> get("domain"), domain.toUpperCase()));
				}
				// Add perdicate for usage
				if (!SOAStringUtil.isBlank(usage)) {
					predicate.getExpressions().add(
							cb.equal(
									registryPolicyCodeRoot.<String> get(
											"usage"), usage.toUpperCase()));
				}
				// Add perdicate for environment
				if (!SOAStringUtil.isBlank(environment)) {
					predicate.getExpressions().add(
							cb.like(cb.lower(registryPolicyCodeRoot
									.<String> get("environment")),
									getLikePattern(environment)));
				}
				return predicate;
			}

		};
	}
	
	public static Specification<ServiceDO> buildSearchPredicate(
			final String name, final String environment) {

		return new Specification<ServiceDO>() {
			@Override
			public Predicate toPredicate(
					Root<ServiceDO> registryPolicyCodeRoot,
					CriteriaQuery<?> query, CriteriaBuilder cb) {
				Predicate predicate = cb.conjunction();
				// Add perdicate for name
				if (!SOAStringUtil.isBlank(name)) {
					predicate.getExpressions().add(
							cb.equal(cb.lower(registryPolicyCodeRoot
									.<String> get("name")),
									getLowerCasePattern(name)));
				}
				// Add perdicate for environment
				if (!SOAStringUtil.isBlank(environment)) {
					predicate.getExpressions().add(
							cb.equal(cb.lower(registryPolicyCodeRoot
									.<String> get("environment")),
									getLowerCasePattern(environment)));
				}
				return predicate;
			}

		};
	}

	public static Specification<ServiceDO> buildSearchPredicate(
			final List<String> status) {

		return new Specification<ServiceDO>() {
			@Override
			public Predicate toPredicate(
					Root<ServiceDO> registryPolicyCodeRoot,
					CriteriaQuery<?> query, CriteriaBuilder cb) {
				Predicate predicate = cb.conjunction();
				// Add perdicate for name
				if (status != null && !status.isEmpty()) {
					predicate.getExpressions().add(
							registryPolicyCodeRoot.<String> get("status")
									.in(status));
				}
				return predicate;
			}

		};
	}
	
}