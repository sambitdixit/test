package com.walmart.platform.soari.registry.domain.util;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class DomainUtil {

	/*public static String getDecryptedJasyptText(String input) {
		EnvironmentStringPBEConfig e = new EnvironmentStringPBEConfig();
		e.setAlgorithm("PBEWithMD5AndDES");
		e.setPassword("soari-registry-app");
		StandardPBEStringEncryptor s = new StandardPBEStringEncryptor();
		s.setConfig(e);
		return s.decrypt(input);
	}
	
	public static String getEncryptedJasyptText(String input) {
		EnvironmentStringPBEConfig e = new EnvironmentStringPBEConfig();
		e.setAlgorithm("PBEWithMD5AndDES");
		e.setPassword("soari-registry-app");
		StandardPBEStringEncryptor s = new StandardPBEStringEncryptor();
		s.setConfig(e);
		return s.encrypt(input);
	}
	
	public static void main(String[] args) {
		String myEncryptedText = getEncryptedJasyptText("soa_APP_p");
		System.out.println("myEncryptedText = "+myEncryptedText);
		String myDecryptedText = getDecryptedJasyptText("eI9WUu/uUMsbYPZgnzL7g1QhGzP0CPaz");
		System.out.println("myDecryptedText = "+myDecryptedText);
	}
	*/

	public static String buildCountPerEnvironmentResult(List<Object[]> rows, final String rootNode) {
		Map<String, Integer> envConsumerMap = new HashMap<String, Integer>(0);
		for(Object[] row : rows) {
			String env = String.valueOf(row[0]);
			Integer count = Integer.valueOf(String.valueOf(row[1]));
			Integer countValue = envConsumerMap.get(env);
			if(countValue == null || countValue < count){
				envConsumerMap.put(env, count);
			}
		}
		StringBuilder sb = new StringBuilder();
		Iterator<String> iter = envConsumerMap.keySet().iterator();
		while(iter.hasNext()) {
			String env = iter.next();
			Integer count = envConsumerMap.get(env);
			sb.append("{");
			sb.append("\"environment\":\""+env+"\",");
			sb.append("\"count\":\""+count+"\"");
			sb.append("}");
			if(iter.hasNext()) {
				sb.append(",");	
			}
		}
		String result = sb.toString();
		return (result!=null && !result.isEmpty())?"{\""+rootNode+"\" : ["+result+"]}":"";
	}
	
	public static String buildCountPerEnvironmentResult(List<Object[]> rows, final String rootNode, final String childNode, final String countNode) {
		return buildCountPerEnvironmentResult(rows, rootNode, childNode, countNode, "environment");
	}
	public static String buildCountPerEnvironmentResult(List<Object[]> rows, final String rootNode, final String childNode, final String countNode, final String identifier) {
		StringBuilder sb = new StringBuilder();
		Map<String, Map<String, String>> serviceMap = new HashMap<String, Map<String, String>>(0);
		for(Object[] row : rows) {
			String item = String.valueOf(row[0]);
			String environment = String.valueOf(row[1]);
			String count = String.valueOf(row[2]);
			Map<String, String> envCountMap = serviceMap.get(item);
			if(envCountMap == null) {
				envCountMap = new HashMap<String, String>(0);
				serviceMap.put(item, envCountMap);
			}
			envCountMap.put(environment, count);
		}
		Iterator<String> iter = serviceMap.keySet().iterator();
		while(iter.hasNext()) {
			String service = iter.next();
			sb.append("{\""+childNode+"\":\""+service+"\"");
			Map<String, String> envServiceMap = serviceMap.get(service);
			if(envServiceMap != null && !envServiceMap.isEmpty()) {
				sb.append(",\""+countNode+"\":[");
				Iterator<String> envServiceIter = envServiceMap.keySet().iterator();
				while(envServiceIter.hasNext()) {
					sb.append("{");
					String environment = envServiceIter.next();
					sb.append("\""+identifier+"\":\""+environment+"\",");
					sb.append("\"count\":\""+envServiceMap.get(environment)+"\"");
					sb.append("}");
					if(envServiceIter.hasNext()) {
						sb.append(",");
					}
				}
				sb.append("]");
			}
			sb.append("}");
			if(iter.hasNext()) {
				sb.append(",");
			}
		}
		String result = sb.toString();
		return (result!=null && !result.isEmpty())?"{\""+rootNode+"\" : ["+result+"]}":"";
	}
	
	public static String buildConsumerServiceCountPerEnvironmentResult(List<Object[]> rows, final String rootNode, final String childNode, final String countNode) {
		StringBuilder sb = new StringBuilder();
		Map<String, Map<String, Set<String>>> consumerMap = new HashMap<String, Map<String, Set<String>>>(0);
		for(Object[] row : rows) {
			String item = String.valueOf(row[0]);
			String environment = String.valueOf(row[1]);
			String service = String.valueOf(row[2]);
			Map<String, Set<String>> envServiceMap = consumerMap.get(item);
			if(envServiceMap == null) {
				envServiceMap = new HashMap<String, Set<String>>(0);
				consumerMap.put(item, envServiceMap);
			}
			Set<String> services = envServiceMap.get(environment);
			if(services == null) {
				services = new HashSet<String>(0);
				envServiceMap.put(environment, services);
			}
			services.add(service);
		}
		Iterator<String> iter = consumerMap.keySet().iterator();
		while(iter.hasNext()) {
			String consumer = iter.next();
			sb.append("{\""+childNode+"\":\""+consumer+"\"");
			Map<String, Set<String>> envServiceMap = consumerMap.get(consumer);
			if(envServiceMap != null && !envServiceMap.isEmpty()) {
				sb.append(",\""+countNode+"\":[");
				Iterator<String> envServiceIter = envServiceMap.keySet().iterator();
				while(envServiceIter.hasNext()) {
					sb.append("{");
					String environment = envServiceIter.next();
					sb.append("\"environment\":\""+environment+"\",");
					sb.append("\"count\":\""+envServiceMap.get(environment).size()+"\"");
					sb.append("}");
					if(envServiceIter.hasNext()) {
						sb.append(",");
					}
				}
				sb.append("]");
			}
			sb.append("}");
			if(iter.hasNext()) {
				sb.append(",");
			}
		}
		String result = sb.toString();
		return (result!=null && !result.isEmpty())?"{\""+rootNode+"\" : ["+result+"]}":"";
	}
	
}
