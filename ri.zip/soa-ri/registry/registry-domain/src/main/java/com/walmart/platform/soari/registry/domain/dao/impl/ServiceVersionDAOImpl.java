package com.walmart.platform.soari.registry.domain.dao.impl;

import java.text.MessageFormat;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.walmart.platform.kernel.exception.layers.dao.DataAccessException;
import com.walmart.platform.soari.registry.domain.ServiceVersionDO;
import com.walmart.platform.soari.registry.domain.dao.api.ServiceVersionDAO;
import com.walmart.platform.soari.registry.domain.repository.ServiceVersionRepository;
import com.walmart.platform.soari.registry.server.common.exception.ExceptionHandler;
import com.walmart.platform.soari.registry.domain.util.Timed;
import com.walmart.platform.soari.registry.server.common.util.CommonConstants;

@Service("serviceVersionDAO")
@Timed
public class ServiceVersionDAOImpl implements ServiceVersionDAO {

	private static final Logger LOG = LoggerFactory.getLogger(ServiceVersionDAOImpl.class);

	@Autowired
	private ServiceVersionRepository serviceVersionRepository;
	
	@Autowired
	private ExceptionHandler exceptionHandler;
	
	@Override
	public List<ServiceVersionDO> findAll() throws DataAccessException {
		LOG.debug("Executing findAll()");
		List<ServiceVersionDO> result = null;
		try {
			result = serviceVersionRepository.findAll();
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding all ServiceVersions", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public List<ServiceVersionDO> findAll(Sort sort) throws DataAccessException {
		LOG.debug("Executing findAll(Sort sort)");
		List<ServiceVersionDO> result = null;
		try {
			result = serviceVersionRepository.findAll(sort);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding all ordered ServiceVersions", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public List<ServiceVersionDO> save(Iterable<? extends ServiceVersionDO> serviceVersions)
			throws DataAccessException {
		LOG.debug("Executing save(Iterable<? extends ServiceVersionDO> serviceVersions");
		List<ServiceVersionDO> result = null;
		try {
			result = serviceVersionRepository.save(serviceVersions);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "persisitng ServiceVersions", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public Page<ServiceVersionDO> findAll(Pageable pageable)
			throws DataAccessException {
		LOG.debug("Executing findAll(Pageable pageable)");
		Page<ServiceVersionDO> result = null;
		try {
			result = serviceVersionRepository.findAll(pageable);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding pageable ServiceVersions", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	/**
	 * NOTE: need to add the code in catch block to preserve the stack trace
	 */
	@Override
	public ServiceVersionDO save(ServiceVersionDO serviceVersion) throws DataAccessException {
		LOG.debug("Executing save(ServiceVersionDO serviceVersion)");
		ServiceVersionDO result = null;
		try {
			result = serviceVersionRepository.save(serviceVersion);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "persisitng ServiceVersion", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public ServiceVersionDO saveAndFlush(ServiceVersionDO serviceVersion) throws DataAccessException {
		LOG.debug("Executing save(ServiceVersionDO serviceVersion)");
		ServiceVersionDO result = null;
		try {
			result = serviceVersionRepository.save(serviceVersion);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "persisitng ServiceVersion", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public ServiceVersionDO findOne(String id) throws DataAccessException {
		LOG.debug("Executing findOne(String id)");
		ServiceVersionDO result = null;
		try {
			result = serviceVersionRepository.findOne(id);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding ServiceVersion by id", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public void delete(String id) throws DataAccessException {
		LOG.debug("Executing delete(String id)");
		try {
			serviceVersionRepository.delete(id);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "deleting ServiceVersion by id", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
	}

	@Override
	public void delete(ServiceVersionDO serviceVersion) throws DataAccessException {
		LOG.debug("Executing delete(ServiceVersionDO serviceVersion)");
		try {
			serviceVersionRepository.delete(serviceVersion);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "deleting ServiceVersion", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
	}

	@Override
	public void delete(Iterable<? extends ServiceVersionDO> serviceVersions)
			throws DataAccessException {
		LOG.debug("Executing delete(Iterable<? extends ServiceVersionDO> serviceVersions)");
		try {
			serviceVersionRepository.delete(serviceVersions);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "deleting ServiceVersions", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
	}
	
	@Override
	public List<ServiceVersionDO> findServiceVersion(String serviceId,
			String serviceVersion) throws DataAccessException {
		LOG.debug("Executing findServiceVersion(String serviceId, String serviceVersion)");
		List<ServiceVersionDO> result = null;
		try {
			result = serviceVersionRepository.findServiceVersion(serviceId, serviceVersion);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding service version by serviceid and version", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}
	
	@Override
	public List<ServiceVersionDO> findByAvailabilityTier(String availabilityTier) throws DataAccessException {
		LOG.debug("Executing findByAvailabilityTier(String availabilityTier)");
		List<ServiceVersionDO> result = null;
		try {
			result = serviceVersionRepository.findByAvailabilityTier(availabilityTier.toUpperCase());
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding service version by availabilityTier", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}
	
	@Override
	public List<ServiceVersionDO> findByESBReference(String esbReference) throws DataAccessException {
		LOG.debug("Executing findByESBReference(String esbReference)");
		List<ServiceVersionDO> result = null;
		try {
			result = serviceVersionRepository.findByESBReference(esbReference.toUpperCase());
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding service version by esbReference", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}
}
