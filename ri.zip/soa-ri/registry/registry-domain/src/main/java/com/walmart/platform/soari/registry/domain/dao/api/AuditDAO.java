package com.walmart.platform.soari.registry.domain.dao.api;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import com.walmart.platform.kernel.exception.layers.dao.DataAccessException;
import com.walmart.platform.soari.registry.domain.AuditDO;

public interface AuditDAO {
	
	List<AuditDO> findAll() throws DataAccessException;

	List<AuditDO> findAll(Sort sort) throws DataAccessException;

	List<AuditDO> save(Iterable<? extends AuditDO> policyRegistryPolicyAudits)
			throws DataAccessException;

	Page<AuditDO> findAll(Pageable pageable)
			throws DataAccessException;

	AuditDO save(AuditDO policyRegistryPolicyAudit) throws DataAccessException;

	AuditDO findOne(String id) throws DataAccessException;

	void delete(String id) throws DataAccessException;

	void delete(AuditDO policyRegistryPolicyAudit) throws DataAccessException;

	void delete(Iterable<? extends AuditDO> policyRegistryPolicyAudits)
			throws DataAccessException;
	
	List<AuditDO> findByEntity(String entityId, Integer fetchCount) throws DataAccessException;

}
