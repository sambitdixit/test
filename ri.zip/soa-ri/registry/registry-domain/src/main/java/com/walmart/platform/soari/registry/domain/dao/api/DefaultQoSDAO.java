package com.walmart.platform.soari.registry.domain.dao.api;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import com.walmart.platform.kernel.exception.layers.dao.DataAccessException;
import com.walmart.platform.soari.registry.domain.DefaultQoSDO;
import com.walmart.platform.soari.registry.domain.QoSDO;

public interface DefaultQoSDAO {
	
	List<DefaultQoSDO> findAll() throws DataAccessException;

	List<DefaultQoSDO> findAll(Sort sort) throws DataAccessException;

	List<DefaultQoSDO> save(Iterable<? extends DefaultQoSDO> qos)
			throws DataAccessException;

	Page<DefaultQoSDO> findAll(Pageable pageable)
			throws DataAccessException;

	DefaultQoSDO save(DefaultQoSDO qos) throws DataAccessException;

	DefaultQoSDO findOne(String id) throws DataAccessException;

	void delete(String id) throws DataAccessException;

	void delete(DefaultQoSDO qos) throws DataAccessException;

	void delete(Iterable<? extends DefaultQoSDO> qos)
			throws DataAccessException;

	List<DefaultQoSDO> findByMatchingName(String name)
			throws DataAccessException;

	List<DefaultQoSDO> findByName(String name) throws DataAccessException;
	
	List<DefaultQoSDO> findByMatchingStatus(String status) throws DataAccessException;
	List<DefaultQoSDO> findByStatus(List<String> status) throws DataAccessException;

	List<DefaultQoSDO> findByMatchingEnv(String searchValue) throws DataAccessException;
	List<DefaultQoSDO> findByMatchingCategory(String searchValue) throws DataAccessException;
	
//	List<DefaultQoSDO> findByMatchingValue(String searchValue) throws DataAccessException;
//	List<DefaultQoSDO> findByMatchingType(String searchValue) throws DataAccessException;
}
