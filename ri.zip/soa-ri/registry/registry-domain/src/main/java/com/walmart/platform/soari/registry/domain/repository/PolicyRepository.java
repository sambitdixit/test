package com.walmart.platform.soari.registry.domain.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.walmart.platform.kernel.exception.layers.dao.DataAccessException;
import com.walmart.platform.soari.registry.domain.PolicyDO;

@Repository(value="policyRepository")
public interface PolicyRepository extends JpaRepository<PolicyDO, String>{
	
	/**
	 * Fetches list of {@link PolicyDO} with name similar to 'name' and status != deleted
	 * 
	 * @param name {@link PolicyDO}'s name to be matched
	 * @return list of matching {@link PolicyDO} 
	 * @throws DataAccessException
	 */
	@Query("from PolicyDO policy where lower(policy.name) like :name and policy.status <>'DELETED'")
	List<PolicyDO> findByMatchingName(@Param("name") String name) throws DataAccessException;
	
	/**
	 * Fetches list of {@link PolicyDO} with name as name'
	 * 
	 * @param name {@link PolicyDO}'s name to be matched
	 * @return list of matching {@link PolicyDO} 
	 * @throws DataAccessException
	 */
	@Query("from PolicyDO policy where lower(policy.name) = :name")
	List<PolicyDO> findByName(@Param("name") String name) throws DataAccessException;
	
	/**
	 * Fetches list of {@link PolicyDO} with status present in  'status'
	 * 
	 * @param status list of {@link PolicyDO}'s status to be matched
	 * @return list of matching {@link PolicyDO} 
	 * @throws DataAccessException
	 */
	@Query("from PolicyDO policy where policy.status in :status")
	List<PolicyDO> findByStatus(@Param("status") List<String> status) throws DataAccessException;
}
