package com.walmart.platform.soari.registry.domain.dao.api;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import com.walmart.platform.kernel.exception.layers.dao.DataAccessException;
import com.walmart.platform.soari.registry.domain.QoSDO;

public interface QoSDAO {
	
	List<QoSDO> findAll() throws DataAccessException;

	List<QoSDO> findAll(Sort sort) throws DataAccessException;

	List<QoSDO> save(Iterable<? extends QoSDO> qos)
			throws DataAccessException;

	Page<QoSDO> findAll(Pageable pageable)
			throws DataAccessException;

	QoSDO save(QoSDO qos) throws DataAccessException;

	QoSDO findOne(String id) throws DataAccessException;

	void delete(String id) throws DataAccessException;

	void delete(QoSDO qos) throws DataAccessException;

	void delete(Iterable<? extends QoSDO> qos)
			throws DataAccessException;

	List<QoSDO> findByMatchingName(String name)
			throws DataAccessException;

	List<QoSDO> findByName(String name) throws DataAccessException;
	
	List<QoSDO> findByMatchingStatus(String status) throws DataAccessException;
	List<QoSDO> findByStatus(List<String> status) throws DataAccessException;
}
