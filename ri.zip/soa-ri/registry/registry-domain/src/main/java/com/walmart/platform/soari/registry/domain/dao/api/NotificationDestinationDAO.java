package com.walmart.platform.soari.registry.domain.dao.api;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import com.walmart.platform.kernel.exception.layers.dao.DataAccessException;
import com.walmart.platform.soari.registry.domain.NotificationDestinationDO;

public interface NotificationDestinationDAO {
	List<NotificationDestinationDO> findAll() throws DataAccessException;

	List<NotificationDestinationDO> findAll(Sort sort) throws DataAccessException;

	List<NotificationDestinationDO> save(Iterable<? extends NotificationDestinationDO> notificationDestinations)
			throws DataAccessException;

	Page<NotificationDestinationDO> findAll(Pageable pageable)
			throws DataAccessException;

	NotificationDestinationDO save(NotificationDestinationDO notificationDestination) throws DataAccessException;

	NotificationDestinationDO findOne(String id) throws DataAccessException;

	void delete(String id) throws DataAccessException;

	void delete(NotificationDestinationDO notificationDestination) throws DataAccessException;

	void delete(Iterable<? extends NotificationDestinationDO> notificationDestinations)
			throws DataAccessException;
	List<NotificationDestinationDO> findByMatchingName(String name)
			throws DataAccessException;
	List<NotificationDestinationDO> findByName(String name) throws DataAccessException;
	List<NotificationDestinationDO> findByStatus(List<String> status) throws DataAccessException;
}
