package com.walmart.platform.soari.registry.domain.dao.impl;

import java.io.Serializable;
import java.text.MessageFormat;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;

import com.walmart.platform.kernel.exception.layers.dao.DataAccessException;
import com.walmart.platform.soari.registry.domain.dao.GenericDAO;
import com.walmart.platform.soari.registry.domain.validation.EntityValidator;
import com.walmart.platform.soari.registry.server.common.exception.ExceptionHandler;
import com.walmart.platform.soari.registry.server.common.util.CommonConstants;

public abstract class GenericDAOImpl<T> implements GenericDAO<T>{
	
	private static final Logger LOG = LoggerFactory.getLogger(GenericDAOImpl.class);
	
	//@Autowired
	private JpaRepository<T, Serializable> dao;
	
	@Autowired
	private ExceptionHandler exceptionHandler;
	
	@Autowired
	private EntityValidator entityValidator;
	
	public GenericDAOImpl(JpaRepository<T, Serializable> dao) {
		this.dao = dao;
	}
	
	@Override
	public Page<T> findAll(Pageable pageable) throws DataAccessException {
		LOG.debug("Executing findAll(Pageable pageable) : ");
		Page<T> result = null;
		try {
			result = dao.findAll(pageable);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE,CommonConstants.EXCEPTION_MESSAGE, "finding Pageable entities", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public T save(T entity) throws DataAccessException {
		LOG.debug("Executing save(T entity) : ");
		T result = null;
		try {
			result = dao.save(entity);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "persisting entity", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public T findOne(String id) throws DataAccessException {
		LOG.debug("Executing findOne(Serializable id) for id : "+id);
		T result = null;
		try {
			result = dao.findOne(id);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding entity by id", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public boolean exists(String id) throws DataAccessException {
		LOG.debug("Executing exists(Serializable id) for id : "+id);
		boolean result = false;
		try {
			result = dao.exists(id);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "checking if entity exists", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public long count() throws DataAccessException {
		LOG.debug("Executing count() : ");
		long result = 0;
		try {
			result = dao.count();
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "count of entities", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public void delete(String id) throws DataAccessException {
		LOG.debug("Executing delete(Serializable id) for id : " + id);
		try {
			dao.delete(id);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "deleting entity by id", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
	}

	@Override
	public void delete(T entity) throws DataAccessException {
		LOG.debug("Executing delete(T entity)");
		try {
			dao.delete(entity);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "deleting entity", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
	}

	@Override
	public void delete(Iterable<? extends T> entities)
			throws DataAccessException {
		LOG.debug("Executing delete(Iterable<? extends T> entities)");
		try {
			dao.delete(entities);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "deleting entities", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
	}

	@Override
	public void deleteAll() throws DataAccessException {
		LOG.debug("Executing deleteAll()");
		try {
			dao.deleteAll();
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "deleting all entities", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
	}

	@Override
	public List<T> findAll() throws DataAccessException {
		LOG.debug("Executing findAll()");
		List<T> result = null;
		try {
			result = dao.findAll();
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding all entities", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public List<T> findAll(Sort sort) throws DataAccessException {
		LOG.debug("Executing findAll(Sort sort)");
		List<T> result = null;
		try {
			result = dao.findAll(sort);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding all sorted entities", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
}

	@Override
	public List<T> save(Iterable<? extends T> entities)
			throws DataAccessException {
		LOG.debug("Executing save(Iterable<? extends T>");
		List<T> result = null;
		try {
			result = dao.save(entities);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "persisitng entities", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public void flush() throws DataAccessException {
		LOG.debug("Executing flush()");
		try {
			dao.flush();
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "flush the session", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
	}

	@Override
	public T saveAndFlush(T entity) throws DataAccessException {
		LOG.debug("Executing saveAndFlush(T entity)");
		T result = null;
		try {
			result = dao.saveAndFlush(entity);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "persisting and flushing the session", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public void deleteInBatch(Iterable<T> entities) throws DataAccessException {
		LOG.debug("Executing deleteInBatch(Iterable<T> entities)");
		try {
			dao.deleteInBatch(entities);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "deleting entities in batch", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
	}
	
	@Override
	public List<T> findByIds(List<String> ids) throws DataAccessException {
		return null;
	}
	
	@Override
	public T findByName(String name) throws DataAccessException {
		return null;
	}
	
	@Override
	public List<T> findByMatchingName(String name) throws DataAccessException {
		return null;
	}
	
	/**
	 * Getter for the dao
	 * 
	 * @return dao
	 */
	public JpaRepository<T, Serializable> getDao() {
		return this.dao;
	}
	
	/**
	 * 
	 * setter for the dao
	 * @param dAO
	 */
	public void setDao(JpaRepository<T, Serializable> dAO) {
		this.dao = dAO;
	}
	
	/**
	 * Getter for the exceptionHandler
	 * 
	 * @return exceptionHandler
	 */
	public ExceptionHandler getExceptionHandler() {
		return this.exceptionHandler;
	}
	
	/**
	 * 
	 * setter for the exceptionHandler
	 * @param exHndlr
	 */
	public void setExceptionHandler(ExceptionHandler exHndlr) {
		this.exceptionHandler = exHndlr;
	}
	
	/**
	 * Getter for the exceptionHandler
	 * 
	 * @return exceptionHandler
	 */
	public EntityValidator getEntityValidator() {
		return this.entityValidator;
	}
	
	/**
	 * 
	 * setter for the exceptionHandler
	 * @param exHndlr
	 */
	public void setEntityValidator(EntityValidator entVldtr) {
		this.entityValidator = entVldtr;
	}
}
