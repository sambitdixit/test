package com.walmart.platform.soari.registry.domain.dao.impl;

import java.text.MessageFormat;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.walmart.platform.kernel.exception.layers.dao.DataAccessException;
import com.walmart.platform.soari.registry.domain.ConsumerDO;
import com.walmart.platform.soari.registry.domain.dao.api.ConsumerDAO;
import com.walmart.platform.soari.registry.domain.repository.ConsumerRepository;
import com.walmart.platform.soari.registry.domain.util.Timed;
import com.walmart.platform.soari.registry.server.common.exception.ExceptionHandler;
import com.walmart.platform.soari.registry.server.common.util.CommonConstants;

@Service("consumerDAO")
@Timed
public class ConsumerDAOImpl implements ConsumerDAO {

	private static final Logger LOG = LoggerFactory.getLogger(ConsumerDAOImpl.class);

	@Autowired
	private ConsumerRepository consumerRepository;
	
	@Autowired
	private ExceptionHandler exceptionHandler;

	@Override
	public List<ConsumerDO> findAll() throws DataAccessException {
		LOG.debug("Executing findAll()");
		List<ConsumerDO> result = null;
		try {
			result = consumerRepository.findAll();
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding all Consumers", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public List<ConsumerDO> findAll(Sort sort) throws DataAccessException {
		LOG.debug("Executing findAll(Sort sort)");
		List<ConsumerDO> result = null;
		try {
			result = consumerRepository.findAll(sort);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding all ordered Consumers", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public List<ConsumerDO> save(Iterable<? extends ConsumerDO> consumers)
			throws DataAccessException {
		LOG.debug("Executing save(Iterable<? extends ConsumerDO> consumers");
		List<ConsumerDO> result = null;
		try {
			result = consumerRepository.save(consumers);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "persisitng Consumers", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public Page<ConsumerDO> findAll(Pageable pageable)
			throws DataAccessException {
		LOG.debug("Executing findAll(Pageable pageable)");
		Page<ConsumerDO> result = null;
		try {
			result = consumerRepository.findAll(pageable);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding pageable Consumers", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	/**
	 * NOTE: need to add the code in catch block to preserve the stack trace
	 */
	@Override
	public ConsumerDO save(ConsumerDO consumer) throws DataAccessException {
		LOG.debug("Executing save(ConsumerDO consumer)");
		ConsumerDO result = null;
		try {
			result = consumerRepository.save(consumer);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "persisitng Consumer", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public ConsumerDO findOne(String id) throws DataAccessException {
		LOG.debug("Executing findOne(String id)");
		ConsumerDO result = null;
		try {
			result = consumerRepository.findOne(id);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding Consumer by id", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public void delete(String id) throws DataAccessException {
		LOG.debug("Executing delete(String id)");
		try {
			consumerRepository.delete(id);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "deleting Consumer by id", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
	}

	@Override
	public void delete(ConsumerDO consumer) throws DataAccessException {
		LOG.debug("Executing delete(ConsumerDO consumer)");
		try {
			consumerRepository.delete(consumer);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "deleting Consumer", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
	}

	@Override
	public void delete(Iterable<? extends ConsumerDO> consumers)
			throws DataAccessException {
		LOG.debug("Executing delete(Iterable<? extends ConsumerDO> consumers)");
		try {
			consumerRepository.delete(consumers);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "deleting Consumers", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
	}

	@Override
	public List<ConsumerDO> findByStatus(List<String> status) throws DataAccessException {
		LOG.debug("Executing findByMatchingStatus()");
		List<ConsumerDO> result = null;
		try {
			result = consumerRepository.findByStatus(status);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding Consumers by status", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}
	
	@Override
	public List<ConsumerDO> findByConsumerId(String consumerId) throws DataAccessException {
		LOG.debug("Executing findByConsumerId()");
		List<ConsumerDO> result = null;
		try {
			result = consumerRepository.findByConsumerId(consumerId);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding Consumers by consumerId", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}
	
}
