package com.walmart.platform.soari.registry.domain.dao.api;

import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import com.walmart.platform.kernel.exception.layers.dao.DataAccessException;
import com.walmart.platform.soari.registry.domain.ServiceDO;

public interface ServiceDAO {
	
	/**
	 * Fetches list of all {@link ServiceDO}
	 * 
	 * @return list of all services
	 * @throws DataAccessException
	 */
	List<ServiceDO> findAll() throws DataAccessException;
	
	/**
	 * Fetches list of all {@link ServiceDO} with application id as 'applicationId'
	 * 
	 * @param applicationId {@link ServiceDO}'s application id to be matched against
	 * @return list of matching {@link ServiceDO} 
	 * @throws DataAccessException
	 */
	List<ServiceDO> findByApplicationId(String applicationId) throws DataAccessException;

	/**
	 * Fetches list of matching {@link ServiceDO}
	 * NOTE: need to add more description
	 * 
	 * @param sort
	 * @return list of matching {@link ServiceDO} 
	 * @throws DataAccessException
	 */
	List<ServiceDO> findAll(Sort sort) throws DataAccessException;

	/**
	 * Saves multiple {@link ServiceDO}
	 * 
	 * @param services list of {@link ServiceDO} to be saved
	 * @return list of {@link ServiceDO} that were saved
	 * @throws DataAccessException
	 */
	List<ServiceDO> save(Iterable<? extends ServiceDO> services)
			throws DataAccessException;
 
	Page<ServiceDO> findAll(Pageable pageable)
			throws DataAccessException;

	/**
	 * Saves {@link ServiceDO}
	 * 
	 * @param service {@link ServiceDO} object to be saved
	 * @return {@link ServiceDO} that is saved 
	 * @throws DataAccessException
	 */
	ServiceDO save(ServiceDO service) throws DataAccessException;

	/**
	 * Fetches {@link ServiceDO} by id
	 * 
	 * @param id Identifier for {@link ServiceDO}'s to be searched
	 * @return matching {@link ServiceDO} 
	 * @throws DataAccessException
	 */
	ServiceDO findOne(String id) throws DataAccessException;

	/**
	 * Removes matching {@link ServiceDO} 
	 * 
	 * @param id identifier for {@link ServiceDO} to be removed
	 * @throws DataAccessException
	 */
	void delete(String id) throws DataAccessException;

	/**
	 * Removes matching {@link ServiceDO} 
	 * 
	 * @param service {@link ServiceDO} object that is to be removed
	 * @throws DataAccessException
	 */
	void delete(ServiceDO service) throws DataAccessException;

	/**
	 * Removes multiple {@link ServiceDO} 
	 * 
	 * @param services list of {@link ServiceDO} to be reomved
	 * @throws DataAccessException
	 */
	void delete(Iterable<? extends ServiceDO> services)
			throws DataAccessException;

	/**
	 * Fetches list of {@link ServiceDO} having name as 'name'
	 * 
	 * @param name {@link ServiceDO}'s name to be matched 
	 * @return list of matching {@link ServiceDO}
	 * @throws DataAccessException
	 */
	List<ServiceDO> findByName(String name) throws DataAccessException;
	
	/**
	 * Fetches list of {@link ServiceDO} by environment
	 * 
	 * @param environment {@link ServiceDO}'s environment to be compared
	 * @return list of matching {@link ServiceDO}
	 * @throws DataAccessException
	 */
	List<ServiceDO> findByEnvironment(String environment) throws DataAccessException;
	
	/**
	 * Fetches  {@link ServiceDO} by name & environment
	 * 
	 * @param name {@link ServiceDO}'s name to be matched 
	 * @param environment {@link ServiceDO}'s environment to be compared
	 * @return matching {@link ServiceDO}
	 * @throws DataAccessException
	 */
	ServiceDO find(String name, String environment) throws DataAccessException;
	List<ServiceDO> findDuplicate(String name, String environment, String applicationId) throws DataAccessException;
	
	/**
	 * Fetches {@link ServiceDO} having name similar to 'name' (i.e. %name%)
	 * 
	 * @param name {@link ServiceDO}'s name to be matched 
	 * @return list of matching {@link ServiceDO}
	 * @throws DataAccessException
	 */
	List<ServiceDO> findByMatchingName(String name) throws DataAccessException;
	
	/**
	 * Fetches {@link ServiceDO} by category
	 * 
	 * @param search category to be compared against
	 * @return list of matching {@link ServiceDO}
	 * @throws DataAccessException
	 */
	List<ServiceDO> findByCategory(String search) throws DataAccessException;
	
	/**
	 * Fetches {@link ServiceDO} having similar description as 'search'
	 * 
	 * @param search description of {@link ServiceDO} to be compared against
	 * @return list of matching {@link ServiceDO}
	 * @throws DataAccessException
	 */
	List<ServiceDO> findByMatchingDescription(String search) throws DataAccessException;
	
	/**
	 * Fetches {@link ServiceDO} having similar owner as 'search'
	 * 
	 * @param search owner of {@link ServiceDO} to be compared against
	 * @return list of matching {@link ServiceDO}
	 * @throws DataAccessException
	 */
	List<ServiceDO> findByMatchingOwner(String search) throws DataAccessException;
	
	/**
	 * Fetches {@link ServiceDO} having similar description as 'search'
	 * 
	 * @param search
	 * @return list of matching {@link ServiceDO}
	 * @throws DataAccessException
	 */
	List<ServiceDO> findByDomain(String search) throws DataAccessException;
	
	/**
	 * Fetches {@link ServiceDO} by usage
	 * 
	 * @param search Service Usage to be matched for
	 * @return list of matching {@link ServiceDO}
	 * @throws DataAccessException
	 */
	List<ServiceDO> findByUsage(String search) throws DataAccessException;
	
	/**
	 * Fetches {@link ServiceDO} by status
	 * 
	 * @param status Service status to be matched for
	 * @return list of matching {@link ServiceDO}
	 * @throws DataAccessException
	 */
	List<ServiceDO> findByStatus(List<String> status) throws DataAccessException;
	
	/**
	 * Fetches {@link ServiceDO} by qos id
	 * 
	 * @param qosId Service's Qos Id 's to be searched for
	 * @return list of matching {@link ServiceDO}
	 * @throws DataAccessException
	 */
	List<ServiceDO> findByQoSId(String qosId) throws DataAccessException;
	
	/**
	 * Fetches {@link ServiceDO} by policy id
	 * 
	 * @param policyId Identifier for policies to be searched for
	 * @return list of matching {@link ServiceDO}
	 * @throws DataAccessException
	 */
	List<ServiceDO> findByPolicyId(String policyId) throws DataAccessException;
	
	/**
	 * Fetches {@link ServiceDO} 
	 * 
	 * @param search  
	 * @return list of matching {@link ServiceDO}
	 * @throws DataAccessException
	 */
	List<ServiceDO> search(Map<String, String> search) throws DataAccessException;
	
	/**
	 * Fetches {@link ServiceDO}
	 * 
	 * @param search
	 * @return list of matching {@link ServiceDO}
	 * @throws DataAccessException
	 */
	ServiceDO searchOne(Map<String, String> search) throws DataAccessException;
	
	String findServiceCountPerEnvironment() throws DataAccessException;
	String findCategoryCountPerEnvironment() throws DataAccessException;
	String findEnvironmentCountForService() throws DataAccessException;
	String findServiceCountPerMonth() throws DataAccessException;
}
