
package com.walmart.platform.soari.registry.domain.dao.impl;

import java.text.MessageFormat;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.walmart.platform.kernel.exception.layers.dao.DataAccessException;
import com.walmart.platform.soari.registry.domain.QoSDO;
import com.walmart.platform.soari.registry.domain.dao.api.QoSDAO;
import com.walmart.platform.soari.registry.domain.repository.QoSRepository;
import com.walmart.platform.soari.registry.server.common.exception.ExceptionHandler;
import com.walmart.platform.soari.registry.domain.util.Timed;
import com.walmart.platform.soari.registry.server.common.util.CommonConstants;

@Service("qosDAO")
@Timed
public class QoSDAOImpl implements QoSDAO {

	private static final Logger LOG = LoggerFactory.getLogger(QoSDAOImpl.class);

	@Autowired
	private QoSRepository qosRepository;
	
	@Autowired
	private ExceptionHandler exceptionHandler;

	@Override
	public List<QoSDO> findAll() throws DataAccessException {
		LOG.debug("Executing findAll()");
		List<QoSDO> result = null;
		try {
			result = qosRepository.findAll();
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding all QOS", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public List<QoSDO> findAll(Sort sort) throws DataAccessException {
		LOG.debug("Executing findAll(Sort sort)");
		List<QoSDO> result = null;
		try {
			result = qosRepository.findAll(sort);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding all ordered QOS", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public List<QoSDO> save(Iterable<? extends QoSDO> qos)
			throws DataAccessException {
		LOG.debug("Executing save(Iterable<? extends QoSDO> qoss");
		List<QoSDO> result = null;
		try {
			result = qosRepository.save(qos);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "persisitng QOS", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public Page<QoSDO> findAll(Pageable pageable)
			throws DataAccessException {
		LOG.debug("Executing findAll(Pageable pageable)");
		Page<QoSDO> result = null;
		try {
			result = qosRepository.findAll(pageable);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding pageable QOS", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public QoSDO save(QoSDO qos) throws DataAccessException {
		LOG.debug("Executing save(QoSDO qos)");
		QoSDO result = null;
		try {
			result = qosRepository.save(qos);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "persisitng QOS", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public QoSDO findOne(String id) throws DataAccessException {
		LOG.debug("Executing findOne(String id)");
		QoSDO result = null;
		try {
			result = qosRepository.findOne(id);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding QOS by id", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public void delete(String id) throws DataAccessException {
		LOG.debug("Executing delete(String id)");
		try {
			qosRepository.delete(id);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "deleting QOS by id", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
	}

	@Override
	public void delete(QoSDO qos) throws DataAccessException {
		LOG.debug("Executing delete(QoSDO qos)");
		try {
			qosRepository.delete(qos);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "deleting QOS", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
	}

	@Override
	public void delete(Iterable<? extends QoSDO> qoss)
			throws DataAccessException {
		LOG.debug("Executing delete(Iterable<? extends QoSDO> qoss)");
		try {
			qosRepository.delete(qoss);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "deleting QOS", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
	}

	@Override
	public List<QoSDO> findByMatchingName(String name)
			throws DataAccessException {
		LOG.debug("Executing findByMatchingName()");
		List<QoSDO> result = null;
		try {
			String search = "%"+name+"%";
			result = qosRepository.findByMatchingName(search.toLowerCase());
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding QOS by matching name", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public List<QoSDO> findByName(String name) throws DataAccessException {
		LOG.debug("Executing findByName()");
		List<QoSDO> result = null;
		try {
			result = qosRepository.findByName(name.toLowerCase());
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding QOS by name", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}
	
	@Override
	public List<QoSDO> findByMatchingStatus(String status) throws DataAccessException {
		LOG.debug("Executing findByMatchingStatus()");
		List<QoSDO> result = null;
		try {
			String search = "%"+status+"%";
			result = qosRepository.findByMatchingStatus(search.toUpperCase());
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding QOS by matching status", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}
	
	@Override
	public List<QoSDO> findByStatus(List<String> status) throws DataAccessException {
		LOG.debug("Executing findByMatchingStatus()");
		List<QoSDO> result = null;
		try {
			result = qosRepository.findByStatus(status);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding QOS by status", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}
	
}
