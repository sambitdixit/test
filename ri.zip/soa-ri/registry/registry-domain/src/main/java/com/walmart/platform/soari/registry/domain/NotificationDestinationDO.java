package com.walmart.platform.soari.registry.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.walmart.platform.soari.registry.common.enums.EntityType;

@Entity
@Table(name = "NOTIFICATION_DESTINATION")
public class NotificationDestinationDO extends EntityDO implements Serializable {

	/**
	 * class version id for serialization
	 */
	private static final long serialVersionUID = 1L;

	@NotNull(message = "DAO_VALIDATE_NOTIFICATION_TYPE_NOT_NULL")
	@Size(min = 1, max = 36, message = "DAO_VALIDATE_NOTIFICATION_TYPE_NOT_NULL")
	@Column(name = "TYPE", length = 36, nullable = false)
	private String type;

	@NotNull(message = "DAO_VALIDATE_NOTIFICATION_NAME_NOT_NULL")
	@Size(min = 1, max = 64, message = "DAO_VALIDATE_NOTIFICATION_NAME_SIZE")
	@Column(name = "NAME", nullable = false, length = 64)
	private String name;

	@NotNull(message = "DAO_VALIDATE_NOTIFICATION_URL_NOT_NULL")
	@Size(min = 1, max = 256, message = "DAO_VALIDATE_NOTIFICATION_URL_SIZE")
	@Column(name = "URL", nullable = false, length = 256)
	private String url;

	@NotNull(message = "DAO_VALIDATE_NOTIFICATION_ENV_NOT_NULL")
	@Size(min = 1, max = 64, message = "DAO_VALIDATE_NOTIFICATION_ENV_SIZE")
	@Column(name = "ENV", nullable = false, length = 64)
	private String environment;

	@NotNull(message = "DAO_VALIDATE_NOTIFICATION_TIER_NOT_NULL")
	@Size(min = 1, max = 64, message = "DAO_VALIDATE_NOTIFICATION_TIER_SIZE")
	@Column(name = "AVAILABILITY_TIER", nullable = false, length = 64)
	private String availabilityTier;
	
	/**
	 * no-arg constructor
	 */
	public NotificationDestinationDO() {
		this.setEntityType(EntityType.NOTIFICATION_DESTINATION);
	}

	
	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}


	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}


	/**
	 * getter for name
	 * @return
	 */
	public String getName() {
		return name;
	}

	/**
	 * setter for name
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * getter for url
	 * @return
	 */
	public String getUrl() {
		return url;
	}

	/**
	 * setter for url
	 * @param url
	 */
	public void setUrl(String url) {
		this.url = url;
	}

	/**
	 * getter for Environment
	 * @return
	 */
	public String getEnvironment() {
		return environment;
	}

	/**
	 * setter for Environment
	 * @param environment
	 */
	public void setEnvironment(String environment) {
		this.environment = environment;
	}

	/**
	 * getter for {@link AvailabilityTier}
	 * @return
	 */
	public String getAvailabilityTier() {
		return availabilityTier;
	}

	/**
	 *  setter for {@link AvailabilityTier}
	 * @param availabilityTier
	 */
	public void setAvailabilityTier(String availabilityTier) {
		this.availabilityTier = availabilityTier;
	}

	/**
	 * overridden hashCode method
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime
				* result
				+ ((availabilityTier == null) ? 0 : availabilityTier.hashCode());
		result = prime * result
				+ ((environment == null) ? 0 : environment.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((type == null) ? 0 : type.hashCode());
		result = prime * result + ((url == null) ? 0 : url.hashCode());
		return result;
	}

	/**
	 * overridden equals method
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof NotificationDestinationDO)) {
			return false;
		}
		NotificationDestinationDO other = (NotificationDestinationDO) obj;
		if (availabilityTier != other.availabilityTier) {
			return false;
		}
		if (environment != other.environment) {
			return false;
		}
		if (name == null) {
			if (other.name != null) {
				return false;
			}
		} else if (!name.equals(other.name)) {
			return false;
		}
		if (type == null) {
			if (other.type != null) {
				return false;
			}
		} else if (!type.equals(other.type)) {
			return false;
		}
		if (url == null) {
			if (other.url != null) {
				return false;
			}
		} else if (!url.equals(other.url)) {
			return false;
		}
		return true;
	}

}
