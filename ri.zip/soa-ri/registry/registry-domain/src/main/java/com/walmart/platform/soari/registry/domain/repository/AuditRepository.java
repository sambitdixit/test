package com.walmart.platform.soari.registry.domain.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.walmart.platform.kernel.exception.layers.dao.DataAccessException;
import com.walmart.platform.soari.registry.domain.AuditDO;

@Repository
public interface AuditRepository extends JpaRepository<AuditDO, String>, JpaSpecificationExecutor<AuditDO>{
	
	/**
	 * Fetches list of Audits with entity_id as 'entityId'
	 * 
	 * @param entityId Audit' entityId to be matched against
	 * @return list of matching policies
	 * @throws DataAccessException
	 */
	//@Query("from AuditDO audit where audit.entity.id =:entityId order by modifiedAt desc")
	@Query("from AuditDO audit where audit.entityId =:entityId order by modifiedAt desc")
	List<AuditDO> findByEntity(@Param("entityId") String entityId) throws DataAccessException;
}
