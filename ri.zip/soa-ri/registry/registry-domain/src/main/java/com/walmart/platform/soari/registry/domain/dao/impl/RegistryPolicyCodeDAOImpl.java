package com.walmart.platform.soari.registry.domain.dao.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import com.walmart.platform.kernel.exception.layers.dao.DataAccessException;
import com.walmart.platform.soari.registry.common.enums.RegistryPolicyCodeType;
import com.walmart.platform.soari.registry.domain.RegistryPolicyCode;
import com.walmart.platform.soari.registry.domain.repository.RegistryPolicyCodeRepository;
import com.walmart.platform.soari.registry.domain.util.Timed;

@Timed
public class RegistryPolicyCodeDAOImpl {

	@Autowired
	private RegistryPolicyCodeRepository registryPolicyCodeRepository;

	private static ConcurrentHashMap<RegistryPolicyCodeType, Map<String, RegistryPolicyCode>> codeCache;
	
	private static final Logger LOG = LoggerFactory.getLogger(ServiceDAOImpl.class);
	
	public synchronized void rebuildCodeCache() {
		LOG.info("Building the cache");
		ConcurrentHashMap<RegistryPolicyCodeType, Map<String, RegistryPolicyCode>> cache = new ConcurrentHashMap<RegistryPolicyCodeType, Map<String, RegistryPolicyCode>>(0);
		List<RegistryPolicyCode> codes = registryPolicyCodeRepository.findAll();
		for(RegistryPolicyCode registryPolicyCode : codes) {
			Map<String, RegistryPolicyCode> map = cache.get(registryPolicyCode.getType());
			if(map == null) {
				map = new HashMap<String, RegistryPolicyCode>(0);
				cache.put(registryPolicyCode.getType(), map);
			}
			map.put(registryPolicyCode.getCode(), registryPolicyCode);
		}
		if(codeCache != null) {
			Map<String, RegistryPolicyCode> environmentCache = codeCache.get(RegistryPolicyCodeType.CMDB_ENVIRONMENT);
			Map<String, RegistryPolicyCode> artifactCache = codeCache.get(RegistryPolicyCodeType.CMDB_ARTIFACT);
			Map<String, RegistryPolicyCode> jiraProjectCache = codeCache.get(RegistryPolicyCodeType.JIRA_PROJECT);
			if(environmentCache != null) {
				cache.put(RegistryPolicyCodeType.CMDB_ENVIRONMENT, environmentCache);
			}
			if(artifactCache != null) {
				cache.put(RegistryPolicyCodeType.CMDB_ARTIFACT, artifactCache);
			}
			if(jiraProjectCache != null) {
				cache.put(RegistryPolicyCodeType.JIRA_PROJECT, jiraProjectCache);
			}
		}
		codeCache = new ConcurrentHashMap<RegistryPolicyCodeType, Map<String, RegistryPolicyCode>>(0);
		if(cache !=null) {
			codeCache.putAll(cache);
		}
	}
	
	public synchronized static List<RegistryPolicyCode> getCodesByType(RegistryPolicyCodeType type) throws DataAccessException {
 		List<RegistryPolicyCode> list = new ArrayList<RegistryPolicyCode>(0);
		if(codeCache == null) {
			return list;
		}
		Map<String, RegistryPolicyCode> map = codeCache.get(type);
		if(map != null) {
			list.addAll(map.values());
		}
		return list;
	}
	
	public synchronized static RegistryPolicyCode getCode(RegistryPolicyCodeType type, String code) throws DataAccessException {
		if(codeCache == null) {
			return null;
		}
		Map<String, RegistryPolicyCode> map = codeCache.get(type);
		return map != null?map.get(code):null;
	}
	
	public Long findCount() throws DataAccessException {
		return registryPolicyCodeRepository.count();
	}
	
	public synchronized static void refreshEnvCache(Map<String, RegistryPolicyCode> environments) {
		if(codeCache == null) {
			return;
		}
		codeCache.put(RegistryPolicyCodeType.CMDB_ENVIRONMENT, environments);
	}
	public synchronized static void refreshArtifactCache(Map<String, RegistryPolicyCode> artifacts) {
		if(codeCache == null) {
			return;
		}
		codeCache.put(RegistryPolicyCodeType.CMDB_ARTIFACT, artifacts);
	}
	
	public synchronized static void refreshJIRACache(Map<String, RegistryPolicyCode> jiraProjects) {
		if(codeCache == null) {
			return;
		}
		codeCache.put(RegistryPolicyCodeType.JIRA_PROJECT, jiraProjects);
	}
}
