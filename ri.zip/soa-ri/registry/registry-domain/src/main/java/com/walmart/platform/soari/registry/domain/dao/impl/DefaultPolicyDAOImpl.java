package com.walmart.platform.soari.registry.domain.dao.impl;

import java.text.MessageFormat;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.walmart.platform.kernel.exception.layers.dao.DataAccessException;
import com.walmart.platform.soari.registry.domain.DefaultPolicyDO;
import com.walmart.platform.soari.registry.domain.dao.api.DefaultPolicyDAO;
import com.walmart.platform.soari.registry.domain.repository.DefaultPolicyRepository;
import com.walmart.platform.soari.registry.server.common.exception.ExceptionHandler;
import com.walmart.platform.soari.registry.domain.util.Timed;
import com.walmart.platform.soari.registry.server.common.util.CommonConstants;

@Service("DefaultPolicyDAO")
@Timed
public class DefaultPolicyDAOImpl implements DefaultPolicyDAO {

	private static final Logger LOG = LoggerFactory.getLogger(DefaultPolicyDAOImpl.class);

	@Autowired
	private DefaultPolicyRepository policyRepository;
	
	@Autowired
	private ExceptionHandler exceptionHandler;

	@Override
	public List<DefaultPolicyDO> findAll() throws DataAccessException {
		LOG.debug("Executing findAll()");
		List<DefaultPolicyDO> result = null;
		try {
			result = policyRepository.findAll();
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding all Policies", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public List<DefaultPolicyDO> findAll(Sort sort) throws DataAccessException {
		LOG.debug("Executing findAll(Sort sort)");
		List<DefaultPolicyDO> result = null;
		try {
			result = policyRepository.findAll(sort);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding all ordered Policies", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public List<DefaultPolicyDO> save(Iterable<? extends DefaultPolicyDO> policies)
			throws DataAccessException {
		LOG.debug("Executing save(Iterable<? extends DefaultPolicyDO> policys");
		List<DefaultPolicyDO> result = null;
		try {
			result = policyRepository.save(policies);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "persisitng Policies", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public Page<DefaultPolicyDO> findAll(Pageable pageable)
			throws DataAccessException {
		LOG.debug("Executing findAll(Pageable pageable)");
		Page<DefaultPolicyDO> result = null;
		try {
			result = policyRepository.findAll(pageable);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding pageable Policies", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public DefaultPolicyDO save(DefaultPolicyDO policy) throws DataAccessException {
		LOG.debug("Executing save(DefaultPolicyDO policy)");
		DefaultPolicyDO result = null;
		try {
			result = policyRepository.save(policy);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "persisitng Policy", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public DefaultPolicyDO findOne(String id) throws DataAccessException {
		LOG.debug("Executing findOne(String id)");
		DefaultPolicyDO result = null;
		try {
			result = policyRepository.findOne(id);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding Policy by id", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public void delete(String id) throws DataAccessException {
		LOG.debug("Executing delete(String id)");
		try {
			policyRepository.delete(id);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "deleting Policy by id", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
	}

	@Override
	public void delete(DefaultPolicyDO policy) throws DataAccessException {
		LOG.debug("Executing delete(DefaultPolicyDO policy)");
		try {
			policyRepository.delete(policy);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "deleting Policy", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
	}

	@Override
	public void delete(Iterable<? extends DefaultPolicyDO> policys)
			throws DataAccessException {
		LOG.debug("Executing delete(Iterable<? extends DefaultPolicyDO> policys)");
		try {
			policyRepository.delete(policys);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "deleting Policies", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
	}

	@Override
	public List<DefaultPolicyDO> findByMatchingName(String name)
			throws DataAccessException {
		LOG.debug("Executing findByMatchingName()");
		List<DefaultPolicyDO> result = null;
		try {
			String search = "%"+name+"%";
			result = policyRepository.findByMatchingName(search.toLowerCase());
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding Policies by matching name", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public List<DefaultPolicyDO> findByName(String name) throws DataAccessException {
		LOG.debug("Executing findByName()");
		List<DefaultPolicyDO> result = null;
		try {
			result = policyRepository.findByName(name.toLowerCase());
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding Policies by name", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}
	
	@Override
	public List<DefaultPolicyDO> findByStatus(List<String> status) throws DataAccessException {
		LOG.debug("Executing findByMatchingStatus()");
		List<DefaultPolicyDO> result = null;
		try {
			result = policyRepository.findByStatus(status);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding Policies by status", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}
	
}
