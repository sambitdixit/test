package com.walmart.platform.soari.registry.domain;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import javax.persistence.Version;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.walmart.platform.soari.registry.common.enums.AuditType;
import com.walmart.platform.soari.registry.common.enums.EntityType;

@Entity
@Table(name = "AUDIT_DETAIL")
public class AuditDO implements Serializable {

	/**
	 * class version id for serialization
	 */
	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@Column(name = "ID", nullable = false, length = 36)
	private String id;

	@Version
	@Column(name = "VERSION", nullable = false, length = 36)
	private Integer version;

	@Enumerated(EnumType.STRING)
	@NotNull(message = "Audit type cannot be null")
	@Column(name = "OPTYPE", nullable = false, length = 36)
	private AuditType type;

	@NotNull(message = "Audit field cannot be null")
	@Size(min = 1, max = 128, message = "Audit field cannot be empty")
	@Column(name = "FIELD", nullable = false, length = 128)
	private String field;

	@Column(name = "OLD_VALUE", length = 128)
	private String oldValue;

	@Column(name = "NEW_VALUE", length = 128)
	private String newValue;

	@Column(name = "MODIFIED_BY", length = 128)
	private String modifiedBy;
	
	@Column(name = "MODIFIED_AT")
	private Timestamp modifiedAt;

	@NotNull(message = "Audit entity id cannot  be null")
	@Column(name = "ENTITY_ID", nullable = false, length = 36)
	private String entityId;

	@NotNull(message = "Audit entity type cannot  be null")
	@Column(name = "ENTITY_TYPE", nullable = false, length = 36)
	@Enumerated(EnumType.STRING)
	private EntityType entityType;
	
	public AuditDO() {
		
	}
	
	public AuditDO(EntityDO entity) {
		this.entityType = entity.getEntityType();
		this.setEntityId(entity.getId());
	}

	/**
	 * @return the entityId
	 */
	public String getEntityId() {
		return entityId;
	}

	/**
	 * @param entityId the entityId to set
	 */
	public void setEntityId(String entityId) {
		this.entityId = entityId;
	}

	/**
	 * @return the entityType
	 */
	public EntityType getEntityType() {
		return entityType;
	}

	/**
	 * @param entityType the entityType to set
	 */
	public void setEntityType(EntityType entityType) {
		this.entityType = entityType;
	}

	/**
	 * getter for AuditType
	 * @return trype
	 */
	public AuditType getType() {
		return type;
	}

	/**
	 * setter for AuditType
	 * @param type
	 */
	public void setType(AuditType type) {
		this.type = type;
	}

	/**
	 * getter for field
	 * @return field
	 */
	public String getField() {
		return field;
	}
	
	/**
	 * setter for field
	 * @param field
	 */
	public void setField(String field) {
		this.field = field;
	}

	/**
	 * getter for OldValue
	 * @return oldValue
	 */
	public String getOldValue() {
		return oldValue;
	}

	/**
	 * setter for the old value
	 * @param oldValue
	 */
	public void setOldValue(String oldValue) {
		this.oldValue = oldValue;
	}

	/**
	 * getter for the new value
	 * @return newValue
	 */
	public String getNewValue() {
		return newValue;
	}

	/**
	 * setter for the new value
	 * @param newValue
	 */
	public void setNewValue(String newValue) {
		this.newValue = newValue;
	}

	/**
	 * getter for the id
	 * @return id
	 */
	public String getId() {
		return id;
	}

	/**
	 * setter for id
	 * @param id
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the version
	 */
	public Integer getVersion() {
		return version;
	}

	/**
	 * @param version the version to set
	 */
	public void setVersion(Integer version) {
		this.version = version;
	}

	/**
	 * getter for modifiedBy
	 * @return modifiedBy
	 */
	public String getModifiedBy() {
		return modifiedBy;
	}

	/**
	 * setter for the modified by
	 * @param modifiedBy
	 */
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	/**
	 * getter for modifiedAt
	 * @return modifiedAt
	 */
	public Timestamp getModifiedAt() {
		return modifiedAt;
	}

	/**
	 * seeter for modifiedAt
	 * @param modifiedAt
	 */
	public void setModifiedAt(Timestamp modifiedAt) {
		this.modifiedAt = modifiedAt;
	}

	/**
	 * On create.
	 */
	@PrePersist
	void onCreate() {
		this.setId(UUID.randomUUID().toString().replace("-", ""));
		if (this.getModifiedBy() == null) {
			this.setModifiedBy("soari_registry_app");
		}
		this.setModifiedAt(new Timestamp(System.currentTimeMillis()));
	}

}
