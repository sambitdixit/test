package com.walmart.platform.soari.registry.domain.dao.impl;

import java.text.MessageFormat;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.walmart.platform.kernel.exception.layers.dao.DataAccessException;
import com.walmart.platform.soari.registry.domain.PolicyDO;
import com.walmart.platform.soari.registry.domain.dao.api.PolicyDAO;
import com.walmart.platform.soari.registry.domain.repository.PolicyRepository;
import com.walmart.platform.soari.registry.server.common.exception.ExceptionHandler;
import com.walmart.platform.soari.registry.domain.util.Timed;
import com.walmart.platform.soari.registry.server.common.util.CommonConstants;

@Service("policyDAO")
@Timed
public class PolicyDAOImpl implements PolicyDAO {

	private static final Logger LOG = LoggerFactory.getLogger(PolicyDAOImpl.class);

	@Autowired
	private PolicyRepository policyRepository;
	
	@Autowired
	private ExceptionHandler exceptionHandler;

	@Override
	public List<PolicyDO> findAll() throws DataAccessException {
		LOG.debug("Executing findAll()");
		List<PolicyDO> result = null;
		try {
			result = policyRepository.findAll();
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding all Policies", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public List<PolicyDO> findAll(Sort sort) throws DataAccessException {
		LOG.debug("Executing findAll(Sort sort)");
		List<PolicyDO> result = null;
		try {
			result = policyRepository.findAll(sort);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding all ordered Policies", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public List<PolicyDO> save(Iterable<? extends PolicyDO> policies)
			throws DataAccessException {
		LOG.debug("Executing save(Iterable<? extends PolicyDO> policys");
		List<PolicyDO> result = null;
		try {
			result = policyRepository.save(policies);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "persisitng Policies", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public Page<PolicyDO> findAll(Pageable pageable)
			throws DataAccessException {
		LOG.debug("Executing findAll(Pageable pageable)");
		Page<PolicyDO> result = null;
		try {
			result = policyRepository.findAll(pageable);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding pageable Policies", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public PolicyDO save(PolicyDO policy) throws DataAccessException {
		LOG.debug("Executing save(PolicyDO policy)");
		PolicyDO result = null;
		try {
			result = policyRepository.save(policy);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "persisitng Policy", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public PolicyDO findOne(String id) throws DataAccessException {
		LOG.debug("Executing findOne(String id)");
		PolicyDO result = null;
		try {
			result = policyRepository.findOne(id);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding Policy by id", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public void delete(String id) throws DataAccessException {
		LOG.debug("Executing delete(String id)");
		try {
			policyRepository.delete(id);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "deleting Policy by id", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
	}

	@Override
	public void delete(PolicyDO policy) throws DataAccessException {
		LOG.debug("Executing delete(PolicyDO policy)");
		try {
			policyRepository.delete(policy);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "deleting Policy", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
	}

	@Override
	public void delete(Iterable<? extends PolicyDO> policys)
			throws DataAccessException {
		LOG.debug("Executing delete(Iterable<? extends PolicyDO> policys)");
		try {
			policyRepository.delete(policys);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "deleting Policies", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
	}

	@Override
	public List<PolicyDO> findByMatchingName(String name)
			throws DataAccessException {
		LOG.debug("Executing findByMatchingName()");
		List<PolicyDO> result = null;
		try {
			String search = "%"+name+"%";
			result = policyRepository.findByMatchingName(search.toLowerCase());
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding Policies by matching name", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}

	@Override
	public List<PolicyDO> findByName(String name) throws DataAccessException {
		LOG.debug("Executing findByName()");
		List<PolicyDO> result = null;
		try {
			result = policyRepository.findByName(name.toLowerCase());
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding Policies by name", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}
	
	@Override
	public List<PolicyDO> findByStatus(List<String> status) throws DataAccessException {
		LOG.debug("Executing findByMatchingStatus()");
		List<PolicyDO> result = null;
		try {
			result = policyRepository.findByStatus(status);
		}catch(Exception t) {
			String errorMessage = MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE, "finding Policies by status", t.getMessage());
			LOG.error(errorMessage);
			exceptionHandler.handleDataAccessException(t);
		}
		return result;
	}
	
}
