package com.walmart.platform.soari.registry.domain;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.walmart.platform.soari.registry.common.enums.EntityType;

@Entity
@Table(name = "QOS")
public class QoSDO extends EntityDO {
	
	/**
	 * class version id for serialization
	 */
	private static final long serialVersionUID = 1L;

	@NotNull(message = "DAO_VALIDATE_QOS_NAME_NOT_NULL")
	@Size(min = 1, max = 128, message = "DAO_VALIDATE_QOS_NAME_SIZE")
	@Column(name = "NAME", nullable = false, length = 128)
	private String name;

	@NotNull(message = "DAO_VALIDATE_QOS_DESCRIPTION_NOT_NULL")
	@Size(min = 1, max = 256, message = "DAO_VALIDATE_QOS_DESCRIPTION_SIZE")
	@Column(name = "DESCRIPTION", nullable = false, length = 256)
	private String description;

	@NotNull(message = "DAO_VALIDATE_QOS_TYPE_NOT_NULL")
	@Size(min = 1, max = 36, message = "DAO_VALIDATE_QOS_TYPE_NOT_NULL")
	@Column(name = "TYPE", length = 36, nullable = false)
	private String type;
	
	private transient String value;
	
	/**
	 * no-arg constructor
	 */
	public QoSDO() {
		this.setEntityType(EntityType.QoS);
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	
	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * @return the value
	 */
	public String getValue() {
		return value;
	}

	/**
	 * @param value the value to set
	 */
	public void setValue(String value) {
		this.value = value;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result
				+ ((description == null) ? 0 : description.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((type == null) ? 0 : type.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (!(obj instanceof QoSDO)) {
			return false;
		}
		QoSDO other = (QoSDO) obj;
		if (description == null) {
			if (other.description != null) {
				return false;
			}
		} else if (!description.equals(other.description)) {
			return false;
		}
		if (name == null) {
			if (other.name != null) {
				return false;
			}
		} else if (!name.equals(other.name)) {
			return false;
		}
		if (type == null) {
			if (other.type != null) {
				return false;
			}
		} else if (!type.equals(other.type)) {
			return false;
		}
		return true;
	}


}
