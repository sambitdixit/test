package com.walmart.platform.soari.registry.domain.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.walmart.platform.kernel.exception.layers.dao.DataAccessException;
import com.walmart.platform.soari.registry.domain.ConsumerDO;

@Repository(value="consumerRepository")
public interface ConsumerRepository extends JpaRepository<ConsumerDO, String>, JpaSpecificationExecutor<ConsumerDO>{
	
	/**
	 * Fetches list of consumers having status present in 'status'
	 * 
	 * @param status list of statuses to be matched against
	 * @return list of matching consumers
	 * @throws DataAccessException
	 */
	@Query("from ConsumerDO consumer where consumer.status in :status")
	List<ConsumerDO> findByStatus(@Param("status") List<String> status) throws DataAccessException;
	
	/**
	 * Fetches list of consumers having Consumer_ID as 'consumerId'
	 * 
	 * @param consumerId Identifier for the consumer to be compared against
	 * @return list of matching consumers
	 * @throws DataAccessException
	 */
	@Query("from ConsumerDO consumer where consumer.consumerId =:consumerId")
	List<ConsumerDO> findByConsumerId(@Param("consumerId")String consumerId) throws DataAccessException;
}
