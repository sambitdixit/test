package com.walmart.platform.soari.registry.domain.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.walmart.platform.kernel.exception.layers.dao.DataAccessException;
import com.walmart.platform.soari.registry.domain.NotificationDestinationDO;

@Repository
public interface NotificationDestinationRepository extends JpaRepository<NotificationDestinationDO, String>, JpaSpecificationExecutor<NotificationDestinationDO>{
	
	/**
	 * Fetches list of NotificationDestination having name similar to 'name' (%name%)
	 * 
	 * @param name NotificationDestination's name to be matched against
	 * @return list of matching NotificationDestination
	 * @throws DataAccessException
	 */
	@Query("from NotificationDestinationDO notificationDestination where lower(notificationDestination.name) like :name")
	List<NotificationDestinationDO> findByMatchingName(@Param("name") String name) throws DataAccessException;
	
	/**
	 * Fetches list of NotificationDestination with name as 'name'
	 * 
	 * @param name NotificationDestination's name to be matched against
	 * @return list of matching NotificationDestination
	 * @throws DataAccessException
	 */
	@Query("from NotificationDestinationDO notificationDestination where lower(notificationDestination.name) = :name")
	List<NotificationDestinationDO> findByName(@Param("name") String name) throws DataAccessException;
	
	/**
	 * Fetches list of NotificationDestination having status present in 'status' 
	 * 
	 * @param status list of statuses to matched against for
	 * @return list of matching NotificationDestination
	 * @throws DataAccessException
	 */
	@Query("from NotificationDestinationDO notificationDestination where notificationDestination.status in :status")
	List<NotificationDestinationDO> findByStatus(@Param("status") List<String> status) throws DataAccessException;
}
