package com.walmart.platform.soari.registry.domain.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.walmart.platform.kernel.exception.layers.dao.DataAccessException;
import com.walmart.platform.soari.registry.domain.SubscriptionDO;

@Repository
public interface SubscriptionRepository extends JpaRepository<SubscriptionDO, String>, JpaSpecificationExecutor<SubscriptionDO>{
	
	/**
	 * Fetches list of all subscriptions with matching 'status'
	 * 
	 * @param status Subscription status to be matched against
	 * @return list of all matching Subscriptions
	 * @throws DataAccessException
	 */
	@Query("from SubscriptionDO Subscription where Subscription.status in :status")
	List<SubscriptionDO> findByStatus(@Param("status") List<String> status) throws DataAccessException;
	@Query("select subscription.serviceVersion.service.environment, count(*) from SubscriptionDO subscription group by subscription.serviceVersion.service.environment")
	List<Object[]> findSubscriptionCountPerEnvironment() throws DataAccessException;
	@Query("select subscription.consumer.consumerId, subscription.serviceVersion.service.environment, count(*) from SubscriptionDO subscription group by subscription.consumer.consumerId,subscription.serviceVersion.service.environment")
	List<Object[]> findConsumerSubscriptionCountPerEnvironment() throws DataAccessException;
	@Query("select subscription.serviceVersion.service.environment,count(subscription.serviceVersion.service.environment) from SubscriptionDO subscription group by subscription.consumer.consumerId, subscription.serviceVersion.service.environment")
	List<Object[]> findConsumerCountPerEnvironment() throws DataAccessException;
	@Query("select subscription.serviceVersion.service.applicationId, subscription.serviceVersion.service.environment, count(subscription.serviceVersion.service.environment) from SubscriptionDO subscription group by subscription.serviceVersion.service.applicationId, subscription.serviceVersion.service.environment")
	List<Object[]> findSubscriptionCountPerService() throws DataAccessException;
	@Query("select subscription.consumer.consumerId, subscription.serviceVersion.service.environment, subscription.serviceVersion.service.applicationId from SubscriptionDO subscription")
	List<Object[]> findServiceCountPerConsumer() throws DataAccessException;
}
