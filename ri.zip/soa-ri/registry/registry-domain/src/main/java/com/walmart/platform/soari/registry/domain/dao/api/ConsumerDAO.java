package com.walmart.platform.soari.registry.domain.dao.api;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import com.walmart.platform.kernel.exception.layers.dao.DataAccessException;
import com.walmart.platform.soari.registry.domain.ConsumerDO;

public interface ConsumerDAO {
	List<ConsumerDO> findAll() throws DataAccessException;

	List<ConsumerDO> findAll(Sort sort) throws DataAccessException;

	List<ConsumerDO> save(Iterable<? extends ConsumerDO> consumers)
			throws DataAccessException;

	Page<ConsumerDO> findAll(Pageable pageable)
			throws DataAccessException;

	ConsumerDO save(ConsumerDO consumer) throws DataAccessException;

	ConsumerDO findOne(String id) throws DataAccessException;

	void delete(String id) throws DataAccessException;

	void delete(ConsumerDO consumer) throws DataAccessException;

	void delete(Iterable<? extends ConsumerDO> consumers)
			throws DataAccessException;
	List<ConsumerDO> findByStatus(List<String> status) throws DataAccessException;
	List<ConsumerDO> findByConsumerId(String consumerId) throws DataAccessException;
}
