package com.walmart.platform.soari.registry.domain.dao.impl.test;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.Page;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.walmart.platform.kernel.exception.layers.dao.DataAccessException;
import com.walmart.platform.soari.registry.domain.ServiceDO;
import com.walmart.platform.soari.registry.domain.dao.impl.ServiceDAOImpl;
import com.walmart.platform.soari.registry.domain.repository.ServiceRepository;
import com.walmart.platform.soari.registry.server.common.exception.ExceptionHandler;

public class ServiceDAOImplTest extends AbstractDAOTest {
	
	@Mock private ServiceRepository serviceRepository;
	@Mock private ServiceDO serviceDO;
	@Mock private List<ServiceDO> serviceDOs;
	@Mock private Page<ServiceDO> page;
	@Mock private ExceptionHandler exceptionHandler;
	@Mock private DataAccessException dataAccessException;

	@InjectMocks private ServiceDAOImpl serviceDAOImpl = new ServiceDAOImpl();
	
	@BeforeMethod(alwaysRun=true)  
	public void init() throws Exception {
		MockitoAnnotations.initMocks(this);
		Mockito.doThrow(dataAccessException).when(exceptionHandler).handleDataAccessException(Mockito.any(Exception.class));
	}
	
	@Test(enabled = true)
	public void testFindAll() throws Exception {
		when(serviceRepository.findAll()).thenReturn(serviceDOs);
		serviceDAOImpl.findAll();
		verify(serviceRepository, times(1)).findAll();
	}
	
	@Test(enabled = true, expectedExceptions = {DataAccessException.class})
	public void testFindAllHandleException() throws Exception {
		when(serviceRepository.findAll()).thenThrow(exception);
		serviceDAOImpl.findAll();
		verify(serviceRepository, times(1)).findAll();
	}
	
	@Test(enabled = true)
	public void testFindAllPageable() throws Exception {
		when(serviceRepository.findAll(pageable)).thenReturn(page);
		serviceDAOImpl.findAll(pageable);
		verify(serviceRepository, times(1)).findAll(pageable);
	}
	
	@Test(enabled = true, expectedExceptions = {DataAccessException.class})
	public void testFindAllPageableHandleException() throws Exception {
		when(serviceRepository.findAll(pageable)).thenThrow(exception);
		serviceDAOImpl.findAll(pageable);
		verify(serviceRepository, times(1)).findAll(pageable);
	}
	
	@Test(enabled = true)
	public void testFindAllBySort() throws Exception {
		when(serviceRepository.findAll(sort)).thenReturn(serviceDOs);
		serviceDAOImpl.findAll(sort);
		verify(serviceRepository, times(1)).findAll(sort);
	}
	
	@Test(enabled = true, expectedExceptions = {DataAccessException.class})
	public void testFindAllBySortHandleException() throws Exception {
		when(serviceRepository.findAll(sort)).thenThrow(exception);
		serviceDAOImpl.findAll(sort);
		verify(serviceRepository, times(1)).findAll(sort);
	}
	@Test(enabled = true)
	public void testSave() throws Exception {
		when(serviceRepository.save(serviceDO)).thenReturn(serviceDO);
		serviceDAOImpl.save(serviceDO);
		verify(serviceRepository, times(1)).save(serviceDO);
	}
	
	@Test(enabled = true, expectedExceptions = {DataAccessException.class})
	public void testSaveHandleException() throws Exception {
		when(serviceRepository.save(serviceDO)).thenThrow(exception);
		serviceDAOImpl.save(serviceDO);
		verify(serviceRepository, times(1)).save(serviceDO);
	}
	
	@Test(enabled = true)
	public void testSaveEntities() throws Exception {
		when(serviceRepository.save(serviceDOs)).thenReturn(serviceDOs);
		serviceDAOImpl.save(serviceDOs);
		verify(serviceRepository, times(1)).save(serviceDOs);
	}
	
	@Test(enabled = true, expectedExceptions = {DataAccessException.class})
	public void testSaveEntitiesHandleException() throws Exception {
		when(serviceRepository.save(serviceDOs)).thenThrow(exception);
		serviceDAOImpl.save(serviceDOs);
		verify(serviceRepository, times(1)).save(serviceDOs);
	}

	@Test(enabled = true)
	public void testFindOne() throws Exception {
		when(serviceRepository.findOne(POLICY_CONFIGURATION_ID)).thenReturn(serviceDO);
		serviceDAOImpl.findOne(POLICY_CONFIGURATION_ID);
		verify(serviceRepository, times(1)).findOne(POLICY_CONFIGURATION_ID);
	}
	
	@Test(enabled = true, expectedExceptions = {DataAccessException.class})
	public void testFindOneHandleException() throws Exception {
		when(serviceRepository.findOne(POLICY_CONFIGURATION_ID)).thenThrow(exception);
		serviceDAOImpl.findOne(POLICY_CONFIGURATION_ID);
		verify(serviceRepository, times(1)).findOne(POLICY_CONFIGURATION_ID);
	}

	@Test(enabled = true)
	public void testDeleteById() throws Exception {
		Mockito.doNothing().when(serviceRepository).delete(POLICY_CONFIGURATION_ID);
		serviceDAOImpl.delete(POLICY_CONFIGURATION_ID);
		verify(serviceRepository, times(1)).delete(POLICY_CONFIGURATION_ID);
	}
	
	@Test(enabled = true, expectedExceptions = {DataAccessException.class})
	public void testDeleteByIdHandleException() throws Exception {
		Mockito.doThrow(exception).when(serviceRepository).delete(POLICY_CONFIGURATION_ID);
		serviceDAOImpl.delete(POLICY_CONFIGURATION_ID);
		verify(serviceRepository, times(1)).delete(POLICY_CONFIGURATION_ID);
	}

	@Test(enabled = true)
	public void testDeleteEntity() throws Exception {
		Mockito.doNothing().when(serviceRepository).delete(serviceDO);
		serviceDAOImpl.delete(serviceDO);
		verify(serviceRepository, times(1)).delete(serviceDO);
	}
	
	@Test(enabled = true, expectedExceptions = {DataAccessException.class})
	public void testDeleteEntityHandleException() throws Exception {
		Mockito.doThrow(exception).when(serviceRepository).delete(serviceDO);
		serviceDAOImpl.delete(serviceDO);
		verify(serviceRepository, times(1)).delete(serviceDO);
	}
	@Test(enabled = true)
	public void testDeleteEntities() throws Exception {
		Mockito.doNothing().when(serviceRepository).delete(serviceDOs);
		serviceDAOImpl.delete(serviceDOs);
		verify(serviceRepository, times(1)).delete(serviceDOs);
	}
	
	@Test(enabled = true, expectedExceptions = {DataAccessException.class})
	public void testDeleteEntitiesHandleException() throws Exception {
		Mockito.doThrow(exception).when(serviceRepository).delete(serviceDOs);
		serviceDAOImpl.delete(serviceDOs);
		verify(serviceRepository, times(1)).delete(serviceDOs);
	}
}
