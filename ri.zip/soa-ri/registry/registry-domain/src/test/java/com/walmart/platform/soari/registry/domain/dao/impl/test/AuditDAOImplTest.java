package com.walmart.platform.soari.registry.domain.dao.impl.test;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.Page;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.walmart.platform.kernel.exception.layers.dao.DataAccessException;
import com.walmart.platform.soari.registry.domain.AuditDO;
import com.walmart.platform.soari.registry.domain.dao.impl.AuditDAOImpl;
import com.walmart.platform.soari.registry.domain.repository.AuditRepository;
import com.walmart.platform.soari.registry.server.common.exception.ExceptionHandler;

public class AuditDAOImplTest extends AbstractDAOTest {
	
	@Mock private AuditRepository auditRepository;
	@Mock private AuditDO registryPolicyAuditDO;
	@Mock private List<AuditDO> registryPolicyAuditDOs;
	@Mock private Page<AuditDO> page;
	@Mock private DataAccessException dataAccessException;
	@Mock private ExceptionHandler exceptionHandler;
	@InjectMocks private AuditDAOImpl auditDAOImpl = new AuditDAOImpl();
	
	@BeforeMethod(alwaysRun=true)  
	public void init() throws Exception {
		MockitoAnnotations.initMocks(this);
		Mockito.doThrow(dataAccessException).when(exceptionHandler).handleDataAccessException(Mockito.any(Exception.class));
	}
	
	@Test(enabled = true)
	public void testFindAll() throws Exception {
		when(auditRepository.findAll()).thenReturn(registryPolicyAuditDOs);
		auditDAOImpl.findAll();
		verify(auditRepository, times(1)).findAll();
	}
	
	@Test(enabled = true, expectedExceptions = {DataAccessException.class})
	public void testFindAllHandleException() throws Exception {
		when(auditRepository.findAll()).thenThrow(exception);
		auditDAOImpl.findAll();
		verify(auditRepository, times(1)).findAll();
	}
	
	@Test(enabled = true)
	public void testFindAllPageable() throws Exception {
		when(auditRepository.findAll(pageable)).thenReturn(page);
		auditDAOImpl.findAll(pageable);
		verify(auditRepository, times(1)).findAll(pageable);
	}
	
	@Test(enabled = true, expectedExceptions = {DataAccessException.class})
	public void testFindAllPageableHandleException() throws Exception {
		when(auditRepository.findAll(pageable)).thenThrow(exception);
		auditDAOImpl.findAll(pageable);
		verify(auditRepository, times(1)).findAll(pageable);
	}
	
	@Test(enabled = true)
	public void testFindAllBySort() throws Exception {
		when(auditRepository.findAll(sort)).thenReturn(registryPolicyAuditDOs);
		auditDAOImpl.findAll(sort);
		verify(auditRepository, times(1)).findAll(sort);
	}
	
	@Test(enabled = true, expectedExceptions = {DataAccessException.class})
	public void testFindAllBySortHandleException() throws Exception {
		when(auditRepository.findAll(sort)).thenThrow(exception);
		auditDAOImpl.findAll(sort);
		verify(auditRepository, times(1)).findAll(sort);
	}
	@Test(enabled = true)
	public void testSave() throws Exception {
		when(auditRepository.save(registryPolicyAuditDO)).thenReturn(registryPolicyAuditDO);
		auditDAOImpl.save(registryPolicyAuditDO);
		verify(auditRepository, times(1)).save(registryPolicyAuditDO);
	}
	
	@Test(enabled = true, expectedExceptions = {DataAccessException.class})
	public void testSaveHandleException() throws Exception {
		when(auditRepository.save(registryPolicyAuditDO)).thenThrow(exception);
		auditDAOImpl.save(registryPolicyAuditDO);
		verify(auditRepository, times(1)).save(registryPolicyAuditDO);
	}
	
	@Test(enabled = true)
	public void testSaveEntities() throws Exception {
		when(auditRepository.save(registryPolicyAuditDOs)).thenReturn(registryPolicyAuditDOs);
		auditDAOImpl.save(registryPolicyAuditDOs);
		verify(auditRepository, times(1)).save(registryPolicyAuditDOs);
	}
	
	@Test(enabled = true, expectedExceptions = {DataAccessException.class})
	public void testSaveEntitiesHandleException() throws Exception {
		when(auditRepository.save(registryPolicyAuditDOs)).thenThrow(exception);
		auditDAOImpl.save(registryPolicyAuditDOs);
		verify(auditRepository, times(1)).save(registryPolicyAuditDOs);
	}

	@Test(enabled = true)
	public void testFindOne() throws Exception {
		when(auditRepository.findOne(POLICY_CONFIGURATION_ID)).thenReturn(registryPolicyAuditDO);
		auditDAOImpl.findOne(POLICY_CONFIGURATION_ID);
		verify(auditRepository, times(1)).findOne(POLICY_CONFIGURATION_ID);
	}
	
	@Test(enabled = true, expectedExceptions = {DataAccessException.class})
	public void testFindOneHandleException() throws Exception {
		when(auditRepository.findOne(POLICY_CONFIGURATION_ID)).thenThrow(exception);
		auditDAOImpl.findOne(POLICY_CONFIGURATION_ID);
		verify(auditRepository, times(1)).findOne(POLICY_CONFIGURATION_ID);
	}

	@Test(enabled = true)
	public void testDeleteById() throws Exception {
		Mockito.doNothing().when(auditRepository).delete(POLICY_CONFIGURATION_ID);
		auditDAOImpl.delete(POLICY_CONFIGURATION_ID);
		verify(auditRepository, times(1)).delete(POLICY_CONFIGURATION_ID);
	}
	
	@Test(enabled = true, expectedExceptions = {DataAccessException.class})
	public void testDeleteByIdHandleException() throws Exception {
		Mockito.doThrow(exception).when(auditRepository).delete(POLICY_CONFIGURATION_ID);
		auditDAOImpl.delete(POLICY_CONFIGURATION_ID);
		verify(auditRepository, times(1)).delete(POLICY_CONFIGURATION_ID);
	}

	@Test(enabled = true)
	public void testDeleteEntity() throws Exception {
		Mockito.doNothing().when(auditRepository).delete(registryPolicyAuditDO);
		auditDAOImpl.delete(registryPolicyAuditDO);
		verify(auditRepository, times(1)).delete(registryPolicyAuditDO);
	}
	
	@Test(enabled = true, expectedExceptions = {DataAccessException.class})
	public void testDeleteEntityHandleException() throws Exception {
		Mockito.doThrow(exception).when(auditRepository).delete(registryPolicyAuditDO);
		auditDAOImpl.delete(registryPolicyAuditDO);
		verify(auditRepository, times(1)).delete(registryPolicyAuditDO);
	}
	@Test(enabled = true)
	public void testDeleteEntities() throws Exception {
		Mockito.doNothing().when(auditRepository).delete(registryPolicyAuditDOs);
		auditDAOImpl.delete(registryPolicyAuditDOs);
		verify(auditRepository, times(1)).delete(registryPolicyAuditDOs);
	}
	
	@Test(enabled = true, expectedExceptions = {DataAccessException.class})
	public void testDeleteEntitiesHandleException() throws Exception {
		Mockito.doThrow(exception).when(auditRepository).delete(registryPolicyAuditDOs);
		auditDAOImpl.delete(registryPolicyAuditDOs);
		verify(auditRepository, times(1)).delete(registryPolicyAuditDOs);
	}
}
