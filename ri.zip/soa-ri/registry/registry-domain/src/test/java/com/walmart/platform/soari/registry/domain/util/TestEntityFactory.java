package com.walmart.platform.soari.registry.domain.util;

import java.sql.Timestamp;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import org.apache.commons.lang.math.RandomUtils;

import com.walmart.platform.soari.registry.common.enums.AuditType;
import com.walmart.platform.soari.registry.common.enums.AvailabilityTierType;
import com.walmart.platform.soari.registry.common.enums.EnvironmentType;
import com.walmart.platform.soari.registry.domain.AuditDO;
import com.walmart.platform.soari.registry.domain.ConsumerDO;
import com.walmart.platform.soari.registry.domain.DefaultPolicyDO;
import com.walmart.platform.soari.registry.domain.DefaultQoSDO;
import com.walmart.platform.soari.registry.domain.EntityDO;
import com.walmart.platform.soari.registry.domain.NotificationDestinationDO;
import com.walmart.platform.soari.registry.domain.PolicyDO;
import com.walmart.platform.soari.registry.domain.QoSDO;
import com.walmart.platform.soari.registry.domain.ServiceDO;
import com.walmart.platform.soari.registry.domain.ServiceVersionDO;
import com.walmart.platform.soari.registry.domain.SubscriptionDO;
import com.walmart.platform.soari.registry.domain.UrlDO;

public class TestEntityFactory {
	public static DefaultPolicyDO DefaultnewPolicy(String status, String type, String flowType) {
		long now = System.currentTimeMillis();
		int random = RandomUtils.nextInt();
		String createdBy = "test user_"+now;
		Date createdDate = new Date();
		String name = "test policy_"+now+"_"+random;
		String data = "Test Policy Data";
		String description = "Test Description";
		//Set<ServiceVersionDO> serviceVersions = new HashSet<ServiceVersionDO>();
		return EntityFactory.newDefaultPolicy(status, createdBy, createdDate, name, description, type, data, flowType, 1);
	}
	
	public static PolicyDO newPolicy(String status, String type, String flowType) {
		long now = System.currentTimeMillis();
		int random = RandomUtils.nextInt();
		String createdBy = "test user_"+now;
		Date createdDate = new Date();
		String name = "test policy_"+now+"_"+random;
		String data = "Test Policy Data";
		String description = "Test Description";
		Set<ServiceVersionDO> serviceVersions = new HashSet<ServiceVersionDO>();
		return EntityFactory.newPolicy(status, createdBy, createdDate, name, description, type, data, flowType, 1, serviceVersions);
	}

	public static ConsumerDO newConsumer(String status) {
		long now = System.currentTimeMillis();
		String createdBy = "test user_"+now;
		String consumerId = UUID.randomUUID().toString().replace("-", "");
		return EntityFactory.newConsumer(status, createdBy, consumerId);
	}

	public static SubscriptionDO newSubscription(String status, ConsumerDO consumer, ServiceVersionDO serviceVersion, String communicationType) {
		long now = System.currentTimeMillis();
		String createdBy = "test user_"+now;
		String consumerId = UUID.randomUUID().toString().replace("-", "");
		return EntityFactory.newSubscription(status, createdBy, consumerId, consumer, serviceVersion, communicationType);
	}

	public static QoSDO newQoS(String status, String type) {
		long now = System.currentTimeMillis();
		String createdBy = "test user_"+now;
		Date createdDate = new Date();
		String name = "test policy_"+now;
		String description = "Test Description";
		return EntityFactory.newQoS(status, createdBy, createdDate, name, description, type);
	}

	public static DefaultQoSDO DefaultnewQoS(String status, String type) {
		long now = System.currentTimeMillis();
		String name = "test policy_"+now;
		String value = "test value_"+now;
		String description = "Test Description";
		String env ="default";
		String category = "SLA";
		return EntityFactory.newDefaultQoS(name,env,category,status,description, type,value);
	}
	
	public static AuditDO newAudit(EntityDO entity) {
		AuditDO audit = new AuditDO(entity);
		audit.setType(AuditType.UPDATE_POLICY);
		audit.setNewValue("New Value");
		audit.setOldValue("Old Value");
		audit.setField("Name");
		audit.setModifiedBy(entity.getModifiedBy()!=null?entity.getModifiedBy():entity.getCreatedBy());
		
		return audit;
	}
	
	public static NotificationDestinationDO newNotificationDestination(String status, String type) {
		long now = System.currentTimeMillis();
		NotificationDestinationDO notificationDestination = new NotificationDestinationDO();
		notificationDestination.setAvailabilityTier(AvailabilityTierType.TIER1.toString());
		notificationDestination.setEnvironment(EnvironmentType.DEV.toString());
		notificationDestination.setName("Test Notification Destination "+now);
		notificationDestination.setType(type);
		notificationDestination.setUrl("Test Notification Url");
		notificationDestination.setStatus(status);
		return notificationDestination;
	}
	
	public static ServiceDO newService(String category, String domain, String usage, String status) {
		long now = System.currentTimeMillis();
		String applicationId = "TEST_APP_ID";
		String createdBy = "Test User";
		Date createdTime = new Date();
		String description = "description";
		String owner = "Test User";
		String serviceName = "Test Service "+now;
		String environment = "default";
		Set<ServiceVersionDO> serviceVersions = new HashSet<ServiceVersionDO>(0);
		return EntityFactory.newService(applicationId, category, createdBy, createdTime, description, owner, serviceName, serviceVersions, domain, usage, status, environment);
	}
	
	private static ServiceVersionDO newServiceVersion(String status, Set<UrlDO> urls) {
		Timestamp currentTimestamp = new Timestamp(new Date().getTime());
		Timestamp activationStartDate = currentTimestamp;
		Timestamp activationEndDate = currentTimestamp;
		Timestamp publicationDate = currentTimestamp;
		String availabilityTier = "TIER1";
		String esbReference = "ESB_REF";
		String environment = "DEV";
		ServiceDO service = null;
		String serVersion = "1.0.0";
		
		
		/*UrlDO endpointUrl = new UrlDO();
		endpointUrl.setType(UrlType.ENDPOINT);
		endpointUrl.setUrl("endpoint_url");
		urls.add(endpointUrl);
		UrlDO endpointUrlAlternate = new UrlDO();
		endpointUrlAlternate.setType(UrlType.ENDPOINT_ALTERNATE);
		endpointUrlAlternate.setUrl("endpint_url_alternate");
		urls.add(endpointUrlAlternate);
		UrlDO contractUrl = new UrlDO();
		contractUrl.setType(UrlType.CONTRACT);
		contractUrl.setUrl("contract_url");
		urls.add(contractUrl);*/
		
		ServiceVersionDO serviceVersion = EntityFactory.newServiceVersion(activationStartDate, activationEndDate, availabilityTier, environment, esbReference, publicationDate, service, status, serVersion, urls);
		return serviceVersion;
	}
	
	public static ServiceVersionDO newServiceVersion(ServiceDO service, String status, Set<UrlDO> urlDOs) {
		ServiceVersionDO serviceVersion = newServiceVersion(status, urlDOs);
		serviceVersion.setService(service);
		return serviceVersion;
	}
}
