package com.walmart.platform.soari.registry.domain.dao.impl.test;

import org.mockito.Mock;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

public abstract class AbstractDAOTest {
	
	protected final String POLICY_ID = "10L";
	protected final String SERVICE_ID = "10L";
	protected final String SERVICE_VERSION_ID = "10L";
	protected final String SERVICE_PARAMETER_ID = "10L";
	protected final String POLICY_CONFIGURATION_ID = "10L";
	protected final String CONSUMER_ID = "10L";
	protected final String SERVICE_CONFIGURATION_ID = "10L";
	protected final String SERVICE_NAME = "TEST_SERVICE";
	protected final String POLICY_NAME = "TEST_POLICY";
	@Mock protected Pageable pageable;
	@Mock protected Sort sort;
	@Mock protected RuntimeException exception;

}
