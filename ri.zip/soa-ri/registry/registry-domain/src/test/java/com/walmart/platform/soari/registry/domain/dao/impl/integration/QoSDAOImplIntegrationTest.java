package com.walmart.platform.soari.registry.domain.dao.impl.integration;

import java.util.ArrayList;
import java.util.List;

import junit.framework.Assert;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;
import org.testng.annotations.Test;

import com.walmart.platform.kernel.exception.layers.dao.DataAccessException;
import com.walmart.platform.soari.registry.common.enums.RegistryPolicyCodeType;
import com.walmart.platform.soari.registry.common.enums.StatusType;
import com.walmart.platform.soari.registry.domain.QoSDO;
import com.walmart.platform.soari.registry.domain.RegistryPolicyCode;
import com.walmart.platform.soari.registry.domain.dao.impl.RegistryPolicyCodeDAOImpl;

@TransactionConfiguration(transactionManager = "transactionManager", defaultRollback = true)
public class QoSDAOImplIntegrationTest extends AbstractDAOIntegrationTest {

	private static Logger LOG = LoggerFactory
			.getLogger(QoSDAOImplIntegrationTest.class);

	@Test(enabled = true)
	@Transactional
	public void testSave() {
		try {
			QoSDO expected = newQoS();
			expected = qosDAO.save(expected);
			Assert.assertEquals(expected, qosDAO.findOne(expected.getId()));
		} catch (DataAccessException ex) {
			LOG.error("error while testSave : " + ex.getMessage());
			Assert.fail("error while testSave : " + ex.getMessage());
		}
	}

	@Test(enabled = true)
	@Transactional
	public void testFindByStatus() {
		try {
			QoSDO qos1 = newQoS();
			qos1 = qosDAO.save(qos1);
			QoSDO qos2 = newQoS();
			qos2 = qosDAO.save(qos2);
			QoSDO qos3 = newQoS();
			RegistryPolicyCode status = RegistryPolicyCodeDAOImpl.getCode(RegistryPolicyCodeType.STATUS, StatusType.DELETED.toString());
			qos3.setStatus(status.getCode());
			qos3 = qosDAO.save(qos3);
			List<QoSDO> result = qosDAO.findByMatchingStatus(StatusType.ACTIVE.toString());
			Assert.assertTrue(contains(result, qos1.getId()));
			Assert.assertTrue(contains(result, qos2.getId()));
			Assert.assertFalse(contains(result, qos3.getId()));
		} catch (DataAccessException ex) {
			String error = "error while testFindByStatus() : "
					+ ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}
	}
	
	@Test(enabled = true)
	@Transactional
	public void testFindAllByPage() {
		try {
			QoSDO qos1 = newQoS();
			qos1 = qosDAO.save(qos1);
			QoSDO qos2 = newQoS();
			qos2 = qosDAO.save(qos2);
			QoSDO qos3 = newQoS();
			qos3 = qosDAO.save(qos3);

			Pageable pageable = new PageRequest(0, 2);
			List<QoSDO> result = qosDAO.findAll(pageable).getContent();
			Assert.assertEquals(result.size(), 2);
		} catch (DataAccessException ex) {
			String error = "error while testFindAllByPage() : "
					+ ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}
	}

	@Test(enabled = true)
	@Transactional
	public void testFindOne() {
		try {
			QoSDO expected = newQoS();
			expected = qosDAO.save(expected);
			Assert.assertEquals(expected, qosDAO.findOne(expected.getId()));
		} catch (DataAccessException ex) {
			String error = "error while testFindOne() : " + ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}
	}

	@Test(enabled = true)
	@Transactional
	public void testDeleteById() {
		try {
			QoSDO expected = newQoS();
			expected = qosDAO.save(expected);
			qosDAO.delete(expected.getId());
			Assert.assertNull(qosDAO.findOne(expected.getId()));
		} catch (DataAccessException ex) {
			String error = "error while testDeleteById() : " + ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}
	}

	@Test(enabled = true)
	@Transactional
	public void testDeleteEntity() {
		try {
			QoSDO expected = newQoS();
			expected = qosDAO.save(expected);
			qosDAO.delete(expected);
			Assert.assertNull(qosDAO.findOne(expected.getId()));
		} catch (DataAccessException ex) {
			String error = "error while testDeleteEntity() : "
					+ ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}
	}

	@Test(enabled = true)
	@Transactional
	public void testDeleteEntities() {
		try {
			List<QoSDO> qos = new ArrayList<QoSDO>();
			QoSDO qos1 = newQoS();
			qos1 = qosDAO.save(qos1);
			qos.add(qos1);
			QoSDO qos2 = newQoS();
			qos2 = qosDAO.save(qos2);
			qos.add(qos2);
			qosDAO.delete(qos);
			Assert.assertNull(qosDAO.findOne(qos1.getId()));
			Assert.assertNull(qosDAO.findOne(qos2.getId()));
		} catch (DataAccessException ex) {
			String error = "error while testDeleteEntities() : "
					+ ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}
	}

	@Test(enabled = true)
	@Transactional
	public void testDeleteAll() {
		Assert.assertTrue(true);
	}

	@Test(enabled = true)
	@Transactional
	public void testFindAll() {
		try {
			QoSDO qos1 = newQoS();
			qos1 = qosDAO.save(qos1);
			QoSDO qos2 = newQoS();
			qos2 = qosDAO.save(qos2);
			List<QoSDO> result = qosDAO.findAll();
			Assert.assertTrue(result.size() >= 2);
		} catch (DataAccessException ex) {
			String error = "error while testFindAll() : " + ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}
	}
	
	@Test(enabled = true)
	@Transactional
	public void testFindQoSByMatchingName() {
		try {
			long now = System.currentTimeMillis();
			QoSDO qos1 = newQoS();
			qos1.setName("QoS1 "+now+" Test");
			qos1 = qosDAO.save(qos1);
			QoSDO qos2 = newQoS();
			qos2.setName("QoS2 "+now+" Test");
			qos2 = qosDAO.save(qos2);
			QoSDO qos3 = newQoS();
			qos3.setName("QoS3 Test");
			qos3 = qosDAO.save(qos3);
			List<QoSDO> result = qosDAO.findByMatchingName(String.valueOf(now));
			Assert.assertTrue(contains(result, qos1.getId()));
			Assert.assertTrue(contains(result, qos2.getId()));
			Assert.assertFalse(contains(result, qos3.getId()));
		} catch (DataAccessException ex) {
			String error = "error while testFindQoSByMatchingName() : " + ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}
	}
	
	@Test(enabled = true)
	@Transactional
	public void testFindQoSByMatchingStatus() {
		try {
			QoSDO qos1 = newQoS();
			qos1 = qosDAO.save(qos1);
			QoSDO qos2 = newQoS();
			qos2 = qosDAO.save(qos2);
			QoSDO qos3 = newQoS();
			RegistryPolicyCode status = RegistryPolicyCodeDAOImpl.getCode(RegistryPolicyCodeType.STATUS, StatusType.DELETED.toString());
			qos3.setStatus(status.getCode());
			qos3 = qosDAO.save(qos3);
			List<QoSDO> result = qosDAO.findByMatchingStatus(StatusType.ACTIVE.toString());
			Assert.assertTrue(contains(result, qos1.getId()));
			Assert.assertTrue(contains(result, qos2.getId()));
			Assert.assertFalse(contains(result, qos3.getId()));
		} catch (DataAccessException ex) {
			String error = "error while testFindQoSByMatchingStatus() : " + ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}
	}

	@Test(enabled = true)
	@Transactional
	public void findAllBySort() {
		// qosDAO.findAll(sort);
		Assert.assertTrue(true);
	}

	@Test(enabled = true)
	@Transactional
	public void saveEntities() {
		try {
			List<QoSDO> qos = new ArrayList<QoSDO>();
			QoSDO qos1 = newQoS();
			qos.add(qos1);
			QoSDO qos2 = newQoS();
			qos.add(qos2);
			qosDAO.save(qos);
			Assert.assertNotNull(qosDAO.findOne(qos1.getId()));
			Assert.assertNotNull(qosDAO.findOne(qos2.getId()));
		} catch (DataAccessException ex) {
			String error = "error while saveEntities() : " + ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}
	}

	private boolean contains(List<QoSDO> qos, String id) {
		for(QoSDO qosDO : qos) {
			if(qosDO.getId().equals(id)) {
				return true;
			}
		}
		return false;
	}

}
