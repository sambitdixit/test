package com.walmart.platform.soari.registry.domain.dao.impl.test;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;

import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.Page;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.walmart.platform.kernel.exception.layers.dao.DataAccessException;
import com.walmart.platform.soari.registry.domain.ServiceVersionDO;
import com.walmart.platform.soari.registry.domain.dao.impl.ServiceVersionDAOImpl;
import com.walmart.platform.soari.registry.domain.repository.ServiceVersionRepository;
import com.walmart.platform.soari.registry.server.common.exception.ExceptionHandler;

public class ServiceVersionDAOImplTest extends AbstractDAOTest {
	
	@Mock private ServiceVersionDO serviceVersionDO;
	@Mock private List<ServiceVersionDO> serviceVersionDOs;
	@Mock private Page<ServiceVersionDO> page;
	@Mock private ExceptionHandler exceptionHandler;
	@Mock private DataAccessException dataAccessException;
	@Mock private ServiceVersionRepository serviceVersionRepository;
	
	@InjectMocks private ServiceVersionDAOImpl serviceVersionDAO = new ServiceVersionDAOImpl();
	
	@BeforeMethod(alwaysRun=true)  
	public void init() throws Exception {
		MockitoAnnotations.initMocks(this);
		Mockito.doThrow(dataAccessException).when(exceptionHandler).handleDataAccessException(Matchers.any(Exception.class));
	}
	
	@Test(enabled = true)
	public void testFindAll() throws Exception {
		when(serviceVersionRepository.findAll()).thenReturn(serviceVersionDOs);
		serviceVersionDAO.findAll();
		verify(serviceVersionRepository, times(1)).findAll();
	}
	
	@Test(enabled = true, expectedExceptions = {DataAccessException.class})
	public void testFindAllHandleException() throws Exception {
		when(serviceVersionRepository.findAll()).thenThrow(exception);
		serviceVersionDAO.findAll();
		verify(serviceVersionRepository, times(1)).findAll();
	}
	
	@Test(enabled = true)
	public void testFindAllPageable() throws Exception {
		when(serviceVersionRepository.findAll(pageable)).thenReturn(page);
		serviceVersionDAO.findAll(pageable);
		verify(serviceVersionRepository, times(1)).findAll(pageable);
	}
	
	@Test(enabled = true, expectedExceptions = {DataAccessException.class})
	public void testFindAllPageableHandleException() throws Exception {
		when(serviceVersionRepository.findAll(pageable)).thenThrow(exception);
		serviceVersionDAO.findAll(pageable);
		verify(serviceVersionRepository, times(1)).findAll(pageable);
	}
	
	@Test(enabled = true)
	public void testFindAllBySort() throws Exception {
		when(serviceVersionRepository.findAll(sort)).thenReturn(serviceVersionDOs);
		serviceVersionDAO.findAll(sort);
		verify(serviceVersionRepository, times(1)).findAll(sort);
	}
	
	@Test(enabled = true, expectedExceptions = {DataAccessException.class})
	public void testFindAllBySortHandleException() throws Exception {
		when(serviceVersionRepository.findAll(sort)).thenThrow(exception);
		serviceVersionDAO.findAll(sort);
		verify(serviceVersionRepository, times(1)).findAll(sort);
	}
	@Test(enabled = true)
	public void testSave() throws Exception {
		when(serviceVersionRepository.save(serviceVersionDO)).thenReturn(serviceVersionDO);
		serviceVersionDAO.save(serviceVersionDO);
		verify(serviceVersionRepository, times(1)).save(serviceVersionDO);
	}
	
	@Test(enabled = true, expectedExceptions = {DataAccessException.class})
	public void testSaveHandleException() throws Exception {
		when(serviceVersionRepository.save(serviceVersionDO)).thenThrow(exception);
		serviceVersionDAO.save(serviceVersionDO);
		verify(serviceVersionRepository, times(1)).save(serviceVersionDO);
	}
	
	@Test(enabled = true)
	public void testSaveEntities() throws Exception {
		when(serviceVersionRepository.save(serviceVersionDOs)).thenReturn(serviceVersionDOs);
		serviceVersionDAO.save(serviceVersionDOs);
		verify(serviceVersionRepository, times(1)).save(serviceVersionDOs);
	}
	
	@Test(enabled = true, expectedExceptions = {DataAccessException.class})
	public void testSaveEntitiesHandleException() throws Exception {
		when(serviceVersionRepository.save(serviceVersionDOs)).thenThrow(exception);
		serviceVersionDAO.save(serviceVersionDOs);
		verify(serviceVersionRepository, times(1)).save(serviceVersionDOs);
	}

	@Test(enabled = true)
	public void testFindOne() throws Exception {
		when(serviceVersionRepository.findOne(POLICY_CONFIGURATION_ID)).thenReturn(serviceVersionDO);
		serviceVersionDAO.findOne(POLICY_CONFIGURATION_ID);
		verify(serviceVersionRepository, times(1)).findOne(POLICY_CONFIGURATION_ID);
	}
	
	@Test(enabled = true, expectedExceptions = {DataAccessException.class})
	public void testFindOneHandleException() throws Exception {
		when(serviceVersionRepository.findOne(POLICY_CONFIGURATION_ID)).thenThrow(exception);
		serviceVersionDAO.findOne(POLICY_CONFIGURATION_ID);
		verify(serviceVersionRepository, times(1)).findOne(POLICY_CONFIGURATION_ID);
	}

	@Test(enabled = true)
	public void testDeleteById() throws Exception {
		Mockito.doNothing().when(serviceVersionRepository).delete(POLICY_CONFIGURATION_ID);
		serviceVersionDAO.delete(POLICY_CONFIGURATION_ID);
		verify(serviceVersionRepository, times(1)).delete(POLICY_CONFIGURATION_ID);
	}
	
	@Test(enabled = true, expectedExceptions = {DataAccessException.class})
	public void testDeleteByIdHandleException() throws Exception {
		Mockito.doThrow(exception).when(serviceVersionRepository).delete(POLICY_CONFIGURATION_ID);
		serviceVersionDAO.delete(POLICY_CONFIGURATION_ID);
		verify(serviceVersionRepository, times(1)).delete(POLICY_CONFIGURATION_ID);
	}

	@Test(enabled = true)
	public void testDeleteEntity() throws Exception {
		Mockito.doNothing().when(serviceVersionRepository).delete(serviceVersionDO);
		serviceVersionDAO.delete(serviceVersionDO);
		verify(serviceVersionRepository, times(1)).delete(serviceVersionDO);
	}
	
	@Test(enabled = true, expectedExceptions = {DataAccessException.class})
	public void testDeleteEntityHandleException() throws Exception {
		Mockito.doThrow(exception).when(serviceVersionRepository).delete(serviceVersionDO);
		serviceVersionDAO.delete(serviceVersionDO);
		verify(serviceVersionRepository, times(1)).delete(serviceVersionDO);
	}
	@Test(enabled = true)
	public void testDeleteEntities() throws Exception {
		Mockito.doNothing().when(serviceVersionRepository).delete(serviceVersionDOs);
		serviceVersionDAO.delete(serviceVersionDOs);
		verify(serviceVersionRepository, times(1)).delete(serviceVersionDOs);
	}
	
	@Test(enabled = true, expectedExceptions = {DataAccessException.class})
	public void testDeleteEntitiesHandleException() throws Exception {
		Mockito.doThrow(exception).when(serviceVersionRepository).delete(serviceVersionDOs);
		serviceVersionDAO.delete(serviceVersionDOs);
		verify(serviceVersionRepository, times(1)).delete(serviceVersionDOs);
	}
}
