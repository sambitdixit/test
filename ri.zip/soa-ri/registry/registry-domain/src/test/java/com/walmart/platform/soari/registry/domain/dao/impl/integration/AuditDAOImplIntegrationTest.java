package com.walmart.platform.soari.registry.domain.dao.impl.integration;

import java.util.ArrayList;
import java.util.List;

import junit.framework.Assert;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;
import org.testng.annotations.Test;

import com.walmart.platform.kernel.exception.layers.dao.DataAccessException;
import com.walmart.platform.soari.registry.domain.AuditDO;
import com.walmart.platform.soari.registry.domain.PolicyDO;
import com.walmart.platform.soari.registry.domain.repository.AuditRepository;

@TransactionConfiguration(transactionManager = "transactionManager", defaultRollback = true)
public class AuditDAOImplIntegrationTest extends
		AbstractDAOIntegrationTest {
	
	private PolicyDO policy;
	
	private static Logger LOG = LoggerFactory
			.getLogger(AuditDAOImplIntegrationTest.class);

	@Test(enabled = true)
	@Transactional
	public void testSave() {
		try {
			policy = newPolicy();
			policy = policyDAO.save(policy);
			AuditDO expected = newAudit(policy);
			expected = auditDAO.save(expected);
			Assert.assertEquals(expected,
					auditDAO.findOne(expected.getId()));
		} catch (DataAccessException ex) {
			LOG.error("error while testSave : " + ex.getMessage());
			Assert.fail("error while testSave : " + ex.getMessage());
		}
	}

	@Test(enabled = true)
	@Transactional
	public void testFindAllByPage() {
		try {
			policy = newPolicy();
			policy = policyDAO.save(policy);
			AuditDO expected1 = newAudit(policy);
			expected1 = auditDAO.save(expected1);
			AuditDO expected2 = newAudit(policy);
			expected2 = auditDAO.save(expected2);
			AuditDO nonExpected = newAudit(policy);
			nonExpected = auditDAO.save(nonExpected);

			Pageable pageable = new PageRequest(0, 2);
			List<AuditDO> result = auditDAO.findAll(
					pageable).getContent();
			Assert.assertNotNull(result);
			Assert.assertEquals(2, result.size());
		} catch (DataAccessException ex) {
			String error = "error while testFindAllByPage() : "
					+ ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}
	}

	@Test(enabled = true)
	@Transactional
	public void testFindOne() {
		try {
			policy = newPolicy();
			policy = policyDAO.save(policy);
			AuditDO expected = newAudit(policy);
			expected = auditDAO.save(expected);
			Assert.assertEquals(expected,
					auditDAO.findOne(expected.getId()));
		} catch (DataAccessException ex) {
			String error = "error while testFindOne() : " + ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}
	}

	@Test(enabled = true)
	@Transactional
	public void testDeleteById() {
		try {
			policy = newPolicy();
			policy = policyDAO.save(policy);
			AuditDO expected = newAudit(policy);
			expected = auditDAO.save(expected);
			auditDAO.delete(expected.getId());
			Assert.assertNull(auditDAO.findOne(expected.getId()));
		} catch (DataAccessException ex) {
			String error = "error while testDeleteById() : " + ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}
	}

	@Test(enabled = true)
	@Transactional
	public void testDeleteEntity() {
		try {
			policy = newPolicy();
			policy = policyDAO.save(policy);
			AuditDO expected = newAudit(policy);
			expected = auditDAO.save(expected);
			auditDAO.delete(expected);
			Assert.assertNull(auditDAO.findOne(expected.getId()));
		} catch (DataAccessException ex) {
			String error = "error while testDeleteEntity() : "
					+ ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}
	}

	@Test(enabled = true)
	@Transactional
	public void testDeleteEntities() {
		try {
			policy = newPolicy();
			policy = policyDAO.save(policy);
			List<AuditDO> registryPolicyAuditDOs = new ArrayList<AuditDO>();
			AuditDO expected1 = newAudit(policy);
			expected1 = auditDAO.save(expected1);
			registryPolicyAuditDOs.add(expected1);
			AuditDO expected2 = newAudit(policy);
			expected2 = auditDAO.save(expected2);
			registryPolicyAuditDOs.add(expected2);
			auditDAO.delete(registryPolicyAuditDOs);
			Assert.assertNull(auditDAO.findOne(expected1.getId()));
			Assert.assertNull(auditDAO.findOne(expected2.getId()));
		} catch (DataAccessException ex) {
			String error = "error while testDeleteEntities() : "
					+ ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}
	}

	@Test(enabled = true)
	@Transactional
	public void testDeleteAll() {
		Assert.assertTrue(true);
	}

	@Test(enabled = false)
	@Transactional
	public void testFindAll() {
		try {
			policy = newPolicy();
			policy = policyDAO.save(policy);
			AuditDO expected1 = newAudit(policy);
			expected1 = auditDAO.save(expected1);
			AuditDO expected2 = newAudit(policy);
			expected2 = auditDAO.save(expected2);
			List<AuditDO> result = auditDAO.findAll();
			Assert.assertTrue(result.size() >= 2);
		} catch (DataAccessException ex) {
			String error = "error while count() : " + ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}
	}
	
	@Test(enabled = true)
	@Transactional
	public void testFindByEntityId() {
		try {
			policy = newPolicy();
			policy = policyDAO.save(policy);
			AuditDO expected1 = newAudit(policy);
			expected1 = auditDAO.save(expected1);
			AuditDO expected2 = newAudit(policy);
			expected2 = auditDAO.save(expected2);
			List<AuditDO> result = auditDAO.findByEntity(policy.getId(), 1);
			Assert.assertTrue(result.size() == 1);
		} catch (DataAccessException ex) {
			String error = "error while count() : " + ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}
	}

	@Test(enabled = true)
	@Transactional
	public void findAllBySort() {
		// auditDAO.findAll(sort);
		Assert.assertTrue(true);
	}

	@Test(enabled = true)
	@Transactional
	public void saveEntities() {
		try {
			policy = newPolicy();
			policy = policyDAO.save(policy);
			List<AuditDO> registryPolicyAuditDOs = new ArrayList<AuditDO>();
			AuditDO expected1 = newAudit(policy);
			registryPolicyAuditDOs.add(expected1);
			AuditDO expected2 = newAudit(policy);
			registryPolicyAuditDOs.add(expected2);
			auditDAO.save(registryPolicyAuditDOs);
			Assert.assertNotNull(auditDAO.findOne(expected1.getId()));
			Assert.assertNotNull(auditDAO.findOne(expected2.getId()));
		} catch (DataAccessException ex) {
			String error = "error while saveEntities() : " + ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}
	}

}
