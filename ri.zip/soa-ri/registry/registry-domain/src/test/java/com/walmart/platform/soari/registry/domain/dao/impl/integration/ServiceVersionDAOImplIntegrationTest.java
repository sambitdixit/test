package com.walmart.platform.soari.registry.domain.dao.impl.integration;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.walmart.platform.kernel.exception.layers.dao.DataAccessException;
import com.walmart.platform.soari.registry.domain.QoSDO;
import com.walmart.platform.soari.registry.domain.ServiceDO;
import com.walmart.platform.soari.registry.domain.ServiceVersionDO;
import com.walmart.platform.soari.registry.domain.ServiceVersionQoS;

@TransactionConfiguration(transactionManager = "transactionManager", defaultRollback = true)
public class ServiceVersionDAOImplIntegrationTest extends AbstractDAOIntegrationTest {

	private static Logger LOG = LoggerFactory
			.getLogger(ServiceVersionDAOImplIntegrationTest.class);

	@Test(enabled=true)
	@Transactional
	public void testTestQoS() {
		try {
			QoSDO qos = newQoS();
			qos = qosDAO.save(qos);
			ServiceVersionDO expected = newServiceVersion();
			ServiceVersionQoS serviceVersionQoS = new ServiceVersionQoS();
			serviceVersionQoS.setQos(qos);
			serviceVersionQoS.setServiceVersion(expected);
			serviceVersionQoS.setQosValue("123");
			expected.getServiceVersionQos().add(serviceVersionQoS);
			
			expected = serviceVersionDAO.save(expected);
			ServiceVersionDO actual = serviceVersionDAO.findOne(expected.getId());
			Assert.assertEquals(expected, actual);
			Assert.assertEquals(expected.getServiceVersionQos().size(), 1);
			
			serviceVersionQoS = expected.getServiceVersionQos().iterator().next();
			serviceVersionQoS.setQosValue("456");
			expected.getServiceVersionQos().clear();
			expected.getServiceVersionQos().add(serviceVersionQoS);
			expected = serviceVersionDAO.save(expected);
			expected = serviceVersionDAO.findOne(expected.getId());
			Assert.assertEquals(expected, actual);
			Assert.assertEquals(expected.getServiceVersionQos().size(), 1);
			Assert.assertEquals(expected.getServiceVersionQos().iterator().next().getQosValue(), "456");
			
			expected.getServiceVersionQos().clear();
			expected = serviceVersionDAO.save(expected);
			actual = serviceVersionDAO.findOne(expected.getId());
			Assert.assertEquals(expected, actual);
			Assert.assertEquals(expected.getServiceVersionQos().size(), 0);
			//expected.getServiceVersionQos().remove(qos);
		} catch (DataAccessException ex) {
			LOG.error("error while testSave : " + ex.getMessage());
			Assert.fail("error while testSave : " + ex.getMessage());
		}
	}
	
	@Test(enabled=true)
	@Transactional
	public void testSave() {
		try {
			ServiceVersionDO expected = newServiceVersion();
			expected = serviceVersionDAO.save(expected);
			ServiceVersionDO actual = serviceVersionDAO.findOne(expected.getId());
			Assert.assertEquals(expected, actual);
			Assert.assertEquals(expected.getUrls().size(), actual.getUrls().size());
		} catch (DataAccessException ex) {
			LOG.error("error while testSave : " + ex.getMessage());
			Assert.fail("error while testSave : " + ex.getMessage());
		}
	}
	
	@Test(enabled=true)
	@Transactional
	public void testFindAllByPage() {
		try {
			ServiceVersionDO expected1 = newServiceVersion();
			expected1 = serviceVersionDAO.save(expected1);
			ServiceVersionDO expected2 = newServiceVersion();
			expected2 = serviceVersionDAO.save(expected2);
			ServiceVersionDO nonExpected = newServiceVersion();
			nonExpected = serviceVersionDAO.save(nonExpected);

			Pageable pageable = new PageRequest(0, 2);
			List<ServiceVersionDO> result = serviceVersionDAO.findAll(pageable).getContent();
			Assert.assertEquals(result.size(), 2);
		} catch (DataAccessException ex) {
			String error = "error while testFindAllByPage() : " + ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}
	}

	@Test(enabled=true)
	@Transactional
	public void testFindOne() {
		try {
			ServiceVersionDO expected = newServiceVersion();
			expected = serviceVersionDAO.save(expected);
			Assert.assertEquals(expected, serviceVersionDAO.findOne(expected.getId()));
		} catch (DataAccessException ex) {
			String error = "error while testFindOne() : " + ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}
	}

	@Test(enabled=true)
	@Transactional
	public void testDeleteById() {
		try {
			ServiceVersionDO expected = newServiceVersion();
			expected = serviceVersionDAO.save(expected);
			serviceVersionDAO.delete(expected.getId());
			Assert.assertNull(serviceVersionDAO.findOne(expected.getId()));
		} catch (DataAccessException ex) {
			String error = "error while testDeleteById() : " + ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}
	}

	@Test(enabled=true)
	@Transactional
	public void testDeleteEntity() {
		try {
			ServiceVersionDO expected = newServiceVersion();
			expected = serviceVersionDAO.save(expected);
			serviceVersionDAO.delete(expected);
			Assert.assertNull(serviceVersionDAO.findOne(expected.getId()));
		} catch (DataAccessException ex) {
			String error = "error while testDeleteEntity() : "
					+ ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}
	}

	@Test(enabled=true)
	@Transactional
	public void testDeleteEntities() {
		try {
			List<ServiceVersionDO> serviceVersions = new ArrayList<ServiceVersionDO>();
			ServiceVersionDO expected1 = newServiceVersion();
			expected1 = serviceVersionDAO.save(expected1);
			serviceVersions.add(expected1);
			ServiceVersionDO expected2 = newServiceVersion();
			expected2 = serviceVersionDAO.save(expected2);
			serviceVersions.add(expected2);
			serviceVersionDAO.delete(serviceVersions);
			Assert.assertNull(serviceVersionDAO.findOne(expected1.getId()));
			Assert.assertNull(serviceVersionDAO.findOne(expected2.getId()));
		} catch (DataAccessException ex) {
			String error = "error while testDeleteEntities() : "
					+ ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}
	}

	@Test(enabled=true)
	@Transactional
	public void testDeleteAll() {
		Assert.assertTrue(true);
	}

	@Test(enabled=true)
	@Transactional
	public void testFindAll() {
		try {
			ServiceVersionDO expected1 = newServiceVersion();
			expected1 = serviceVersionDAO.save(expected1);
			ServiceVersionDO expected2 = newServiceVersion();
			expected2 = serviceVersionDAO.save(expected2);
			List<ServiceVersionDO> result = serviceVersionDAO.findAll();
			Assert.assertTrue(result.size() >= 2);
		} catch (DataAccessException ex) {
			String error = "error while testFindAll() : " + ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}
	}

	@Test(enabled=true)
	@Transactional
	public void findAllBySort() {
		//serviceVersionDAO.findAll(sort);
		Assert.assertTrue(true);
	}

	@Test(enabled=true)
	@Transactional
	public void testSaveEntities() {
		try {
			List<ServiceVersionDO> serviceVersions = new ArrayList<ServiceVersionDO>();
			ServiceVersionDO expected1 = newServiceVersion();
			serviceVersions.add(expected1);
			ServiceVersionDO expected2 = newServiceVersion();
			serviceVersions.add(expected2);
			serviceVersionDAO.save(serviceVersions);
			Assert.assertNotNull(serviceVersionDAO.findOne(expected1.getId()));
			Assert.assertNotNull(serviceVersionDAO.findOne(expected2.getId()));
		} catch (DataAccessException ex) {
			String error = "error while saveEntities() : "
					+ ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}	
	}

	@Test(enabled=true)
	public void testService() {
		try {
			ServiceVersionDO expected = newServiceVersion();
			expected = serviceVersionDAO.save(expected);
			Assert.assertEquals(expected.getService(), serviceVersionDAO.findOne(expected.getId()).getService());
		} catch (DataAccessException ex) {
			LOG.error("error while testService : " + ex.getMessage());
			Assert.fail("error while testService : " + ex.getMessage());
		}
	}

	@Test(enabled=true)
	public void testServiceParemeter() {
		try {
			ServiceVersionDO expected = newServiceVersion();
			expected = serviceVersionDAO.save(expected);
			//Assert.assertNotNull(expected.getQoSParameters());
			//Assert.assertTrue(expected.getQoSParameters().size() > 0);
		} catch (DataAccessException ex) {
			LOG.error("error while testServiceParemeter : " + ex.getMessage());
			Assert.fail("error while testServiceParemeter : " + ex.getMessage());
		}
	}

}
