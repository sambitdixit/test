package com.walmart.platform.soari.registry.domain.dao.impl.integration;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import junit.framework.Assert;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;
import org.testng.annotations.Test;

import com.walmart.platform.kernel.exception.layers.dao.DataAccessException;
import com.walmart.platform.soari.registry.common.enums.RegistryPolicyCodeType;
import com.walmart.platform.soari.registry.common.enums.ServiceCategoryType;
import com.walmart.platform.soari.registry.common.enums.ServiceDomainType;
import com.walmart.platform.soari.registry.common.enums.ServiceUseType;
import com.walmart.platform.soari.registry.common.enums.StatusType;
import com.walmart.platform.soari.registry.domain.PolicyDO;
import com.walmart.platform.soari.registry.domain.QoSDO;
import com.walmart.platform.soari.registry.domain.RegistryPolicyCode;
import com.walmart.platform.soari.registry.domain.ServiceDO;
import com.walmart.platform.soari.registry.domain.ServiceVersionDO;
import com.walmart.platform.soari.registry.domain.ServiceVersionQoS;
import com.walmart.platform.soari.registry.domain.dao.impl.RegistryPolicyCodeDAOImpl;

@TransactionConfiguration(transactionManager = "transactionManager", defaultRollback = true)
public class ServiceDAOImplIntegrationTest extends AbstractDAOIntegrationTest {

	private static Logger LOG = LoggerFactory
			.getLogger(ServiceDAOImplIntegrationTest.class);

	@Test(enabled=true)
	@Transactional
	public void testFimdByQoSId() throws Exception{
		try {
			
			QoSDO qos = newQoS();
			qos = qosDAO.save(qos);
			
			ServiceDO expected1 = newService();
			expected1 = serviceDAO.save(expected1);
			Assert.assertEquals(expected1, serviceDAO.findOne(expected1.getId()));
		
			ServiceVersionDO expectedVersion = newServiceVersion();
			expected1.getServiceVersions().add(expectedVersion);
			expected1 = serviceDAO.save(expected1);
		
			expectedVersion = serviceVersionDAO.findOne(expected1.getServiceVersions().iterator().next().getId());
			ServiceVersionQoS serviceVersionQoS = new ServiceVersionQoS();
			serviceVersionQoS.setQos(qos);
			serviceVersionQoS.setServiceVersion(expectedVersion);
			serviceVersionQoS.setQosValue("123");
			expectedVersion.getServiceVersionQos().add(serviceVersionQoS);
			
			expectedVersion = serviceVersionDAO.save(expectedVersion);
			
			Assert.assertEquals(expected1.getServiceVersions().size(), 1);
			Assert.assertEquals(expected1.getServiceVersions().iterator().next().getServiceVersionQos().size(), 1);
		
			//New Service with new version using same QOS
			ServiceDO expected2 = newService();
			expected1 = serviceDAO.save(expected2);
			Assert.assertEquals(expected1, serviceDAO.findOne(expected2.getId()));
		
			ServiceVersionDO expectedVersion2 = newServiceVersion();
			expected2.getServiceVersions().add(expectedVersion2);
			expected2 = serviceDAO.save(expected2);
		
			expectedVersion2 = serviceVersionDAO.findOne(expected2.getServiceVersions().iterator().next().getId());
			ServiceVersionQoS serviceVersionQoS2 = new ServiceVersionQoS();
			serviceVersionQoS2.setQos(qos);
			serviceVersionQoS2.setServiceVersion(expectedVersion2);
			serviceVersionQoS2.setQosValue("123");
			expectedVersion2.getServiceVersionQos().add(serviceVersionQoS2);
			
			expectedVersion2 = serviceVersionDAO.save(expectedVersion2);
			
			Assert.assertEquals(expected2.getServiceVersions().size(), 1);
			Assert.assertEquals(expected2.getServiceVersions().iterator().next().getServiceVersionQos().size(), 1);
		
			
			List<ServiceDO> services = serviceDAO.findByQoSId(qos.getId());
			Assert.assertTrue(!services.isEmpty());
			Assert.assertEquals(2, services.size());
		} catch (DataAccessException ex) {
			LOG.error("error while testSave : " + ex.getMessage());
			Assert.fail("error while testSave : " + ex.getMessage());
		}
	}
	
	@Test(enabled=true)
	@Transactional
	public void testFimdByPolicyId() throws Exception{
		try {
			
			PolicyDO expectedPolicy = newPolicy();
			expectedPolicy = policyDAO.save(expectedPolicy);
			
			ServiceDO expected1 = newService();
			expected1 = serviceDAO.save(expected1);
			Assert.assertEquals(expected1, serviceDAO.findOne(expected1.getId()));
		
			ServiceVersionDO expectedVersion = newServiceVersion();
			expected1.getServiceVersions().add(expectedVersion);
			expected1 = serviceDAO.save(expected1);
		
			expectedVersion = serviceVersionDAO.findOne(expected1.getServiceVersions().iterator().next().getId());
			expectedVersion.getPolicies().add(expectedPolicy);
			
			expectedVersion = serviceVersionDAO.save(expectedVersion);
			
			Assert.assertEquals(expected1.getServiceVersions().size(), 1);
			Assert.assertEquals(expected1.getServiceVersions().iterator().next().getPolicies().size(), 1);
		
			//New Service with new version using same QOS
			ServiceDO expected2 = newService();
			expected1 = serviceDAO.save(expected2);
			Assert.assertEquals(expected1, serviceDAO.findOne(expected2.getId()));
		
			ServiceVersionDO expectedVersion2 = newServiceVersion();
			expected2.getServiceVersions().add(expectedVersion2);
			expected2 = serviceDAO.save(expected2);
		
			expectedVersion2 = serviceVersionDAO.findOne(expected2.getServiceVersions().iterator().next().getId());
			expectedVersion2.getPolicies().add(expectedPolicy);
			
			expectedVersion2 = serviceVersionDAO.save(expectedVersion2);
			
			Assert.assertEquals(expected2.getServiceVersions().size(), 1);
			Assert.assertEquals(expected2.getServiceVersions().iterator().next().getPolicies().size(), 1);
		
			
			List<ServiceDO> services = serviceDAO.findByPolicyId(expectedPolicy.getId());
			Assert.assertTrue(!services.isEmpty());
			Assert.assertEquals(2, services.size());
		} catch (DataAccessException ex) {
			LOG.error("error while testSave : " + ex.getMessage());
			Assert.fail("error while testSave : " + ex.getMessage());
		}
	}
	
	@Test(enabled=true)
	@Transactional
	public void testSave() {
		try {
			ServiceDO expected = newService();
			expected = serviceDAO.save(expected);
			Assert.assertEquals(expected, serviceDAO.findOne(expected.getId()));
		} catch (DataAccessException ex) {
			LOG.error("error while testSave : " + ex.getMessage());
			Assert.fail("error while testSave : " + ex.getMessage());
		}
	}

	@Test(enabled=true)
	@Transactional
	public void testFindAllByPage() {
		try {
			ServiceDO expected1 = newService();
			expected1 = serviceDAO.save(expected1);
			ServiceDO expected2 = newService();
			expected2 = serviceDAO.save(expected2);
			ServiceDO nonExpected = newService();
			nonExpected = serviceDAO.save(nonExpected);

			Pageable pageable = new PageRequest(0, 2);
			List<ServiceDO> result = serviceDAO.findAll(pageable).getContent();
			Assert.assertEquals(result.size(), 2);
		} catch (DataAccessException ex) {
			String error = "error while testFindAllByPage() : " + ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}
	}

	@Test(enabled=true)
	@Transactional
	public void testFindOne() {
		try {
			ServiceDO expected = newService();
			expected = serviceDAO.save(expected);
			Assert.assertEquals(expected, serviceDAO.findOne(expected.getId()));
		} catch (DataAccessException ex) {
			String error = "error while testFindOne() : " + ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}
	}

	@Test(enabled=true)
	@Transactional
	public void testDeleteById() {
		try {
			ServiceDO expected = newService();
			expected = serviceDAO.save(expected);
			serviceDAO.delete(expected.getId());
			Assert.assertNull(serviceDAO.findOne(expected.getId()));
		} catch (DataAccessException ex) {
			String error = "error while testDeleteById() : " + ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}
	}

	@Test(enabled=true)
	@Transactional
	public void testDeleteEntity() {
		try {
			ServiceDO expected = newService();
			expected = serviceDAO.save(expected);
			serviceDAO.delete(expected);
			Assert.assertNull(serviceDAO.findOne(expected.getId()));
		} catch (DataAccessException ex) {
			String error = "error while testDeleteEntity() : "
					+ ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}
	}

	@Test(enabled=true)
	@Transactional
	public void testDeleteEntities() {
		try {
			List<ServiceDO> services = new ArrayList<ServiceDO>();
			ServiceDO expected1 = newService();
			expected1 = serviceDAO.save(expected1);
			services.add(expected1);
			ServiceDO expected2 = newService();
			expected2 = serviceDAO.save(expected2);
			services.add(expected2);
			serviceDAO.delete(services);
			Assert.assertNull(serviceDAO.findOne(expected1.getId()));
			Assert.assertNull(serviceDAO.findOne(expected2.getId()));
		} catch (DataAccessException ex) {
			String error = "error while testDeleteEntities() : "
					+ ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}
	}

	@Test(enabled=true)
	@Transactional
	public void testDeleteAll() {
		Assert.assertTrue(true);
	}

	@Test(enabled=true)
	@Transactional
	public void testFindAll() {
		try {
			ServiceDO expected1 = newService();
			expected1 = serviceDAO.save(expected1);
			ServiceDO expected2 = newService();
			expected2 = serviceDAO.save(expected2);
			List<ServiceDO> result = serviceDAO.findAll();
			Assert.assertTrue(result.size() >= 2);
		} catch (DataAccessException ex) {
			String error = "error while count() : " + ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}
	}

	@Test(enabled=true)
	@Transactional
	public void findAllBySort() {
		//serviceDAO.findAll(sort);
		Assert.assertTrue(true);
	}

	@Test(enabled=true)
	@Transactional
	public void saveEntities() {
		try {
			List<ServiceDO> services = new ArrayList<ServiceDO>();
			ServiceDO expected1 = newService();
			services.add(expected1);
			ServiceDO expected2 = newService();
			services.add(expected2);
			serviceDAO.save(services);
			Assert.assertNotNull(serviceDAO.findOne(expected1.getId()));
			Assert.assertNotNull(serviceDAO.findOne(expected2.getId()));
		} catch (DataAccessException ex) {
			String error = "error while saveEntities() : "
					+ ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}	
	}
	
	@Test(enabled = true)
	@Transactional
	public void  testFindByMatchingCategory() throws Exception {
		try {
			ServiceDO service1 = newService();
			service1 = serviceDAO.save(service1);
			ServiceDO service2 = newService();
			service2 = serviceDAO.save(service2);
			ServiceDO service3 = newService();
			RegistryPolicyCode category = RegistryPolicyCodeDAOImpl.getCode(RegistryPolicyCodeType.SERVICE_CATEGORY, ServiceCategoryType.BIZ.toString());
			service3.setCategory(category.getCode());
			service3 = serviceDAO.save(service3);
			List<ServiceDO> services = serviceDAO.findByCategory(ServiceCategoryType.DATA.toString());
			Assert.assertTrue(contains(services, service1.getId()));
			Assert.assertTrue(contains(services, service2.getId()));
			Assert.assertFalse(contains(services, service3.getId()));
		} catch (DataAccessException ex) {
			String error = "error while saveEntities() : "
					+ ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}	
	}
	
	@Test(enabled = true)
	@Transactional
	public void  testFindByMatchingDescription() throws Exception {
		try {
			ServiceDO service1 = newService();
			service1.setDescription("Service Description1 Test1");
			service1 = serviceDAO.save(service1);
			ServiceDO service2 = newService();
			service2.setDescription("Service Description1 Test2");
			service2 = serviceDAO.save(service2);
			ServiceDO service3 = newService();
			service3.setDescription("Service Description2 Test3");
			service3 = serviceDAO.save(service3);
			List<ServiceDO> services = serviceDAO.findByMatchingDescription("Description1");;
			Assert.assertTrue(contains(services, service1.getId()));
			Assert.assertTrue(contains(services, service2.getId()));
			Assert.assertFalse(contains(services, service3.getId()));
		} catch (DataAccessException ex) {
			String error = "error while saveEntities() : "
					+ ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}	
	}
	
	@Test(enabled = true)
	@Transactional
	public void  testFindByMatchingOwner() throws Exception {
		try {
			ServiceDO service1 = newService();
			service1.setOwner("Service Owner1 Test1");
			service1 = serviceDAO.save(service1);
			ServiceDO service2 = newService();
			service2.setOwner("Service Owner1 Test2");
			service2 = serviceDAO.save(service2);
			ServiceDO service3 = newService();
			service3.setOwner("Service Owner3 Test1");
			service3 = serviceDAO.save(service3);
			List<ServiceDO> services = serviceDAO.findByMatchingOwner("Owner1");;
			Assert.assertTrue(contains(services, service1.getId()));
			Assert.assertTrue(contains(services, service2.getId()));
			Assert.assertFalse(contains(services, service3.getId()));
		} catch (DataAccessException ex) {
			String error = "error while saveEntities() : "
					+ ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}	
	}
	
	@Test(enabled = true)
	@Transactional
	public void  testFindByMatchingDomain() throws Exception {
		try {
			ServiceDO service1 = newService();
			service1 = serviceDAO.save(service1);
			ServiceDO service2 = newService();
			service2 = serviceDAO.save(service2);
			ServiceDO service3 = newService();
			RegistryPolicyCode domain = RegistryPolicyCodeDAOImpl.getCode(RegistryPolicyCodeType.SERVICE_DOMAIN, ServiceDomainType.B2C.toString());
			service3.setDomain(domain.getCode());
			service3 = serviceDAO.save(service3);
			List<ServiceDO> services = serviceDAO.findByDomain(ServiceDomainType.B2B.toString());;
			Assert.assertTrue(contains(services, service1.getId()));
			Assert.assertTrue(contains(services, service2.getId()));
			Assert.assertFalse(contains(services, service3.getId()));
		} catch (DataAccessException ex) {
			String error = "error while saveEntities() : "
					+ ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}	
	}
	
	@Test(enabled = true)
	@Transactional
	public void  testFindByMatchingUsage() throws Exception {
		try {
			ServiceDO service1 = newService();
			service1 = serviceDAO.save(service1);
			ServiceDO service2 = newService();
			service2 = serviceDAO.save(service2);
			ServiceDO service3 = newService();
			RegistryPolicyCode usage = RegistryPolicyCodeDAOImpl.getCode(RegistryPolicyCodeType.SERVICE_USAGE, ServiceUseType.EXTERNAL.toString());
			service3.setUsage(usage.getCode());
			service3 = serviceDAO.save(service3);
			List<ServiceDO> services = serviceDAO.findByUsage(ServiceUseType.INTERNAL.toString());
			Assert.assertTrue(contains(services, service1.getId()));
			Assert.assertTrue(contains(services, service2.getId()));
			Assert.assertFalse(contains(services, service3.getId()));
		} catch (DataAccessException ex) {
			String error = "error while testFindByMatchingUsage() : "
					+ ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}	
	}
	
	@Test(enabled = true)
	@Transactional
	public void  testFindByStatus() throws Exception {
		try {
			ServiceDO service1 = newService();
			service1 = serviceDAO.save(service1);
			ServiceDO service2 = newService();
			service2 = serviceDAO.save(service2);
			ServiceDO service3 = newService();
			RegistryPolicyCode status = RegistryPolicyCodeDAOImpl.getCode(RegistryPolicyCodeType.STATUS, StatusType.DELETED.toString());
			service3.setStatus(status.getCode());
			service3 = serviceDAO.save(service3);
			List<String> statusTypes = new ArrayList<String>(0);
			statusTypes.add(StatusType.ACTIVE.toString());
			List<ServiceDO> services = serviceDAO.findByStatus(statusTypes);
			Assert.assertTrue(contains(services, service1.getId()));
			Assert.assertTrue(contains(services, service2.getId()));
			Assert.assertFalse(contains(services, service3.getId()));
		} catch (DataAccessException ex) {
			String error = "error while testFindByStatus() : "
					+ ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}	
	}
	
	@Test(enabled = true)
	@Transactional
	public void  testFindByMatchingName() throws Exception {
		try {
			long now = System.currentTimeMillis();
			ServiceDO service1 = newService();
			service1.setName("Test Service_"+now+"_1");
			service1 = serviceDAO.save(service1);
			ServiceDO service2 = newService();
			service2.setName("Test Service_"+now+"_2");
			service2 = serviceDAO.save(service2);
			ServiceDO service3 = newService();
			service3.setName("Test Service_"+now*2);
			service3 = serviceDAO.save(service3);
			
			List<ServiceDO> services = serviceDAO.findByMatchingName(String.valueOf(now));
			Assert.assertTrue(contains(services, service1.getId()));
			Assert.assertTrue(contains(services, service2.getId()));
			Assert.assertFalse(contains(services, service3.getId()));
		} catch (DataAccessException ex) {
			String error = "error while testFindByMatchingName() : "
					+ ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}	
	}
	
	@Test(enabled = true)
	@Transactional
	public void  testSearchByMatchingName() throws Exception {
		try {
			long now = System.currentTimeMillis();
			ServiceDO service1 = newService();
			service1.setName("Test Service_"+now+"_1");
			service1 = serviceDAO.save(service1);
			ServiceDO service2 = newService();
			service2.setName("Test Service_"+now+"_2");
			service2 = serviceDAO.save(service2);
			ServiceDO service3 = newService();
			service3.setName("Test Service_"+now*2);
			service3 = serviceDAO.save(service3);
			Map<String, String> search = new HashMap<String, String>(0);
			search.put("name", String.valueOf(now));
			List<ServiceDO> services = serviceDAO.search(search);
			Assert.assertTrue(contains(services, service1.getId()));
			Assert.assertTrue(contains(services, service2.getId()));
			Assert.assertFalse(contains(services, service3.getId()));
		} catch (DataAccessException ex) {
			String error = "error while testFindByMatchingName() : "
					+ ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}	
	}
	
	@Test(enabled = true)
	public void testFindServiceCountPerEnvironment() throws Exception {
		long now = System.currentTimeMillis();
		ServiceDO service1 = newService();
		service1.setEnvironment("qa");
		service1.setName("Test Service_"+now+"_1");
		service1 = serviceDAO.save(service1);
		ServiceDO service2 = newService();
		service2.setEnvironment("qa");
		service2.setName("Test Service_"+now+"_2");
		service2 = serviceDAO.save(service2);
		ServiceDO service3 = newService();
		service3.setEnvironment("dev");
		service3.setName("Test Service_"+now+"_3");
		service3 = serviceDAO.save(service3);
		ServiceDO service4 = newService();
		service4.setEnvironment("dev");
		service4.setName("Test Service_"+now+"_4");
		service4 = serviceDAO.save(service4);
		String result = serviceDAO.findServiceCountPerEnvironment();
		System.out.println("result = "+result);
		Assert.assertNotNull(result);
		Assert.assertFalse(result.isEmpty());
	}
	
	@Test(enabled = true)
	public void testFindCountPerCategoryPerEnvironment() throws Exception {
		long now = System.currentTimeMillis();
		ServiceDO service_qa_data1 = newService();
		service_qa_data1.setEnvironment("qa");
		service_qa_data1.setCategory(ServiceCategoryType.DATA.toString());
		service_qa_data1.setName("service_qa_data1"+now);
		service_qa_data1 = serviceDAO.save(service_qa_data1);
		
		ServiceDO service_qa_data2 = newService();
		service_qa_data2.setEnvironment("qa");
		service_qa_data2.setCategory(ServiceCategoryType.DATA.toString());
		service_qa_data2.setName("service_qa_data2"+now);
		service_qa_data2 = serviceDAO.save(service_qa_data2);
		
		ServiceDO service_qa_util1 = newService();
		service_qa_util1.setEnvironment("qa");
		service_qa_util1.setCategory(ServiceCategoryType.UTIL.toString());
		service_qa_util1.setName("service_qa_util1"+now);
		service_qa_util1 = serviceDAO.save(service_qa_util1);
		
		ServiceDO service_qa_util2 = newService();
		service_qa_util2.setEnvironment("qa");
		service_qa_util2.setCategory(ServiceCategoryType.UTIL.toString());
		service_qa_util2.setName("service_qa_util2"+now);
		service_qa_util2 = serviceDAO.save(service_qa_util2);
		
		ServiceDO service_dev_biz1 = newService();
		service_dev_biz1.setEnvironment("dev");
		service_dev_biz1.setCategory(ServiceCategoryType.BIZ.toString());
		service_dev_biz1.setName("service_dev_biz1"+now);
		service_dev_biz1 = serviceDAO.save(service_dev_biz1);
		
		ServiceDO service_dev_biz2 = newService();
		service_dev_biz2.setEnvironment("dev");
		service_dev_biz2.setCategory(ServiceCategoryType.BIZ.toString());
		service_dev_biz2.setName("service_dev_biz2"+now);
		service_dev_biz2 = serviceDAO.save(service_dev_biz2);
		
		ServiceDO service_dev_infra1 = newService();
		service_dev_infra1.setEnvironment("dev");
		service_dev_infra1.setCategory(ServiceCategoryType.INFRA.toString());
		service_dev_infra1.setName("service_dev_infra1"+now);
		service_dev_infra1 = serviceDAO.save(service_dev_infra1);
		
		ServiceDO service_dev_infra2 = newService();
		service_dev_infra2.setEnvironment("dev");
		service_dev_infra2.setCategory(ServiceCategoryType.INFRA.toString());
		service_dev_infra2.setName("service_dev_infra2"+now);
		service_dev_infra2 = serviceDAO.save(service_dev_infra2);
		
		String result = serviceDAO.findCategoryCountPerEnvironment();
		System.out.println("result = "+result);
		Assert.assertNotNull(result);
		Assert.assertFalse(result.isEmpty());
	}
	
	@Test(enabled = true)
	public void testFindEnvironmentCountForService() throws Exception {
		long now = System.currentTimeMillis();
		ServiceDO service1 = newService();
		service1.setEnvironment("qa");
		service1.setName("Test Service_"+now+"_1");
		service1.setApplicationId(service1.getName());
		service1 = serviceDAO.save(service1);
		ServiceDO service2 = newService();
		service2.setEnvironment("dev");
		service2.setName("Test Service_"+now+"_1");
		service2.setApplicationId(service2.getName());
		service2 = serviceDAO.save(service2);
		ServiceDO service3 = newService();
		service3.setEnvironment("dev-int");
		service3.setName("Test Service_"+now+"_1");
		service3.setApplicationId(service3.getName());
		service3 = serviceDAO.save(service3);
		ServiceDO service4 = newService();
		service4.setEnvironment("qa");
		service4.setName("Test Service_"+now+"_4");
		service4.setApplicationId(service4.getName());
		service4 = serviceDAO.save(service4);
		String result = serviceDAO.findEnvironmentCountForService();
		System.out.println("result = "+result);
		Assert.assertNotNull(result);
		Assert.assertFalse(result.isEmpty());
	}
	
	@Test(enabled = true)
	public void testFindServiceCountPerMonth() throws Exception {
		long now = System.currentTimeMillis();
		ServiceDO service1 = newService();
		service1.setEnvironment("qa");
		service1.setName("Test Service_"+now+"_1");
		service1.setApplicationId(service1.getName());
		service1 = serviceDAO.save(service1);
		ServiceDO service2 = newService();
		service2.setEnvironment("dev");
		service2.setName("Test Service_"+now+"_1");
		service2.setApplicationId(service2.getName());
		service2 = serviceDAO.save(service2);
		ServiceDO service3 = newService();
		service3.setEnvironment("dev-int");
		service3.setName("Test Service_"+now+"_1");
		service3.setApplicationId(service3.getName());
		service3 = serviceDAO.save(service3);
		ServiceDO service4 = newService();
		service4.setEnvironment("qa");
		service4.setName("Test Service_"+now+"_4");
		service4.setApplicationId(service4.getName());
		service4 = serviceDAO.save(service4);
		String result = serviceDAO.findServiceCountPerMonth();
		System.out.println("result = "+result);
		Assert.assertNotNull(result);
		Assert.assertFalse(result.isEmpty());
	}
	
	private boolean contains(List<ServiceDO> services, String id) {
		for(ServiceDO serviceDO : services) {
			if(serviceDO.getId().equals(id)) {
				return true;
			}
		}
		return false;
	}
}
