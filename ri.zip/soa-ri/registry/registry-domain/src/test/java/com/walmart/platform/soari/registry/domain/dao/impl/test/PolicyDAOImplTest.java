package com.walmart.platform.soari.registry.domain.dao.impl.test;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.Page;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.walmart.platform.kernel.exception.layers.dao.DataAccessException;
import com.walmart.platform.soari.registry.domain.PolicyDO;
import com.walmart.platform.soari.registry.domain.dao.impl.PolicyDAOImpl;
import com.walmart.platform.soari.registry.domain.repository.PolicyRepository;
import com.walmart.platform.soari.registry.server.common.exception.ExceptionHandler;

public class PolicyDAOImplTest extends AbstractDAOTest {
	
	@Mock private PolicyRepository policyRepository;
	@Mock private PolicyDO policyDO;
	@Mock private List<PolicyDO> policyDOs;
	@Mock private Page<PolicyDO> page;
	@Mock private DataAccessException dataAccessException;
	@Mock private ExceptionHandler exceptionHandler;
	
	@InjectMocks private PolicyDAOImpl policyDAOImpl = new PolicyDAOImpl();
	
	@BeforeMethod(alwaysRun=true)  
	public void init() throws Exception {
		MockitoAnnotations.initMocks(this);
		Mockito.doThrow(dataAccessException).when(exceptionHandler).handleDataAccessException(Mockito.any(Exception.class));
	}
	
	@Test(enabled = true)
	public void testFindAll() throws Exception {
		when(policyRepository.findAll()).thenReturn(policyDOs);
		policyDAOImpl.findAll();
		verify(policyRepository, times(1)).findAll();
	}
	
	@Test(enabled = true, expectedExceptions = {DataAccessException.class})
	public void testFindAllHandleException() throws Exception {
		when(policyRepository.findAll()).thenThrow(exception);
		policyDAOImpl.findAll();
		verify(policyRepository, times(1)).findAll();
	}
	
	@Test(enabled = true)
	public void testFindAllPageable() throws Exception {
		when(policyRepository.findAll(pageable)).thenReturn(page);
		policyDAOImpl.findAll(pageable);
		verify(policyRepository, times(1)).findAll(pageable);
	}
	
	@Test(enabled = true, expectedExceptions = {DataAccessException.class})
	public void testFindAllPageableHandleException() throws Exception {
		when(policyRepository.findAll(pageable)).thenThrow(exception);
		policyDAOImpl.findAll(pageable);
		verify(policyRepository, times(1)).findAll(pageable);
	}
	
	@Test(enabled = true)
	public void testFindAllBySort() throws Exception {
		when(policyRepository.findAll(sort)).thenReturn(policyDOs);
		policyDAOImpl.findAll(sort);
		verify(policyRepository, times(1)).findAll(sort);
	}
	
	@Test(enabled = true, expectedExceptions = {DataAccessException.class})
	public void testFindAllBySortHandleException() throws Exception {
		when(policyRepository.findAll(sort)).thenThrow(exception);
		policyDAOImpl.findAll(sort);
		verify(policyRepository, times(1)).findAll(sort);
	}
	@Test(enabled = true)
	public void testSave() throws Exception {
		when(policyRepository.save(policyDO)).thenReturn(policyDO);
		policyDAOImpl.save(policyDO);
		verify(policyRepository, times(1)).save(policyDO);
	}
	
	@Test(enabled = true, expectedExceptions = {DataAccessException.class})
	public void testSaveHandleException() throws Exception {
		when(policyRepository.save(policyDO)).thenThrow(exception);
		policyDAOImpl.save(policyDO);
		verify(policyRepository, times(1)).save(policyDO);
	}
	
	@Test(enabled = true)
	public void testSaveEntities() throws Exception {
		when(policyRepository.save(policyDOs)).thenReturn(policyDOs);
		policyDAOImpl.save(policyDOs);
		verify(policyRepository, times(1)).save(policyDOs);
	}
	
	@Test(enabled = true, expectedExceptions = {DataAccessException.class})
	public void testSaveEntitiesHandleException() throws Exception {
		when(policyRepository.save(policyDOs)).thenThrow(exception);
		policyDAOImpl.save(policyDOs);
		verify(policyRepository, times(1)).save(policyDOs);
	}

	@Test(enabled = true)
	public void testFindOne() throws Exception {
		when(policyRepository.findOne(POLICY_CONFIGURATION_ID)).thenReturn(policyDO);
		policyDAOImpl.findOne(POLICY_CONFIGURATION_ID);
		verify(policyRepository, times(1)).findOne(POLICY_CONFIGURATION_ID);
	}
	
	@Test(enabled = true, expectedExceptions = {DataAccessException.class})
	public void testFindOneHandleException() throws Exception {
		when(policyRepository.findOne(POLICY_CONFIGURATION_ID)).thenThrow(exception);
		policyDAOImpl.findOne(POLICY_CONFIGURATION_ID);
		verify(policyRepository, times(1)).findOne(POLICY_CONFIGURATION_ID);
	}

	@Test(enabled = true)
	public void testDeleteById() throws Exception {
		Mockito.doNothing().when(policyRepository).delete(POLICY_CONFIGURATION_ID);
		policyDAOImpl.delete(POLICY_CONFIGURATION_ID);
		verify(policyRepository, times(1)).delete(POLICY_CONFIGURATION_ID);
	}
	
	@Test(enabled = true, expectedExceptions = {DataAccessException.class})
	public void testDeleteByIdHandleException() throws Exception {
		Mockito.doThrow(exception).when(policyRepository).delete(POLICY_CONFIGURATION_ID);
		policyDAOImpl.delete(POLICY_CONFIGURATION_ID);
		verify(policyRepository, times(1)).delete(POLICY_CONFIGURATION_ID);
	}

	@Test(enabled = true)
	public void testDeleteEntity() throws Exception {
		Mockito.doNothing().when(policyRepository).delete(policyDO);
		policyDAOImpl.delete(policyDO);
		verify(policyRepository, times(1)).delete(policyDO);
	}
	
	@Test(enabled = true, expectedExceptions = {DataAccessException.class})
	public void testDeleteEntityHandleException() throws Exception {
		Mockito.doThrow(exception).when(policyRepository).delete(policyDO);
		policyDAOImpl.delete(policyDO);
		verify(policyRepository, times(1)).delete(policyDO);
	}
	@Test(enabled = true)
	public void testDeleteEntities() throws Exception {
		Mockito.doNothing().when(policyRepository).delete(policyDOs);
		policyDAOImpl.delete(policyDOs);
		verify(policyRepository, times(1)).delete(policyDOs);
	}
	
	@Test(enabled = true, expectedExceptions = {DataAccessException.class})
	public void testDeleteEntitiesHandleException() throws Exception {
		Mockito.doThrow(exception).when(policyRepository).delete(policyDOs);
		policyDAOImpl.delete(policyDOs);
		verify(policyRepository, times(1)).delete(policyDOs);
	}
}
