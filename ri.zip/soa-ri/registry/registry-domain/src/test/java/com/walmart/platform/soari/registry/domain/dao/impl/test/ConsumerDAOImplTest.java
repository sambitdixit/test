package com.walmart.platform.soari.registry.domain.dao.impl.test;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.Page;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.walmart.platform.kernel.exception.layers.dao.DataAccessException;
import com.walmart.platform.soari.registry.domain.ConsumerDO;
import com.walmart.platform.soari.registry.domain.dao.impl.ConsumerDAOImpl;
import com.walmart.platform.soari.registry.domain.repository.ConsumerRepository;
import com.walmart.platform.soari.registry.server.common.exception.ExceptionHandler;

public class ConsumerDAOImplTest extends AbstractDAOTest {
	
	@Mock private ConsumerRepository consumerRepository;
	@Mock private ConsumerDO consumerDO;
	@Mock private List<ConsumerDO> consumerDOs;
	@Mock private Page<ConsumerDO> page;
	@Mock private DataAccessException dataAccessException;
	@Mock private ExceptionHandler exceptionHandler;
	
	@InjectMocks private ConsumerDAOImpl consumerDAOImpl = new ConsumerDAOImpl();
	
	@BeforeMethod(alwaysRun=true)  
	public void init() throws Exception {
		MockitoAnnotations.initMocks(this);
		Mockito.doThrow(dataAccessException).when(exceptionHandler).handleDataAccessException(Mockito.any(Exception.class));
	}
	
	@Test(enabled = true)
	public void testFindAll() throws Exception {
		when(consumerRepository.findAll()).thenReturn(consumerDOs);
		consumerDAOImpl.findAll();
		verify(consumerRepository, times(1)).findAll();
	}
	
	@Test(enabled = true, expectedExceptions = {DataAccessException.class})
	public void testFindAllHandleException() throws Exception {
		when(consumerRepository.findAll()).thenThrow(exception);
		consumerDAOImpl.findAll();
		verify(consumerRepository, times(1)).findAll();
	}
	
	@Test(enabled = true)
	public void testFindAllPageable() throws Exception {
		when(consumerRepository.findAll(pageable)).thenReturn(page);
		consumerDAOImpl.findAll(pageable);
		verify(consumerRepository, times(1)).findAll(pageable);
	}
	
	@Test(enabled = true, expectedExceptions = {DataAccessException.class})
	public void testFindAllPageableHandleException() throws Exception {
		when(consumerRepository.findAll(pageable)).thenThrow(exception);
		consumerDAOImpl.findAll(pageable);
		verify(consumerRepository, times(1)).findAll(pageable);
	}
	
	@Test(enabled = true)
	public void testFindAllBySort() throws Exception {
		when(consumerRepository.findAll(sort)).thenReturn(consumerDOs);
		consumerDAOImpl.findAll(sort);
		verify(consumerRepository, times(1)).findAll(sort);
	}
	
	@Test(enabled = true, expectedExceptions = {DataAccessException.class})
	public void testFindAllBySortHandleException() throws Exception {
		when(consumerRepository.findAll(sort)).thenThrow(exception);
		consumerDAOImpl.findAll(sort);
		verify(consumerRepository, times(1)).findAll(sort);
	}
	@Test(enabled = true)
	public void testSave() throws Exception {
		when(consumerRepository.save(consumerDO)).thenReturn(consumerDO);
		consumerDAOImpl.save(consumerDO);
		verify(consumerRepository, times(1)).save(consumerDO);
	}
	
	@Test(enabled = true, expectedExceptions = {DataAccessException.class})
	public void testSaveHandleException() throws Exception {
		when(consumerRepository.save(consumerDO)).thenThrow(exception);
		consumerDAOImpl.save(consumerDO);
		verify(consumerRepository, times(1)).save(consumerDO);
	}
	
	@Test(enabled = true)
	public void testSaveEntities() throws Exception {
		when(consumerRepository.save(consumerDOs)).thenReturn(consumerDOs);
		consumerDAOImpl.save(consumerDOs);
		verify(consumerRepository, times(1)).save(consumerDOs);
	}
	
	@Test(enabled = true, expectedExceptions = {DataAccessException.class})
	public void testSaveEntitiesHandleException() throws Exception {
		when(consumerRepository.save(consumerDOs)).thenThrow(exception);
		consumerDAOImpl.save(consumerDOs);
		verify(consumerRepository, times(1)).save(consumerDOs);
	}

	@Test(enabled = true)
	public void testFindOne() throws Exception {
		when(consumerRepository.findOne(CONSUMER_ID)).thenReturn(consumerDO);
		consumerDAOImpl.findOne(CONSUMER_ID);
		verify(consumerRepository, times(1)).findOne(CONSUMER_ID);
	}
	
	@Test(enabled = true, expectedExceptions = {DataAccessException.class})
	public void testFindOneHandleException() throws Exception {
		when(consumerRepository.findOne(CONSUMER_ID)).thenThrow(exception);
		consumerDAOImpl.findOne(CONSUMER_ID);
		verify(consumerRepository, times(1)).findOne(CONSUMER_ID);
	}

	@Test(enabled = true)
	public void testDeleteById() throws Exception {
		Mockito.doNothing().when(consumerRepository).delete(CONSUMER_ID);
		consumerDAOImpl.delete(CONSUMER_ID);
		verify(consumerRepository, times(1)).delete(CONSUMER_ID);
	}
	
	@Test(enabled = true, expectedExceptions = {DataAccessException.class})
	public void testDeleteByIdHandleException() throws Exception {
		Mockito.doThrow(exception).when(consumerRepository).delete(CONSUMER_ID);
		consumerDAOImpl.delete(CONSUMER_ID);
		verify(consumerRepository, times(1)).delete(CONSUMER_ID);
	}

	@Test(enabled = true)
	public void testDeleteEntity() throws Exception {
		Mockito.doNothing().when(consumerRepository).delete(consumerDO);
		consumerDAOImpl.delete(consumerDO);
		verify(consumerRepository, times(1)).delete(consumerDO);
	}
	
	@Test(enabled = true, expectedExceptions = {DataAccessException.class})
	public void testDeleteEntityHandleException() throws Exception {
		Mockito.doThrow(exception).when(consumerRepository).delete(consumerDO);
		consumerDAOImpl.delete(consumerDO);
		verify(consumerRepository, times(1)).delete(consumerDO);
	}
	@Test(enabled = true)
	public void testDeleteEntities() throws Exception {
		Mockito.doNothing().when(consumerRepository).delete(consumerDOs);
		consumerDAOImpl.delete(consumerDOs);
		verify(consumerRepository, times(1)).delete(consumerDOs);
	}
	
	@Test(enabled = true, expectedExceptions = {DataAccessException.class})
	public void testDeleteEntitiesHandleException() throws Exception {
		Mockito.doThrow(exception).when(consumerRepository).delete(consumerDOs);
		consumerDAOImpl.delete(consumerDOs);
		verify(consumerRepository, times(1)).delete(consumerDOs);
	}
}
