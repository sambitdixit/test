package com.walmart.platform.soari.registry.domain.dao.impl.integration;

import java.util.ArrayList;
import java.util.List;

import junit.framework.Assert;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;
import org.testng.annotations.Test;

import com.walmart.platform.kernel.exception.layers.dao.DataAccessException;
import com.walmart.platform.soari.registry.common.enums.RegistryPolicyCodeType;
import com.walmart.platform.soari.registry.common.enums.StatusType;
import com.walmart.platform.soari.registry.domain.ConsumerDO;
import com.walmart.platform.soari.registry.domain.RegistryPolicyCode;
import com.walmart.platform.soari.registry.domain.ServiceDO;
import com.walmart.platform.soari.registry.domain.ServiceVersionDO;
import com.walmart.platform.soari.registry.domain.SubscriptionDO;
import com.walmart.platform.soari.registry.domain.dao.impl.RegistryPolicyCodeDAOImpl;

@TransactionConfiguration(transactionManager = "transactionManager", defaultRollback = true)
public class ConsumerDAOImplIntegrationTest extends AbstractDAOIntegrationTest {

	private static Logger LOG = LoggerFactory
			.getLogger(ConsumerDAOImplIntegrationTest.class);

	@Test(enabled = true)
	@Transactional
	public void testSave() {
		try {
			ConsumerDO expected = newConsumer();
			String consumerId = expected.getConsumerId();
			expected = consumerDAO.save(expected);
			ConsumerDO actual = consumerDAO.findOne(expected.getId());
			Assert.assertEquals(expected, actual);
			Assert.assertEquals(consumerId, actual.getConsumerId());
		} catch (DataAccessException ex) {
			LOG.error("error while testSave : " + ex.getMessage());
			Assert.fail("error while testSave : " + ex.getMessage());
		}
	}

	@Test(enabled = true)
	@Transactional
	public void testSaveConsumerWithSubscriptions() {
		try {
			
			ServiceDO expected1 = newService();
			serviceDAO.save(expected1);
			ServiceDO actual1 = serviceDAO.findOne(expected1.getId());
			Assert.assertEquals(expected1, actual1);
		
			ServiceVersionDO serviceVersion11 = newServiceVersion(actual1);
			serviceVersion11.setSerVersion("1.0.1");
			serviceVersion11 = serviceVersionDAO.save(serviceVersion11);
			
			ServiceVersionDO serviceVersion12 = newServiceVersion(actual1);
			serviceVersion12.setSerVersion("1.0.2");
			serviceVersion12 = serviceVersionDAO.save(serviceVersion12);
	
			ServiceDO expected2 = newService();
			serviceDAO.save(expected2);
			ServiceDO actual2 = serviceDAO.findOne(expected2.getId());
			Assert.assertEquals(expected2, actual2);

			ServiceVersionDO serviceVersion21 = newServiceVersion(actual2);
			serviceVersion21.setSerVersion("2.0.1");
			serviceVersion21 = serviceVersionDAO.save(serviceVersion21);
	
			ServiceVersionDO serviceVersion22 = newServiceVersion(actual2);
			serviceVersion22.setSerVersion("2.0.2");
			serviceVersion22 = serviceVersionDAO.save(serviceVersion22);
	
			ConsumerDO expected = newConsumer();
			String consumerId = expected.getConsumerId();
			expected = consumerDAO.save(expected);
			ConsumerDO actual = consumerDAO.findOne(expected.getId());
			Assert.assertEquals(expected, actual);
			Assert.assertEquals(consumerId, actual.getConsumerId());
			
			SubscriptionDO subscription1 = newSubscription(actual, serviceVersion11);
			SubscriptionDO subscription2 = newSubscription(actual, serviceVersion12);
			SubscriptionDO subscription3 = newSubscription(actual, serviceVersion21);
			SubscriptionDO subscription4 = newSubscription(actual, serviceVersion22);
			actual.addSubscription(subscription1);
			actual.addSubscription(subscription2);
			actual.addSubscription(subscription3);
			actual.addSubscription(subscription4);
			
			actual = consumerDAO.save(actual);
			Assert.assertNotNull(actual);
				
			actual = consumerDAO.findOne(actual.getId());
			Assert.assertNotNull(actual);
			Assert.assertNotNull(actual.getSubscriptions());
			Assert.assertTrue(actual.getSubscriptions().size() == 4);
			SubscriptionDO sub = actual.getSubscriptions().iterator().next();
			Assert.assertEquals(actual, sub.getConsumer());
			
			sub = subscriptionDAO.findOne(sub.getId());
			Assert.assertNotNull(sub);
			actual.removeSubscription(sub);
			actual = consumerDAO.save(actual);
		
			actual = consumerDAO.findOne(actual.getId());
			Assert.assertNotNull(actual);
			Assert.assertNotNull(actual.getSubscriptions());
			Assert.assertEquals(3, actual.getSubscriptions().size());
			Assert.assertEquals(actual, sub.getConsumer());
		
		} catch (DataAccessException ex) {
			LOG.error("error while testSave : " + ex.getMessage());
			Assert.fail("error while testSave : " + ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	@Transactional
	public void testSaveConsumerWithAddSubscriptions() {
		try {
			
			ServiceDO expected1 = newService();
			serviceDAO.save(expected1);
			ServiceDO actual1 = serviceDAO.findOne(expected1.getId());
			Assert.assertEquals(expected1, actual1);
		
			ServiceVersionDO serviceVersion11 = newServiceVersion(actual1);
			serviceVersion11.setSerVersion("1.0.1");
			serviceVersion11 = serviceVersionDAO.save(serviceVersion11);
			
			ServiceVersionDO serviceVersion12 = newServiceVersion(actual1);
			serviceVersion12.setSerVersion("1.0.2");
			serviceVersion12 = serviceVersionDAO.save(serviceVersion12);
	
			ConsumerDO expected = newConsumer();
			String consumerId = expected.getConsumerId();
			expected = consumerDAO.save(expected);
			ConsumerDO actual = consumerDAO.findOne(expected.getId());
			Assert.assertEquals(expected, actual);
			Assert.assertEquals(consumerId, actual.getConsumerId());
			
			SubscriptionDO subscription1 = newSubscription(actual, serviceVersion11);
			SubscriptionDO subscription2 = newSubscription(actual, serviceVersion12);
		
			actual.addSubscription(subscription1);
			actual.addSubscription(subscription2);
			
			actual = consumerDAO.save(actual);
			Assert.assertNotNull(actual);
				
			actual = consumerDAO.findOne(actual.getId());
			Assert.assertNotNull(actual);
			Assert.assertNotNull(actual.getSubscriptions());
			Assert.assertTrue(actual.getSubscriptions().size() == 2);
			Assert.assertEquals(actual, actual.getSubscriptions().iterator().next().getConsumer());
			
			ServiceDO expected2 = newService();
			serviceDAO.save(expected2);
			ServiceDO actual2 = serviceDAO.findOne(expected2.getId());
			Assert.assertEquals(expected2, actual2);

			ServiceVersionDO serviceVersion21 = newServiceVersion(actual2);
			serviceVersion21.setSerVersion("2.0.1");
			serviceVersion21 = serviceVersionDAO.save(serviceVersion21);
	
			ServiceVersionDO serviceVersion22 = newServiceVersion(actual2);
			serviceVersion22.setSerVersion("2.0.2");
			serviceVersion22 = serviceVersionDAO.save(serviceVersion22);
	
			SubscriptionDO subscription3 = newSubscription(actual, serviceVersion21);
			SubscriptionDO subscription4 = newSubscription(actual, serviceVersion22);
			actual.addSubscription(subscription3);
			actual.addSubscription(subscription4);
			
			actual = consumerDAO.save(actual);
			Assert.assertNotNull(actual);
				
			actual = consumerDAO.findOne(actual.getId());
			Assert.assertNotNull(actual);
			Assert.assertNotNull(actual.getSubscriptions());
			Assert.assertTrue(actual.getSubscriptions().size() == 4);
			Assert.assertEquals(actual, actual.getSubscriptions().iterator().next().getConsumer());
			
		} catch (DataAccessException ex) {
			LOG.error("error while testSave : " + ex.getMessage());
			Assert.fail("error while testSave : " + ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	@Transactional
	public void testSaveConsumerWithDeleteSubscriptions() {
		try {
			
			ServiceDO expected1 = newService();
			serviceDAO.save(expected1);
			ServiceDO actual1 = serviceDAO.findOne(expected1.getId());
			Assert.assertEquals(expected1, actual1);
		
			ServiceVersionDO serviceVersion11 = newServiceVersion(actual1);
			serviceVersion11.setSerVersion("1.0.1");
			serviceVersion11 = serviceVersionDAO.save(serviceVersion11);
			
			ServiceVersionDO serviceVersion12 = newServiceVersion(actual1);
			serviceVersion12.setSerVersion("1.0.2");
			serviceVersion12 = serviceVersionDAO.save(serviceVersion12);
	
			ServiceDO expected2 = newService();
			serviceDAO.save(expected2);
			ServiceDO actual2 = serviceDAO.findOne(expected2.getId());
			Assert.assertEquals(expected2, actual2);

			ServiceVersionDO serviceVersion21 = newServiceVersion(actual2);
			serviceVersion21.setSerVersion("2.0.1");
			serviceVersion21 = serviceVersionDAO.save(serviceVersion21);
	
			ServiceVersionDO serviceVersion22 = newServiceVersion(actual2);
			serviceVersion22.setSerVersion("2.0.2");
			serviceVersion22 = serviceVersionDAO.save(serviceVersion22);
	
			ConsumerDO expected = newConsumer();
			String consumerId = expected.getConsumerId();
			expected = consumerDAO.save(expected);
			ConsumerDO actual = consumerDAO.findOne(expected.getId());
			Assert.assertEquals(expected, actual);
			Assert.assertEquals(consumerId, actual.getConsumerId());
			
			SubscriptionDO subscription1 = newSubscription(actual, serviceVersion11);
			SubscriptionDO subscription2 = newSubscription(actual, serviceVersion12);
			SubscriptionDO subscription3 = newSubscription(actual, serviceVersion21);
			SubscriptionDO subscription4 = newSubscription(actual, serviceVersion22);
			actual.addSubscription(subscription1);
			actual.addSubscription(subscription2);
			actual.addSubscription(subscription3);
			actual.addSubscription(subscription4);
			
			actual = consumerDAO.save(actual);
			Assert.assertNotNull(actual);
				
			actual = consumerDAO.findOne(actual.getId());
			Assert.assertNotNull(actual);
			Assert.assertNotNull(actual.getSubscriptions());

			List<SubscriptionDO> subscriptions = new ArrayList<SubscriptionDO>(0);
			subscriptions.addAll(actual.getSubscriptions());

			Assert.assertTrue(actual.getSubscriptions().size() == 4);
			Assert.assertEquals(actual,subscriptions.get(0).getConsumer());
			
			actual.removeSubscription(subscriptions.get(0));
			actual.removeSubscription(subscriptions.get(1));
			
			actual = consumerDAO.save(actual);
			Assert.assertNotNull(actual);
				
			actual = consumerDAO.findOne(actual.getId());
			Assert.assertNotNull(actual);
			Assert.assertNotNull(actual.getSubscriptions());
			Assert.assertTrue(actual.getSubscriptions().size() == 2);

		} catch (DataAccessException ex) {
			LOG.error("error while testSave : " + ex.getMessage());
			Assert.fail("error while testSave : " + ex.getMessage());
		}
	}

	@Test(enabled = true)
	@Transactional
	public void testFindByStatus() {
		try {
			ConsumerDO consumer1 = newConsumer();
			consumer1 = consumerDAO.save(consumer1);
			ConsumerDO consumer2 = newConsumer();
			consumer2 = consumerDAO.save(consumer2);
			ConsumerDO consumer3 = newConsumer();
			RegistryPolicyCode status = RegistryPolicyCodeDAOImpl.getCode(RegistryPolicyCodeType.STATUS, StatusType.DELETED.toString());
			consumer3.setStatus(status.getCode());
			consumer3 = consumerDAO.save(consumer3);
			List<String> statusTypes = new ArrayList<String>(0);
			statusTypes.add(StatusType.ACTIVE.toString());
			List<ConsumerDO> result = consumerDAO.findByStatus(statusTypes);
			Assert.assertTrue(contains(result, consumer1.getId()));
			Assert.assertTrue(contains(result, consumer2.getId()));
			Assert.assertFalse(contains(result, consumer3.getId()));
		} catch (DataAccessException ex) {
			String error = "error while testFindByStatus() : "
					+ ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}
	}
	
	@Test(enabled = true)
	@Transactional
	public void testFindAllByPage() {
		try {
			ConsumerDO consumer1 = newConsumer();
			consumer1 = consumerDAO.save(consumer1);
			ConsumerDO consumer2 = newConsumer();
			consumer2 = consumerDAO.save(consumer2);
			ConsumerDO consumer3 = newConsumer();
			consumer3 = consumerDAO.save(consumer3);

			Pageable pageable = new PageRequest(0, 2);
			List<ConsumerDO> result = consumerDAO.findAll(pageable).getContent();
			Assert.assertEquals(result.size(), 2);
		} catch (DataAccessException ex) {
			String error = "error while testFindAllByPage() : "
					+ ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}
	}

	@Test(enabled = true)
	@Transactional
	public void testFindOne() {
		try {
			ConsumerDO expected = newConsumer();
			expected = consumerDAO.save(expected);
			Assert.assertEquals(expected, consumerDAO.findOne(expected.getId()));
		} catch (DataAccessException ex) {
			String error = "error while testFindOne() : " + ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}
	}

	@Test(enabled = true)
	@Transactional
	public void testDeleteById() {
		try {
			ConsumerDO expected = newConsumer();
			expected = consumerDAO.save(expected);
			consumerDAO.delete(expected.getId());
			Assert.assertNull(consumerDAO.findOne(expected.getId()));
		} catch (DataAccessException ex) {
			String error = "error while testDeleteById() : " + ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}
	}

	@Test(enabled = true)
	@Transactional
	public void testDeleteEntity() {
		try {
			ConsumerDO expected = newConsumer();
			expected = consumerDAO.save(expected);
			consumerDAO.delete(expected);
			Assert.assertNull(consumerDAO.findOne(expected.getId()));
		} catch (DataAccessException ex) {
			String error = "error while testDeleteEntity() : "
					+ ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}
	}

	@Test(enabled = true)
	@Transactional
	public void testDeleteEntities() {
		try {
			List<ConsumerDO> consumers = new ArrayList<ConsumerDO>();
			ConsumerDO consumer1 = newConsumer();
			consumer1 = consumerDAO.save(consumer1);
			consumers.add(consumer1);
			ConsumerDO consumer2 = newConsumer();
			consumer2 = consumerDAO.save(consumer2);
			consumers.add(consumer2);
			consumerDAO.delete(consumers);
			Assert.assertNull(consumerDAO.findOne(consumer1.getId()));
			Assert.assertNull(consumerDAO.findOne(consumer2.getId()));
		} catch (DataAccessException ex) {
			String error = "error while testDeleteEntities() : "
					+ ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}
	}

	@Test(enabled = true)
	@Transactional
	public void testDeleteAll() {
		Assert.assertTrue(true);
	}

	@Test(enabled = true)
	@Transactional
	public void testFindAll() {
		try {
			ConsumerDO consumer1 = newConsumer();
			consumer1 = consumerDAO.save(consumer1);
			ConsumerDO consumer2 = newConsumer();
			consumer2 = consumerDAO.save(consumer2);
			List<ConsumerDO> result = consumerDAO.findAll();
			Assert.assertTrue(result.size() >= 2);
		} catch (DataAccessException ex) {
			String error = "error while testFindAll() : " + ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}
	}
	
	@Test(enabled = true)
	@Transactional
	public void testFindConsumersByMatchingStatus() {
		try {
			ConsumerDO consumer1 = newConsumer();
			consumer1 = consumerDAO.save(consumer1);
			ConsumerDO consumer2 = newConsumer();
			consumer2 = consumerDAO.save(consumer2);
			ConsumerDO consumer3 = newConsumer();
			RegistryPolicyCode status = RegistryPolicyCodeDAOImpl.getCode(RegistryPolicyCodeType.STATUS, StatusType.DELETED.toString());
			consumer3.setStatus(status.getCode());
			consumer3 = consumerDAO.save(consumer3);
			List<String> statusTypes = new ArrayList<String>(0);
			statusTypes.add(StatusType.ACTIVE.toString());
			List<ConsumerDO> result = consumerDAO.findByStatus(statusTypes);
			Assert.assertTrue(contains(result, consumer1.getId()));
			Assert.assertTrue(contains(result, consumer2.getId()));
			Assert.assertFalse(contains(result, consumer3.getId()));
		} catch (DataAccessException ex) {
			String error = "error while testFindConsumersByMatchingStatus() : " + ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}
	}

	@Test(enabled = true)
	@Transactional
	public void findAllBySort() {
		// consumerDAO.findAll(sort);
		Assert.assertTrue(true);
	}

	@Test(enabled = true)
	@Transactional
	public void saveEntities() {
		try {
			List<ConsumerDO> consumers = new ArrayList<ConsumerDO>();
			ConsumerDO consumer1 = newConsumer();
			consumers.add(consumer1);
			ConsumerDO consumer2 = newConsumer();
			consumers.add(consumer2);
			consumerDAO.save(consumers);
			Assert.assertNotNull(consumerDAO.findOne(consumer1.getId()));
			Assert.assertNotNull(consumerDAO.findOne(consumer2.getId()));
		} catch (DataAccessException ex) {
			String error = "error while saveEntities() : " + ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}
	}
	

	@Test
	public void testFindSubscriptionCountPerEnvironment() throws Exception {
		ServiceVersionDO expected1 = newServiceVersion("qa");
		expected1 = serviceVersionDAO.save(expected1);
		ServiceVersionDO expected2 = newServiceVersion("qa");
		expected2 = serviceVersionDAO.save(expected2);
		ServiceVersionDO expected3 = newServiceVersion("dev");
		expected3 = serviceVersionDAO.save(expected3);
		ConsumerDO consumer = newConsumer();
		consumer = consumerDAO.save(consumer);
		SubscriptionDO sub1 = newSubscription(consumer, expected1);
		SubscriptionDO sub2 = newSubscription(consumer, expected2);
		SubscriptionDO sub3 = newSubscription(consumer, expected3);
		subscriptionDAO.save(sub1);
		subscriptionDAO.save(sub2);
		subscriptionDAO.save(sub3);
		String response = subscriptionDAO.findSubscriptionCountPerEnvironment();
		System.out.println("response = "+response);
		Assert.assertNotNull(response);
		Assert.assertFalse(response.isEmpty());
	}
	
	@Test
	public void testFindConsumerSubscriptionCountPerEnvironment() throws Exception {
		ServiceVersionDO expected1 = newServiceVersion("qa");
		expected1 = serviceVersionDAO.save(expected1);
		ServiceVersionDO expected2 = newServiceVersion("qa");
		expected2 = serviceVersionDAO.save(expected2);
		ServiceVersionDO expected3 = newServiceVersion("dev");
		expected3 = serviceVersionDAO.save(expected3);
		ConsumerDO consumer = newConsumer();
		consumer = consumerDAO.save(consumer);
		SubscriptionDO sub1 = newSubscription(consumer, expected1);
		SubscriptionDO sub2 = newSubscription(consumer, expected2);
		SubscriptionDO sub3 = newSubscription(consumer, expected3);
		subscriptionDAO.save(sub1);
		subscriptionDAO.save(sub2);
		subscriptionDAO.save(sub3);
		
		ConsumerDO consumer2 = newConsumer();
		consumer2 = consumerDAO.save(consumer2);
		SubscriptionDO sub21 = newSubscription(consumer2, expected1);
		SubscriptionDO sub22 = newSubscription(consumer2, expected2);
		subscriptionDAO.save(sub21);
		subscriptionDAO.save(sub22);
		String response = subscriptionDAO.findConsumerSubscriptionCountPerEnvironment();
		System.out.println("response = "+response);
		Assert.assertNotNull(response);
		Assert.assertFalse(response.isEmpty());
	}
	
	@Test
	public void testFindConsumerCountPerEnvironment() throws Exception {
		ServiceVersionDO expected1 = newServiceVersion("qa");
		expected1 = serviceVersionDAO.save(expected1);
		ServiceVersionDO expected2 = newServiceVersion("qa");
		expected2 = serviceVersionDAO.save(expected2);
		ServiceVersionDO expected3 = newServiceVersion("dev");
		expected3 = serviceVersionDAO.save(expected3);
		ServiceVersionDO expected4 = newServiceVersion("qa");
		expected4 = serviceVersionDAO.save(expected4);
		ConsumerDO consumer = newConsumer();
		consumer = consumerDAO.save(consumer);
		SubscriptionDO sub1 = newSubscription(consumer, expected1);
		SubscriptionDO sub2 = newSubscription(consumer, expected2);
		SubscriptionDO sub3 = newSubscription(consumer, expected3);
		SubscriptionDO sub4 = newSubscription(consumer, expected4);
		
		subscriptionDAO.save(sub1);
		subscriptionDAO.save(sub2);
		subscriptionDAO.save(sub3);
		subscriptionDAO.save(sub4);
		
		ConsumerDO consumer2 = newConsumer();
		consumer2 = consumerDAO.save(consumer2);
		SubscriptionDO sub21 = newSubscription(consumer2, expected1);
		SubscriptionDO sub22 = newSubscription(consumer2, expected2);
		subscriptionDAO.save(sub21);
		subscriptionDAO.save(sub22);
		
		ConsumerDO consumer3 = newConsumer();
		consumer3 = consumerDAO.save(consumer3);
		ServiceVersionDO expected33 = newServiceVersion("qa");
		expected33 = serviceVersionDAO.save(expected33);
		SubscriptionDO sub33 = newSubscription(consumer3, expected33);
		subscriptionDAO.save(sub33);
		
		String response = subscriptionDAO.findConsumerCountPerEnvironment();
		System.out.println("response = "+response);
		Assert.assertNotNull(response);
		Assert.assertFalse(response.isEmpty());
	}
	
	@Test
	public void testFindSubscriptionCountPerService() throws Exception {
		
		ConsumerDO consumer1 = newConsumer();
		consumer1 = consumerDAO.save(consumer1);
		
		ConsumerDO consumer2 = newConsumer();
		consumer2 = consumerDAO.save(consumer2);
		
		ConsumerDO consumer3 = newConsumer();
		consumer3 = consumerDAO.save(consumer3);
		
		ServiceDO service1 = newService();
		service1.setName("Service1");
		service1.setApplicationId("service1");
		service1 = serviceDAO.save(service1);
		
		ServiceVersionDO serviceVersion11 = newServiceVersion(service1);
		serviceVersion11 = serviceVersionDAO.save(serviceVersion11);
		
		ServiceVersionDO serviceVersion12 = newServiceVersion(service1);
		serviceVersion12 = serviceVersionDAO.save(serviceVersion12);
		
		SubscriptionDO sub1 = newSubscription(consumer1, serviceVersion11);
		SubscriptionDO sub2 = newSubscription(consumer1, serviceVersion12);
		SubscriptionDO sub3 = newSubscription(consumer2, serviceVersion12);
		SubscriptionDO sub4 = newSubscription(consumer3, serviceVersion12);
		subscriptionDAO.save(sub1);
		subscriptionDAO.save(sub2);
		subscriptionDAO.save(sub3);
		subscriptionDAO.save(sub4);
		
		ServiceDO service21 = newService();
		service21.setName("Service2");
		service21.setApplicationId("Service2");
		service21 = serviceDAO.save(service21);
		
		ServiceVersionDO serviceVersion21 = newServiceVersion(service21);
		serviceVersion21 = serviceVersionDAO.save(serviceVersion21);
		
		SubscriptionDO sub5 = newSubscription(consumer1, serviceVersion21);
		SubscriptionDO sub6 = newSubscription(consumer2, serviceVersion21);
		subscriptionDAO.save(sub5);
		subscriptionDAO.save(sub6);
		
		ServiceDO service22 = newService();
		service22.setName(service21.getName());
		service22.setApplicationId(service21.getApplicationId());
		service22.setEnvironment("qa");
		service22 = serviceDAO.save(service22);
		
		ServiceVersionDO serviceVersion221 = newServiceVersion(service22);
		serviceVersion221 = serviceVersionDAO.save(serviceVersion221);
		
		ServiceVersionDO serviceVersion222 = newServiceVersion(service22);
		serviceVersion222 = serviceVersionDAO.save(serviceVersion222);
		
		SubscriptionDO sub221 = newSubscription(consumer1, serviceVersion221);
		SubscriptionDO sub222 = newSubscription(consumer2, serviceVersion222);
		subscriptionDAO.save(sub221);
		subscriptionDAO.save(sub222);
		
		String response = subscriptionDAO.findSubscriptionCountPerService();
		System.out.println("response = "+response);
		Assert.assertNotNull(response);
		Assert.assertFalse(response.isEmpty());
	}
	
	@Test
	public void testFindServiceCountPerConsumer() throws Exception {
		
		ConsumerDO consumer1 = newConsumer();
		consumer1 = consumerDAO.save(consumer1);
		
		ConsumerDO consumer2 = newConsumer();
		consumer2 = consumerDAO.save(consumer2);
		
		ConsumerDO consumer3 = newConsumer();
		consumer3 = consumerDAO.save(consumer3);
		
		ServiceDO service1 = newService();
		service1.setName("Service1");
		service1 = serviceDAO.save(service1);
		
		ServiceVersionDO serviceVersion11 = newServiceVersion(service1);
		serviceVersion11 = serviceVersionDAO.save(serviceVersion11);
		
		ServiceVersionDO serviceVersion12 = newServiceVersion(service1);
		serviceVersion12 = serviceVersionDAO.save(serviceVersion12);
		
		SubscriptionDO sub1 = newSubscription(consumer1, serviceVersion11);
		SubscriptionDO sub2 = newSubscription(consumer1, serviceVersion12);
		SubscriptionDO sub3 = newSubscription(consumer2, serviceVersion12);
		SubscriptionDO sub4 = newSubscription(consumer3, serviceVersion12);
		subscriptionDAO.save(sub1);
		subscriptionDAO.save(sub2);
		subscriptionDAO.save(sub3);
		subscriptionDAO.save(sub4);
		
		ServiceDO service2 = newService();
		service2.setName("Service2");
		service2 = serviceDAO.save(service2);
		
		ServiceVersionDO serviceVersion21 = newServiceVersion(service2);
		serviceVersion21 = serviceVersionDAO.save(serviceVersion21);
		
		SubscriptionDO sub5 = newSubscription(consumer1, serviceVersion21);
		SubscriptionDO sub6 = newSubscription(consumer2, serviceVersion21);
		subscriptionDAO.save(sub5);
		subscriptionDAO.save(sub6);
		
		ServiceDO service3 = newService();
		service3.setName("Service3");
		service3.setEnvironment("qa");
		service3 = serviceDAO.save(service3);
		
		ServiceVersionDO serviceVersion31 = newServiceVersion(service3);
		serviceVersion31 = serviceVersionDAO.save(serviceVersion31);
		
		ServiceVersionDO serviceVersion32 = newServiceVersion(service3);
		serviceVersion32 = serviceVersionDAO.save(serviceVersion32);
		
		SubscriptionDO sub7 = newSubscription(consumer1, serviceVersion31);
		SubscriptionDO sub8 = newSubscription(consumer1, serviceVersion32);
		subscriptionDAO.save(sub7);
		subscriptionDAO.save(sub8);
		
		ServiceDO service4 = newService();
		service4.setName("Service4");
		service4.setEnvironment("pqa");
		service4 = serviceDAO.save(service4);
		
		ServiceVersionDO serviceVersion41 = newServiceVersion(service4);
		serviceVersion41 = serviceVersionDAO.save(serviceVersion41);
		
		ServiceVersionDO serviceVersion42 = newServiceVersion(service4);
		serviceVersion42 = serviceVersionDAO.save(serviceVersion42);
		
		SubscriptionDO sub9 = newSubscription(consumer1, serviceVersion41);
		SubscriptionDO sub10 = newSubscription(consumer1, serviceVersion42);
		subscriptionDAO.save(sub9);
		subscriptionDAO.save(sub10);
		
		String response = subscriptionDAO.findServiceCountPerConsumer();
		System.out.println("response = "+response);
		Assert.assertNotNull(response);
		Assert.assertFalse(response.isEmpty());
	}



	private boolean contains(List<ConsumerDO> consumers, String id) {
		for(ConsumerDO consumerDO : consumers) {
			if(consumerDO.getId().equals(id)) {
				return true;
			}
		}
		return false;
	}

}
