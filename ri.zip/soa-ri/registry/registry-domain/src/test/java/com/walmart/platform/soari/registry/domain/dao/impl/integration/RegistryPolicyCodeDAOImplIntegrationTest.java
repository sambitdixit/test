package com.walmart.platform.soari.registry.domain.dao.impl.integration;

import java.util.List;

import junit.framework.Assert;

import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;
import org.testng.annotations.Test;

import com.walmart.platform.soari.registry.common.enums.RegistryPolicyCodeType;
import com.walmart.platform.soari.registry.common.enums.ServiceCategoryType;
import com.walmart.platform.soari.registry.common.enums.StatusType;
import com.walmart.platform.soari.registry.domain.RegistryPolicyCode;
import com.walmart.platform.soari.registry.domain.dao.impl.RegistryPolicyCodeDAOImpl;

@TransactionConfiguration(transactionManager = "transactionManager", defaultRollback = true)
public class RegistryPolicyCodeDAOImplIntegrationTest extends
		AbstractDAOIntegrationTest {
	
	@Test(enabled = true)
	public void test() throws Exception {
		RegistryPolicyCode code = RegistryPolicyCodeDAOImpl.getCode(RegistryPolicyCodeType.STATUS, StatusType.ACTIVE.toString());
		Assert.assertNotNull(code);
		code = RegistryPolicyCodeDAOImpl.getCode(RegistryPolicyCodeType.STATUS, StatusType.ACTIVE.toString());
		Assert.assertNotNull(code);
		code = RegistryPolicyCodeDAOImpl.getCode(RegistryPolicyCodeType.SERVICE_CATEGORY, ServiceCategoryType.BIZ.toString());
		Assert.assertNotNull(code);
		RegistryPolicyCode cat = RegistryPolicyCodeDAOImpl.getCode(RegistryPolicyCodeType.SERVICE_CATEGORY, ServiceCategoryType.BIZ.toString());
		Assert.assertNotNull(cat);
	}

	@Test(enabled=false)
	@Transactional
	public void testAutoConnect() throws Exception{
		System.out.println("Executing testAutoConnect");
		try {
			for(int i=1; i<=200;i++) {
				List<RegistryPolicyCode> codes = RegistryPolicyCodeDAOImpl.getCodesByType(RegistryPolicyCodeType.STATUS);
				System.out.println("codes = "+codes.size());
				Thread.sleep(2000);
			}
		}catch(Exception ex) {
		}
	}

}
