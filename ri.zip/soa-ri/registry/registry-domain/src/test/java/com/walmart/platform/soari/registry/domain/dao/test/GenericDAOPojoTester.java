package com.walmart.platform.soari.registry.domain.dao.test;


import org.testng.annotations.Test;

import com.openpojo.reflection.PojoClass;
import com.openpojo.reflection.PojoClassFilter;
import com.openpojo.reflection.filters.FilterEnum;


/**
 * The Class GenericPojoTester.
 */
 
public class GenericDAOPojoTester {
 
    // The package to test
    /** The Constant POJO_PACKAGE. */
    private static final String POJO_PACKAGE = "com.walmart.platform.soari.registry.domain";
 
    /** The pojo class filters. */
    private final PojoClassFilter[] pojoClassFilters = {new PojoClassFilter(){
		@Override
		public boolean include(PojoClass pojoClass) {
			return pojoClass.isAbstract();
		}}};
 
    /**
     * Test pojo structure and behavior.
     */
    @Test
    public void testPojoStructureAndBehavior() {
        final DAOPojoTestUtil pojoTestUtil = new DAOPojoTestUtil();
        pojoTestUtil.testPojoStructureAndBehavior(POJO_PACKAGE, pojoClassFilters);
    }
}

