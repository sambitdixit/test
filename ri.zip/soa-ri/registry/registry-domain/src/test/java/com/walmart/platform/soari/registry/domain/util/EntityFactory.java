package com.walmart.platform.soari.registry.domain.util;

import java.sql.Timestamp;
import java.util.Date;
import java.util.Set;

import com.walmart.platform.soari.registry.domain.ConsumerDO;
import com.walmart.platform.soari.registry.domain.DefaultPolicyDO;
import com.walmart.platform.soari.registry.domain.DefaultQoSDO;
import com.walmart.platform.soari.registry.domain.PolicyDO;
import com.walmart.platform.soari.registry.domain.QoSDO;
import com.walmart.platform.soari.registry.domain.ServiceDO;
import com.walmart.platform.soari.registry.domain.ServiceVersionDO;
import com.walmart.platform.soari.registry.domain.SubscriptionDO;
import com.walmart.platform.soari.registry.domain.UrlDO;
import com.walmart.platform.soari.registry.domain.dao.api.DefaultPolicyDAO;

public class EntityFactory {

	public static ServiceVersionDO newServiceVersion(
			Timestamp activationStartDate, Timestamp activationEndDate,
			String availabilityTierType, String environment, String esbReference,
			Timestamp publicationDate, ServiceDO service,
			String status, String serVersion, Set<UrlDO> urls) {
		ServiceVersionDO serviceVersion = new ServiceVersionDO();
		serviceVersion.setActivationStartDate(activationStartDate);
		serviceVersion.setActivationEndDate(activationEndDate);
		serviceVersion.setAvailabilityTier(availabilityTierType);
		serviceVersion.setEsbReference(esbReference);
		serviceVersion.setUrls(urls);
		
		serviceVersion.setEnvironment(environment);
		serviceVersion.setPublicationDate(publicationDate);
		serviceVersion.setService(service);
		serviceVersion.setStatus(status);
		serviceVersion.setSerVersion(serVersion);
		return serviceVersion;
	}

	public static ServiceDO newService(String applicationId, String category,
			String createdBy, Date createdTime, String description,
			String owner, String name,
			Set<ServiceVersionDO> serviceVersions, String domain, String usage, String status, String environment) {
		ServiceDO service = new ServiceDO();
		service.setCategory(category);
		service.setApplicationId(applicationId);
		service.setDescription(description);
		service.setOwner(owner);
		service.setName(name);
		service.setServiceVersions(serviceVersions);
		service.setDomain(domain);
		service.setUsage(usage);
		service.setStatus(status);
		service.setEnvironment(environment);
		return service;
	}

	public static PolicyDO newPolicy(String status, String createdBy, Date createdDate,
			String name, String description, String type, String data, String flow, Integer order,
			Set<ServiceVersionDO> serviceVersions) {
		PolicyDO policy = new PolicyDO();
		policy.setName(name);
		policy.setDescription(description);
		policy.setData(data);
		policy.setServiceVersions(serviceVersions);
		policy.setType(type);
		policy.setStatus(status);
		policy.setFlow(flow);
		policy.setOrder(order);
		return policy;
	}
	
	public static DefaultPolicyDO newDefaultPolicy(String status, String createdBy, Date createdDate,
			String name, String description, String type, String data, String flow, Integer order) {
		DefaultPolicyDO policy = new DefaultPolicyDO();
		policy.setName(name);
		policy.setDescription(description);
		policy.setData(data);
		policy.setType(type);
		policy.setStatus(status);
		policy.setFlow(flow);
		policy.setOrder(order);
		return policy;
	}

	public static ConsumerDO newConsumer(String status, String createdBy, String consumerId) {
		ConsumerDO consumer = new ConsumerDO();
		consumer.setConsumerId(consumerId);
		consumer.setCreatedBy(createdBy);
		consumer.setStatus(status);
		return consumer;
	}

	public static SubscriptionDO newSubscription(String status, String createdBy, String consumerId, ConsumerDO consumer, ServiceVersionDO serviceVersion, String communicationType) {
		SubscriptionDO subscription = new SubscriptionDO();
		subscription.setCommunicationType(communicationType);
		subscription.setConsumer(consumer);
		subscription.setCreatedBy(createdBy);
		subscription.setServiceVersion(serviceVersion);
		subscription.setStatus(status);
		return subscription;
	}

	public static QoSDO newQoS(String status, String createdBy, Date createdDate,
			String name, String description, String type) {
		QoSDO qos = new QoSDO();
		qos.setName(name);
		qos.setDescription(description);
		qos.setType(type);
		qos.setStatus(status);
		return qos;
	}
	
	public static DefaultQoSDO newDefaultQoS(String name, String env, String category,
			String status, String description, String type, String value) {
		DefaultQoSDO defqos = new DefaultQoSDO();
		defqos.setName(name);
		defqos.setDescription(description);
		defqos.setType(type);
		defqos.setStatus(status);
		defqos.setEnvironment(env);
		defqos.setCategory(category);
		defqos.setValue(value);
		return defqos;
	}
}
