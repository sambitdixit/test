package com.walmart.platform.soari.registry.domain.dao.impl.integration;

import java.util.ArrayList;
import java.util.List;

import junit.framework.Assert;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;
import org.testng.annotations.Test;

import com.walmart.platform.kernel.exception.layers.dao.DataAccessException;
import com.walmart.platform.soari.registry.domain.NotificationDestinationDO;

@TransactionConfiguration(transactionManager = "transactionManager", defaultRollback = true)
public class NotificationDestinationDAOImplIntegrationTest extends
		AbstractDAOIntegrationTest {

	private static Logger LOG = LoggerFactory
			.getLogger(NotificationDestinationDAOImplIntegrationTest.class);

	@Test(enabled = true)
	@Transactional
	public void testSave() {
		try {
			NotificationDestinationDO expected = newNotificationDestination();
			expected = notificationDestinationDAO.save(expected);
			Assert.assertEquals(expected,
					notificationDestinationDAO.findOne(expected.getId()));
		} catch (DataAccessException ex) {
			LOG.error("error while testSave : " + ex.getMessage());
			Assert.fail("error while testSave : " + ex.getMessage());
		}
	}

	@Test(enabled = true)
	@Transactional
	public void testFindAllByPage() {
		try {
			NotificationDestinationDO notificationDestination1 = newNotificationDestination();
			notificationDestination1 = notificationDestinationDAO
					.save(notificationDestination1);
			NotificationDestinationDO notificationDestination2 = newNotificationDestination();
			notificationDestination2 = notificationDestinationDAO
					.save(notificationDestination2);
			NotificationDestinationDO notificationDestination3 = newNotificationDestination();
			notificationDestination3 = notificationDestinationDAO
					.save(notificationDestination3);

			Pageable pageable = new PageRequest(0, 2);
			List<NotificationDestinationDO> result = notificationDestinationDAO
					.findAll(pageable).getContent();
			Assert.assertEquals(result.size(), 2);
		} catch (DataAccessException ex) {
			String error = "error while testFindAllByPage() : "
					+ ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}
	}

	@Test(enabled = true)
	@Transactional
	public void testFindOne() {
		try {
			NotificationDestinationDO expected = newNotificationDestination();
			expected = notificationDestinationDAO.save(expected);
			Assert.assertEquals(expected,
					notificationDestinationDAO.findOne(expected.getId()));
		} catch (DataAccessException ex) {
			String error = "error while testFindOne() : " + ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}
	}

	@Test(enabled = true)
	@Transactional
	public void testDeleteById() {
		try {
			NotificationDestinationDO expected = newNotificationDestination();
			expected = notificationDestinationDAO.save(expected);
			notificationDestinationDAO.delete(expected.getId());
			Assert.assertNull(notificationDestinationDAO.findOne(expected
					.getId()));
		} catch (DataAccessException ex) {
			String error = "error while testDeleteById() : " + ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}
	}

	@Test(enabled = true)
	@Transactional
	public void testDeleteEntity() {
		try {
			NotificationDestinationDO expected = newNotificationDestination();
			expected = notificationDestinationDAO.save(expected);
			notificationDestinationDAO.delete(expected);
			Assert.assertNull(notificationDestinationDAO.findOne(expected
					.getId()));
		} catch (DataAccessException ex) {
			String error = "error while testDeleteEntity() : "
					+ ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}
	}

	@Test(enabled = true)
	@Transactional
	public void testDeleteEntities() {
		try {
			List<NotificationDestinationDO> notificationDestinations = new ArrayList<NotificationDestinationDO>();
			NotificationDestinationDO notificationDestination1 = newNotificationDestination();
			notificationDestination1 = notificationDestinationDAO
					.save(notificationDestination1);
			notificationDestinations.add(notificationDestination1);
			NotificationDestinationDO notificationDestination2 = newNotificationDestination();
			notificationDestination2 = notificationDestinationDAO
					.save(notificationDestination2);
			notificationDestinations.add(notificationDestination2);
			notificationDestinationDAO.delete(notificationDestinations);
			Assert.assertNull(notificationDestinationDAO
					.findOne(notificationDestination1.getId()));
			Assert.assertNull(notificationDestinationDAO
					.findOne(notificationDestination2.getId()));
		} catch (DataAccessException ex) {
			String error = "error while testDeleteEntities() : "
					+ ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}
	}

	@Test(enabled = true)
	@Transactional
	public void testDeleteAll() {
		Assert.assertTrue(true);
	}

	@Test(enabled = true)
	@Transactional
	public void testFindAll() {
		try {
			NotificationDestinationDO notificationDestination1 = newNotificationDestination();
			notificationDestination1 = notificationDestinationDAO
					.save(notificationDestination1);
			NotificationDestinationDO notificationDestination2 = newNotificationDestination();
			notificationDestination2 = notificationDestinationDAO
					.save(notificationDestination2);
			List<NotificationDestinationDO> result = notificationDestinationDAO
					.findAll();
			Assert.assertTrue(result.size() >= 2);
		} catch (DataAccessException ex) {
			String error = "error while count() : " + ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}
	}

	@Test(enabled = true)
	@Transactional
	public void findAllBySort() {
		// notificationDestinationDAO.findAll(sort);
		Assert.assertTrue(true);
	}

	@Test(enabled = true)
	@Transactional
	public void saveEntities() {
		try {
			List<NotificationDestinationDO> notificationDestinations = new ArrayList<NotificationDestinationDO>();
			NotificationDestinationDO notificationDestination1 = newNotificationDestination();
			notificationDestinations.add(notificationDestination1);
			NotificationDestinationDO notificationDestination2 = newNotificationDestination();
			notificationDestinations.add(notificationDestination2);
			notificationDestinationDAO.save(notificationDestinations);
			Assert.assertNotNull(notificationDestinationDAO
					.findOne(notificationDestination1.getId()));
			Assert.assertNotNull(notificationDestinationDAO
					.findOne(notificationDestination2.getId()));
		} catch (DataAccessException ex) {
			String error = "error while saveEntities() : " + ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}
	}

	@Test(enabled = true)
	@Transactional
	public void testSearch() throws Exception {
		try {
			long now = System.currentTimeMillis();
			NotificationDestinationDO notificationDestinationDO1 = newNotificationDestination();
			notificationDestinationDO1.setName("Test Notftn1 "+now);
			notificationDestinationDO1 = notificationDestinationDAO
					.save(notificationDestinationDO1);

			NotificationDestinationDO notificationDestinationDO2 = newNotificationDestination();
			notificationDestinationDO2.setName("Test Notftn2 "+now);
			notificationDestinationDO2 = notificationDestinationDAO
					.save(notificationDestinationDO2);

			NotificationDestinationDO notificationDestinationDO3 = newNotificationDestination();
			notificationDestinationDO3.setName("Test Notftn3 "+now);
			notificationDestinationDO3 = notificationDestinationDAO
					.save(notificationDestinationDO3);

			NotificationDestinationDO notificationDestinationDO4 = newNotificationDestination();
			notificationDestinationDO4 = notificationDestinationDAO
					.save(notificationDestinationDO4);

			List<NotificationDestinationDO> result = notificationDestinationDAO.findByMatchingName("notftn");
			Assert.assertTrue(result.contains(notificationDestinationDO1));
			Assert.assertTrue(result.contains(notificationDestinationDO2));
			Assert.assertTrue(result.contains(notificationDestinationDO3)); 
			Assert.assertFalse(result.contains(notificationDestinationDO4)); 												// different
		} catch (Exception ex) {
		}

	}
}
