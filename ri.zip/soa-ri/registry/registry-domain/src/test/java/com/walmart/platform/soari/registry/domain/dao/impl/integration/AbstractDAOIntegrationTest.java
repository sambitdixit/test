package com.walmart.platform.soari.registry.domain.dao.impl.integration;


import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.testng.AbstractTransactionalTestNGSpringContextTests;

import com.walmart.platform.kernel.exception.layers.dao.DataAccessException;
import com.walmart.platform.soari.registry.common.enums.NotificationDestinationType;
import com.walmart.platform.soari.registry.common.enums.RegistryPolicyCodeType;
import com.walmart.platform.soari.registry.common.enums.ServiceCategoryType;
import com.walmart.platform.soari.registry.common.enums.ServiceCommunicationType;
import com.walmart.platform.soari.registry.common.enums.ServiceDomainType;
import com.walmart.platform.soari.registry.common.enums.ServiceUseType;
import com.walmart.platform.soari.registry.common.enums.StatusType;
import com.walmart.platform.soari.registry.domain.AuditDO;
import com.walmart.platform.soari.registry.domain.ConsumerDO;
import com.walmart.platform.soari.registry.domain.DefaultPolicyDO;
import com.walmart.platform.soari.registry.domain.DefaultQoSDO;
import com.walmart.platform.soari.registry.domain.EntityDO;
import com.walmart.platform.soari.registry.domain.NotificationDestinationDO;
import com.walmart.platform.soari.registry.domain.PolicyDO;
import com.walmart.platform.soari.registry.domain.QoSDO;
import com.walmart.platform.soari.registry.domain.RegistryPolicyCode;
import com.walmart.platform.soari.registry.domain.ServiceDO;
import com.walmart.platform.soari.registry.domain.ServiceVersionDO;
import com.walmart.platform.soari.registry.domain.SubscriptionDO;
import com.walmart.platform.soari.registry.domain.UrlDO;
import com.walmart.platform.soari.registry.domain.dao.api.AuditDAO;
import com.walmart.platform.soari.registry.domain.dao.api.ConsumerDAO;
import com.walmart.platform.soari.registry.domain.dao.api.DefaultPolicyDAO;
import com.walmart.platform.soari.registry.domain.dao.api.DefaultQoSDAO;
import com.walmart.platform.soari.registry.domain.dao.api.NotificationDestinationDAO;
import com.walmart.platform.soari.registry.domain.dao.api.PolicyDAO;
import com.walmart.platform.soari.registry.domain.dao.api.QoSDAO;
import com.walmart.platform.soari.registry.domain.dao.api.ServiceDAO;
import com.walmart.platform.soari.registry.domain.dao.api.ServiceVersionDAO;
import com.walmart.platform.soari.registry.domain.dao.api.SubscriptionDAO;
import com.walmart.platform.soari.registry.domain.dao.impl.RegistryPolicyCodeDAOImpl;
import com.walmart.platform.soari.registry.domain.util.TestEntityFactory;

@ContextConfiguration(locations = { "classpath:/META-INF/domainContext-test.xml"})
public class AbstractDAOIntegrationTest extends AbstractTransactionalTestNGSpringContextTests{
	
	@Autowired
	protected PolicyDAO policyDAO;
	
	@Autowired
	protected DefaultPolicyDAO defaultPolicyDAO;
	
	@Autowired
	protected ServiceDAO serviceDAO;
	
	@Autowired
	protected ServiceVersionDAO serviceVersionDAO;
	
	@Autowired
	protected NotificationDestinationDAO notificationDestinationDAO;
	
	@Autowired
	protected AuditDAO auditDAO;
	
	@Autowired
	protected QoSDAO qosDAO;
	
	@Autowired
	protected DefaultQoSDAO defaultQosDAO;
	
	@Autowired
	protected ConsumerDAO consumerDAO;

	@Autowired
	protected SubscriptionDAO subscriptionDAO;
	
	protected ServiceVersionDO newServiceVersion() throws DataAccessException {
		ServiceDO service = newService();
		service = serviceDAO.save(service);
		RegistryPolicyCode status = RegistryPolicyCodeDAOImpl.getCode(RegistryPolicyCodeType.STATUS, StatusType.ACTIVE.toString());
		RegistryPolicyCode contractUrl = RegistryPolicyCodeDAOImpl.getCode(
				RegistryPolicyCodeType.URL, com.walmart.platform.soari.registry.common.enums.UrlType.CONTRACT.toString());
		Set<UrlDO> urlDOs = new HashSet<UrlDO>(0);
		UrlDO urlDO = new UrlDO();
		urlDO.setType(contractUrl.getCode());
		urlDO.setUrl("http:\\www.walmart.com\\platform\\soari\\registry");
		urlDO.setVersion(1);
		urlDOs.add(urlDO);
		ServiceVersionDO serviceVersion = TestEntityFactory.newServiceVersion(service, status.getCode(), urlDOs);
		serviceVersion.setStatus(status.getCode());
		return serviceVersion;
	}
	
	protected ServiceVersionDO newServiceVersion(String env) throws DataAccessException {
		ServiceDO service = newService();
		service.setEnvironment(env);
		service = serviceDAO.save(service);
		RegistryPolicyCode status = RegistryPolicyCodeDAOImpl.getCode(RegistryPolicyCodeType.STATUS, StatusType.ACTIVE.toString());
		RegistryPolicyCode contractUrl = RegistryPolicyCodeDAOImpl.getCode(
				RegistryPolicyCodeType.URL, com.walmart.platform.soari.registry.common.enums.UrlType.CONTRACT.toString());
		Set<UrlDO> urlDOs = new HashSet<UrlDO>(0);
		UrlDO urlDO = new UrlDO();
		urlDO.setType(contractUrl.getCode());
		urlDO.setUrl("http:\\www.walmart.com\\platform\\soari\\registry");
		urlDO.setVersion(1);
		urlDOs.add(urlDO);
		ServiceVersionDO serviceVersion = TestEntityFactory.newServiceVersion(service, status.getCode(), urlDOs);
		serviceVersion.setStatus(status.getCode());
		return serviceVersion;
	}
	
	protected ServiceVersionDO newServiceVersion(ServiceDO service) throws DataAccessException {
		RegistryPolicyCode status = RegistryPolicyCodeDAOImpl.getCode(RegistryPolicyCodeType.STATUS, StatusType.ACTIVE.toString());
		RegistryPolicyCode contractUrl = RegistryPolicyCodeDAOImpl.getCode(RegistryPolicyCodeType.URL, com.walmart.platform.soari.registry.common.enums.UrlType.CONTRACT.toString());
		Set<UrlDO> urlDOs = new HashSet<UrlDO>(0);
		UrlDO urlDO = new UrlDO();
		urlDO.setType(contractUrl.getCode());
		urlDO.setUrl("http:\\www.walmart.com\\platform\\soari\\registry");
		urlDO.setVersion(1);
		urlDOs.add(urlDO);
		ServiceVersionDO serviceVersion = TestEntityFactory.newServiceVersion(service, status.getCode(), urlDOs);
		serviceVersion.setStatus(status.getCode());
		return serviceVersion;
	}
	
	protected PolicyDO newPolicy() throws DataAccessException{
		RegistryPolicyCode status = RegistryPolicyCodeDAOImpl.getCode(RegistryPolicyCodeType.STATUS, StatusType.ACTIVE.toString());
		RegistryPolicyCode flowType = RegistryPolicyCodeDAOImpl.getCode(RegistryPolicyCodeType.FLOW, com.walmart.platform.soari.registry.common.enums.FlowType.REQUEST.toString());
		RegistryPolicyCode type = RegistryPolicyCodeDAOImpl.getCode(RegistryPolicyCodeType.POLICY_TYPE, com.walmart.platform.soari.registry.common.enums.PolicyType.SLA.toString());
		return TestEntityFactory.newPolicy(status.getCode(), type.getCode(), flowType.getCode());
	}
	
	protected DefaultPolicyDO newDefaultPolicy() throws DataAccessException{
		RegistryPolicyCode status = RegistryPolicyCodeDAOImpl.getCode(RegistryPolicyCodeType.STATUS, StatusType.ACTIVE.toString());
		RegistryPolicyCode flowType = RegistryPolicyCodeDAOImpl.getCode(RegistryPolicyCodeType.FLOW, com.walmart.platform.soari.registry.common.enums.FlowType.REQUEST.toString());
		RegistryPolicyCode type = RegistryPolicyCodeDAOImpl.getCode(RegistryPolicyCodeType.POLICY_TYPE, com.walmart.platform.soari.registry.common.enums.PolicyType.SLA.toString());
		//return TestEntityFactory.newPolicy(status.getCode(), type.getCode(), flowType.getCode());
		return TestEntityFactory.DefaultnewPolicy(status.getCode(), type.getCode() , flowType.getCode());
	}
	
	protected QoSDO newQoS() throws DataAccessException{
		RegistryPolicyCode status = RegistryPolicyCodeDAOImpl.getCode(RegistryPolicyCodeType.STATUS, StatusType.ACTIVE.toString());
		RegistryPolicyCode type = RegistryPolicyCodeDAOImpl.getCode(RegistryPolicyCodeType.QoS_TYPE, "SLA");
		return TestEntityFactory.newQoS(status.getCode(), type.getCode());
	}
	
	protected DefaultQoSDO newDefaultQoS() throws DataAccessException{
		RegistryPolicyCode status = RegistryPolicyCodeDAOImpl.getCode(RegistryPolicyCodeType.STATUS, StatusType.ACTIVE.toString());
		RegistryPolicyCode type = RegistryPolicyCodeDAOImpl.getCode(RegistryPolicyCodeType.QoS_TYPE, "SLA");
		//return TestEntityFactory.newQoS(status.getCode(), type.getCode());
		return TestEntityFactory.DefaultnewQoS(status.getCode(), type.getCode());
	}

	protected ConsumerDO newConsumer() throws DataAccessException{
		RegistryPolicyCode status = RegistryPolicyCodeDAOImpl.getCode(RegistryPolicyCodeType.STATUS, StatusType.ACTIVE.toString());
		return TestEntityFactory.newConsumer(status.getCode());
	}

	protected SubscriptionDO newSubscription(ConsumerDO consumer, ServiceVersionDO serviceVersion) throws DataAccessException{
		RegistryPolicyCode status = RegistryPolicyCodeDAOImpl.getCode(RegistryPolicyCodeType.STATUS, StatusType.ACTIVE.toString());
		RegistryPolicyCode communicationType = RegistryPolicyCodeDAOImpl.getCode(RegistryPolicyCodeType.COMMUNICATION_TYPE, ServiceCommunicationType.ESB_PROXY.toString());
		return TestEntityFactory.newSubscription(status.getCode(), consumer, serviceVersion, communicationType.getCode());
	}

	protected NotificationDestinationDO newNotificationDestination() throws DataAccessException{
		RegistryPolicyCode status = RegistryPolicyCodeDAOImpl.getCode(RegistryPolicyCodeType.STATUS, StatusType.ACTIVE.toString());
		RegistryPolicyCode type = RegistryPolicyCodeDAOImpl.getCode(RegistryPolicyCodeType.NOTIFICATION_TYPE, NotificationDestinationType.JMS.toString());
		return TestEntityFactory.newNotificationDestination(status.getCode(), type.getCode());
	}

	protected ServiceDO newService() throws DataAccessException {
		RegistryPolicyCode category = RegistryPolicyCodeDAOImpl.getCode(RegistryPolicyCodeType.SERVICE_CATEGORY, ServiceCategoryType.DATA.toString());
		RegistryPolicyCode domain = RegistryPolicyCodeDAOImpl.getCode(RegistryPolicyCodeType.SERVICE_DOMAIN, ServiceDomainType.B2B.toString());
		RegistryPolicyCode usage = RegistryPolicyCodeDAOImpl.getCode(RegistryPolicyCodeType.SERVICE_USAGE, ServiceUseType.INTERNAL.toString());
		RegistryPolicyCode status = RegistryPolicyCodeDAOImpl.getCode(RegistryPolicyCodeType.STATUS, StatusType.ACTIVE.toString());
		return TestEntityFactory.newService(category.getCode(), domain.getCode(), usage.getCode(), status.getCode());
	}
	
	protected AuditDO newAudit(EntityDO entity) {
		return TestEntityFactory.newAudit(entity);
	}

}
