package com.walmart.platform.soari.registry.domain.dao.impl.integration;

import java.util.ArrayList;
import java.util.List;

import junit.framework.Assert;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;
import org.testng.annotations.Test;

import com.walmart.platform.kernel.exception.layers.dao.DataAccessException;
import com.walmart.platform.soari.registry.common.enums.FlowType;
import com.walmart.platform.soari.registry.common.enums.RegistryPolicyCodeType;
import com.walmart.platform.soari.registry.common.enums.StatusType;
import com.walmart.platform.soari.registry.domain.PolicyDO;
import com.walmart.platform.soari.registry.domain.RegistryPolicyCode;
import com.walmart.platform.soari.registry.domain.dao.impl.RegistryPolicyCodeDAOImpl;

@TransactionConfiguration(transactionManager = "transactionManager", defaultRollback = true)
public class PolicyDAOImplIntegrationTest extends AbstractDAOIntegrationTest {

	private static Logger LOG = LoggerFactory
			.getLogger(PolicyDAOImplIntegrationTest.class);

	@Test(enabled = true)
	@Transactional
	public void testSave() {
		try {
			PolicyDO expected = newPolicy();
			String data = expected.getData();
			expected = policyDAO.save(expected);
			PolicyDO actual = policyDAO.findOne(expected.getId());
			Assert.assertEquals(expected, actual);
			Assert.assertEquals(data, actual.getData());
			Assert.assertEquals(Integer.valueOf(1), actual.getOrder());
			Assert.assertEquals(FlowType.REQUEST.toString(), actual.getFlow());
		} catch (DataAccessException ex) {
			LOG.error("error while testSave : " + ex.getMessage());
			Assert.fail("error while testSave : " + ex.getMessage());
		}
	}

	@Test(enabled = true)
	@Transactional
	public void testFindByStatus() {
		try {
			PolicyDO policy1 = newPolicy();
			policy1 = policyDAO.save(policy1);
			PolicyDO policy2 = newPolicy();
			policy2 = policyDAO.save(policy2);
			PolicyDO policy3 = newPolicy();
			RegistryPolicyCode status = RegistryPolicyCodeDAOImpl.getCode(RegistryPolicyCodeType.STATUS, StatusType.DELETED.toString());
			policy3.setStatus(status.getCode());
			policy3 = policyDAO.save(policy3);
			List<String> statusTypes = new ArrayList<String>(0);
			statusTypes.add(StatusType.ACTIVE.toString());
			List<PolicyDO> result = policyDAO.findByStatus(statusTypes);
			Assert.assertTrue(contains(result, policy1.getId()));
			Assert.assertTrue(contains(result, policy2.getId()));
			Assert.assertFalse(contains(result, policy3.getId()));
		} catch (DataAccessException ex) {
			String error = "error while testFindByStatus() : "
					+ ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}
	}
	
	@Test(enabled = true)
	@Transactional
	public void testFindAllByPage() {
		try {
			PolicyDO policy1 = newPolicy();
			policy1 = policyDAO.save(policy1);
			PolicyDO policy2 = newPolicy();
			policy2 = policyDAO.save(policy2);
			PolicyDO policy3 = newPolicy();
			policy3 = policyDAO.save(policy3);

			Pageable pageable = new PageRequest(0, 2);
			List<PolicyDO> result = policyDAO.findAll(pageable).getContent();
			Assert.assertEquals(result.size(), 2);
		} catch (DataAccessException ex) {
			String error = "error while testFindAllByPage() : "
					+ ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}
	}

	@Test(enabled = true)
	@Transactional
	public void testFindOne() {
		try {
			PolicyDO expected = newPolicy();
			expected = policyDAO.save(expected);
			Assert.assertEquals(expected, policyDAO.findOne(expected.getId()));
		} catch (DataAccessException ex) {
			String error = "error while testFindOne() : " + ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}
	}

	@Test(enabled = true)
	@Transactional
	public void testDeleteById() {
		try {
			PolicyDO expected = newPolicy();
			expected = policyDAO.save(expected);
			policyDAO.delete(expected.getId());
			Assert.assertNull(policyDAO.findOne(expected.getId()));
		} catch (DataAccessException ex) {
			String error = "error while testDeleteById() : " + ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}
	}

	@Test(enabled = true)
	@Transactional
	public void testDeleteEntity() {
		try {
			PolicyDO expected = newPolicy();
			expected = policyDAO.save(expected);
			policyDAO.delete(expected);
			Assert.assertNull(policyDAO.findOne(expected.getId()));
		} catch (DataAccessException ex) {
			String error = "error while testDeleteEntity() : "
					+ ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}
	}

	@Test(enabled = true)
	@Transactional
	public void testDeleteEntities() {
		try {
			List<PolicyDO> policies = new ArrayList<PolicyDO>();
			PolicyDO policy1 = newPolicy();
			policy1 = policyDAO.save(policy1);
			policies.add(policy1);
			PolicyDO policy2 = newPolicy();
			policy2 = policyDAO.save(policy2);
			policies.add(policy2);
			policyDAO.delete(policies);
			Assert.assertNull(policyDAO.findOne(policy1.getId()));
			Assert.assertNull(policyDAO.findOne(policy2.getId()));
		} catch (DataAccessException ex) {
			String error = "error while testDeleteEntities() : "
					+ ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}
	}

	@Test(enabled = true)
	@Transactional
	public void testDeleteAll() {
		Assert.assertTrue(true);
	}

	@Test(enabled = true)
	@Transactional
	public void testFindAll() {
		try {
			PolicyDO policy1 = newPolicy();
			policy1 = policyDAO.save(policy1);
			PolicyDO policy2 = newPolicy();
			policy2 = policyDAO.save(policy2);
			List<PolicyDO> result = policyDAO.findAll();
			Assert.assertTrue(result.size() >= 2);
		} catch (DataAccessException ex) {
			String error = "error while testFindAll() : " + ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}
	}
	
	@Test(enabled = true)
	@Transactional
	public void testFindPoliciesByMatchingName() {
		try {
			long now = System.currentTimeMillis();
			PolicyDO policy1 = newPolicy();
			policy1.setName("Policy1 "+now+" ABC Test");
			policy1 = policyDAO.save(policy1);
			PolicyDO policy2 = newPolicy();
			policy2.setName("Policy2 "+now+" ABC Test");
			policy2 = policyDAO.save(policy2);
			PolicyDO policy3 = newPolicy();
			policy3.setName("Policy3 Test");
			policy3 = policyDAO.save(policy3);
			RegistryPolicyCode deletedStatus = RegistryPolicyCodeDAOImpl.getCode(RegistryPolicyCodeType.STATUS, StatusType.DELETED.toString());
			PolicyDO policy4 = newPolicy();
			policy4.setStatus(deletedStatus.getCode());
			policy4.setName("Policy4 "+now+" ABC Test");
			policy4 = policyDAO.save(policy4);
			List<PolicyDO> result = policyDAO.findByMatchingName(String.valueOf(now)+" abc");
			Assert.assertTrue(contains(result, policy1.getId()));
			Assert.assertTrue(contains(result, policy2.getId()));
			Assert.assertFalse(contains(result, policy3.getId()));
			Assert.assertFalse(contains(result, policy4.getId()));
		} catch (DataAccessException ex) {
			String error = "error while testFindPoliciesByMatchingName() : " + ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}
	}
	
	@Test(enabled = true)
	@Transactional
	public void testFindPoliciesByMatchingNameCase() {
		try {
			long now = System.currentTimeMillis();
			PolicyDO policy1 = newPolicy();
			policy1.setName("Policy1 "+now+"_CASE_Test");
			policy1 = policyDAO.save(policy1);
			PolicyDO policy2 = newPolicy();
			policy2.setName("Policy2 "+now+"_case_Test");
			policy2 = policyDAO.save(policy2);
			PolicyDO policy3 = newPolicy();
			policy3.setName("Policy3 Test");
			policy3 = policyDAO.save(policy3);
			List<PolicyDO> result = policyDAO.findByMatchingName(String.valueOf(now)+"_CASE");
			Assert.assertTrue(contains(result, policy1.getId()));
			Assert.assertTrue(contains(result, policy2.getId()));
			Assert.assertFalse(contains(result, policy3.getId()));
		} catch (DataAccessException ex) {
			String error = "error while testFindPoliciesByMatchingName() : " + ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}
	}
	
	@Test(enabled = true)
	@Transactional
	public void testFindPoliciesByMatchingStatus() {
		try {
			PolicyDO policy1 = newPolicy();
			policy1 = policyDAO.save(policy1);
			PolicyDO policy2 = newPolicy();
			policy2 = policyDAO.save(policy2);
			PolicyDO policy3 = newPolicy();
			RegistryPolicyCode status = RegistryPolicyCodeDAOImpl.getCode(RegistryPolicyCodeType.STATUS, StatusType.DELETED.toString());
			policy3.setStatus(status.getCode());
			policy3 = policyDAO.save(policy3);
			List<String> statusTypes = new ArrayList<String>(0);
			statusTypes.add(StatusType.ACTIVE.toString());
			List<PolicyDO> result = policyDAO.findByStatus(statusTypes);
			Assert.assertTrue(contains(result, policy1.getId()));
			Assert.assertTrue(contains(result, policy2.getId()));
			Assert.assertFalse(contains(result, policy3.getId()));
		} catch (DataAccessException ex) {
			String error = "error while testFindPoliciesByMatchingStatus() : " + ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}
	}

	@Test(enabled = true)
	@Transactional
	public void findAllBySort() {
		// policyDAO.findAll(sort);
		Assert.assertTrue(true);
	}

	@Test(enabled = true)
	@Transactional
	public void saveEntities() {
		try {
			List<PolicyDO> policies = new ArrayList<PolicyDO>();
			PolicyDO policy1 = newPolicy();
			policies.add(policy1);
			PolicyDO policy2 = newPolicy();
			policies.add(policy2);
			policyDAO.save(policies);
			Assert.assertNotNull(policyDAO.findOne(policy1.getId()));
			Assert.assertNotNull(policyDAO.findOne(policy2.getId()));
		} catch (DataAccessException ex) {
			String error = "error while saveEntities() : " + ex.getMessage();
			LOG.error(error);
			Assert.fail(error);
		}
	}

	private boolean contains(List<PolicyDO> policies, String id) {
		for(PolicyDO policyDO : policies) {
			if(policyDO.getId().equals(id)) {
				return true;
			}
		}
		return false;
	}

}
