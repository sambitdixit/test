package com.walmart.platform.soari.registry.notification;

/**
 *
 */
public enum NotificationConstants {
	CACHE_NAME,
	CACHE_KEY,
	AVAILABILITY_TIER,
	ESB_REFERENCE,
	SELECTOR
}
