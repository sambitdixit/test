package com.walmart.platform.soari.registry.notification;

import java.io.Serializable;

/**
 *
 */
public class NotificationRequest implements Serializable {
	private static final long serialVersionUID = 1L;
	private String id;
	private String availaibilityTier;
	private String esbReference;
	private String serviceId;
	private String serviceCategory;
	private String serviceDescription;
	private String serviceOwner;
	private String serviceName;
	private String serviceEnv;
	private String applicationId;
	private String domain;
	private String usage;
	private String status;
	private Serializable data;

    /**
     *
     * @return
     */
	public String getId() {
		return this.id;
	}

    /**
     *
     * @param id
     */
	public void setId(String id) {
		this.id = id;
	}

    /**
     *
     * @return
     */
	public String getAvailaibilityTier() {
		return this.availaibilityTier;
	}

    /**
     *
     * @param availaibilityTier
     */
	public void setAvailaibilityTier(String availaibilityTier) {
		this.availaibilityTier = availaibilityTier;
	}

    /**
     *
     * @return
     */
	public String getEsbReference() {
		return this.esbReference;
	}

    /**
     *
     * @param esbReference
     */
	public void setEsbReference(String esbReference) {
		this.esbReference = esbReference;
	}

    /**
     *
     * @return
     */
	public Serializable getData() {
		return this.data;
	}

    /**
     *
     * @param data
     */
	public void setData(Serializable data) {
		this.data = data;
	}

    /**
     *
     * @return
     */
	public String getServiceId() {
		return serviceId;
	}

    /**
     *
     * @param serviceId
     */
	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}

    /**
     *
     * @return
     */
	public String getServiceCategory() {
		return serviceCategory;
	}

    /**
     *
     * @param serviceCategory
     */
	public void setServiceCategory(String serviceCategory) {
		this.serviceCategory = serviceCategory;
	}

    /**
     *
     * @return
     */
	public String getServiceDescription() {
		return serviceDescription;
	}

    /**
     *
     * @param serviceDescription
     */
	public void setServiceDescription(String serviceDescription) {
		this.serviceDescription = serviceDescription;
	}

    /**
     *
     * @return
     */
	public String getServiceOwner() {
		return serviceOwner;
	}

    /**
     *
     * @param serviceOwner
     */
	public void setServiceOwner(String serviceOwner) {
		this.serviceOwner = serviceOwner;
	}

    /**
     *
     * @return
     */
	public String getServiceName() {
		return this.serviceName;
	}

    /**
     *
     * @param serviceName
     */
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

    /**
     *
     * @return
     */
	public String getApplicationId() {
		return applicationId;
	}

    /**
     *
     * @param applicationId
     */
	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}

    /**
     *
     * @return
     */
	public String getDomain() {
		return domain;
	}

    /**
     *
     * @param domain
     */
	public void setDomain(String domain) {
		this.domain = domain;
	}

    /**
     *
     * @return
     */
	public String getUsage() {
		return usage;
	}

    /**
     *
     * @param usage
     */
	public void setUsage(String usage) {
		this.usage = usage;
	}

    /**
     *
     * @return
     */
	public String getStatus() {
		return status;
	}

    /**
     *
     * @param status
     */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return
	 */
	public String getServiceEnv() {
		return serviceEnv;
	}

	/**
	 * @param serviceEnv
	 */
	public void setServiceEnv(String serviceEnv) {
		this.serviceEnv = serviceEnv;
	}

}
