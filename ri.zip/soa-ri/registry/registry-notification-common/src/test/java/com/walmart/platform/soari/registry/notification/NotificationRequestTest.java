package com.walmart.platform.soari.registry.notification;

import java.io.Serializable;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.walmart.platform.soari.registry.notification.NotificationConstants;
import com.walmart.platform.soari.registry.notification.NotificationRequest;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotNull;

public class NotificationRequestTest {
	
	NotificationRequest request;
	
	public NotificationRequestTest(){
		request = new NotificationRequest();
	}
	
	@Test
	public void idTest(){
		request.setId("1");
		assertEquals(request.getId(), "1");
	}
	
	@Test
	public void availaibilityTierTest(){
		request.setAvailaibilityTier(NotificationConstants.AVAILABILITY_TIER.name());
		assertEquals(request.getAvailaibilityTier(), "AVAILABILITY_TIER");
	}
	
	@Test
	public void esbReferenceTest(){
		request.setEsbReference(NotificationConstants.ESB_REFERENCE.name());
		assertEquals(request.getEsbReference(), "ESB_REFERENCE");
	}
	
	@Test
	public void dataTest(){
		request.setData(new Serializable() {});
		assertNotNull(request.getData());
	}

    @Test
    public void testServiceId() {
        request.setServiceId("CA-2.0");
        assertEquals("CA-2.0", request.getServiceId());
    }

    @Test
    public void testServiceCategory() {
        request.setServiceCategory("Enablers");
        assertEquals("Enablers", request.getServiceCategory());
    }

    @Test
    public void testServiceDescription() {
        request.setServiceDescription("Dummy Service");
        assertEquals("Dummy Service", request.getServiceDescription());
    }

    @Test
    public void testServiceOwner() {
        request.setServiceOwner("CA");
        assertEquals("CA", request.getServiceOwner());
    }

    @Test
    public void testServiceName() {
        request.setServiceName("CA");
        assertEquals("CA", request.getServiceName());
    }

    @Test
    public void testGetApplicationId() {
        request.setApplicationId("App-CA");
        assertEquals("App-CA", request.getApplicationId());
    }

    @Test
    public void testAttributes() {
        request.setDomain("WM");
        assertEquals("WM", request.getDomain());

        request.setUsage("WM-Gen");
        assertEquals("WM-Gen", request.getUsage());

        request.setStatus("A");
        assertEquals("A", request.getStatus());
    }
	
}
