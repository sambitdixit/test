package com.walmart.platform.soari.registry.notification.consumer;


/**
 *
 */
public interface NotificationDelegate {

    /**
     *
     * @param key
     * @param req
     */
	void process(String key, Object req);

}
