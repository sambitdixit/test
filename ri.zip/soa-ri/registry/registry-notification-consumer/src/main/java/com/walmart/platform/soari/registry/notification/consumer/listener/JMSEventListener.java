package com.walmart.platform.soari.registry.notification.consumer.listener;

import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.ObjectMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.walmart.platform.soari.registry.notification.NotificationConstants;
import com.walmart.platform.soari.registry.notification.consumer.NotificationDelegate;

/**
 * This class handles message events
 * 
 */
public class JMSEventListener implements MessageListener {
	
	private static final Logger logger = LoggerFactory
			.getLogger(JMSEventListener.class);

	@Autowired(required=false)
	private NotificationDelegate delegate;

	/**
	 * onMessage - message
	 * 
	 * @param fail
	 *            - if true, generates a runtime exception to simulate an
	 *            application exception.
	 * @throws Exception
	 */
	public void onMessage(final Message message) {

		logger.debug("Start of JMSEventListener onMessage");
		try {
			ObjectMessage msg = (ObjectMessage) message;
			if (msg != null) {
				String key = msg.getStringProperty(NotificationConstants.CACHE_KEY.name());
				String esbSelector = msg.getStringProperty(NotificationConstants.SELECTOR.name());
				Object data = msg.getObject();
				logger.debug("Key= {}, Selector= {}",key,esbSelector);
				if (key != null) {
					if(delegate!=null){
						delegate.process(key, data);
					}
				}
				message.acknowledge();
			}
		} catch (Exception e) {
				logger.error("error while listening message in jms listener", e);
		}
		logger.debug("End of JMSEventListener onMessage");
		
	}

	public void setDelegate(NotificationDelegate delegate) {
		this.delegate = delegate;
	}
	
}