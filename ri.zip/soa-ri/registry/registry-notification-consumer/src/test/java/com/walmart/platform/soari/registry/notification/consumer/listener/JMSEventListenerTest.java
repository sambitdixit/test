package com.walmart.platform.soari.registry.notification.consumer.listener;
import javax.jms.JMSException;
import javax.jms.ObjectMessage;

import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.testng.annotations.Test;

import com.walmart.platform.soari.registry.notification.NotificationConstants;


public class JMSEventListenerTest {
	
	//I've tried to mock Message class. As message is a mock object, it gets null value 
	//so for source file JMSEventListener, Test case is not going further from "if(msg!=null)" statement
	//and coverage is around 35% only in this case...
	
	@Mock ObjectMessage message;
	
	public JMSEventListenerTest(){
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void onMessageTest() throws JMSException{
			JMSEventListener jmsListener = new JMSEventListener();
			Mockito.when(message.getStringProperty("SELECTOR")).thenReturn("ESB-SELECTOR");
			Mockito.when(message.getStringProperty(NotificationConstants.CACHE_KEY
					.name())).thenReturn("SOACache");
			jmsListener.onMessage(message);
			Mockito.verify(message).getStringProperty("SELECTOR");
			Mockito.verify(message).getStringProperty(NotificationConstants.CACHE_KEY.name());
		
	}
}
