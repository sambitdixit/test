package com.walmart.platform.soari.registry.client;

import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;

import com.walmart.platform.kernel.exception.layers.service.ServiceException;
import com.walmart.platform.soa.common.service.wrappers.ServiceResponse;
import com.walmart.platform.soa.http.client.AbstractServiceHttpClient;
import com.walmart.platform.soari.registry.client.util.ClientUtil;
import com.walmart.platform.soari.registry.common.dto.RegistryOption;
import com.walmart.platform.soari.registry.common.dto.RegistryOptionList;
import com.walmart.platform.soari.registry.common.enums.RegistryPolicyCodeType;
import com.walmart.platform.soari.registry.common.service.api.RegistryOptionService;

public class RegistryOptionServiceClient extends AbstractServiceHttpClient
		implements RegistryOptionService {

	private Map<String, String> headers = new ConcurrentHashMap<String, String>(
			0);

	//private static final String CLIENT_CONFIG_FILE = "META-INF/client-jaxrs.xml";
	private RegistryOptionService ros;

	public RegistryOptionServiceClient(String hostString) {
		init(hostString);
	}

	private void init(String hostString) {
		//initClient(RegistryOptionServiceClient.CLIENT_CONFIG_FILE);
		setExtraClass(new Class[] {RegistryOption.class, RegistryOptionList.class});
		ClientUtil.setMandatoryHeaders(headers);
		//buildSOARIHeaders(headers);
		for(Entry<String,String> entry:headers.entrySet()){
			String key = entry.getKey();
			String value = entry.getValue();
			if(key!=null && value!=null){
				setHeader(key,value);
			}
		}
		try{
			ros = getProxy(ClientUtil.buildBaseUrl(hostString), RegistryOptionService.class,headers);
		}catch(ServiceException e){
			LOGGER.error("Can not get RegistryOptionServcie",e);
		}
	}

	@Override
	public ServiceResponse<RegistryOptionList> getOptionsByType(RegistryPolicyCodeType type) throws ServiceException {
		ServiceResponse<RegistryOptionList> res = ros.getOptionsByType(type);
		return res;
	}

	public void addMandatoryHeader(String header, String value) {
		setHeader(header,value);
	}

}
