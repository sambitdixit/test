
package com.walmart.platform.soari.registry.client;

import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;

import com.walmart.platform.kernel.exception.layers.service.ServiceException;
import com.walmart.platform.soa.common.service.wrappers.ServiceResponse;
import com.walmart.platform.soa.http.client.AbstractServiceHttpClient;
import com.walmart.platform.soari.registry.client.util.ClientUtil;
import com.walmart.platform.soari.registry.common.dto.BaseDTO;
import com.walmart.platform.soari.registry.common.dto.Policy;
import com.walmart.platform.soari.registry.common.dto.PolicyList;
import com.walmart.platform.soari.registry.common.dto.QoS;
import com.walmart.platform.soari.registry.common.dto.QoSList;
import com.walmart.platform.soari.registry.common.dto.Service;
import com.walmart.platform.soari.registry.common.dto.ServiceList;
import com.walmart.platform.soari.registry.common.dto.ServiceVersion;
import com.walmart.platform.soari.registry.common.dto.ServiceVersionList;
import com.walmart.platform.soari.registry.common.enums.ReportType;
import com.walmart.platform.soari.registry.common.service.api.DashboardService;

public class DashboardServiceClient extends AbstractServiceHttpClient implements
DashboardService {

	private Map<String, String> headers = new ConcurrentHashMap<String, String>(
			0);

	//private static final String CLIENT_CONFIG_FILE = "META-INF/client-jaxrs.xml";
	private DashboardService dashboardService;

	public DashboardServiceClient(String hostString) {
		init(hostString);
	}

	private void init(String hostString) {
		//initClient(DashboardServiceClient.CLIENT_CONFIG_FILE);
		setExtraClass(new Class[] { Policy.class, PolicyList.class,
				QoS.class, QoSList.class,
				ServiceVersion.class, ServiceVersionList.class, Service.class, ServiceList.class, BaseDTO.class });
		ClientUtil.setMandatoryHeaders(headers);
		//buildSOARIHeaders(headers);
		for(Entry<String,String> entry:headers.entrySet()){
			String key = entry.getKey();
			String value = entry.getValue();
			if(key!=null && value!=null){
				setHeader(key,value);
			}
		}
		try {
			dashboardService = getProxy(ClientUtil.buildBaseUrl(hostString), DashboardService.class,
					headers);
		} catch (ServiceException e) {
			LOGGER.error("Can not get proxy for DashboardService", e);
		}
	}

	@Override
	public ServiceResponse<String> getReport(ReportType reportType) throws ServiceException {
		ServiceResponse<String> res = dashboardService.getReport(reportType);
		return res;
	}

	public void addMandatoryHeader(String header, String value) {
		setHeader(header,value);
		
	}

}
