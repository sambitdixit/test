package com.walmart.platform.soari.registry.client;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.walmart.platform.kernel.exception.layers.service.ServiceException;
import com.walmart.platform.soa.common.service.wrappers.ServiceResponse;
import com.walmart.platform.soa.http.client.AbstractServiceHttpClient;
import com.walmart.platform.soari.registry.client.util.ClientUtil;
import com.walmart.platform.soari.registry.common.service.api.RegistryHealthCheckService;

public class RegistryHealthCheckServiceClient extends AbstractServiceHttpClient
		implements RegistryHealthCheckService {

	private Map<String, String> headers = new ConcurrentHashMap<String, String>(
			0);

	//private static final String CLIENT_CONFIG_FILE = "META-INF/client-jaxrs.xml";
	private RegistryHealthCheckService rhs;
	
	public RegistryHealthCheckServiceClient(String hostString) {
		init(hostString);
	}

	private void init(String hostString) {
	//	initClient(RegistryHealthCheckServiceClient.CLIENT_CONFIG_FILE);
		try {
			rhs = getProxy(ClientUtil.buildBaseUrl(hostString), RegistryHealthCheckService.class,
					headers);
		} catch (ServiceException e) {
			LOGGER.error("Can not get RegistryHealthCheckService", e);
		}

	}

	@Override
	public ServiceResponse<Long> getOptionCount() throws ServiceException {
		ServiceResponse<Long> res = rhs.getOptionCount();
		return res;
	}

	public void addMandatoryHeader(String header, String value) {
		setHeader(header,value);
	}

	@Override
	public ServiceResponse<Integer> getCurrentEcvStatus()
			throws ServiceException {
		return rhs.getCurrentEcvStatus();
	}

	@Override
	public ServiceResponse<Integer> updateEcvStatus(int status)
			throws ServiceException {
		return rhs.updateEcvStatus(status);
	}
}
