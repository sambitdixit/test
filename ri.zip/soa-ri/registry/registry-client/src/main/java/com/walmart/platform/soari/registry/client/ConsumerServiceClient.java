
package com.walmart.platform.soari.registry.client;

import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;

import com.walmart.platform.kernel.exception.layers.service.ServiceException;
import com.walmart.platform.soa.common.service.wrappers.ServiceRequest;
import com.walmart.platform.soa.common.service.wrappers.ServiceResponse;
import com.walmart.platform.soa.http.client.AbstractServiceHttpClient;
import com.walmart.platform.soari.registry.client.util.ClientUtil;
import com.walmart.platform.soari.registry.common.dto.BaseDTO;
import com.walmart.platform.soari.registry.common.dto.Consumer;
import com.walmart.platform.soari.registry.common.dto.ConsumerList;
import com.walmart.platform.soari.registry.common.dto.QoS;
import com.walmart.platform.soari.registry.common.dto.QoSList;
import com.walmart.platform.soari.registry.common.dto.Service;
import com.walmart.platform.soari.registry.common.dto.ServiceList;
import com.walmart.platform.soari.registry.common.dto.ServiceSearchBean;
import com.walmart.platform.soari.registry.common.dto.ServiceVersion;
import com.walmart.platform.soari.registry.common.dto.ServiceVersionList;
import com.walmart.platform.soari.registry.common.dto.ServiceVersionSubscription;
import com.walmart.platform.soari.registry.common.dto.Subscription;
import com.walmart.platform.soari.registry.common.dto.SubscriptionList;
import com.walmart.platform.soari.registry.common.dto.SubscriptionRequest;
import com.walmart.platform.soari.registry.common.service.api.ConsumerService;

public class ConsumerServiceClient extends AbstractServiceHttpClient implements
		ConsumerService {

	private Map<String, String> headers = new ConcurrentHashMap<String, String>(
			0);

	//private static final String CLIENT_CONFIG_FILE = "META-INF/client-jaxrs.xml";
	private ConsumerService consumerService;

	
	public ConsumerServiceClient(String hostString) {
		init(hostString);
	}

	private void init(String hostString) {
		
		//initClient(ConsumerServiceClient.CLIENT_CONFIG_FILE);
		setExtraClass(new Class[] { Consumer.class, ConsumerList.class,Subscription.class,SubscriptionList.class,
				QoS.class, QoSList.class,
				ServiceVersion.class, ServiceVersionList.class, Service.class, ServiceList.class, ServiceVersionSubscription.class, SubscriptionRequest.class, BaseDTO.class });
		ClientUtil.setMandatoryHeaders(headers);
		for(Entry<String,String> entry:headers.entrySet()){
			String key = entry.getKey();
			String value = entry.getValue();
			if(key!=null && value!=null){
				setHeader(key,value);
			}
		}
		//	buildSOARIHeaders(headers);
		try {
			consumerService = getProxy(ClientUtil.buildBaseUrl(hostString), ConsumerService.class, headers);
		} catch (ServiceException e) {
			LOGGER.error("Can not get proxy for ConsumerService",e);
		}
	}

	
	@Override
	public ServiceResponse<ConsumerList> getConsumers() throws ServiceException {
		ServiceResponse<ConsumerList> res = consumerService.getConsumers();
		return res;
	}

	
	@Override
	public ServiceResponse<Consumer> getConsumer(String id) throws ServiceException {
		ServiceResponse<Consumer> res = consumerService.getConsumer(id);
		return res;
	}

	
	@Override
	public ServiceResponse<Consumer> addConsumer(ServiceRequest<Consumer> request)
			throws ServiceException {
		ServiceResponse<Consumer> res = consumerService.addConsumer(request);
		return res;
	}

	
	@Override
	public ServiceResponse<Consumer> updateConsumer(ServiceRequest<Consumer> request)
			throws ServiceException{
		ServiceResponse<Consumer> res = consumerService.updateConsumer(request);
		return res;
	}

	
	@Override
	public ServiceResponse<Consumer> updateConsumerStatus(String id, String action, String actionBy) throws ServiceException {
		ServiceResponse<Consumer> res = consumerService.updateConsumerStatus(id, action, actionBy);
		return res;
	}


	@Override
	public ServiceResponse<SubscriptionList> searchSubscriptions(ServiceSearchBean search) throws ServiceException {
		ServiceResponse<SubscriptionList> res = consumerService.searchSubscriptions(search);
		return res;
	}

	@Override
	public ServiceResponse<Subscription> addSubscription(String consumerId, ServiceRequest<SubscriptionRequest> request) throws ServiceException {
		ServiceResponse<Subscription> res = consumerService.addSubscription(consumerId, request);
		return res;
	}
	
	@Override
	public ServiceResponse<Subscription> updateSubscription(ServiceRequest<SubscriptionRequest> request) throws ServiceException {
		ServiceResponse<Subscription> res = consumerService.updateSubscription(request);
		return res;
	}

	@Override
	public ServiceResponse<Subscription> updateSubscriptionStatus(String subscriptionId, String action, String actionBy) throws ServiceException {
		ServiceResponse<Subscription> res = consumerService.updateSubscriptionStatus(subscriptionId, action, actionBy);
		return res;
	}

	@Override
	public ServiceResponse<Subscription> deleteSubscription(String subscriptionId, String actionBy) throws ServiceException {
		ServiceResponse<Subscription> res = consumerService.deleteSubscription(subscriptionId, actionBy);
		return res;
	}

	@Override
	public ServiceResponse<SubscriptionList> getSubscriptions(String consumerId) throws ServiceException {
		ServiceResponse<SubscriptionList> res = consumerService.getSubscriptions(consumerId);
		return res;
	}
	
	public void addMandatoryHeader(String header, String value) {
		setHeader(header,value);
		
	}

	@Override
	public ServiceResponse<Subscription> addSubscription(
			ServiceRequest<ServiceVersionSubscription> request)
			throws ServiceException {
		ServiceResponse<Subscription> res = consumerService.addSubscription(request);
		return res;
	}
}
