package com.walmart.platform.soari.registry.client;

import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;

import com.walmart.platform.kernel.exception.layers.service.ServiceException;
import com.walmart.platform.soa.common.service.wrappers.ServiceRequest;
import com.walmart.platform.soa.common.service.wrappers.ServiceResponse;
import com.walmart.platform.soa.http.client.AbstractServiceHttpClient;
import com.walmart.platform.soari.registry.client.util.ClientUtil;
import com.walmart.platform.soari.registry.common.dto.Policy;
import com.walmart.platform.soari.registry.common.dto.PolicyList;
import com.walmart.platform.soari.registry.common.dto.QoS;
import com.walmart.platform.soari.registry.common.dto.QoSList;
import com.walmart.platform.soari.registry.common.dto.Service;
import com.walmart.platform.soari.registry.common.dto.ServiceList;
import com.walmart.platform.soari.registry.common.dto.ServiceSearchBean;
import com.walmart.platform.soari.registry.common.dto.ServiceVersion;
import com.walmart.platform.soari.registry.common.dto.ServiceVersionList;
import com.walmart.platform.soari.registry.common.service.api.RegistryService;

public class RegistryServiceClient extends AbstractServiceHttpClient implements
		RegistryService {

	private Map<String, String> headers = new ConcurrentHashMap<String, String>(
			0);

	//private static final String CLIENT_CONFIG_FILE = "META-INF/client-jaxrs.xml";
	private RegistryService rs;

	
	/**
	 * Constructor for RegisteryServiceClient
	 * 
	 * @param hostString client url for RegistryServiceClient
	 */
	public RegistryServiceClient(String hostString) {
		init(hostString);
	}

	/**
	 * Initialization of Client
	 * @param hostString
	 */
	private void init(String hostString) {
		
		//initClient(RegistryServiceClient.CLIENT_CONFIG_FILE);
		setExtraClass(new Class[] { Policy.class, PolicyList.class, QoS.class,
				QoSList.class, ServiceVersion.class, ServiceVersionList.class,
				Service.class, ServiceList.class });
		ClientUtil.setMandatoryHeaders(headers);
		for(Entry<String,String> entry:headers.entrySet()){
			String key = entry.getKey();
			String value = entry.getValue();
			if(key!=null && value!=null){
				setHeader(key,value);
			}
		}
		try {
			rs = getProxy(ClientUtil.buildBaseUrl(hostString), RegistryService.class, headers);
		} catch (ServiceException e) {
			LOGGER.error("Can not get RegistryService proxy", e);
		}
	}

	@Override
	public ServiceResponse<ServiceList> getServices() throws ServiceException {
		return searchServices("", null);
	}

	@Override
	public ServiceResponse<Service> getService(String id)
			throws ServiceException {
		ServiceResponse<Service> res = rs.getService(id);
		return res;
	}

	@Override
	public ServiceResponse<Service> addService(ServiceRequest<Service> request)
			throws ServiceException {
		ServiceResponse<Service> res = rs.addService(request);
		return res;
	}

	@Override
	public ServiceResponse<Service> updateService(
			ServiceRequest<Service> request) throws ServiceException {
		ServiceResponse<Service> res = rs.updateService(request);
		return res;
	}

	@Override
	public ServiceResponse<ServiceList> searchServices(String searchName,
			String searchValue) throws ServiceException {
		ServiceResponse<ServiceList> res = rs.searchServices(searchName,searchValue);
		return res;
	}

	@Override
	public ServiceResponse<ServiceList> searchServices(ServiceSearchBean search) throws ServiceException {
		ServiceResponse<ServiceList> res = rs.searchServices(search);
		return res;
	}

	@Override
	public ServiceResponse<ServiceList> findServices(String serviceName)
			throws ServiceException {
		ServiceResponse<ServiceList> res = rs.findServices(serviceName);
		return res;
	}

	@Override
	public ServiceResponse<ServiceVersion> getServiceVersion(String serviceId,
			String serviceVersion) throws ServiceException {
		ServiceResponse<ServiceVersion> res = rs.getServiceVersion(serviceId, serviceVersion);
		return res;

	}

	@Override
	public ServiceResponse<ServiceVersion> addServiceVersion(String serviceId,
			ServiceRequest<ServiceVersion> request) throws ServiceException {
		ServiceResponse<ServiceVersion> res = rs.addServiceVersion(serviceId, request);
		return res;
	}

	@Override
	public ServiceResponse<ServiceVersion> updateServiceVersion(
			String serviceId, ServiceRequest<ServiceVersion> request)
			throws ServiceException {
		ServiceResponse<ServiceVersion> res = rs.updateServiceVersion(serviceId, request);
		return res;
	}

	@Override
	public ServiceResponse<PolicyList> getServiceVersionPolicies(
			String serviceVersionId) throws ServiceException {
		ServiceResponse<PolicyList> res = rs.getServiceVersionPolicies(serviceVersionId);
		return res;
	}

	@Override
	public ServiceResponse<ServiceVersion> addServiceVersionPolicy(
			String serviceVersionId, String policyId) throws ServiceException {
		ServiceResponse<ServiceVersion> res = rs.addServiceVersionPolicy(serviceVersionId, policyId);
		return res;
	}

	@Override
	public ServiceResponse<ServiceVersion> deleteServiceVersionPolicy(
			String serviceVersionId, String policyId) throws ServiceException {
		ServiceResponse<ServiceVersion> res = rs.deleteServiceVersionPolicy(serviceVersionId, policyId);
		return res;
	}

	@Override
	public ServiceResponse<QoSList> getServiceVersionParameters(
			String serviceVersionId) throws ServiceException {
		ServiceResponse<QoSList> res = rs.getServiceVersionParameters(serviceVersionId);
		return res;
	}

	@Override
	public ServiceResponse<QoS> addServiceVersionParameter(
			String serviceVersionId, ServiceRequest<QoS> request)
			throws ServiceException {
		ServiceResponse<QoS> res = rs.addServiceVersionParameter(serviceVersionId, request);
		return res;
	}

	@Override
	public ServiceResponse<QoS> updateServiceVersionParameter(
			String serviceVersionId, ServiceRequest<QoS> request)
			throws ServiceException {
		ServiceResponse<QoS> res = rs.updateServiceVersionParameter(serviceVersionId, request);
		return res;
	}

	@Override
	public ServiceResponse<QoS> deleteServiceVersionParameter(
			String serviceVersionId, String qosId) throws ServiceException {
		ServiceResponse<QoS> res = rs.deleteServiceVersionParameter(serviceVersionId, qosId);
		return res;
	}

	
	@Override
	public ServiceResponse<Service> updateServiceStatus(String serviceId, String action, String actionBy)
			throws ServiceException {
		ServiceResponse<Service> res = rs.updateServiceStatus(serviceId, action, actionBy);
		return res;
	}

	@Override
	public ServiceResponse<ServiceVersion> updateServiceVersionStatus(
			String serviceVersionId, String action, String actionBy) throws ServiceException {
		ServiceResponse<ServiceVersion> res = rs.updateServiceVersionStatus(serviceVersionId, action, actionBy);
		return res;
	}
	

}
