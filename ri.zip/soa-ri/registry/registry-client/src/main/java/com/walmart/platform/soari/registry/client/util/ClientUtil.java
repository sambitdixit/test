package com.walmart.platform.soari.registry.client.util;

import java.util.Map;

import com.walmart.platform.soa.common.HeaderElements;
import com.walmart.platform.soa.common.util.SOAStringUtil;
import com.walmart.platform.soari.registry.common.dto.ServiceSearchBean;

public class ClientUtil {

	private static final String registryServiceName = "RegistrySService";
	private static final String registryServiceVersion = "3.0.5";
	private static final String registryConsumerId = "a3b799098c9e493a9b3a04ba4daedae0";
	private static final String registryConsumerPrivateKey = "a2V5QWxnb05hbWU9UlNBCWtleUVuY29kaW5nRm9ybWF0PVBLQ1MjOAllbmNvZGluZz1FNklqNXN3MlZ6WEQ2NUl4dHhJNjZtaDRybmZoZGhwUFJwY1Rpejd2Wlp4YUtwZk9IM1hWRGxWWVJ1WXhUalRUK3pLUDV5M2NtOGFRMVdoRUFYRlRvZlk4bzBXUy9kMVJ4cFFBMXoyWG5QNTZ3STNiTmtTNzRkWjBnN3Z6cENmUGhvZlF2a1VZL1VKVytJTXdoTi9iQ3hSa2ZnQ3F2NG51bkNtVWlqNzgyM3JiajBmYVZTYlVIL0I5NkRHMzZOYWV0RXhIdHZsM1F0ZTlUZ1FwczhiWW1ndE1qMytEa0wxaDlTY1JSeEFEQlljbTJJVDRNZVVHWXppYXd3MUtiWUU4bTdPNU9VclJDYUF3RzFhWTZ5TzRlWWxnS3VZT1NQV2NVTXpIOG5zTWcrR0NCTWZhTXFlZWZvbmhSalprTVI5bjFyR1Y5V3FmY1YzTUxBaWpCcXlEamRPMXpvK1ZKL0JFZ1p5VSs0cklUSU1mVWVTTy9kMkR1TkQvcU5zT1JSRFZpM1F2MWVla3kzaXQxMkluMTlGUzFXMldzV3dpVXd2SFJUa01tbTNrSVhUbFd5WjlWSndRa3VCMUU4bnZsbHk4ZzhLN0tDWHliY1IwMGpSVHU0ZWJQdlhhSzRsMVBvSlphWXA3dWRTVmVCYlZKUkxBanZWb2JmRXRGSEttakZmd05QZGs0Q3A0UVV6c09mTTdLcVUxNGJGSDR2azBGZSt2ZjAxaW0rSE5WV1RrR3NwYkhxZ1gxbXY1UEpTQisxMVFXaDJDWUZITUlJVkhSY3VGTm9hUlJSWmZ3NUpuMC9JblJIZXIxdzVlYzAySFh4U1VySDA0RXBVaitUMHF6VjlTZlJrNnJlZzNjcHNobWFKQlp5NzcyNjh3VGJ0UzQ2UGhuaTZ0NVg2SjNQaDdGek1aWUovTDlWK2d0bGNqYVFySTJob1FnWVhFZElweVhIZjRoazdmOE41em8vSXRPK2lINEllQkwzcW9qTkdBOHMrbXhydzhWU3J0VzFOcjRRWGhxYlBoOTk3VlFwclpZNUxhOWJ2Vk5qY3JsTlRJTTcvV0NhZUFTa3hQczJsS21CeUZqaGVNZWdLVS9EbkZ6eTQ0SDZqQWpRMjZQSDVzL0VML1hOWHZTZz09CQ==";
	private static final String registryContextUrl = "registry-app/services";
	
	private static String env = "";
	
	static {
		env = System.getProperty("com.walmart.platform.config.runOnEnv","default");
	}
	
	/**
	 * Sets mandatory headers
	 * 
	 * @param headers
	 *            Key-Value of map of mandatory headers
	 */
	public static void setMandatoryHeaders(Map<String, String> headers) {
		headers.put(HeaderElements.CONSUMER_ID, registryConsumerId);
		headers.put(HeaderElements.SERVICE_NAME, registryServiceName);
		headers.put(HeaderElements.SERVICE_VERSION, registryServiceVersion);
		headers.put(HeaderElements.SERVICE_ENV, env);
	}

	public static String buildBaseUrl(String baseUrl) {
		String newUrl = null;
		if (baseUrl != null) {
			if (baseUrl.endsWith(registryContextUrl))
				return baseUrl;
			
			int endIndex = baseUrl.indexOf(registryContextUrl);
			String temp = baseUrl.substring(0, endIndex);
			newUrl = temp + registryContextUrl;

		}
		return newUrl;
	}

	/**
	 * Replace blank-spaces in the 'url' with '%20'
	 * 
	 * @param url
	 *            Input url
	 * @return
	 */
	public static String replaceBlankSpaces(String url) {
		return url.replaceAll(" ", "%20");
	}

	/**
	 * Builds the 'param-value' format url
	 * 
	 * @param url
	 *            Input Url
	 * @param search
	 *            provides value to params
	 * @return
	 */
	public static String buildParamUrl(String url, ServiceSearchBean search) {
		if (search == null) {
			return url;
		}
		url = url + "?";
		StringBuilder paramUrl1 = new StringBuilder(url);
		StringBuilder paramUrl = new StringBuilder("");
		if (!SOAStringUtil.isBlank(search.getName())) {
			paramUrl.append("name=" + search.getName() + "&");
		}
		if (!SOAStringUtil.isBlank(search.getStatus())) {
			paramUrl.append("status=" + search.getStatus() + "&");
		}
		if (!SOAStringUtil.isBlank(search.getCategory())) {
			paramUrl.append("category=" + search.getCategory() + "&");
		}
		if (!SOAStringUtil.isBlank(search.getDescription())) {
			paramUrl.append("description=" + search.getDescription() + "&");
		}
		if (!SOAStringUtil.isBlank(search.getOwner())) {
			paramUrl.append("owner=" + search.getOwner() + "&");
		}
		if (!SOAStringUtil.isBlank(search.getDomain())) {
			paramUrl.append("domain=" + search.getDomain() + "&");
		}
		if (!SOAStringUtil.isBlank(search.getUsage())) {
			paramUrl.append("usage=" + search.getUsage() + "&");
		}
		if (!SOAStringUtil.isBlank(search.getEnvironment())) {
			paramUrl.append("environment=" + search.getEnvironment() + "&");
		}
		if (!SOAStringUtil.isBlank(search.getEsbReference())) {
			paramUrl.append("esbReference=" + search.getEsbReference() + "&");
		}
		if (!SOAStringUtil.isBlank(search.getSerVersion())) {
			paramUrl.append("serVersion=" + search.getSerVersion() + "&");
		}
		if (!SOAStringUtil.isBlank(search.getEsbReference())) {
			paramUrl.append("esbReference=" + search.getEsbReference() + "&");
		}
		if (!SOAStringUtil.isBlank(search.getAvailabilityTier())) {
			paramUrl.append("availabilityTier=" + search.getAvailabilityTier()
					+ "&");
		}
		if (!SOAStringUtil.isBlank(search.getVersionStatus())) {
			paramUrl.append("versionStatus=" + search.getVersionStatus() + "&");
		}
		if (!SOAStringUtil.isBlank(search.getConsumerId())) {
			paramUrl.append("consumerId=" + search.getConsumerId() + "&");
		}
		if (!SOAStringUtil.isBlank(search.getCommunicationType())) {
			paramUrl.append("communicationType="
					+ search.getCommunicationType() + "&");
		}
		if (!SOAStringUtil.isBlank(search.getSubscriptonStatus())) {
			paramUrl.append("subscriptonStatus="
					+ search.getSubscriptonStatus() + "&");
		}
		String s = paramUrl.toString().replaceAll(" ", "%20")
				.substring(0, paramUrl.toString().length() - 1);
		paramUrl1.append(s);
		return paramUrl1.toString();
	}

}