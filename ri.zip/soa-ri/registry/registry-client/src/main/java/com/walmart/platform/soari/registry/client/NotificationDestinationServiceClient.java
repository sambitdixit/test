package com.walmart.platform.soari.registry.client;

import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;

import com.walmart.platform.kernel.exception.layers.service.ServiceException;
import com.walmart.platform.soa.common.service.wrappers.ServiceRequest;
import com.walmart.platform.soa.common.service.wrappers.ServiceResponse;
import com.walmart.platform.soa.http.client.AbstractServiceHttpClient;
import com.walmart.platform.soari.registry.client.util.ClientUtil;
import com.walmart.platform.soari.registry.common.dto.BaseDTO;
import com.walmart.platform.soari.registry.common.dto.NotificationDestination;
import com.walmart.platform.soari.registry.common.dto.NotificationDestinationList;
import com.walmart.platform.soari.registry.common.dto.QoS;
import com.walmart.platform.soari.registry.common.dto.QoSList;
import com.walmart.platform.soari.registry.common.dto.Service;
import com.walmart.platform.soari.registry.common.dto.ServiceList;
import com.walmart.platform.soari.registry.common.dto.ServiceVersion;
import com.walmart.platform.soari.registry.common.dto.ServiceVersionList;
import com.walmart.platform.soari.registry.common.service.api.NotificationDestinationService;

public class NotificationDestinationServiceClient extends AbstractServiceHttpClient implements
		NotificationDestinationService {

	private Map<String, String> headers = new ConcurrentHashMap<String, String>(
			0);

	//private static final String CLIENT_CONFIG_FILE = "META-INF/client-jaxrs.xml";
	private NotificationDestinationService nds;
	
	public NotificationDestinationServiceClient(String hostString) {
		init(hostString);
	}

	private void init(String hostString) {
	
		//initClient(NotificationDestinationServiceClient.CLIENT_CONFIG_FILE);
		setExtraClass(new Class[] { NotificationDestination.class, NotificationDestinationList.class,
				QoS.class, QoSList.class,
				ServiceVersion.class, ServiceVersionList.class, Service.class, ServiceList.class, BaseDTO.class });
		ClientUtil.setMandatoryHeaders(headers);
		//buildSOARIHeaders(headers);
		for(Entry<String,String> entry:headers.entrySet()){
			String key = entry.getKey();
			String value = entry.getValue();
			if(key!=null && value!=null){
				setHeader(key,value);
			}
		}
		try{
			nds = getProxy(ClientUtil.buildBaseUrl(hostString), NotificationDestinationService.class,headers);
		}catch(ServiceException e){
			LOGGER.error("Can not get proxy instance for NotificationDestinationService",e);
		}
	}

	@Override
	public ServiceResponse<NotificationDestinationList> getNotificationDestinations() throws ServiceException {
		return searchNotificationDestinations("", null);
	}
	
	@Override
	public ServiceResponse<NotificationDestinationList> searchNotificationDestinations(String searchName, String searchValue) throws ServiceException {
		ServiceResponse<NotificationDestinationList> res = nds.searchNotificationDestinations(searchName, searchValue);
		return res;
	}
	
	@Override
	public ServiceResponse<NotificationDestination> getNotificationDestination(String id) throws ServiceException {
		ServiceResponse<NotificationDestination> res = nds.getNotificationDestination(id);
		return res;
	}

	@Override
	public ServiceResponse<NotificationDestination> addNotificationDestination(ServiceRequest<NotificationDestination> request)
			throws ServiceException {
		ServiceResponse<NotificationDestination> res = nds.addNotificationDestination(request);
		return res;
	}

	@Override
	public ServiceResponse<NotificationDestination> updateNotificationDestination(ServiceRequest<NotificationDestination> request) throws ServiceException {
		ServiceResponse<NotificationDestination> res = nds.updateNotificationDestination(request);
		return res;
	}

	@Override
	public ServiceResponse<NotificationDestination> updateNotificationDestinationStatus(String notificationDestinationId, String action, String actionBy) throws ServiceException {
		ServiceResponse<NotificationDestination> res = nds.updateNotificationDestinationStatus(notificationDestinationId, action, actionBy);
		return res;
	}
	
	public void addMandatoryHeader(String header, String value) {
		setHeader(header,value);
	}

}
