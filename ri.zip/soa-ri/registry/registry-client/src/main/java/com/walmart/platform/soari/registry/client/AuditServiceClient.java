package com.walmart.platform.soari.registry.client;

import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;

import com.walmart.platform.kernel.exception.layers.service.ServiceException;
import com.walmart.platform.soa.common.service.wrappers.ServiceResponse;
import com.walmart.platform.soa.http.client.AbstractServiceHttpClient;
import com.walmart.platform.soari.registry.client.util.ClientUtil;
import com.walmart.platform.soari.registry.common.dto.Audit;
import com.walmart.platform.soari.registry.common.dto.AuditList;
import com.walmart.platform.soari.registry.common.service.api.AuditService;

public class AuditServiceClient extends AbstractServiceHttpClient
		implements AuditService {

	private Map<String, String> headers = new ConcurrentHashMap<String, String>(
			0);

	//private static final String CLIENT_CONFIG_FILE = "META-INF/client-jaxrs.xml";
	private AuditService auditService;

	public AuditServiceClient(String hostString) {
		init(hostString);
	}

	/**
	 * Initialization
	 * @param hostString
	 */
	private void init(String hostString) {
		//initClient(AuditServiceClient.CLIENT_CONFIG_FILE);
		setExtraClass(new Class[] {Audit.class, AuditList.class});
		ClientUtil.setMandatoryHeaders(headers);
		//buildSOARIHeaders(headers);
		for(Entry<String,String> entry:headers.entrySet()){
			String key = entry.getKey();
			String value = entry.getValue();
			if(key!=null && value!=null){
				setHeader(key,value);
			}
		}
		try {
			auditService = getProxy(ClientUtil.buildBaseUrl(hostString), AuditService.class, headers);
		} catch (ServiceException e) {
			LOGGER.error("Can not get proxy for AuditService",e);
		}
	}

	@Override
	public ServiceResponse<AuditList> getAuditByEntityId(String entityId, Integer fetchCount) throws ServiceException{
		
		ServiceResponse<AuditList> res = auditService.getAuditByEntityId(entityId,fetchCount);
		return res;
	}

	public void addMandatoryHeader(String header, String value) {
		setHeader(header,value);
	}

}
