package com.walmart.platform.soari.registry.client;

import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.walmart.platform.soa.common.service.wrappers.ServiceHeader;
import com.walmart.platform.soa.common.service.wrappers.ServiceRequest;
import com.walmart.platform.soa.common.service.wrappers.ServiceResponse;
import com.walmart.platform.soa.common.service.wrappers.Status;
import com.walmart.platform.soari.registry.client.util.AbstractClientTest;
import com.walmart.platform.soari.registry.client.util.PlatformJAXRSHttpServer;
import com.walmart.platform.soari.registry.common.dto.Consumer;
import com.walmart.platform.soari.registry.common.dto.ConsumerList;
import com.walmart.platform.soari.registry.common.dto.RegistryOptionList;
import com.walmart.platform.soari.registry.common.enums.RegistryPolicyCodeType;
import com.walmart.platform.soari.registry.common.enums.StatusType;

public class ConsumerServiceClientTest extends AbstractClientTest {
	private static final Logger LOG = LoggerFactory
			.getLogger(ConsumerServiceClientTest.class);

	int artifactIndex = 0;
	
	@BeforeClass
	public void startServers() throws Exception {
		Assert.assertTrue(launchServer(PlatformJAXRSHttpServer.class, true),
				"server did not launch correctly");
		init();
		ServiceResponse<RegistryOptionList> gerRegistryOptionResp = registryOptionServiceClient.getOptionsByType(RegistryPolicyCodeType.CMDB_ARTIFACT);
		Assert.assertEquals(gerRegistryOptionResp.getStatus(), Status.OK);
		Assert.assertNotNull(gerRegistryOptionResp.getPayload());
		Assert.assertNotNull(gerRegistryOptionResp.getPayload().getOptions());
		Assert.assertFalse(gerRegistryOptionResp.getPayload().getOptions().isEmpty());
		cmdbArtifacts.addAll(gerRegistryOptionResp.getPayload().getOptions());
	}

	@Test(enabled = true)
	public void testGetConsumers() throws Exception {
		try {
			Consumer consumer1 = newConsumer();
			ServiceRequest<Consumer> newConsumerRequest1 = new ServiceRequest<Consumer>(
					new ServiceHeader(), consumer1);
			ServiceResponse<Consumer> addedConsumerResponse1 = consumerServiceClient
					.addConsumer(newConsumerRequest1);
			Assert.assertEquals(addedConsumerResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedConsumerResponse1.getPayload());
			consumer1 = addedConsumerResponse1.getPayload();
			
			Consumer consumer2 = newConsumer();
			ServiceRequest<Consumer> newConsumerRequest2 = new ServiceRequest<Consumer>(
					new ServiceHeader(), consumer2);
			ServiceResponse<Consumer> addedConsumerResponse2 = consumerServiceClient
					.addConsumer(newConsumerRequest2);
			Assert.assertEquals(addedConsumerResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedConsumerResponse2.getPayload());
			consumer2 = addedConsumerResponse2.getPayload();
			
			ServiceResponse<ConsumerList> getConsumersResp = consumerServiceClient
					.getConsumers();
			Assert.assertEquals(getConsumersResp.getStatus(), Status.OK);
			Assert.assertNotNull(getConsumersResp.getPayload());
			Assert.assertTrue(!getConsumersResp.getPayload().getConsumers()
					.isEmpty());
			
			consumer1 = getConsumerById(getConsumersResp.getPayload().getConsumers(), consumer1.getId());
			consumer2 = getConsumerById(getConsumersResp.getPayload().getConsumers(), consumer2.getId());
			
			Assert.assertNotNull(consumer1);
			Assert.assertNotNull(consumer2);
			
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testGetConsumer() throws Exception {
		try {
			Consumer consumer1 = newConsumer();
			ServiceRequest<Consumer> newConsumerRequest1 = new ServiceRequest<Consumer>(
					new ServiceHeader(), consumer1);
			ServiceResponse<Consumer> addedConsumerResponse1 = consumerServiceClient
					.addConsumer(newConsumerRequest1);
			Assert.assertEquals(addedConsumerResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedConsumerResponse1.getPayload());

			ServiceResponse<Consumer> getConsumerResp = consumerServiceClient
					.getConsumer(addedConsumerResponse1.getPayload().getId());
			Assert.assertEquals(getConsumerResp.getStatus(), Status.OK);
			Assert.assertNotNull(getConsumerResp.getPayload());
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testAddConsumer() throws Exception {
		try {
			Consumer consumer = newConsumer();
			ServiceRequest<Consumer> newConsumerRequest = new ServiceRequest<Consumer>(
					new ServiceHeader(), consumer);
			ServiceResponse<Consumer> addedConsumerResponse = consumerServiceClient
					.addConsumer(newConsumerRequest);
			Assert.assertEquals(addedConsumerResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedConsumerResponse.getPayload());
			Assert.assertEquals(addedConsumerResponse.getPayload().getConsumerId(), consumer.getConsumerId());
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}

@Test(enabled = true)
	public void testUpdateConsumer() throws Exception {
		try {
			Consumer consumer = newConsumer();
			ServiceRequest<Consumer> newConsumerRequest = new ServiceRequest<Consumer>(
					new ServiceHeader(), consumer);
			ServiceResponse<Consumer> addedConsumerResponse = consumerServiceClient
					.addConsumer(newConsumerRequest);
			Assert.assertEquals(addedConsumerResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedConsumerResponse.getPayload());

			Consumer consumerToUpdate = addedConsumerResponse.getPayload();
			String updatedConsumerId = UUID.randomUUID().toString().replace("-", "");
			consumerToUpdate.setConsumerId(updatedConsumerId);
			consumerToUpdate.setStatus(StatusType.INACTIVE.toString());
			consumerToUpdate.setModifiedBy("Test Modifier");
			ServiceRequest<Consumer> updateReq = new ServiceRequest<Consumer>(
					new ServiceHeader(), consumerToUpdate);
			ServiceResponse<Consumer> updateConsumerResp = consumerServiceClient.updateConsumer(updateReq);
			Assert.assertEquals(addedConsumerResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedConsumerResponse.getPayload());
			Assert.assertEquals(updateConsumerResp.getPayload().getConsumerId(), updatedConsumerId);
			Assert.assertEquals(updateConsumerResp.getPayload().getStatus(), StatusType.INACTIVE.toString());
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testUpdateConsumerAddIfNotFound() throws Exception {
		try {
			Consumer consumer = newConsumer();
			ServiceRequest<Consumer> updateConsumerReq = new ServiceRequest<Consumer>(
					new ServiceHeader(), consumer);
			ServiceResponse<Consumer> updateConsumerResp = consumerServiceClient
					.updateConsumer(updateConsumerReq);
			Assert.assertEquals(updateConsumerResp.getStatus(), Status.OK);
			Assert.assertNotNull(updateConsumerResp.getPayload());

		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testUpdateConsumerCheckDuplicate() throws Exception {
		try {
			Consumer consumer1 = newConsumer();
			ServiceRequest<Consumer> newConsumerRequest1 = new ServiceRequest<Consumer>(
					new ServiceHeader(), consumer1);
			ServiceResponse<Consumer> addedConsumerResponse1 = consumerServiceClient
					.addConsumer(newConsumerRequest1);
			Assert.assertEquals(addedConsumerResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedConsumerResponse1.getPayload());

			Consumer consumer2 = newConsumer();
			ServiceRequest<Consumer> newConsumerRequest2 = new ServiceRequest<Consumer>(
					new ServiceHeader(), consumer2);
			ServiceResponse<Consumer> addedConsumerResponse2 = consumerServiceClient
					.addConsumer(newConsumerRequest2);
			Assert.assertEquals(addedConsumerResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedConsumerResponse2.getPayload());

			Consumer consumerToUpdate = addedConsumerResponse2.getPayload();
			consumerToUpdate.setConsumerId(consumer1.getConsumerId());

			ServiceRequest<Consumer> updateReq = new ServiceRequest<Consumer>(
					new ServiceHeader(), consumerToUpdate);
			ServiceResponse<Consumer> uopdateResp = consumerServiceClient
					.updateConsumer(updateReq);
			Assert.assertEquals(uopdateResp.getStatus(), Status.FAIL);
			Assert.assertNull(uopdateResp.getPayload());

		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.assertTrue(true);
		}
	}

	@Test(enabled = true)
	public void testAddConsumerCheckDuplicate() throws Exception {
		try {
			Consumer consumer1 = newConsumer();
			ServiceRequest<Consumer> newConsumerRequest1 = new ServiceRequest<Consumer>(
					new ServiceHeader(), consumer1);
			ServiceResponse<Consumer> addedConsumerResponse1 = consumerServiceClient
					.addConsumer(newConsumerRequest1);
			Assert.assertEquals(addedConsumerResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedConsumerResponse1.getPayload());

			Consumer consumer2 = newConsumer();
			consumer2.setConsumerId(consumer1.getConsumerId());
			ServiceRequest<Consumer> newConsumerRequest2 = new ServiceRequest<Consumer>(
					new ServiceHeader(), consumer2);
			ServiceResponse<Consumer> addedConsumerResponse2 = consumerServiceClient
					.addConsumer(newConsumerRequest2);
			Assert.assertEquals(addedConsumerResponse2.getStatus(), Status.FAIL);
			Assert.assertNull(addedConsumerResponse2.getPayload());
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.assertTrue(true, "Consumer name must be unique");
		}
	}

	@Test(enabled = true)
	public void testActionConsumerInactivate() throws Exception {
		try {
			Consumer consumer = newConsumer();
			ServiceRequest<Consumer> newConsumerRequest = new ServiceRequest<Consumer>(
					new ServiceHeader(), consumer);
			ServiceResponse<Consumer> addedConsumerResponse = consumerServiceClient
					.addConsumer(newConsumerRequest);
			Assert.assertEquals(addedConsumerResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedConsumerResponse.getPayload());
			Assert.assertEquals(addedConsumerResponse.getPayload().getStatus(), StatusType.ACTIVE.toString());
			
			ServiceResponse<Consumer> updateConsumerStatusResp = consumerServiceClient
					.updateConsumerStatus(addedConsumerResponse.getPayload().getId(), "INACTIVATE","test_user");
			Assert.assertEquals(updateConsumerStatusResp.getStatus(), Status.OK);
			Assert.assertNotNull(updateConsumerStatusResp.getPayload());
			Assert.assertEquals(updateConsumerStatusResp.getPayload().getStatus(), StatusType.INACTIVE.toString());
			
			ServiceResponse<Consumer> getResp = consumerServiceClient.getConsumer(addedConsumerResponse.getPayload().getId());
			Assert.assertEquals(getResp.getStatus(), Status.OK);
			Assert.assertNotNull(getResp.getPayload());
			Assert.assertEquals(getResp.getPayload().getStatus(), StatusType.INACTIVE.toString());
		
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testActionConsumerActivate() throws Exception {
		try {
			Consumer consumer = newConsumer();
			consumer.setStatus(StatusType.INACTIVE.toString());
			ServiceRequest<Consumer> newConsumerRequest = new ServiceRequest<Consumer>(
					new ServiceHeader(), consumer);
			ServiceResponse<Consumer> addedConsumerResponse = consumerServiceClient
					.addConsumer(newConsumerRequest);
			Assert.assertEquals(addedConsumerResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedConsumerResponse.getPayload());
			Assert.assertEquals(addedConsumerResponse.getPayload().getStatus(), StatusType.INACTIVE.toString());
			
			ServiceResponse<Consumer> updateConsumerStatusResp = consumerServiceClient
					.updateConsumerStatus(addedConsumerResponse.getPayload().getId(), "ACTIVATE","test_user");
			Assert.assertEquals(updateConsumerStatusResp.getStatus(), Status.OK);
			Assert.assertNotNull(updateConsumerStatusResp.getPayload());
			Assert.assertEquals(updateConsumerStatusResp.getPayload().getStatus(), StatusType.ACTIVE.toString());
			
			ServiceResponse<Consumer> getResp = consumerServiceClient.getConsumer(addedConsumerResponse.getPayload().getId());
			Assert.assertEquals(getResp.getStatus(), Status.OK);
			Assert.assertNotNull(getResp.getPayload());
			Assert.assertEquals(getResp.getPayload().getStatus(), StatusType.ACTIVE.toString());
		
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testActionConsumerDelete() throws Exception {
		try {
			Consumer consumer = newConsumer();
			consumer.setStatus(StatusType.INACTIVE.toString());
			ServiceRequest<Consumer> newConsumerRequest = new ServiceRequest<Consumer>(
					new ServiceHeader(), consumer);
			ServiceResponse<Consumer> addedConsumerResponse = consumerServiceClient
					.addConsumer(newConsumerRequest);
			Assert.assertEquals(addedConsumerResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedConsumerResponse.getPayload());
			Assert.assertEquals(addedConsumerResponse.getPayload().getStatus(), StatusType.INACTIVE.toString());
			
			ServiceResponse<Consumer> updateConsumerStatusResp = consumerServiceClient
					.updateConsumerStatus(addedConsumerResponse.getPayload().getId(), "DELETE","test_user");
			Assert.assertEquals(updateConsumerStatusResp.getStatus(), Status.OK);
			Assert.assertNotNull(updateConsumerStatusResp.getPayload());
			Assert.assertEquals(updateConsumerStatusResp.getPayload().getStatus(), StatusType.DELETED.toString());
			
			ServiceResponse<Consumer> getResp = consumerServiceClient.getConsumer(addedConsumerResponse.getPayload().getId());
			Assert.assertEquals(getResp.getStatus(), Status.OK);
			Assert.assertNotNull(getResp.getPayload());
			Assert.assertEquals(getResp.getPayload().getStatus(), StatusType.DELETED.toString());
		
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
}
