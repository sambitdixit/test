package com.walmart.platform.soari.registry.client;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.walmart.platform.kernel.exception.layers.service.ServiceException;
import com.walmart.platform.soa.common.service.wrappers.ServiceHeader;
import com.walmart.platform.soa.common.service.wrappers.ServiceRequest;
import com.walmart.platform.soa.common.service.wrappers.ServiceResponse;
import com.walmart.platform.soa.common.service.wrappers.Status;
import com.walmart.platform.soari.registry.client.util.AbstractClientTest;
import com.walmart.platform.soari.registry.client.util.PlatformJAXRSHttpServer;
import com.walmart.platform.soari.registry.common.dto.DefaultQoS;
import com.walmart.platform.soari.registry.common.dto.DefaultQoSList;
import com.walmart.platform.soari.registry.common.enums.SearchFieldType;
import com.walmart.platform.soari.registry.common.enums.StatusType;

public class DeafultQoSServiceClientTest extends AbstractClientTest {

	private static final Logger LOG = LoggerFactory
			.getLogger(DeafultQoSServiceClientTest.class);

	@BeforeClass
	public void startServers() throws Exception {
		Assert.assertTrue(launchServer(PlatformJAXRSHttpServer.class, true),
				"server did not launch correctly");
		init();
	}
	
	@Test
	public void intgTest() throws ServiceException{
		
		// Inserting First element into DB
		DefaultQoS qos1 = newDefaultQoS();
		ServiceRequest<DefaultQoS> newQoSRequest1 = new ServiceRequest<DefaultQoS>(
				new ServiceHeader(), qos1);
		ServiceResponse<DefaultQoS> addedQoSResponse1 = defaultQosServiceClient
				.addQoS(newQoSRequest1);
		
		// Printing first element
		System.out.println(addedQoSResponse1.getPayload());
		
		// Search by feild
		DefaultQoS defQos = defaultQosServiceClient.searchQoS("CATEGORY", "BIZ").getPayload().getQosList().get(0);
		
		// Update Env
		defQos.setEnvironment("dev");
		ServiceRequest<DefaultQoS> newQoSRequest =  new ServiceRequest<DefaultQoS>(new ServiceHeader(), defQos);
		ServiceResponse<DefaultQoS> addedQoSResponse=defaultQosServiceClient
			.updateQoS(newQoSRequest);
		
		System.out.println(addedQoSResponse.getPayload());
		
		
	}

	@Test(enabled = true)
	public void testGetQoS() throws Exception {
		try {
			DefaultQoS qos1 = newDefaultQoS();
			ServiceRequest<DefaultQoS> newQoSRequest1 = new ServiceRequest<DefaultQoS>(
					new ServiceHeader(), qos1);
			ServiceResponse<DefaultQoS> addedQoSResponse1 = defaultQosServiceClient
					.addQoS(newQoSRequest1);
			Assert.assertEquals(addedQoSResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedQoSResponse1.getPayload());
			qos1 = addedQoSResponse1.getPayload();
			
			DefaultQoS qos2 = newDefaultQoS();
			ServiceRequest<DefaultQoS> newQoSRequest2 = new ServiceRequest<DefaultQoS>(
					new ServiceHeader(), qos2);
			ServiceResponse<DefaultQoS> addedQoSResponse2 = defaultQosServiceClient
					.addQoS(newQoSRequest2);
			Assert.assertEquals(addedQoSResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedQoSResponse2.getPayload());
			qos2 = addedQoSResponse2.getPayload();
			
			ServiceResponse<DefaultQoSList> getQoSResp = defaultQosServiceClient
					.getQoS();
			Assert.assertEquals(getQoSResp.getStatus(), Status.OK);
			Assert.assertNotNull(getQoSResp.getPayload());
			Assert.assertTrue(!getQoSResp.getPayload().getQosList()
					.isEmpty());
			Assert.assertTrue(contains(getQoSResp.getPayload().getQosList(), qos1.getId()));
			Assert.assertTrue(contains(getQoSResp.getPayload().getQosList(), qos2.getId()));

		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testGetActiveQoSQueryParam() throws Exception {
		try {
			DefaultQoS qos1 = newDefaultQoS();
			ServiceRequest<DefaultQoS> newQoSRequest1 = new ServiceRequest<DefaultQoS>(
					new ServiceHeader(), qos1);
			ServiceResponse<DefaultQoS> addedQoSResponse1 = defaultQosServiceClient
					.addQoS(newQoSRequest1);
			Assert.assertEquals(addedQoSResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedQoSResponse1.getPayload());
			qos1 = addedQoSResponse1.getPayload();
			
			DefaultQoS qos2 = newDefaultQoS();
			qos2.setStatus(StatusType.INACTIVE.toString());
			ServiceRequest<DefaultQoS> newQoSRequest2 = new ServiceRequest<DefaultQoS>(
					new ServiceHeader(), qos2);
			ServiceResponse<DefaultQoS> addedQoSResponse2 = defaultQosServiceClient
					.addQoS(newQoSRequest2);
			Assert.assertEquals(addedQoSResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedQoSResponse2.getPayload());
			qos2 = addedQoSResponse2.getPayload();
			
			ServiceResponse<DefaultQoSList> getQoSResp = defaultQosServiceClient.searchQoS(SearchFieldType.STATUS.toString(), StatusType.ACTIVE.toString());
			Assert.assertEquals(getQoSResp.getStatus(), Status.OK);
			Assert.assertNotNull(getQoSResp.getPayload());
			Assert.assertTrue(!getQoSResp.getPayload().getQosList()
					.isEmpty());
			Assert.assertTrue(contains(getQoSResp.getPayload().getQosList(), qos1.getId()));
			Assert.assertFalse(contains(getQoSResp.getPayload().getQosList(), qos2.getId()));
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	

	@Test(enabled = true)
	public void testGetAvailableQoSQueryParam() throws Exception {
		try {
			DefaultQoS qos1 = newDefaultQoS();
			ServiceRequest<DefaultQoS> newQoSRequest1 = new ServiceRequest<DefaultQoS>(
					new ServiceHeader(), qos1);
			ServiceResponse<DefaultQoS> addedQoSResponse1 = defaultQosServiceClient
					.addQoS(newQoSRequest1);
			Assert.assertEquals(addedQoSResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedQoSResponse1.getPayload());
			qos1 = addedQoSResponse1.getPayload();
			
			DefaultQoS qos2 = newDefaultQoS();
			qos2.setStatus(StatusType.INACTIVE.toString());
			ServiceRequest<DefaultQoS> newQoSRequest2 = new ServiceRequest<DefaultQoS>(
					new ServiceHeader(), qos2);
			ServiceResponse<DefaultQoS> addedQoSResponse2 = defaultQosServiceClient
					.addQoS(newQoSRequest2);
			Assert.assertEquals(addedQoSResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedQoSResponse2.getPayload());
			qos2 = addedQoSResponse2.getPayload();
			
			DefaultQoS qos3 = newDefaultQoS();
			qos2.setStatus(StatusType.DELETED.toString());
			ServiceRequest<DefaultQoS> newQoSRequest3 = new ServiceRequest<DefaultQoS>(
					new ServiceHeader(), qos3);
			ServiceResponse<DefaultQoS> addedQoSResponse3 = defaultQosServiceClient
					.addQoS(newQoSRequest3);
			Assert.assertEquals(addedQoSResponse3.getStatus(), Status.OK);
			Assert.assertNotNull(addedQoSResponse3.getPayload());
			qos2 = addedQoSResponse3.getPayload();
			
			ServiceResponse<DefaultQoSList> getQoSResp = defaultQosServiceClient.searchQoS(SearchFieldType.STATUS.toString(), StatusType.AVAILABLE.toString());
			
			Assert.assertEquals(getQoSResp.getStatus(), Status.OK);
			Assert.assertNotNull(getQoSResp.getPayload());
			Assert.assertTrue(!getQoSResp.getPayload().getQosList()
					.isEmpty());
			Assert.assertTrue(contains(getQoSResp.getPayload().getQosList(), qos1.getId()));
			Assert.assertTrue(contains(getQoSResp.getPayload().getQosList(), qos2.getId()));
			Assert.assertFalse(contains(getQoSResp.getPayload().getQosList(), qos3.getId()));
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	@Test(enabled = true)
	public void testSearchQoSByName() throws Exception {
		try {
			long now = System.currentTimeMillis();
			DefaultQoS qos1 = newDefaultQoS();
			qos1.setName("QoS1 "+now+" Test");
			ServiceRequest<DefaultQoS> newQoSRequest1 = new ServiceRequest<DefaultQoS>(
					new ServiceHeader(), qos1);
			ServiceResponse<DefaultQoS> addedQoSResponse1 = defaultQosServiceClient
					.addQoS(newQoSRequest1);
			Assert.assertEquals(addedQoSResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedQoSResponse1.getPayload());

			DefaultQoS qos2 = newDefaultQoS();
			qos2.setName("QOS "+now+" Test");
			ServiceRequest<DefaultQoS> newQoSRequest2 = new ServiceRequest<DefaultQoS>(
					new ServiceHeader(), qos2);
			ServiceResponse<DefaultQoS> addedQoSResponse2 = defaultQosServiceClient
					.addQoS(newQoSRequest2);
			Assert.assertEquals(addedQoSResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedQoSResponse2.getPayload());
			
			DefaultQoS qos3 = newDefaultQoS();
			long now2 = System.currentTimeMillis();
			qos3.setName("QoS3 "+now2+" Test");
			ServiceRequest<DefaultQoS> newQoSRequest3 = new ServiceRequest<DefaultQoS>(
					new ServiceHeader(), qos3);
			ServiceResponse<DefaultQoS> addedQoSResponse3 = defaultQosServiceClient
					.addQoS(newQoSRequest3);
			Assert.assertEquals(addedQoSResponse3.getStatus(), Status.OK);
			Assert.assertNotNull(addedQoSResponse3.getPayload());

			ServiceResponse<DefaultQoSList> getDefaultQoSListResp = defaultQosServiceClient.searchQoS(SearchFieldType.NAME.toString(),String.valueOf(now));
			Assert.assertEquals(getDefaultQoSListResp.getStatus(), Status.OK);
			Assert.assertNotNull(getDefaultQoSListResp.getPayload());
			Assert.assertTrue(contains(getDefaultQoSListResp.getPayload().getQosList(), addedQoSResponse1.getPayload().getId()));
			Assert.assertTrue(contains(getDefaultQoSListResp.getPayload().getQosList(), addedQoSResponse2.getPayload().getId()));
			Assert.assertFalse(contains(getDefaultQoSListResp.getPayload().getQosList(), addedQoSResponse3.getPayload().getId()));

		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testSearchQoSListByStatus() throws Exception {
		try {
			DefaultQoS qos1 = newDefaultQoS();
			ServiceRequest<DefaultQoS> newQoSRequest1 = new ServiceRequest<DefaultQoS>(
					new ServiceHeader(), qos1);
			ServiceResponse<DefaultQoS> addedQoSResponse1 = defaultQosServiceClient
					.addQoS(newQoSRequest1);
			Assert.assertEquals(addedQoSResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedQoSResponse1.getPayload());

			DefaultQoS qos2 = newDefaultQoS();
			ServiceRequest<DefaultQoS> newQoSRequest2 = new ServiceRequest<DefaultQoS>(
					new ServiceHeader(), qos2);
			ServiceResponse<DefaultQoS> addedQoSResponse2 = defaultQosServiceClient
					.addQoS(newQoSRequest2);
			Assert.assertEquals(addedQoSResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedQoSResponse2.getPayload());
			
			DefaultQoS qos3 = newDefaultQoS();
			qos3.setStatus(StatusType.DELETED.toString());
			ServiceRequest<DefaultQoS> newQoSRequest3 = new ServiceRequest<DefaultQoS>(
					new ServiceHeader(), qos3);
			ServiceResponse<DefaultQoS> addedQoSResponse3 = defaultQosServiceClient
					.addQoS(newQoSRequest3);
			Assert.assertEquals(addedQoSResponse3.getStatus(), Status.OK);
			Assert.assertNotNull(addedQoSResponse3.getPayload());

			ServiceResponse<DefaultQoSList> getQoSListResp = defaultQosServiceClient.searchQoS(SearchFieldType.STATUS.toString(),StatusType.ACTIVE.toString());
			Assert.assertEquals(getQoSListResp.getStatus(), Status.OK);
			Assert.assertNotNull(getQoSListResp.getPayload());
			
			Assert.assertTrue(contains(getQoSListResp.getPayload().getQosList(), addedQoSResponse1.getPayload().getId()));
			Assert.assertTrue(contains(getQoSListResp.getPayload().getQosList(), addedQoSResponse2.getPayload().getId()));
			Assert.assertFalse(contains(getQoSListResp.getPayload().getQosList(), addedQoSResponse3.getPayload().getId()));

		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testGetQoSById() throws Exception {
		try {
			DefaultQoS qos1 = newDefaultQoS();
			ServiceRequest<DefaultQoS> newQoSRequest1 = new ServiceRequest<DefaultQoS>(
					new ServiceHeader(), qos1);
			ServiceResponse<DefaultQoS> addedQoSResponse1 = defaultQosServiceClient
					.addQoS(newQoSRequest1);
			Assert.assertEquals(addedQoSResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedQoSResponse1.getPayload());

			ServiceResponse<DefaultQoS> getQoSResp = defaultQosServiceClient
					.getQoS(addedQoSResponse1.getPayload().getId());
			Assert.assertEquals(getQoSResp.getStatus(), Status.OK);
			Assert.assertNotNull(getQoSResp.getPayload());
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testAddQoS() throws Exception {
		try {
			DefaultQoS qos = newDefaultQoS();
			ServiceRequest<DefaultQoS> newQoSRequest = new ServiceRequest<DefaultQoS>(
					new ServiceHeader(), qos);
			ServiceResponse<DefaultQoS> addedQoSResponse = defaultQosServiceClient
					.addQoS(newQoSRequest);
			Assert.assertEquals(addedQoSResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedQoSResponse.getPayload());
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testUpdateQoS() throws Exception {
		try {
			DefaultQoS qos = newDefaultQoS();
			ServiceRequest<DefaultQoS> newQoSRequest = new ServiceRequest<DefaultQoS>(
					new ServiceHeader(), qos);
			ServiceResponse<DefaultQoS> addedQoSResponse = defaultQosServiceClient
					.addQoS(newQoSRequest);
			Assert.assertEquals(addedQoSResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedQoSResponse.getPayload());
			
			DefaultQoS qosToUpdate = addedQoSResponse.getPayload();
			long now = System.currentTimeMillis();
			String updatedName = TEST_POLICY_NAME + now;
			qosToUpdate.setName(updatedName);
			qosToUpdate.setStatus(StatusType.INACTIVE.toString());
			
			ServiceRequest<DefaultQoS> updateReq = new ServiceRequest<DefaultQoS>(
					new ServiceHeader(), qosToUpdate);
			ServiceResponse<DefaultQoS> updateQoSResp = defaultQosServiceClient.updateQoS(updateReq);
			Assert.assertEquals(addedQoSResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedQoSResponse.getPayload());
			Assert.assertEquals(updateQoSResp.getPayload().getName(), updatedName);
			Assert.assertEquals(updateQoSResp.getPayload().getStatus(), StatusType.INACTIVE.toString());
			
			ServiceResponse<DefaultQoS> resp = defaultQosServiceClient.getQoS(updateQoSResp.getPayload().getId());
						
			qosToUpdate = updateQoSResp.getPayload();
			String modifiedBy = TEST_MODIFIED_BY_USER+"_2";
			now = System.currentTimeMillis();
			updatedName = TEST_QoS_NAME + now;
			qosToUpdate.setName(updatedName);
			
			updateReq = new ServiceRequest<DefaultQoS>(
					new ServiceHeader(), qosToUpdate);
			updateQoSResp = defaultQosServiceClient.updateQoS(updateReq);
			Assert.assertEquals(addedQoSResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedQoSResponse.getPayload());
			Assert.assertEquals(updateQoSResp.getPayload().getName(), updatedName);
			Assert.assertEquals(updateQoSResp.getPayload().getStatus(), StatusType.INACTIVE.toString());
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testUpdateQoSAddIfNotFound() throws Exception {
		try {
			DefaultQoS qos = newDefaultQoS();
			ServiceRequest<DefaultQoS> updateQoSReq = new ServiceRequest<DefaultQoS>(
					new ServiceHeader(), qos);
			ServiceResponse<DefaultQoS> updateQoSResp = defaultQosServiceClient
					.updateQoS(updateQoSReq);
			Assert.assertEquals(updateQoSResp.getStatus(), Status.OK);
			Assert.assertNotNull(updateQoSResp.getPayload());

		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testUpdateQoSCheckDuplicate() throws Exception {
		try {
			DefaultQoS qos1 = newDefaultQoS();
			ServiceRequest<DefaultQoS> newQoSRequest1 = new ServiceRequest<DefaultQoS>(
					new ServiceHeader(), qos1);
			ServiceResponse<DefaultQoS> addedQoSResponse1 = defaultQosServiceClient
					.addQoS(newQoSRequest1);
			Assert.assertEquals(addedQoSResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedQoSResponse1.getPayload());

			DefaultQoS qos2 = newDefaultQoS();
			ServiceRequest<DefaultQoS> newQoSRequest2 = new ServiceRequest<DefaultQoS>(
					new ServiceHeader(), qos2);
			ServiceResponse<DefaultQoS> addedQoSResponse2 = defaultQosServiceClient
					.addQoS(newQoSRequest2);
			Assert.assertEquals(addedQoSResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedQoSResponse2.getPayload());

			DefaultQoS qosToUpdate = addedQoSResponse2.getPayload();
			qosToUpdate.setName(qos1.getName());

			ServiceRequest<DefaultQoS> updateReq = new ServiceRequest<DefaultQoS>(
					new ServiceHeader(), qosToUpdate);
			ServiceResponse<DefaultQoS> uopdateResp = defaultQosServiceClient
					.updateQoS(updateReq);
			Assert.assertEquals(uopdateResp.getStatus(), Status.FAIL);
			Assert.assertNull(uopdateResp.getPayload());

		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.assertTrue(true);
		}
	}

	@Test(enabled = true)
	public void testAddQoSCheckDuplicate() throws Exception {
		try {
			DefaultQoS qos1 = newDefaultQoS();
			ServiceRequest<DefaultQoS> newQoSRequest1 = new ServiceRequest<DefaultQoS>(
					new ServiceHeader(), qos1);
			ServiceResponse<DefaultQoS> addedQoSResponse1 = defaultQosServiceClient
					.addQoS(newQoSRequest1);
			Assert.assertEquals(addedQoSResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedQoSResponse1.getPayload());

			DefaultQoS qos2 = newDefaultQoS();
			qos2.setName(qos1.getName());
			ServiceRequest<DefaultQoS> newQoSRequest2 = new ServiceRequest<DefaultQoS>(
					new ServiceHeader(), qos2);
			ServiceResponse<DefaultQoS> addedQoSResponse2 = defaultQosServiceClient
					.addQoS(newQoSRequest2);
			Assert.assertEquals(addedQoSResponse2.getStatus(), Status.FAIL);
			Assert.assertNull(addedQoSResponse2.getPayload());
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.assertTrue(true, "QOS name must be unique");
		}
	}

	@Test(enabled = true)
	public void testDeleteQoS() throws Exception {
		try {
			DefaultQoS qos = newDefaultQoS();
			ServiceRequest<DefaultQoS> newQoSRequest = new ServiceRequest<DefaultQoS>(
					new ServiceHeader(), qos);
			ServiceResponse<DefaultQoS> addedQoSResponse = defaultQosServiceClient
					.addQoS(newQoSRequest);
			Assert.assertEquals(addedQoSResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedQoSResponse.getPayload());
			/*ServiceResponse<QOS> deleteQoSResponse = defaultQosServiceClient
					.deleteQoS(addedQoSResponse.getPayload().getId());*/
			ServiceResponse<DefaultQoS> deleteQoSResponse = defaultQosServiceClient
					.updateQoSStatus(addedQoSResponse.getPayload().getId(), "DELETE","test_user");
			Assert.assertEquals(deleteQoSResponse.getStatus(), Status.OK);
			Assert.assertNotNull(deleteQoSResponse.getPayload());
			
			ServiceResponse<DefaultQoS> getResp = defaultQosServiceClient.getQoS(addedQoSResponse.getPayload().getId());
			Assert.assertEquals(getResp.getStatus(), Status.OK);
			Assert.assertNotNull(getResp.getPayload());
			Assert.assertEquals(getResp.getPayload().getStatus(), StatusType.DELETED.toString());
		
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testUpdateQoSStatus() throws Exception {
		try {
			DefaultQoS qos = newDefaultQoS();
			ServiceRequest<DefaultQoS> newQoSRequest = new ServiceRequest<DefaultQoS>(
					new ServiceHeader(), qos);
			ServiceResponse<DefaultQoS> addedQoSResponse = defaultQosServiceClient
					.addQoS(newQoSRequest);
			Assert.assertEquals(addedQoSResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedQoSResponse.getPayload());
			Assert.assertEquals(addedQoSResponse.getPayload().getStatus(), StatusType.ACTIVE.toString());
			
			/*ServiceResponse<QOS> updateQoSStatusResp = defaultQosServiceClient
					.updateQoSStatus(addedQoSResponse.getPayload().getId(), StatusType.INACTIVE.toString());*/
			ServiceResponse<DefaultQoS> updateQoSStatusResp = defaultQosServiceClient
					.updateQoSStatus(addedQoSResponse.getPayload().getId(),"INACTIVATE","test_user");
			
			Assert.assertEquals(updateQoSStatusResp.getStatus(), Status.OK);
			Assert.assertNotNull(updateQoSStatusResp.getPayload());
			Assert.assertEquals(updateQoSStatusResp.getPayload().getStatus(), StatusType.INACTIVE.toString());
			
			ServiceResponse<DefaultQoS> getResp = defaultQosServiceClient.getQoS(addedQoSResponse.getPayload().getId());
			Assert.assertEquals(getResp.getStatus(), Status.OK);
			Assert.assertNotNull(getResp.getPayload());
			Assert.assertEquals(getResp.getPayload().getStatus(), StatusType.INACTIVE.toString());
		
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testInActivateQoS() throws Exception {
		try {
			DefaultQoS qos = newDefaultQoS();
			ServiceRequest<DefaultQoS> newQoSRequest = new ServiceRequest<DefaultQoS>(
					new ServiceHeader(), qos);
			ServiceResponse<DefaultQoS> addedQoSResponse = defaultQosServiceClient
					.addQoS(newQoSRequest);
			Assert.assertEquals(addedQoSResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedQoSResponse.getPayload());
			Assert.assertEquals(addedQoSResponse.getPayload().getStatus(), StatusType.ACTIVE.toString());
			
			ServiceResponse<DefaultQoS> updateQoSStatusResp = defaultQosServiceClient
					.updateQoSStatus(addedQoSResponse.getPayload().getId(), "INACTIVATE","test_user");
			Assert.assertEquals(updateQoSStatusResp.getStatus(), Status.OK);
			Assert.assertNotNull(updateQoSStatusResp.getPayload());
			Assert.assertEquals(updateQoSStatusResp.getPayload().getStatus(), StatusType.INACTIVE.toString());
			
			ServiceResponse<DefaultQoS> getResp = defaultQosServiceClient.getQoS(addedQoSResponse.getPayload().getId());
			Assert.assertEquals(getResp.getStatus(), Status.OK);
			Assert.assertNotNull(getResp.getPayload());
			Assert.assertEquals(getResp.getPayload().getStatus(), StatusType.INACTIVE.toString());
		
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testActivateQoS() throws Exception {
		try {
			DefaultQoS qos = newDefaultQoS();
			qos.setStatus(StatusType.INACTIVE.toString());
			ServiceRequest<DefaultQoS> newQoSRequest = new ServiceRequest<DefaultQoS>(
					new ServiceHeader(), qos);
			ServiceResponse<DefaultQoS> addedQoSResponse = defaultQosServiceClient
					.addQoS(newQoSRequest);
			Assert.assertEquals(addedQoSResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedQoSResponse.getPayload());
			Assert.assertEquals(addedQoSResponse.getPayload().getStatus(), StatusType.INACTIVE.toString());
			
			ServiceResponse<DefaultQoS> updateQoSStatusResp = defaultQosServiceClient
					.updateQoSStatus(addedQoSResponse.getPayload().getId(), "ACTIVATE","test_user");
			Assert.assertEquals(updateQoSStatusResp.getStatus(), Status.OK);
			Assert.assertNotNull(updateQoSStatusResp.getPayload());
			Assert.assertEquals(updateQoSStatusResp.getPayload().getStatus(), StatusType.ACTIVE.toString());
			
			ServiceResponse<DefaultQoS> getResp = defaultQosServiceClient.getQoS(addedQoSResponse.getPayload().getId());
			Assert.assertEquals(getResp.getStatus(), Status.OK);
			Assert.assertNotNull(getResp.getPayload());
			Assert.assertEquals(getResp.getPayload().getStatus(), StatusType.ACTIVE.toString());
		
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testDeleteQoSQueryParam() throws Exception {
		try {
			DefaultQoS qos = newDefaultQoS();
			qos.setStatus(StatusType.INACTIVE.toString());
			ServiceRequest<DefaultQoS> newQoSRequest = new ServiceRequest<DefaultQoS>(
					new ServiceHeader(), qos);
			ServiceResponse<DefaultQoS> addedQoSResponse = defaultQosServiceClient
					.addQoS(newQoSRequest);
			Assert.assertEquals(addedQoSResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedQoSResponse.getPayload());
			Assert.assertEquals(addedQoSResponse.getPayload().getStatus(), StatusType.INACTIVE.toString());
			
			ServiceResponse<DefaultQoS> updateQoSStatusResp = defaultQosServiceClient
					.updateQoSStatus(addedQoSResponse.getPayload().getId(), "DELETE","test_user");
			Assert.assertEquals(updateQoSStatusResp.getStatus(), Status.OK);
			Assert.assertNotNull(updateQoSStatusResp.getPayload());
			Assert.assertEquals(updateQoSStatusResp.getPayload().getStatus(), StatusType.DELETED.toString());
			
			ServiceResponse<DefaultQoS> getResp = defaultQosServiceClient.getQoS(addedQoSResponse.getPayload().getId());
			Assert.assertEquals(getResp.getStatus(), Status.OK);
			Assert.assertNotNull(getResp.getPayload());
			Assert.assertEquals(getResp.getPayload().getStatus(), StatusType.DELETED.toString());
		
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	private boolean contains(List<DefaultQoS> qosList, String id) {
		for(DefaultQoS qos : qosList) {
			if(qos.getId().equals(id)) {
				return true;
			}
		}
		return false;
	}

}
