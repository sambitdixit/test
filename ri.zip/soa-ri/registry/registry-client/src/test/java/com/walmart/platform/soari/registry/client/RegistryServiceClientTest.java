package com.walmart.platform.soari.registry.client;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.walmart.platform.soa.common.service.wrappers.ServiceHeader;
import com.walmart.platform.soa.common.service.wrappers.ServiceRequest;
import com.walmart.platform.soa.common.service.wrappers.ServiceResponse;
import com.walmart.platform.soa.common.service.wrappers.Status;
import com.walmart.platform.soari.registry.client.util.AbstractClientTest;
import com.walmart.platform.soari.registry.client.util.PlatformJAXRSHttpServer;
import com.walmart.platform.soari.registry.common.dto.Attribute;
import com.walmart.platform.soari.registry.common.dto.NotificationDestination;
import com.walmart.platform.soari.registry.common.dto.Policy;
import com.walmart.platform.soari.registry.common.dto.PolicyList;
import com.walmart.platform.soari.registry.common.dto.QoS;
import com.walmart.platform.soari.registry.common.dto.QoSList;
import com.walmart.platform.soari.registry.common.dto.RegistryOptionList;
import com.walmart.platform.soari.registry.common.dto.Service;
import com.walmart.platform.soari.registry.common.dto.ServiceList;
import com.walmart.platform.soari.registry.common.dto.ServiceSearchBean;
import com.walmart.platform.soari.registry.common.dto.ServiceVersion;
import com.walmart.platform.soari.registry.common.dto.Url;
import com.walmart.platform.soari.registry.common.enums.AuditType;
import com.walmart.platform.soari.registry.common.enums.AvailabilityTierType;
import com.walmart.platform.soari.registry.common.enums.EnvironmentType;
import com.walmart.platform.soari.registry.common.enums.NotificationDestinationType;
import com.walmart.platform.soari.registry.common.enums.RegistryPolicyCodeType;
import com.walmart.platform.soari.registry.common.enums.SearchFieldType;
import com.walmart.platform.soari.registry.common.enums.ServiceCategoryType;
import com.walmart.platform.soari.registry.common.enums.ServiceDomainType;
import com.walmart.platform.soari.registry.common.enums.ServiceUseType;
import com.walmart.platform.soari.registry.common.enums.StatusType;
import com.walmart.platform.soari.registry.common.enums.UrlType;

public class RegistryServiceClientTest extends AbstractClientTest {
	private static final Logger LOG = LoggerFactory
			.getLogger(RegistryServiceClientTest.class);
	
	int artifactIndex = 0;

	@BeforeClass
	public void startServers() throws Exception {
		Assert.assertTrue(launchServer(PlatformJAXRSHttpServer.class, true),
				"server did not launch correctly");
		init();
		ServiceResponse<RegistryOptionList> getCmdbArtifactResp = registryOptionServiceClient.getOptionsByType(RegistryPolicyCodeType.CMDB_ARTIFACT);
		Assert.assertEquals(getCmdbArtifactResp.getStatus(), Status.OK);
		Assert.assertNotNull(getCmdbArtifactResp.getPayload());
		Assert.assertNotNull(getCmdbArtifactResp.getPayload().getOptions());
		Assert.assertFalse(getCmdbArtifactResp.getPayload().getOptions().isEmpty());
		cmdbArtifacts.addAll(getCmdbArtifactResp.getPayload().getOptions());
		/*	ServiceResponse<RegistryOptionList> getJiraProjectResp = registryOptionServiceClient.getOptionsByType(RegistryPolicyCodeType.JIRA_PROJECT);
		Assert.assertEquals(getJiraProjectResp.getStatus(), Status.OK);
		Assert.assertNotNull(getJiraProjectResp.getPayload());
		Assert.assertNotNull(getJiraProjectResp.getPayload().getOptions());
		Assert.assertFalse(getJiraProjectResp.getPayload().getOptions().isEmpty());
		jiraProjects.addAll(getJiraProjectResp.getPayload().getOptions());*/
	}
	
	@Test(enabled = true)
	public void testSearchServicesByBean() throws Exception {
		try {
			long time1 = System.currentTimeMillis();
			Service service1 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			service1.setName("Service " + time1 + "Test1");
			ServiceRequest<Service> newServiceRequest1 = new ServiceRequest<Service>(
					new ServiceHeader(), service1);
			ServiceResponse<Service> addedServiceResponse1 = registryServiceClient
					.addService(newServiceRequest1);
			Assert.assertEquals(addedServiceResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse1.getPayload());
			Assert.assertNotNull(addedServiceResponse1.getPayload().getNotificationFor());
			Assert.assertFalse(addedServiceResponse1.getPayload().getNotificationFor().isEmpty());
			Assert.assertEquals(addedServiceResponse1.getPayload().getNotificationFor().size(), 2);
				
			service1 = addedServiceResponse1.getPayload();
			
			ServiceVersion serviceVersion11 = newServiceVersion();
			ServiceRequest<ServiceVersion> addServiceVersionRequest11 = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion11);
			ServiceResponse<ServiceVersion> addServiceVersionResp11 = registryServiceClient.addServiceVersion(addedServiceResponse1.getPayload().getId(), addServiceVersionRequest11);
			Assert.assertEquals(addServiceVersionResp11.getStatus(), Status.OK);
			Assert.assertNotNull(addServiceVersionResp11.getPayload());
			
			ServiceVersion serviceVersion12 = newServiceVersion();
			serviceVersion12.setSerVersion("2.0.0");
			ServiceRequest<ServiceVersion> addServiceVersionRequest12 = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion12);
			ServiceResponse<ServiceVersion> addServiceVersionResp12 = registryServiceClient.addServiceVersion(addedServiceResponse1.getPayload().getId(), addServiceVersionRequest12);
			Assert.assertEquals(addServiceVersionResp12.getStatus(), Status.OK);
			Assert.assertNotNull(addServiceVersionResp12.getPayload());
			
			Service service2 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			service2.setName("Service " + time1 + "Test2");
			ServiceRequest<Service> newServiceRequest2 = new ServiceRequest<Service>(
					new ServiceHeader(), service2);
			ServiceResponse<Service> addedServiceResponse2 = registryServiceClient
					.addService(newServiceRequest2);
			Assert.assertEquals(addedServiceResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse2.getPayload());

			Service service3 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			long time2 = System.currentTimeMillis();
			service3.setName("Service " + time2 + "Test3");
			ServiceRequest<Service> newServiceRequest3 = new ServiceRequest<Service>(
					new ServiceHeader(), service3);
			ServiceResponse<Service> addedServiceResponse3 = registryServiceClient
					.addService(newServiceRequest3);
			Assert.assertEquals(addedServiceResponse3.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse3.getPayload());

			ServiceSearchBean search = new ServiceSearchBean();
			search.setName(String.valueOf(time1));
			search.setStatus(StatusType.ACTIVE.toString());
			//search.setCategory(ServiceCategoryType.BIZ.toString());
			search.setSerVersion("1.0.0");
			search.setVersionStatus(StatusType.ACTIVE.toString());
			search.setCategory(ServiceCategoryType.DATA.toString());
			ServiceResponse<ServiceList> searchResponse = registryServiceClient
					.searchServices(search);
			Assert.assertEquals(searchResponse.getStatus(), Status.OK);
			Assert.assertNotNull(searchResponse.getPayload());
			Assert.assertNotNull(searchResponse.getPayload().getServices());
			Assert.assertFalse(searchResponse.getPayload().getServices()
					.isEmpty());

			Assert.assertTrue(contains(searchResponse.getPayload()
					.getServices(), addedServiceResponse1.getPayload().getId()));
			//No Service2 as there is no version 1.0.0
			Assert.assertFalse(contains(searchResponse.getPayload()
					.getServices(), addedServiceResponse2.getPayload().getId()));
			Assert.assertFalse(contains(searchResponse.getPayload()
					.getServices(), addedServiceResponse3.getPayload().getId()));
			
			service1 = getServiceById(searchResponse.getPayload().getServices(), service1.getId());
			Assert.assertFalse(service1.getNotificationFor().isEmpty());
			Assert.assertEquals(service1.getNotificationFor().size(), 2);
		
		} catch (Exception ex) {
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testSearchServicesAndQoSByBean() throws Exception {
		try {
			long time1 = System.currentTimeMillis();
			Service service1 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			service1.setName("Service " + time1 + "Test1");
			ServiceRequest<Service> newServiceRequest1 = new ServiceRequest<Service>(
					new ServiceHeader(), service1);
			ServiceResponse<Service> addedServiceResponse1 = registryServiceClient
					.addService(newServiceRequest1);
			Assert.assertEquals(addedServiceResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse1.getPayload());
			Assert.assertNotNull(addedServiceResponse1.getPayload().getNotificationFor());
			Assert.assertFalse(addedServiceResponse1.getPayload().getNotificationFor().isEmpty());
			Assert.assertEquals(addedServiceResponse1.getPayload().getNotificationFor().size(), 2);
				
			service1 = addedServiceResponse1.getPayload();
			QoS qos1 = addQoS();
			
				
			ServiceVersion serviceVersion11 = newServiceVersion();
			serviceVersion11.getQoSParameters().add(qos1);
			ServiceRequest<ServiceVersion> addServiceVersionRequest11 = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion11);
			ServiceResponse<ServiceVersion> addServiceVersionResp11 = registryServiceClient.addServiceVersion(addedServiceResponse1.getPayload().getId(), addServiceVersionRequest11);
			Assert.assertEquals(addServiceVersionResp11.getStatus(), Status.OK);
			Assert.assertNotNull(addServiceVersionResp11.getPayload());
			
			ServiceVersion serviceVersion12 = newServiceVersion();
			serviceVersion12.setSerVersion("2.0.0");
			ServiceRequest<ServiceVersion> addServiceVersionRequest12 = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion12);
			ServiceResponse<ServiceVersion> addServiceVersionResp12 = registryServiceClient.addServiceVersion(addedServiceResponse1.getPayload().getId(), addServiceVersionRequest12);
			Assert.assertEquals(addServiceVersionResp12.getStatus(), Status.OK);
			Assert.assertNotNull(addServiceVersionResp12.getPayload());
			
			Service service2 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			service2.setName("Service " + time1 + "Test2");
			ServiceRequest<Service> newServiceRequest2 = new ServiceRequest<Service>(
					new ServiceHeader(), service2);
			ServiceResponse<Service> addedServiceResponse2 = registryServiceClient
					.addService(newServiceRequest2);
			Assert.assertEquals(addedServiceResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse2.getPayload());

			Service service3 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			long time2 = System.currentTimeMillis();
			service3.setName("Service " + time2 + "Test3");
			ServiceRequest<Service> newServiceRequest3 = new ServiceRequest<Service>(
					new ServiceHeader(), service3);
			ServiceResponse<Service> addedServiceResponse3 = registryServiceClient
					.addService(newServiceRequest3);
			Assert.assertEquals(addedServiceResponse3.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse3.getPayload());

			ServiceSearchBean search = new ServiceSearchBean();
			search.setName(String.valueOf(time1));
			search.setStatus(StatusType.ACTIVE.toString());
			//search.setCategory(ServiceCategoryType.BIZ.toString());
			search.setSerVersion("1.0.0");
			search.setVersionStatus(StatusType.ACTIVE.toString());
			search.setCategory(ServiceCategoryType.DATA.toString());
			ServiceResponse<ServiceList> searchResponse = registryServiceClient
					.searchServices(search);
			Assert.assertEquals(searchResponse.getStatus(), Status.OK);
			Assert.assertNotNull(searchResponse.getPayload());
			Assert.assertNotNull(searchResponse.getPayload().getServices());
			Assert.assertFalse(searchResponse.getPayload().getServices()
					.isEmpty());

			Assert.assertTrue(contains(searchResponse.getPayload()
					.getServices(), addedServiceResponse1.getPayload().getId()));
			
			//No Service2 as there is no version 1.0.0
			Assert.assertFalse(contains(searchResponse.getPayload()
					.getServices(), addedServiceResponse2.getPayload().getId()));
			Assert.assertFalse(contains(searchResponse.getPayload()
					.getServices(), addedServiceResponse3.getPayload().getId()));
			
			service1 = getServiceById(searchResponse.getPayload().getServices(), service1.getId());
			Assert.assertFalse(service1.getNotificationFor().isEmpty());
			Assert.assertEquals(service1.getNotificationFor().size(), 2);
			Assert.assertFalse(service1.getServiceVersions().isEmpty());
			
			ServiceVersion version1 = getServiceVersion(service1.getServiceVersions(), serviceVersion11.getSerVersion());
			Assert.assertNotNull(version1);
			Assert.assertFalse(version1.getQoSParameters().isEmpty());
		} catch (Exception ex) {
			Assert.fail(ex.getMessage());
		}
	}
	@Test(enabled = true)
	public void testSearchServicesByBeanServiceStatus() throws Exception {
		try {
			long time1 = System.currentTimeMillis();
			Service service1 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			String namePrefix= "SearchByStatus ";
			service1.setName(namePrefix + time1 + "Test1");
			ServiceRequest<Service> newServiceRequest1 = new ServiceRequest<Service>(
					new ServiceHeader(), service1);
			ServiceResponse<Service> addedServiceResponse1 = registryServiceClient
					.addService(newServiceRequest1);
			Assert.assertEquals(addedServiceResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse1.getPayload());
			
			ServiceVersion serviceVersion11 = newServiceVersion();
			ServiceRequest<ServiceVersion> addServiceVersionRequest11 = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion11);
			ServiceResponse<ServiceVersion> addServiceVersionResp11 = registryServiceClient.addServiceVersion(addedServiceResponse1.getPayload().getId(), addServiceVersionRequest11);
			Assert.assertEquals(addServiceVersionResp11.getStatus(), Status.OK);
			Assert.assertNotNull(addServiceVersionResp11.getPayload());
			
			Service service2 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			service2.setStatus(StatusType.DELETED.toString());
			service1.setName(namePrefix + time1 + "Test2");
			ServiceRequest<Service> newServiceRequest2 = new ServiceRequest<Service>(
					new ServiceHeader(), service2);
			ServiceResponse<Service> addedServiceResponse2 = registryServiceClient
					.addService(newServiceRequest2);
			Assert.assertEquals(addedServiceResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse2.getPayload());
			
			ServiceVersion serviceVersion21 = newServiceVersion();
			ServiceRequest<ServiceVersion> addServiceVersionRequest21 = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion21);
			ServiceResponse<ServiceVersion> addServiceVersionResp21 = registryServiceClient.addServiceVersion(addedServiceResponse2.getPayload().getId(), addServiceVersionRequest21);
			Assert.assertEquals(addServiceVersionResp21.getStatus(), Status.OK);
			Assert.assertNotNull(addServiceVersionResp21.getPayload());
		
			
			ServiceSearchBean search = new ServiceSearchBean();
			//Search by Status
			search.setStatus(StatusType.ACTIVE.toString());
		
			ServiceResponse<ServiceList> searchResponse = registryServiceClient
					.searchServices(search);
			Assert.assertEquals(searchResponse.getStatus(), Status.OK);
			Assert.assertNotNull(searchResponse.getPayload());
			Assert.assertNotNull(searchResponse.getPayload().getServices());
			Assert.assertFalse(searchResponse.getPayload().getServices()
					.isEmpty());

			Assert.assertTrue(contains(searchResponse.getPayload()
					.getServices(), addedServiceResponse1.getPayload().getId()));
			//Service2 not expected as DELETED
			Assert.assertFalse(contains(searchResponse.getPayload()
					.getServices(), addedServiceResponse2.getPayload().getId()));
		} catch (Exception ex) {
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testSearchServicesByBeanServiceStatusName() throws Exception {
		try {
			long time1 = System.currentTimeMillis();
			Service service1 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			String namePrefix= "SearchByStatusName ";
			service1.setName(namePrefix + time1 + "Test1");
			ServiceRequest<Service> newServiceRequest1 = new ServiceRequest<Service>(
					new ServiceHeader(), service1);
			ServiceResponse<Service> addedServiceResponse1 = registryServiceClient
					.addService(newServiceRequest1);
			Assert.assertEquals(addedServiceResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse1.getPayload());
			
			ServiceVersion serviceVersion11 = newServiceVersion();
			ServiceRequest<ServiceVersion> addServiceVersionRequest11 = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion11);
			ServiceResponse<ServiceVersion> addServiceVersionResp11 = registryServiceClient.addServiceVersion(addedServiceResponse1.getPayload().getId(), addServiceVersionRequest11);
			Assert.assertEquals(addServiceVersionResp11.getStatus(), Status.OK);
			Assert.assertNotNull(addServiceVersionResp11.getPayload());
			
			Service service2 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			service2.setStatus(StatusType.DELETED.toString());
			service2.setName(namePrefix + time1 + "Test2");
			ServiceRequest<Service> newServiceRequest2 = new ServiceRequest<Service>(
					new ServiceHeader(), service2);
			ServiceResponse<Service> addedServiceResponse2 = registryServiceClient
					.addService(newServiceRequest2);
			Assert.assertEquals(addedServiceResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse2.getPayload());
			
			ServiceVersion serviceVersion21 = newServiceVersion();
			ServiceRequest<ServiceVersion> addServiceVersionRequest21 = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion21);
			ServiceResponse<ServiceVersion> addServiceVersionResp21 = registryServiceClient.addServiceVersion(addedServiceResponse2.getPayload().getId(), addServiceVersionRequest21);
			Assert.assertEquals(addServiceVersionResp21.getStatus(), Status.OK);
			Assert.assertNotNull(addServiceVersionResp21.getPayload());
		
			Service service3 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			service3.setName(namePrefix + time1 + "Test3");
			ServiceRequest<Service> newServiceRequest3 = new ServiceRequest<Service>(
					new ServiceHeader(), service3);
			ServiceResponse<Service> addedServiceResponse3 = registryServiceClient
					.addService(newServiceRequest3);
			Assert.assertEquals(addedServiceResponse3.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse3.getPayload());
			
			ServiceVersion serviceVersion31 = newServiceVersion();
			ServiceRequest<ServiceVersion> addServiceVersionRequest31 = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion31);
			ServiceResponse<ServiceVersion> addServiceVersionResp31 = registryServiceClient.addServiceVersion(addedServiceResponse3.getPayload().getId(), addServiceVersionRequest31);
			Assert.assertEquals(addServiceVersionResp31.getStatus(), Status.OK);
			Assert.assertNotNull(addServiceVersionResp31.getPayload());
			
			Service service4 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			service4.setName(namePrefix+" Test4");
			ServiceRequest<Service> newServiceRequest4 = new ServiceRequest<Service>(
					new ServiceHeader(), service4);
			ServiceResponse<Service> addedServiceResponse4 = registryServiceClient
					.addService(newServiceRequest4);
			Assert.assertEquals(addedServiceResponse4.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse4.getPayload());
			
			ServiceVersion serviceVersion41 = newServiceVersion();
			ServiceRequest<ServiceVersion> addServiceVersionRequest41 = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion41);
			ServiceResponse<ServiceVersion> addServiceVersionResp41 = registryServiceClient.addServiceVersion(addedServiceResponse4.getPayload().getId(), addServiceVersionRequest41);
			Assert.assertEquals(addServiceVersionResp41.getStatus(), Status.OK);
			Assert.assertNotNull(addServiceVersionResp41.getPayload());
		
			ServiceSearchBean search = new ServiceSearchBean();
			//Search by Status
			search.setStatus(StatusType.ACTIVE.toString());
			search.setName(String.valueOf(time1));
			
			ServiceResponse<ServiceList> searchResponse = registryServiceClient
					.searchServices(search);
			Assert.assertEquals(searchResponse.getStatus(), Status.OK);
			Assert.assertNotNull(searchResponse.getPayload());
			Assert.assertNotNull(searchResponse.getPayload().getServices());
			Assert.assertFalse(searchResponse.getPayload().getServices()
					.isEmpty());

			Assert.assertTrue(contains(searchResponse.getPayload()
					.getServices(), addedServiceResponse1.getPayload().getId()));
			//Service2 not expected as DELETED
			Assert.assertFalse(contains(searchResponse.getPayload()
					.getServices(), addedServiceResponse2.getPayload().getId()));
			Assert.assertTrue(contains(searchResponse.getPayload()
					.getServices(), addedServiceResponse3.getPayload().getId()));
			//Service4 not expected as Name doesn't match
			Assert.assertFalse(contains(searchResponse.getPayload()
					.getServices(), addedServiceResponse4.getPayload().getId()));
		} catch (Exception ex) {
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testSearchServicesByBeanServiceStatusNameCategory() throws Exception {
		try {
			long time1 = System.currentTimeMillis();
			Service service1 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			String namePrefix= "SearchByStatusNameCategory ";
			service1.setName(namePrefix + time1 + "Test1");
			ServiceRequest<Service> newServiceRequest1 = new ServiceRequest<Service>(
					new ServiceHeader(), service1);
			ServiceResponse<Service> addedServiceResponse1 = registryServiceClient
					.addService(newServiceRequest1);
			Assert.assertEquals(addedServiceResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse1.getPayload());
			
			ServiceVersion serviceVersion11 = newServiceVersion();
			serviceVersion11.setSerVersion("1.1.0");
			ServiceRequest<ServiceVersion> addServiceVersionRequest11 = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion11);
			ServiceResponse<ServiceVersion> addServiceVersionResp11 = registryServiceClient.addServiceVersion(addedServiceResponse1.getPayload().getId(), addServiceVersionRequest11);
			Assert.assertEquals(addServiceVersionResp11.getStatus(), Status.OK);
			Assert.assertNotNull(addServiceVersionResp11.getPayload());
			
			Service service2 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			service2.setStatus(StatusType.DELETED.toString());
			service2.setName(namePrefix + time1 + "Test2");
			ServiceRequest<Service> newServiceRequest2 = new ServiceRequest<Service>(
					new ServiceHeader(), service2);
			ServiceResponse<Service> addedServiceResponse2 = registryServiceClient
					.addService(newServiceRequest2);
			Assert.assertEquals(addedServiceResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse2.getPayload());
			
			ServiceVersion serviceVersion21 = newServiceVersion();
			serviceVersion21.setSerVersion("2.1.0");
			ServiceRequest<ServiceVersion> addServiceVersionRequest21 = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion21);
			ServiceResponse<ServiceVersion> addServiceVersionResp21 = registryServiceClient.addServiceVersion(addedServiceResponse2.getPayload().getId(), addServiceVersionRequest21);
			Assert.assertEquals(addServiceVersionResp21.getStatus(), Status.OK);
			Assert.assertNotNull(addServiceVersionResp21.getPayload());
		
			Service service3 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			service3.setName(namePrefix + time1 + "Test3");
			ServiceRequest<Service> newServiceRequest3 = new ServiceRequest<Service>(
					new ServiceHeader(), service3);
			ServiceResponse<Service> addedServiceResponse3 = registryServiceClient
					.addService(newServiceRequest3);
			Assert.assertEquals(addedServiceResponse3.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse3.getPayload());
			
			ServiceVersion serviceVersion31 = newServiceVersion();
			serviceVersion31.setSerVersion("3.1.0");
			ServiceRequest<ServiceVersion> addServiceVersionRequest31 = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion31);
			ServiceResponse<ServiceVersion> addServiceVersionResp31 = registryServiceClient.addServiceVersion(addedServiceResponse3.getPayload().getId(), addServiceVersionRequest31);
			Assert.assertEquals(addServiceVersionResp31.getStatus(), Status.OK);
			Assert.assertNotNull(addServiceVersionResp31.getPayload());
			
			Service service4 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			service4.setName(namePrefix+" Test4");
			ServiceRequest<Service> newServiceRequest4 = new ServiceRequest<Service>(
					new ServiceHeader(), service4);
			ServiceResponse<Service> addedServiceResponse4 = registryServiceClient
					.addService(newServiceRequest4);
			Assert.assertEquals(addedServiceResponse4.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse4.getPayload());
			
			ServiceVersion serviceVersion41 = newServiceVersion();
			serviceVersion41.setSerVersion("4.1.0");
			
			ServiceRequest<ServiceVersion> addServiceVersionRequest41 = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion41);
			ServiceResponse<ServiceVersion> addServiceVersionResp41 = registryServiceClient.addServiceVersion(addedServiceResponse4.getPayload().getId(), addServiceVersionRequest41);
			Assert.assertEquals(addServiceVersionResp41.getStatus(), Status.OK);
			Assert.assertNotNull(addServiceVersionResp41.getPayload());
			
			Service service5 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			service5.setName(namePrefix + time1 + "Test5");
			service5.setCategory(ServiceCategoryType.UTIL.toString());
			
			ServiceRequest<Service> newServiceRequest5 = new ServiceRequest<Service>(
					new ServiceHeader(), service5);
			ServiceResponse<Service> addedServiceResponse5 = registryServiceClient
					.addService(newServiceRequest5);
			Assert.assertEquals(addedServiceResponse5.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse5.getPayload());
			
			ServiceVersion serviceVersion51 = newServiceVersion();
			serviceVersion51.setSerVersion("5.1.0");
			
			ServiceRequest<ServiceVersion> addServiceVersionRequest51 = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion51);
			ServiceResponse<ServiceVersion> addServiceVersionResp51 = registryServiceClient.addServiceVersion(addedServiceResponse5.getPayload().getId(), addServiceVersionRequest51);
			Assert.assertEquals(addServiceVersionResp51.getStatus(), Status.OK);
			Assert.assertNotNull(addServiceVersionResp51.getPayload());
		
			ServiceSearchBean search = new ServiceSearchBean();
			//Search by Status, name and category
			search.setStatus(StatusType.ACTIVE.toString());
			search.setName(String.valueOf(time1));
			search.setCategory(ServiceCategoryType.DATA.toString());
			
			ServiceResponse<ServiceList> searchResponse = registryServiceClient
					.searchServices(search);
			Assert.assertEquals(searchResponse.getStatus(), Status.OK);
			Assert.assertNotNull(searchResponse.getPayload());
			Assert.assertNotNull(searchResponse.getPayload().getServices());
			Assert.assertFalse(searchResponse.getPayload().getServices()
					.isEmpty());

			Assert.assertTrue(contains(searchResponse.getPayload()
					.getServices(), addedServiceResponse1.getPayload().getId()));
			//Service2 not expected as DELETED
			Assert.assertFalse(contains(searchResponse.getPayload()
					.getServices(), addedServiceResponse2.getPayload().getId()));
			Assert.assertTrue(contains(searchResponse.getPayload()
					.getServices(), addedServiceResponse3.getPayload().getId()));
			//Service4 not expected as Name doesn't match
			Assert.assertFalse(contains(searchResponse.getPayload()
					.getServices(), addedServiceResponse4.getPayload().getId()));
			//Service5 not expected as category doesn't match
			Assert.assertFalse(contains(searchResponse.getPayload()
					.getServices(), addedServiceResponse5.getPayload().getId()));
		} catch (Exception ex) {
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testSearchServicesByBeanServiceApplicationId() throws Exception {
		try {
			long time1 = System.currentTimeMillis();
			Service service1 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			String namePrefix= "SearchByStatusNameCategory ";
			service1.setName(namePrefix + time1 + "Test1");
			ServiceRequest<Service> newServiceRequest1 = new ServiceRequest<Service>(
					new ServiceHeader(), service1);
			ServiceResponse<Service> addedServiceResponse1 = registryServiceClient
					.addService(newServiceRequest1);
			Assert.assertEquals(addedServiceResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse1.getPayload());
			
			Service service2 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			service2.setStatus(StatusType.DELETED.toString());
			service2.setName(namePrefix + time1 + "Test2");
			ServiceRequest<Service> newServiceRequest2 = new ServiceRequest<Service>(
					new ServiceHeader(), service2);
			ServiceResponse<Service> addedServiceResponse2 = registryServiceClient
					.addService(newServiceRequest2);
			Assert.assertEquals(addedServiceResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse2.getPayload());
			
			ServiceSearchBean search = new ServiceSearchBean();
			//Search by applicationId
			search.setApplicationId(service1.getApplicationId());
			
			ServiceResponse<ServiceList> searchResponse = registryServiceClient
					.searchServices(search);
			Assert.assertEquals(searchResponse.getStatus(), Status.OK);
			Assert.assertNotNull(searchResponse.getPayload());
			Assert.assertNotNull(searchResponse.getPayload().getServices());
			Assert.assertFalse(searchResponse.getPayload().getServices()
					.isEmpty());

			Assert.assertTrue(contains(searchResponse.getPayload()
					.getServices(), addedServiceResponse1.getPayload().getId()));
			//Service2 not expected as DELETED
			Assert.assertFalse(contains(searchResponse.getPayload()
					.getServices(), addedServiceResponse2.getPayload().getId()));
		} catch (Exception ex) {
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testSearchServicesByBeanServiceStatusNameCategoryVersion() throws Exception {
		try {
			long time1 = System.currentTimeMillis();
			Service service1 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			String namePrefix= "SearchByStatusNameCategoryVersion ";
			service1.setName(namePrefix + time1 + "Test1");
			ServiceRequest<Service> newServiceRequest1 = new ServiceRequest<Service>(
					new ServiceHeader(), service1);
			ServiceResponse<Service> addedServiceResponse1 = registryServiceClient
					.addService(newServiceRequest1);
			Assert.assertEquals(addedServiceResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse1.getPayload());
			
			ServiceVersion serviceVersion11 = newServiceVersion();
			serviceVersion11.setSerVersion("1.1.0");
			
			ServiceRequest<ServiceVersion> addServiceVersionRequest11 = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion11);
			ServiceResponse<ServiceVersion> addServiceVersionResp11 = registryServiceClient.addServiceVersion(addedServiceResponse1.getPayload().getId(), addServiceVersionRequest11);
			Assert.assertEquals(addServiceVersionResp11.getStatus(), Status.OK);
			Assert.assertNotNull(addServiceVersionResp11.getPayload());
			
			Service service2 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			service2.setStatus(StatusType.DELETED.toString());
			service2.setName(namePrefix + time1 + "Test2");
			ServiceRequest<Service> newServiceRequest2 = new ServiceRequest<Service>(
					new ServiceHeader(), service2);
			ServiceResponse<Service> addedServiceResponse2 = registryServiceClient
					.addService(newServiceRequest2);
			Assert.assertEquals(addedServiceResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse2.getPayload());
			
			ServiceVersion serviceVersion21 = newServiceVersion();
			serviceVersion21.setSerVersion("2.1.0");
			
			ServiceRequest<ServiceVersion> addServiceVersionRequest21 = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion21);
			ServiceResponse<ServiceVersion> addServiceVersionResp21 = registryServiceClient.addServiceVersion(addedServiceResponse2.getPayload().getId(), addServiceVersionRequest21);
			Assert.assertEquals(addServiceVersionResp21.getStatus(), Status.OK);
			Assert.assertNotNull(addServiceVersionResp21.getPayload());
		
			Service service3 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			service3.setName(namePrefix + time1 + "Test3");
			ServiceRequest<Service> newServiceRequest3 = new ServiceRequest<Service>(
					new ServiceHeader(), service3);
			ServiceResponse<Service> addedServiceResponse3 = registryServiceClient
					.addService(newServiceRequest3);
			Assert.assertEquals(addedServiceResponse3.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse3.getPayload());
			
			ServiceVersion serviceVersion31 = newServiceVersion();
			serviceVersion31.setSerVersion("3.1.0");
			
			ServiceRequest<ServiceVersion> addServiceVersionRequest31 = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion31);
			ServiceResponse<ServiceVersion> addServiceVersionResp31 = registryServiceClient.addServiceVersion(addedServiceResponse3.getPayload().getId(), addServiceVersionRequest31);
			Assert.assertEquals(addServiceVersionResp31.getStatus(), Status.OK);
			Assert.assertNotNull(addServiceVersionResp31.getPayload());
			
			Service service4 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			service4.setName(namePrefix+" Test4");
			ServiceRequest<Service> newServiceRequest4 = new ServiceRequest<Service>(
					new ServiceHeader(), service4);
			ServiceResponse<Service> addedServiceResponse4 = registryServiceClient
					.addService(newServiceRequest4);
			Assert.assertEquals(addedServiceResponse4.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse4.getPayload());
			
			ServiceVersion serviceVersion41 = newServiceVersion();
			serviceVersion41.setSerVersion("4.1.0");
			
			ServiceRequest<ServiceVersion> addServiceVersionRequest41 = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion41);
			ServiceResponse<ServiceVersion> addServiceVersionResp41 = registryServiceClient.addServiceVersion(addedServiceResponse4.getPayload().getId(), addServiceVersionRequest41);
			Assert.assertEquals(addServiceVersionResp41.getStatus(), Status.OK);
			Assert.assertNotNull(addServiceVersionResp41.getPayload());
			
			Service service5 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			service5.setName(namePrefix + time1 + "Test5");
			service5.setCategory(ServiceCategoryType.UTIL.toString());
			
			ServiceRequest<Service> newServiceRequest5 = new ServiceRequest<Service>(
					new ServiceHeader(), service5);
			ServiceResponse<Service> addedServiceResponse5 = registryServiceClient
					.addService(newServiceRequest5);
			Assert.assertEquals(addedServiceResponse5.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse5.getPayload());
			
			ServiceVersion serviceVersion51 = newServiceVersion();
			serviceVersion51.setSerVersion("5.1.0");
			
			ServiceRequest<ServiceVersion> addServiceVersionRequest51 = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion51);
			ServiceResponse<ServiceVersion> addServiceVersionResp51 = registryServiceClient.addServiceVersion(addedServiceResponse5.getPayload().getId(), addServiceVersionRequest51);
			Assert.assertEquals(addServiceVersionResp51.getStatus(), Status.OK);
			Assert.assertNotNull(addServiceVersionResp51.getPayload());
			
			Service service6 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			service6.setName(namePrefix + time1 + "Test6");
			
			ServiceRequest<Service> newServiceRequest6 = new ServiceRequest<Service>(
					new ServiceHeader(), service6);
			ServiceResponse<Service> addedServiceResponse6 = registryServiceClient
					.addService(newServiceRequest6);
			Assert.assertEquals(addedServiceResponse6.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse6.getPayload());
			
			ServiceVersion serviceVersion61 = newServiceVersion();
			serviceVersion61.setSerVersion("6.1.0");
			
			ServiceRequest<ServiceVersion> addServiceVersionRequest61 = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion61);
			ServiceResponse<ServiceVersion> addServiceVersionResp61 = registryServiceClient.addServiceVersion(addedServiceResponse6.getPayload().getId(), addServiceVersionRequest61);
			Assert.assertEquals(addServiceVersionResp61.getStatus(), Status.OK);
			Assert.assertNotNull(addServiceVersionResp61.getPayload());
		
			ServiceVersion serviceVersion62 = newServiceVersion();
			serviceVersion62.setSerVersion("6.2.0");
			ServiceRequest<ServiceVersion> addServiceVersionRequest62 = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion62);
			ServiceResponse<ServiceVersion> addServiceVersionResp62 = registryServiceClient.addServiceVersion(addedServiceResponse6.getPayload().getId(), addServiceVersionRequest62);
			Assert.assertEquals(addServiceVersionResp62.getStatus(), Status.OK);
			Assert.assertNotNull(addServiceVersionResp62.getPayload());
		
			ServiceSearchBean search = new ServiceSearchBean();
			//Search by Status, name and category
			search.setStatus(StatusType.ACTIVE.toString());
			search.setName(String.valueOf(time1));
			search.setCategory(ServiceCategoryType.DATA.toString());
			search.setSerVersion("6.2.0");
			
			ServiceResponse<ServiceList> searchResponse = registryServiceClient
					.searchServices(search);
			Assert.assertEquals(searchResponse.getStatus(), Status.OK);
			Assert.assertNotNull(searchResponse.getPayload());
			Assert.assertNotNull(searchResponse.getPayload().getServices());
			Assert.assertFalse(searchResponse.getPayload().getServices()
					.isEmpty());

			//Service 1,2,3, 4 & 5 are not expected as doesn't have version 5.0.0
			Assert.assertFalse(contains(searchResponse.getPayload()
					.getServices(), addedServiceResponse1.getPayload().getId()));
			Assert.assertFalse(contains(searchResponse.getPayload()
					.getServices(), addedServiceResponse2.getPayload().getId()));
			Assert.assertFalse(contains(searchResponse.getPayload()
					.getServices(), addedServiceResponse3.getPayload().getId()));
			Assert.assertFalse(contains(searchResponse.getPayload()
					.getServices(), addedServiceResponse4.getPayload().getId()));
			Assert.assertFalse(contains(searchResponse.getPayload()
					.getServices(), addedServiceResponse5.getPayload().getId()));
			Assert.assertTrue(contains(searchResponse.getPayload()
					.getServices(), addedServiceResponse6.getPayload().getId()));
			Assert.assertTrue(contains(searchResponse.getPayload()
					.getServices(), addedServiceResponse6.getPayload().getId()));
			
			service6 = getService(searchResponse.getPayload().getServices(), service6.getName());
			Assert.assertNotNull(service6);
			
			Assert.assertEquals(service6.getServiceVersions().size(), 1);
			Assert.assertNotNull(getServiceVersion(service6.getServiceVersions(), "6.2.0"));
			Assert.assertNull(getServiceVersion(service6.getServiceVersions(), "1.0.0"));
		} catch (Exception ex) {
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testSearchServicesByBeanServiceStatusNameCategoryVersionStatus() throws Exception {
		try {
			long time1 = System.currentTimeMillis();
			String namePrefix= "SearchByStatusNameCategoryVersionStatus ";
			
			Service service1 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			
			service1.setName(namePrefix + time1 + "Test1");
			ServiceRequest<Service> newServiceRequest1 = new ServiceRequest<Service>(
					new ServiceHeader(), service1);
			ServiceResponse<Service> addedServiceResponse1 = registryServiceClient
					.addService(newServiceRequest1);
			Assert.assertEquals(addedServiceResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse1.getPayload());
			
			ServiceVersion serviceVersion11 = newServiceVersion();
			serviceVersion11.setSerVersion("1.1.0");
			
			ServiceRequest<ServiceVersion> addServiceVersionRequest11 = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion11);
			ServiceResponse<ServiceVersion> addServiceVersionResp11 = registryServiceClient.addServiceVersion(addedServiceResponse1.getPayload().getId(), addServiceVersionRequest11);
			Assert.assertEquals(addServiceVersionResp11.getStatus(), Status.OK);
			Assert.assertNotNull(addServiceVersionResp11.getPayload());
			
			Service service2 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			service2.setStatus(StatusType.DELETED.toString());
			service2.setName(namePrefix + time1 + "Test2");
			ServiceRequest<Service> newServiceRequest2 = new ServiceRequest<Service>(
					new ServiceHeader(), service2);
			ServiceResponse<Service> addedServiceResponse2 = registryServiceClient
					.addService(newServiceRequest2);
			Assert.assertEquals(addedServiceResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse2.getPayload());
			
			ServiceVersion serviceVersion21 = newServiceVersion();
			serviceVersion21.setSerVersion("2.1.0");
			
			ServiceRequest<ServiceVersion> addServiceVersionRequest21 = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion21);
			ServiceResponse<ServiceVersion> addServiceVersionResp21 = registryServiceClient.addServiceVersion(addedServiceResponse2.getPayload().getId(), addServiceVersionRequest21);
			Assert.assertEquals(addServiceVersionResp21.getStatus(), Status.OK);
			Assert.assertNotNull(addServiceVersionResp21.getPayload());
		
			Service service3 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			service3.setName(namePrefix + time1 + "Test3");
			ServiceRequest<Service> newServiceRequest3 = new ServiceRequest<Service>(
					new ServiceHeader(), service3);
			ServiceResponse<Service> addedServiceResponse3 = registryServiceClient
					.addService(newServiceRequest3);
			Assert.assertEquals(addedServiceResponse3.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse3.getPayload());
			
			ServiceVersion serviceVersion31 = newServiceVersion();
			serviceVersion31.setSerVersion("3.1.0");
			
			ServiceRequest<ServiceVersion> addServiceVersionRequest31 = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion31);
			ServiceResponse<ServiceVersion> addServiceVersionResp31 = registryServiceClient.addServiceVersion(addedServiceResponse3.getPayload().getId(), addServiceVersionRequest31);
			Assert.assertEquals(addServiceVersionResp31.getStatus(), Status.OK);
			Assert.assertNotNull(addServiceVersionResp31.getPayload());
			
			Service service4 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			service4.setName(namePrefix+" Test4");
			ServiceRequest<Service> newServiceRequest4 = new ServiceRequest<Service>(
					new ServiceHeader(), service4);
			ServiceResponse<Service> addedServiceResponse4 = registryServiceClient
					.addService(newServiceRequest4);
			Assert.assertEquals(addedServiceResponse4.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse4.getPayload());
			
			ServiceVersion serviceVersion41 = newServiceVersion();
			serviceVersion41.setSerVersion("4.1.0");
			
			ServiceRequest<ServiceVersion> addServiceVersionRequest41 = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion41);
			ServiceResponse<ServiceVersion> addServiceVersionResp41 = registryServiceClient.addServiceVersion(addedServiceResponse4.getPayload().getId(), addServiceVersionRequest41);
			Assert.assertEquals(addServiceVersionResp41.getStatus(), Status.OK);
			Assert.assertNotNull(addServiceVersionResp41.getPayload());
			
			Service service5 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			service5.setName(namePrefix + time1 + "Test5");
			service5.setCategory(ServiceCategoryType.UTIL.toString());
			
			ServiceRequest<Service> newServiceRequest5 = new ServiceRequest<Service>(
					new ServiceHeader(), service5);
			ServiceResponse<Service> addedServiceResponse5 = registryServiceClient
					.addService(newServiceRequest5);
			Assert.assertEquals(addedServiceResponse5.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse5.getPayload());
			
			ServiceVersion serviceVersion51 = newServiceVersion();
			serviceVersion51.setSerVersion("5.1.0");
			
			ServiceRequest<ServiceVersion> addServiceVersionRequest51 = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion51);
			ServiceResponse<ServiceVersion> addServiceVersionResp51 = registryServiceClient.addServiceVersion(addedServiceResponse5.getPayload().getId(), addServiceVersionRequest51);
			Assert.assertEquals(addServiceVersionResp51.getStatus(), Status.OK);
			Assert.assertNotNull(addServiceVersionResp51.getPayload());
			
			Service service6 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			service6.setName(namePrefix + time1 + "Test6");
			
			ServiceRequest<Service> newServiceRequest6 = new ServiceRequest<Service>(
					new ServiceHeader(), service6);
			ServiceResponse<Service> addedServiceResponse6 = registryServiceClient
					.addService(newServiceRequest6);
			Assert.assertEquals(addedServiceResponse6.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse6.getPayload());
			
			ServiceVersion serviceVersion61 = newServiceVersion();
			serviceVersion61.setSerVersion("6.1.0");
			
			ServiceRequest<ServiceVersion> addServiceVersionRequest61 = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion61);
			ServiceResponse<ServiceVersion> addServiceVersionResp61 = registryServiceClient.addServiceVersion(addedServiceResponse6.getPayload().getId(), addServiceVersionRequest61);
			Assert.assertEquals(addServiceVersionResp61.getStatus(), Status.OK);
			Assert.assertNotNull(addServiceVersionResp61.getPayload());
		
			ServiceVersion serviceVersion62 = newServiceVersion();
			serviceVersion62.setSerVersion("6.2.0");
			serviceVersion62.setStatus(StatusType.DELETED.toString());
			ServiceRequest<ServiceVersion> addServiceVersionRequest62 = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion62);
			ServiceResponse<ServiceVersion> addServiceVersionResp62 = registryServiceClient.addServiceVersion(addedServiceResponse6.getPayload().getId(), addServiceVersionRequest62);
			Assert.assertEquals(addServiceVersionResp62.getStatus(), Status.OK);
			Assert.assertNotNull(addServiceVersionResp62.getPayload());
		
			ServiceSearchBean search = new ServiceSearchBean();
			//Search by Status, name and category
			search.setStatus(StatusType.ACTIVE.toString());
			search.setName(String.valueOf(time1));
			search.setCategory(ServiceCategoryType.DATA.toString());
			search.setSerVersion("6.2.0");
			search.setVersionStatus(StatusType.ACTIVE.toString());
			
			ServiceResponse<ServiceList> searchResponse = registryServiceClient
					.searchServices(search);
			Assert.assertEquals(searchResponse.getStatus(), Status.OK);
			Assert.assertNotNull(searchResponse.getPayload());
			Assert.assertNotNull(searchResponse.getPayload().getServices());
			Assert.assertTrue(searchResponse.getPayload().getServices()
					.isEmpty());

		} catch (Exception ex) {
			Assert.fail(ex.getMessage());
		}
	}
	@Test(enabled = true)
	public void testSearchServicesByName() throws Exception {
		try {
			long time1 = System.currentTimeMillis();
			Service service1 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			service1.setName("Service " + time1 + "Test1");
			ServiceRequest<Service> newServiceRequest1 = new ServiceRequest<Service>(
					new ServiceHeader(), service1);
			ServiceResponse<Service> addedServiceResponse1 = registryServiceClient
					.addService(newServiceRequest1);
			Assert.assertEquals(addedServiceResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse1.getPayload());

			Service service2 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			service2.setName("Service " + time1 + "Test2");
			ServiceRequest<Service> newServiceRequest2 = new ServiceRequest<Service>(
					new ServiceHeader(), service2);
			ServiceResponse<Service> addedServiceResponse2 = registryServiceClient
					.addService(newServiceRequest2);
			Assert.assertEquals(addedServiceResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse2.getPayload());

			Service service3 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			long time2 = System.currentTimeMillis();
			service3.setName("Service " + time2 + "Test3");
			ServiceRequest<Service> newServiceRequest3 = new ServiceRequest<Service>(
					new ServiceHeader(), service3);
			ServiceResponse<Service> addedServiceResponse3 = registryServiceClient
					.addService(newServiceRequest3);
			Assert.assertEquals(addedServiceResponse3.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse3.getPayload());

			ServiceResponse<ServiceList> searchResponse = registryServiceClient
					.searchServices(SearchFieldType.NAME.toString(),
							String.valueOf(time1));
			Assert.assertEquals(searchResponse.getStatus(), Status.OK);
			Assert.assertNotNull(searchResponse.getPayload());
			Assert.assertNotNull(searchResponse.getPayload().getServices());
			Assert.assertFalse(searchResponse.getPayload().getServices()
					.isEmpty());

			Assert.assertTrue(contains(searchResponse.getPayload()
					.getServices(), addedServiceResponse1.getPayload().getId()));
			Assert.assertTrue(contains(searchResponse.getPayload()
					.getServices(), addedServiceResponse2.getPayload().getId()));
			Assert.assertFalse(contains(searchResponse.getPayload()
					.getServices(), addedServiceResponse3.getPayload().getId()));
		} catch (Exception ex) {
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testSearchServicesByNameCase() throws Exception {
		try {
			long time1 = System.currentTimeMillis();
			Service service1 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			service1.setName("Service " + time1 + "_CASE_Test1");
			ServiceRequest<Service> newServiceRequest1 = new ServiceRequest<Service>(
					new ServiceHeader(), service1);
			ServiceResponse<Service> addedServiceResponse1 = registryServiceClient
					.addService(newServiceRequest1);
			Assert.assertEquals(addedServiceResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse1.getPayload());

			Service service2 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			service2.setName("Service " + time1 + "_case_Test2");
			ServiceRequest<Service> newServiceRequest2 = new ServiceRequest<Service>(
					new ServiceHeader(), service2);
			ServiceResponse<Service> addedServiceResponse2 = registryServiceClient
					.addService(newServiceRequest2);
			Assert.assertEquals(addedServiceResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse2.getPayload());

			Service service3 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			long time2 = System.currentTimeMillis();
			service3.setName("Service " + time2 + "_CASE_Test3");
			ServiceRequest<Service> newServiceRequest3 = new ServiceRequest<Service>(
					new ServiceHeader(), service3);
			ServiceResponse<Service> addedServiceResponse3 = registryServiceClient
					.addService(newServiceRequest3);
			Assert.assertEquals(addedServiceResponse3.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse3.getPayload());

			ServiceResponse<ServiceList> searchResponse = registryServiceClient
					.searchServices(SearchFieldType.NAME.toString(),
							String.valueOf(time1)+"_CASE");
			Assert.assertEquals(searchResponse.getStatus(), Status.OK);
			Assert.assertNotNull(searchResponse.getPayload());
			Assert.assertNotNull(searchResponse.getPayload().getServices());
			Assert.assertFalse(searchResponse.getPayload().getServices()
					.isEmpty());

			Assert.assertTrue(contains(searchResponse.getPayload()
					.getServices(), addedServiceResponse1.getPayload().getId()));
			Assert.assertTrue(contains(searchResponse.getPayload()
					.getServices(), addedServiceResponse2.getPayload().getId()));
			Assert.assertFalse(contains(searchResponse.getPayload()
					.getServices(), addedServiceResponse3.getPayload().getId()));
		} catch (Exception ex) {
			Assert.fail(ex.getMessage());
		}
	}


	@Test(enabled = true)
	public void testSearchServicesByStatus() throws Exception {
		try {
			Service service1 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceRequest<Service> newServiceRequest1 = new ServiceRequest<Service>(
					new ServiceHeader(), service1);
			ServiceResponse<Service> addedServiceResponse1 = registryServiceClient
					.addService(newServiceRequest1);
			Assert.assertEquals(addedServiceResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse1.getPayload());

			Service service2 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceRequest<Service> newServiceRequest2 = new ServiceRequest<Service>(
					new ServiceHeader(), service2);
			ServiceResponse<Service> addedServiceResponse2 = registryServiceClient
					.addService(newServiceRequest2);
			Assert.assertEquals(addedServiceResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse2.getPayload());

			Service service3 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			service3.setStatus(StatusType.DELETED.toString());
			ServiceRequest<Service> newServiceRequest3 = new ServiceRequest<Service>(
					new ServiceHeader(), service3);
			ServiceResponse<Service> addedServiceResponse3 = registryServiceClient
					.addService(newServiceRequest3);
			Assert.assertEquals(addedServiceResponse3.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse3.getPayload());

			ServiceResponse<ServiceList> searchResponse = registryServiceClient
					.searchServices(SearchFieldType.STATUS.toString(),
							StatusType.ACTIVE.toString());
			Assert.assertEquals(searchResponse.getStatus(), Status.OK);
			Assert.assertNotNull(searchResponse.getPayload());
			Assert.assertNotNull(searchResponse.getPayload().getServices());
			Assert.assertFalse(searchResponse.getPayload().getServices()
					.isEmpty());

			Assert.assertTrue(contains(searchResponse.getPayload()
					.getServices(), addedServiceResponse1.getPayload().getId()));
			Assert.assertTrue(contains(searchResponse.getPayload()
					.getServices(), addedServiceResponse2.getPayload().getId()));
			Assert.assertFalse(contains(searchResponse.getPayload()
					.getServices(), addedServiceResponse3.getPayload().getId()));
		} catch (Exception ex) {
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testSearchServicesByStatusCase() throws Exception {
		try {
			Service service1 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceRequest<Service> newServiceRequest1 = new ServiceRequest<Service>(
					new ServiceHeader(), service1);
			ServiceResponse<Service> addedServiceResponse1 = registryServiceClient
					.addService(newServiceRequest1);
			Assert.assertEquals(addedServiceResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse1.getPayload());

			Service service2 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceRequest<Service> newServiceRequest2 = new ServiceRequest<Service>(
					new ServiceHeader(), service2);
			ServiceResponse<Service> addedServiceResponse2 = registryServiceClient
					.addService(newServiceRequest2);
			Assert.assertEquals(addedServiceResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse2.getPayload());

			Service service3 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			service3.setStatus(StatusType.DELETED.toString());
			ServiceRequest<Service> newServiceRequest3 = new ServiceRequest<Service>(
					new ServiceHeader(), service3);
			ServiceResponse<Service> addedServiceResponse3 = registryServiceClient
					.addService(newServiceRequest3);
			Assert.assertEquals(addedServiceResponse3.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse3.getPayload());

			ServiceResponse<ServiceList> searchResponse = registryServiceClient
					.searchServices(SearchFieldType.STATUS.toString(),StatusType.ACTIVE.toString());
			
			Assert.assertEquals(searchResponse.getStatus(), Status.OK);
			Assert.assertNotNull(searchResponse.getPayload());
			Assert.assertNotNull(searchResponse.getPayload().getServices());
			Assert.assertFalse(searchResponse.getPayload().getServices()
					.isEmpty());

			Assert.assertTrue(contains(searchResponse.getPayload()
					.getServices(), addedServiceResponse1.getPayload().getId()));
			Assert.assertTrue(contains(searchResponse.getPayload()
					.getServices(), addedServiceResponse2.getPayload().getId()));
			Assert.assertFalse(contains(searchResponse.getPayload()
					.getServices(), addedServiceResponse3.getPayload().getId()));
		} catch (Exception ex) {
			Assert.fail(ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testSearchServicesByDescription() throws Exception {
		try {
			long time1 = System.currentTimeMillis();
			Service service1 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			service1.setDescription("Service " + time1 + "Test1");
			ServiceRequest<Service> newServiceRequest1 = new ServiceRequest<Service>(
					new ServiceHeader(), service1);
			ServiceResponse<Service> addedServiceResponse1 = registryServiceClient
					.addService(newServiceRequest1);
			Assert.assertEquals(addedServiceResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse1.getPayload());

			Service service2 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			service2.setDescription("Service " + time1 + "Test2");
			ServiceRequest<Service> newServiceRequest2 = new ServiceRequest<Service>(
					new ServiceHeader(), service2);
			ServiceResponse<Service> addedServiceResponse2 = registryServiceClient
					.addService(newServiceRequest2);
			Assert.assertEquals(addedServiceResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse2.getPayload());

			Service service3 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			long time2 = System.currentTimeMillis();
			service3.setDescription("Service " + time2 + "Test3");
			ServiceRequest<Service> newServiceRequest3 = new ServiceRequest<Service>(
					new ServiceHeader(), service3);
			ServiceResponse<Service> addedServiceResponse3 = registryServiceClient
					.addService(newServiceRequest3);
			Assert.assertEquals(addedServiceResponse3.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse3.getPayload());

			ServiceResponse<ServiceList> searchResponse = registryServiceClient
					.searchServices(SearchFieldType.DESCRIPTION.toString(),
							String.valueOf(time1));
			Assert.assertEquals(searchResponse.getStatus(), Status.OK);
			Assert.assertNotNull(searchResponse.getPayload());
			Assert.assertNotNull(searchResponse.getPayload().getServices());
			Assert.assertFalse(searchResponse.getPayload().getServices()
					.isEmpty());

			Assert.assertTrue(contains(searchResponse.getPayload()
					.getServices(), addedServiceResponse1.getPayload().getId()));
			Assert.assertTrue(contains(searchResponse.getPayload()
					.getServices(), addedServiceResponse2.getPayload().getId()));
			Assert.assertFalse(contains(searchResponse.getPayload()
					.getServices(), addedServiceResponse3.getPayload().getId()));
		} catch (Exception ex) {
			Assert.fail(ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testSearchServicesByCategory() throws Exception {
		try {
			Service service1 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceRequest<Service> newServiceRequest1 = new ServiceRequest<Service>(
					new ServiceHeader(), service1);
			ServiceResponse<Service> addedServiceResponse1 = registryServiceClient
					.addService(newServiceRequest1);
			Assert.assertEquals(addedServiceResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse1.getPayload());

			Service service2 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceRequest<Service> newServiceRequest2 = new ServiceRequest<Service>(
					new ServiceHeader(), service2);
			ServiceResponse<Service> addedServiceResponse2 = registryServiceClient
					.addService(newServiceRequest2);
			Assert.assertEquals(addedServiceResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse2.getPayload());

			Service service3 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			service3.setCategory(ServiceCategoryType.BIZ.toString());
			ServiceRequest<Service> newServiceRequest3 = new ServiceRequest<Service>(
					new ServiceHeader(), service3);
			ServiceResponse<Service> addedServiceResponse3 = registryServiceClient
					.addService(newServiceRequest3);
			Assert.assertEquals(addedServiceResponse3.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse3.getPayload());

			ServiceResponse<ServiceList> searchResponse = registryServiceClient
					.searchServices(SearchFieldType.CATEGORY.toString(),
							ServiceCategoryType.DATA.toString());
			Assert.assertEquals(searchResponse.getStatus(), Status.OK);
			Assert.assertNotNull(searchResponse.getPayload());
			Assert.assertNotNull(searchResponse.getPayload().getServices());
			Assert.assertFalse(searchResponse.getPayload().getServices()
					.isEmpty());

			Assert.assertTrue(contains(searchResponse.getPayload()
					.getServices(), addedServiceResponse1.getPayload().getId()));
			Assert.assertTrue(contains(searchResponse.getPayload()
					.getServices(), addedServiceResponse2.getPayload().getId()));
			Assert.assertFalse(contains(searchResponse.getPayload()
					.getServices(), addedServiceResponse3.getPayload().getId()));
		} catch (Exception ex) {
			Assert.fail(ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testSearchServicesByOwner() throws Exception {
		try {
			long time1 = System.currentTimeMillis();
			Service service1 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			service1.setOwner("Service " + time1 + "Test1");
			ServiceRequest<Service> newServiceRequest1 = new ServiceRequest<Service>(
					new ServiceHeader(), service1);
			ServiceResponse<Service> addedServiceResponse1 = registryServiceClient
					.addService(newServiceRequest1);
			Assert.assertEquals(addedServiceResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse1.getPayload());

			Service service2 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			service2.setOwner("Service " + time1 + "Test2");
			ServiceRequest<Service> newServiceRequest2 = new ServiceRequest<Service>(
					new ServiceHeader(), service2);
			ServiceResponse<Service> addedServiceResponse2 = registryServiceClient
					.addService(newServiceRequest2);
			Assert.assertEquals(addedServiceResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse2.getPayload());

			Service service3 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			long time2 = System.currentTimeMillis();
			service3.setOwner("Service " + time2 + "Test3");
			ServiceRequest<Service> newServiceRequest3 = new ServiceRequest<Service>(
					new ServiceHeader(), service3);
			ServiceResponse<Service> addedServiceResponse3 = registryServiceClient
					.addService(newServiceRequest3);
			Assert.assertEquals(addedServiceResponse3.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse3.getPayload());

			ServiceResponse<ServiceList> searchResponse = registryServiceClient
					.searchServices(SearchFieldType.OWNER.toString(),
							String.valueOf(time1));
			Assert.assertEquals(searchResponse.getStatus(), Status.OK);
			Assert.assertNotNull(searchResponse.getPayload());
			Assert.assertNotNull(searchResponse.getPayload().getServices());
			Assert.assertFalse(searchResponse.getPayload().getServices()
					.isEmpty());

			Assert.assertTrue(contains(searchResponse.getPayload()
					.getServices(), addedServiceResponse1.getPayload().getId()));
			Assert.assertTrue(contains(searchResponse.getPayload()
					.getServices(), addedServiceResponse2.getPayload().getId()));
			Assert.assertFalse(contains(searchResponse.getPayload()
					.getServices(), addedServiceResponse3.getPayload().getId()));
		} catch (Exception ex) {
			Assert.fail(ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testSearchServicesByDomain() throws Exception {
		try {
			Service service1 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceRequest<Service> newServiceRequest1 = new ServiceRequest<Service>(
					new ServiceHeader(), service1);
			ServiceResponse<Service> addedServiceResponse1 = registryServiceClient
					.addService(newServiceRequest1);
			Assert.assertEquals(addedServiceResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse1.getPayload());

			Service service2 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceRequest<Service> newServiceRequest2 = new ServiceRequest<Service>(
					new ServiceHeader(), service2);
			ServiceResponse<Service> addedServiceResponse2 = registryServiceClient
					.addService(newServiceRequest2);
			Assert.assertEquals(addedServiceResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse2.getPayload());

			Service service3 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			service3.setDomain(ServiceDomainType.B2C.toString());
			ServiceRequest<Service> newServiceRequest3 = new ServiceRequest<Service>(
					new ServiceHeader(), service3);
			ServiceResponse<Service> addedServiceResponse3 = registryServiceClient
					.addService(newServiceRequest3);
			Assert.assertEquals(addedServiceResponse3.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse3.getPayload());

			ServiceResponse<ServiceList> searchResponse = registryServiceClient
					.searchServices(SearchFieldType.DOMAIN.toString(),
							ServiceDomainType.B2B.toString());
			Assert.assertEquals(searchResponse.getStatus(), Status.OK);
			Assert.assertNotNull(searchResponse.getPayload());
			Assert.assertNotNull(searchResponse.getPayload().getServices());
			Assert.assertFalse(searchResponse.getPayload().getServices()
					.isEmpty());

			Assert.assertTrue(contains(searchResponse.getPayload()
					.getServices(), addedServiceResponse1.getPayload().getId()));
			Assert.assertTrue(contains(searchResponse.getPayload()
					.getServices(), addedServiceResponse2.getPayload().getId()));
			Assert.assertFalse(contains(searchResponse.getPayload()
					.getServices(), addedServiceResponse3.getPayload().getId()));
		} catch (Exception ex) {
			Assert.fail(ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testSearchServicesByUsage() throws Exception {
		try {
			Service service1 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceRequest<Service> newServiceRequest1 = new ServiceRequest<Service>(
					new ServiceHeader(), service1);
			ServiceResponse<Service> addedServiceResponse1 = registryServiceClient
					.addService(newServiceRequest1);
			Assert.assertEquals(addedServiceResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse1.getPayload());

			Service service2 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceRequest<Service> newServiceRequest2 = new ServiceRequest<Service>(
					new ServiceHeader(), service2);
			ServiceResponse<Service> addedServiceResponse2 = registryServiceClient
					.addService(newServiceRequest2);
			Assert.assertEquals(addedServiceResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse2.getPayload());

			Service service3 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			service3.setUsage(ServiceUseType.EXTERNAL.toString());
			ServiceRequest<Service> newServiceRequest3 = new ServiceRequest<Service>(
					new ServiceHeader(), service3);
			ServiceResponse<Service> addedServiceResponse3 = registryServiceClient
					.addService(newServiceRequest3);
			Assert.assertEquals(addedServiceResponse3.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse3.getPayload());

			ServiceResponse<ServiceList> searchResponse = registryServiceClient
					.searchServices(SearchFieldType.USAGE.toString(),
							ServiceUseType.INTERNAL.toString());
			Assert.assertEquals(searchResponse.getStatus(), Status.OK);
			Assert.assertNotNull(searchResponse.getPayload());
			Assert.assertNotNull(searchResponse.getPayload().getServices());
			Assert.assertFalse(searchResponse.getPayload().getServices()
					.isEmpty());

			Assert.assertTrue(contains(searchResponse.getPayload()
					.getServices(), addedServiceResponse1.getPayload().getId()));
			Assert.assertTrue(contains(searchResponse.getPayload()
					.getServices(), addedServiceResponse2.getPayload().getId()));
			Assert.assertFalse(contains(searchResponse.getPayload()
					.getServices(), addedServiceResponse3.getPayload().getId()));
		} catch (Exception ex) {
			Assert.fail(ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testAddService() throws Exception {
		try {
		
			Service service = newService(cmdbArtifacts.get(artifactIndex++).getCode());
	//		service.setJiraProject(jiraProjects.get(0).getCode());
			
	//		service.getNotificationTypes().add(NotificationDestinationType.JIRA.toString());
			service.getNotificationTypes().add(NotificationDestinationType.JMS.toString());
		
			ServiceRequest<Service> newServiceRequest = new ServiceRequest<Service>(
					new ServiceHeader(), service);
			ServiceResponse<Service> addedServiceResponse = registryServiceClient
					.addService(newServiceRequest);
			Assert.assertEquals(addedServiceResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse.getPayload());
			Assert.assertFalse(addedServiceResponse.getPayload().getNotificationRequested());
			Assert.assertNotNull(addedServiceResponse.getPayload().getNotificationFor());
			Assert.assertFalse(addedServiceResponse.getPayload().getNotificationFor().isEmpty());
			Assert.assertNotNull(addedServiceResponse.getPayload().getNotificationTypes());
			Assert.assertFalse(addedServiceResponse.getPayload().getNotificationTypes().isEmpty());
	//		Assert.assertEquals(addedServiceResponse.getPayload().getNotificationFor().size(), 2);
	//		Assert.assertEquals(addedServiceResponse.getPayload().getNotificationTypes().size(), 2);
	
			ServiceResponse<Service> getServiceResponse = registryServiceClient.getService(addedServiceResponse.getPayload().getId());
			Assert.assertEquals(getServiceResponse.getStatus(), Status.OK);
			Assert.assertNotNull(getServiceResponse.getPayload());
			Assert.assertFalse(getServiceResponse.getPayload().getNotificationRequested());
			Assert.assertNotNull(getServiceResponse.getPayload().getNotificationFor());
			Assert.assertFalse(getServiceResponse.getPayload().getNotificationFor().isEmpty());
			Assert.assertNotNull(getServiceResponse.getPayload().getNotificationTypes());
			Assert.assertFalse(getServiceResponse.getPayload().getNotificationTypes().isEmpty());
	//		Assert.assertEquals(getServiceResponse.getPayload().getNotificationFor().size(), 2);
	//		Assert.assertEquals(getServiceResponse.getPayload().getNotificationTypes().size(), 2);
	//		Assert.assertEquals(getServiceResponse.getPayload().getJiraProject(), jiraProjects.get(0).getCode());
			
		} catch (Exception ex) {
			System.out.println("Error = "+ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testAddServiceEmailNotification() throws Exception {
		try {
		
			//NotificationDestination notificationDestination1 = addEmailNotificationDestination("EMAIL NOTIFICATION");
			
			Service service = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			service.setNotificationRequested(true);service.setOwner("sbonde@walmartlabs.com");
		//	service.setJiraProject(jiraProjects.get(0).getCode());
			
			//service.getNotificationTypes().add(notificationDestination1.getName());
			service.getNotificationTypes().add(NotificationDestinationType.EMAIL.toString());
		
			ServiceRequest<Service> newServiceRequest = new ServiceRequest<Service>(
					new ServiceHeader(), service);
			ServiceResponse<Service> addedServiceResponse = registryServiceClient
					.addService(newServiceRequest);
			Assert.assertEquals(addedServiceResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse.getPayload());
			Assert.assertTrue(addedServiceResponse.getPayload().getNotificationRequested());
			Assert.assertNotNull(addedServiceResponse.getPayload().getNotificationFor());
			Assert.assertFalse(addedServiceResponse.getPayload().getNotificationFor().isEmpty());
			Assert.assertNotNull(addedServiceResponse.getPayload().getNotificationTypes());
			Assert.assertFalse(addedServiceResponse.getPayload().getNotificationTypes().isEmpty());
			Assert.assertEquals(addedServiceResponse.getPayload().getNotificationFor().size(), 2);
			Assert.assertEquals(addedServiceResponse.getPayload().getNotificationTypes().size(), 1);
	
			ServiceResponse<Service> getServiceResponse = registryServiceClient.getService(addedServiceResponse.getPayload().getId());
			Assert.assertEquals(getServiceResponse.getStatus(), Status.OK);
			Assert.assertNotNull(getServiceResponse.getPayload());
			Assert.assertTrue(getServiceResponse.getPayload().getNotificationRequested());
			Assert.assertNotNull(getServiceResponse.getPayload().getNotificationFor());
			Assert.assertFalse(getServiceResponse.getPayload().getNotificationFor().isEmpty());
			Assert.assertNotNull(getServiceResponse.getPayload().getNotificationTypes());
			Assert.assertFalse(getServiceResponse.getPayload().getNotificationTypes().isEmpty());
			Assert.assertEquals(getServiceResponse.getPayload().getNotificationFor().size(), 2);
			Assert.assertEquals(getServiceResponse.getPayload().getNotificationTypes().size(), 1);
		//	Assert.assertEquals(getServiceResponse.getPayload().getJiraProject(), jiraProjects.get(0).getCode());
			
		} catch (Exception ex) {
			ex.printStackTrace();
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testAddServiceNotificationRequested() throws Exception {
		try {
			Service service = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			service.setNotificationRequested(true);
			ServiceRequest<Service> newServiceRequest = new ServiceRequest<Service>(
					new ServiceHeader(), service);
			ServiceResponse<Service> addedServiceResponse = registryServiceClient
					.addService(newServiceRequest);
			Assert.assertEquals(addedServiceResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse.getPayload());
			Assert.assertTrue(addedServiceResponse.getPayload().getNotificationRequested());
		} catch (Exception ex) {
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testAddServiceCascade() throws Exception {
		try {
			Service service = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceVersion serviceVersion1 = newServiceVersion();
			QoS qos1 = addQoS();
			serviceVersion1.getQoSParameters().add(qos1);
			service.getServiceVersions().add(serviceVersion1);
			
			ServiceRequest<Service> newServiceRequest = new ServiceRequest<Service>(
					new ServiceHeader(), service);
			ServiceResponse<Service> addedServiceResponse = registryServiceClient
					.addService(newServiceRequest);
			Assert.assertEquals(addedServiceResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse.getPayload());
			Assert.assertTrue(!addedServiceResponse.getPayload().getServiceVersions().isEmpty());
			Assert.assertEquals(addedServiceResponse.getPayload().getServiceVersions().size(), 1);
			serviceVersion1 = getServiceVersion(addedServiceResponse.getPayload().getServiceVersions(), serviceVersion1.getSerVersion());
			Assert.assertNotNull(serviceVersion1);
			Assert.assertTrue(!serviceVersion1.getQoSParameters().isEmpty());
		} catch (Exception ex) {
			Assert.fail(ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testAddServiceCheckDuplicateSameEnv() throws Exception {
		try {
			Service service1 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			String name = service1.getName();
			ServiceRequest<Service> newServiceRequest1 = new ServiceRequest<Service>(
					new ServiceHeader(), service1);
			ServiceResponse<Service> addedServiceResponse1 = registryServiceClient
					.addService(newServiceRequest1);
			Assert.assertEquals(addedServiceResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse1.getPayload());

			Service service2 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			service2.setName(name);
			ServiceRequest<Service> newServiceRequest2 = new ServiceRequest<Service>(
					new ServiceHeader(), service2);
			ServiceResponse<Service> addedServiceResponse2 = registryServiceClient
					.addService(newServiceRequest2);
			Assert.assertEquals(addedServiceResponse2.getStatus(), Status.FAIL);
			Assert.assertNull(addedServiceResponse2.getPayload());
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.assertTrue(true, ex.getMessage());
		}
	}
	
	/**
	 * This test case should fail as there cannot be multiple services with same environment and applicationId
	 * Same environment
	 * Same applicationid
	 * Different name
	 * @throws Exception
	 */
	@Test(enabled = true)
	public void testAddServiceCheckDuplicateSameEnvArtifactIdDifferentName() throws Exception {
		try {
			Service service1 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceRequest<Service> newServiceRequest1 = new ServiceRequest<Service>(
					new ServiceHeader(), service1);
			ServiceResponse<Service> addedServiceResponse1 = registryServiceClient
					.addService(newServiceRequest1);
			Assert.assertEquals(addedServiceResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse1.getPayload());

			Service service2 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			service2.setApplicationId(service1.getApplicationId());
			ServiceRequest<Service> newServiceRequest2 = new ServiceRequest<Service>(
					new ServiceHeader(), service2);
			ServiceResponse<Service> addedServiceResponse2 = registryServiceClient
					.addService(newServiceRequest2);
			Assert.assertEquals(addedServiceResponse2.getStatus(), Status.FAIL);
			Assert.assertNull(addedServiceResponse2.getPayload());
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.assertTrue(true, ex.getMessage());
		}
	}
	
	/**
	 * This test case should fail as there cannot be multiple services with same environment and name
	 * Same environment
	 * Different applicationid
	 * Same name
	 * @throws Exception
	 */
	@Test(enabled = true)
	public void testAddServiceCheckDuplicateSameEnvNameDifferentArtifactId() throws Exception {
		try {
			Service service1 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceRequest<Service> newServiceRequest1 = new ServiceRequest<Service>(
					new ServiceHeader(), service1);
			ServiceResponse<Service> addedServiceResponse1 = registryServiceClient
					.addService(newServiceRequest1);
			Assert.assertEquals(addedServiceResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse1.getPayload());

			Service service2 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			service2.setName(service1.getName());
			service2.setApplicationId("different appId");
			ServiceRequest<Service> newServiceRequest2 = new ServiceRequest<Service>(
					new ServiceHeader(), service2);
			ServiceResponse<Service> addedServiceResponse2 = registryServiceClient
					.addService(newServiceRequest2);
			Assert.assertEquals(addedServiceResponse2.getStatus(), Status.FAIL);
			Assert.assertNull(addedServiceResponse2.getPayload());
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.assertTrue(true, ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testAddServiceCheckDuplicateDifferentEnv() throws Exception {
		try {
			Service service1 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			String name = service1.getName();
			ServiceRequest<Service> newServiceRequest1 = new ServiceRequest<Service>(
					new ServiceHeader(), service1);
			ServiceResponse<Service> addedServiceResponse1 = registryServiceClient
					.addService(newServiceRequest1);
			Assert.assertEquals(addedServiceResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse1.getPayload());
			Assert.assertEquals(addedServiceResponse1.getPayload().getEnvironment(), "default");

			Service service2 = newService(cmdbArtifacts.get(artifactIndex++).getCode());service2.setEnvironment("dev");
			service2.setName(name);
			ServiceRequest<Service> newServiceRequest2 = new ServiceRequest<Service>(
					new ServiceHeader(), service2);
			ServiceResponse<Service> addedServiceResponse2 = registryServiceClient
					.addService(newServiceRequest2);
			Assert.assertEquals(addedServiceResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse2.getPayload());
			Assert.assertEquals(addedServiceResponse2.getPayload().getEnvironment(), "dev");
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testAddServiceWithServiceVersion() throws Exception {
		try {
			Service service = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceVersion serviceVersion = newServiceVersion();
			service.getServiceVersions().add(serviceVersion);
			ServiceRequest<Service> newServiceRequest = new ServiceRequest<Service>(
					new ServiceHeader(), service);
			ServiceResponse<Service> addedServiceResponse = registryServiceClient
					.addService(newServiceRequest);
			Assert.assertNotNull(addedServiceResponse.getPayload());
			Assert.assertEquals(addedServiceResponse.getStatus(), Status.OK);
			Assert.assertEquals(addedServiceResponse.getPayload()
					.getServiceVersions().size(), 1);
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testGetServices() throws Exception {
		try {
			Service service1 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceRequest<Service> newServiceRequest1 = new ServiceRequest<Service>(
					new ServiceHeader(), service1);
			ServiceResponse<Service> addedServiceResponse1 = registryServiceClient
					.addService(newServiceRequest1);
			Assert.assertEquals(addedServiceResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse1.getPayload());
			service1 = addedServiceResponse1.getPayload();
			
			Service service2 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceRequest<Service> newServiceRequest2 = new ServiceRequest<Service>(
					new ServiceHeader(), service2);
			ServiceResponse<Service> addedServiceResponse2 = registryServiceClient
					.addService(newServiceRequest2);
			Assert.assertEquals(addedServiceResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse2.getPayload());
			service2 = addedServiceResponse2.getPayload();
			
			ServiceResponse<ServiceList> services = registryServiceClient.getServices();

			Assert.assertEquals(services.getStatus(), Status.OK);
			Assert.assertNotNull(services.getPayload());
			Assert.assertTrue(!services.getPayload().getServices().isEmpty());
			Assert.assertTrue(!services.getPayload().getServices().isEmpty());
			Assert.assertTrue(contains(services.getPayload().getServices(), service1.getId()));
			Assert.assertTrue(contains(services.getPayload().getServices(), service2.getId()));

		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testGetActiveServices() throws Exception {
		try {
			Service service1 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceRequest<Service> newServiceRequest1 = new ServiceRequest<Service>(
					new ServiceHeader(), service1);
			ServiceResponse<Service> addedServiceResponse1 = registryServiceClient
					.addService(newServiceRequest1);
			Assert.assertEquals(addedServiceResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse1.getPayload());
			service1 = addedServiceResponse1.getPayload();
					
			Service service2 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			service2.setStatus(StatusType.INACTIVE.toString());
			ServiceRequest<Service> newServiceRequest2 = new ServiceRequest<Service>(
					new ServiceHeader(), service2);
			ServiceResponse<Service> addedServiceResponse2 = registryServiceClient
					.addService(newServiceRequest2);
			Assert.assertEquals(addedServiceResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse2.getPayload());
			service2 = addedServiceResponse2.getPayload();
			
			ServiceResponse<ServiceList> services = registryServiceClient.searchServices(SearchFieldType.STATUS.toString(),StatusType.ACTIVE.toString());


			Assert.assertEquals(services.getStatus(), Status.OK);
			Assert.assertNotNull(services.getPayload());
			Assert.assertTrue(!services.getPayload().getServices().isEmpty());
			Assert.assertTrue(contains(services.getPayload().getServices(), service1.getId()));
			Assert.assertFalse(contains(services.getPayload().getServices(), service2.getId()));
				
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testGetDeletedServices() throws Exception {
		try {
			Service service1 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceRequest<Service> newServiceRequest1 = new ServiceRequest<Service>(
					new ServiceHeader(), service1);
			ServiceResponse<Service> addedServiceResponse1 = registryServiceClient
					.addService(newServiceRequest1);
			Assert.assertEquals(addedServiceResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse1.getPayload());
			service1 = addedServiceResponse1.getPayload();
					
			Service service2 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			service2.setStatus(StatusType.DELETED.toString());
			ServiceRequest<Service> newServiceRequest2 = new ServiceRequest<Service>(
					new ServiceHeader(), service2);
			ServiceResponse<Service> addedServiceResponse2 = registryServiceClient
					.addService(newServiceRequest2);
			Assert.assertEquals(addedServiceResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse2.getPayload());
			service2 = addedServiceResponse2.getPayload();
			
			ServiceResponse<ServiceList> services = registryServiceClient.searchServices(SearchFieldType.STATUS.toString(),StatusType.DELETED.toString());

			Assert.assertEquals(services.getStatus(), Status.OK);
			Assert.assertNotNull(services.getPayload());
			Assert.assertTrue(!services.getPayload().getServices().isEmpty());
			Assert.assertFalse(contains(services.getPayload().getServices(), service1.getId()));
			Assert.assertTrue(contains(services.getPayload().getServices(), service2.getId()));
				
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testGetAvailableServices() throws Exception {
		try {
			Service service1 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceRequest<Service> newServiceRequest1 = new ServiceRequest<Service>(
					new ServiceHeader(), service1);
			ServiceResponse<Service> addedServiceResponse1 = registryServiceClient
					.addService(newServiceRequest1);
			Assert.assertEquals(addedServiceResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse1.getPayload());
			service1 = addedServiceResponse1.getPayload();
					
			Service service2 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			service2.setStatus(StatusType.INACTIVE.toString());
			ServiceRequest<Service> newServiceRequest2 = new ServiceRequest<Service>(
					new ServiceHeader(), service2);
			ServiceResponse<Service> addedServiceResponse2 = registryServiceClient
					.addService(newServiceRequest2);
			Assert.assertEquals(addedServiceResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse2.getPayload());
			service2 = addedServiceResponse2.getPayload();

			Service service3 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			service3.setStatus(StatusType.DELETED.toString());
			ServiceRequest<Service> newServiceRequest3 = new ServiceRequest<Service>(
					new ServiceHeader(), service3);
			ServiceResponse<Service> addedServiceResponse3 = registryServiceClient
					.addService(newServiceRequest3);
			Assert.assertEquals(addedServiceResponse3.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse3.getPayload());
			service3 = addedServiceResponse3.getPayload();

			ServiceResponse<ServiceList> services = registryServiceClient.searchServices(SearchFieldType.STATUS.toString(), StatusType.AVAILABLE.toString());

			Assert.assertEquals(services.getStatus(), Status.OK);
			Assert.assertNotNull(services.getPayload());
			Assert.assertTrue(!services.getPayload().getServices().isEmpty());
			Assert.assertTrue(contains(services.getPayload().getServices(), service1.getId()));
			Assert.assertTrue(contains(services.getPayload().getServices(), service2.getId()));
			Assert.assertFalse(contains(services.getPayload().getServices(), service3.getId()));
				
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	
	@Test(enabled = true)
	public void testGetServiceById() throws Exception {
		try {
			Service service1 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceRequest<Service> newServiceRequest1 = new ServiceRequest<Service>(
					new ServiceHeader(), service1);
			ServiceResponse<Service> addedServiceResponse1 = registryServiceClient
					.addService(newServiceRequest1);
			Assert.assertEquals(addedServiceResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse1.getPayload());
			service1 = addedServiceResponse1.getPayload();
			
			ServiceResponse<Service>  getServiceResp = registryServiceClient.getService(service1.getId());

			Assert.assertEquals(getServiceResp.getStatus(), Status.OK);
			Assert.assertNotNull(getServiceResp.getPayload());
	
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testGetServicesByApplicationId() throws Exception {
		try {
			Service service1 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceRequest<Service> newServiceRequest1 = new ServiceRequest<Service>(
					new ServiceHeader(), service1);
			ServiceResponse<Service> addedServiceResponse1 = registryServiceClient
					.addService(newServiceRequest1);
			Assert.assertEquals(addedServiceResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse1.getPayload());

			Service service2 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			service2.setApplicationId(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceRequest<Service> newServiceRequest2 = new ServiceRequest<Service>(
					new ServiceHeader(), service2);
			ServiceResponse<Service> addedServiceResponse2 = registryServiceClient
					.addService(newServiceRequest2);
			Assert.assertEquals(addedServiceResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse2.getPayload());

			ServiceResponse<ServiceList> services = registryServiceClient.searchServices(SearchFieldType.APPLICATION.toString(), service1.getApplicationId());

			Assert.assertEquals(services.getStatus(), Status.OK);
			Assert.assertNotNull(services.getPayload());
			Assert.assertEquals(services.getPayload().getServices().size(), 1);
			Service service = getService(services.getPayload().getServices(),
					service2.getName());
			Assert.assertNull(service);
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	

	@Test(enabled = true)
	public void testUpdateService() throws Exception {
		try {
			long now = System.currentTimeMillis();
			Service service = newService(cmdbArtifacts.get(artifactIndex++).getCode());service.setOwner("sbonde@walmartlabs.com");
			service.getNotificationFor().add(AuditType.UPDATE_SERVICE.toString());
			service.setNotificationRequested(true);
			/*NotificationDestination notificationDestination1 = addNotificationDestination("NOTIFICATION_DESTINATION11");
			NotificationDestination notificationDestination2 = addNotificationDestination("NOTIFICATION_DESTINATION12");*/
		//	service.getNotificationTypes().add(NotificationDestinationType.JIRA.toString());
			service.getNotificationTypes().add(NotificationDestinationType.JMS.toString());
			
			ServiceRequest<Service> newServiceRequest = new ServiceRequest<Service>(
					new ServiceHeader(), service);
			ServiceResponse<Service> addedServiceResponse = registryServiceClient
					.addService(newServiceRequest);
			Assert.assertEquals(addedServiceResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse.getPayload());
			service = addedServiceResponse.getPayload();
			//Assert.assertFalse(service.getNotificationRequested());
			Assert.assertNotNull(service.getNotificationFor());
			Assert.assertFalse(service.getNotificationFor().isEmpty());
	//		Assert.assertTrue(service.getNotificationFor().size() == 3);
			Assert.assertFalse(service.getNotificationTypes().isEmpty());
	//		Assert.assertTrue(service.getNotificationTypes().size() == 2);
			
			String updatedName = "NEW_NAME_" + now;
			String updatedAppId = cmdbArtifacts.get(artifactIndex++).getCode();
			String updatedCategory = ServiceCategoryType.BIZ.toString();
			String updatedDesc = "NEW_DESC";
			String updatedDomain = ServiceDomainType.B2C.toString();
			//String updatedOwner = "NEW_OWNER";
			String updatedOwner = service.getOwner();
			String updatedStatus = StatusType.INACTIVE.toString();
			String updatedUsage = ServiceUseType.EXTERNAL.toString();
			service.setApplicationId(updatedAppId);
			service.setCategory(updatedCategory);
			service.setDescription(updatedDesc);
			service.setDomain(updatedDomain);
			service.setName(updatedName);
			service.setOwner(updatedOwner);
			service.setStatus(updatedStatus);
			service.setUsage(updatedUsage);
			service.setNotificationRequested(true);
			service.getNotificationFor().add(AuditType.UPDATE_QOS.toString());
			service.setEnvironment("abc");
			
			/*NotificationDestination notificationDestination3 = addEmailNotificationDestination("NOTIFICATION_DESTINATION13");

			service.getNotificationTypes().add(notificationDestination3.getName());*/
			service.getNotificationTypes().add(NotificationDestinationType.EMAIL.toString());
			ServiceRequest<Service> updateRequest = new ServiceRequest<Service>(
					new ServiceHeader(), service);

			ServiceResponse<Service> updateResp = registryServiceClient
					.updateService(updateRequest);

			Assert.assertEquals(updateResp.getStatus(), Status.OK);
			Assert.assertNotNull(updateResp.getPayload());
			Assert.assertEquals(updateResp.getPayload().getName(), updatedName);
			Assert.assertEquals(updateResp.getPayload().getApplicationId(),
					updatedAppId);
			Assert.assertEquals(updateResp.getPayload().getCategory(),
					updatedCategory);
			Assert.assertEquals(updateResp.getPayload().getDescription(),
					updatedDesc);
			Assert.assertEquals(updateResp.getPayload().getDomain(),
					updatedDomain);
			Assert.assertEquals(updateResp.getPayload().getOwner(),
					updatedOwner);
			Assert.assertEquals(updateResp.getPayload().getStatus(),
					updatedStatus);
			Assert.assertEquals(updateResp.getPayload().getUsage(),
					updatedUsage);
			Assert.assertTrue(updateResp.getPayload().getNotificationRequested());
	//		Assert.assertTrue(updateResp.getPayload().getNotificationFor().size() == 4);
	//		Assert.assertTrue(updateResp.getPayload().getNotificationTypes().size() == 3);
			Assert.assertEquals(updateResp.getPayload().getEnvironment(),
					"abc");
				
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testUpdateServiceStatusExistingWithServiceVersion()
			throws Exception {
		try {
			long now = System.currentTimeMillis();
			Service service = newService(cmdbArtifacts.get(artifactIndex++).getCode());

			ServiceRequest<Service> newServiceRequest = new ServiceRequest<Service>(
					new ServiceHeader(), service);
			ServiceResponse<Service> addedServiceResponse = registryServiceClient
					.addService(newServiceRequest);
			Assert.assertEquals(addedServiceResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse.getPayload());
			service = addedServiceResponse.getPayload();

			// Add ServiceVersion to test it is not affected by update Service
			ServiceVersion serviceVersion1 = newServiceVersion();
			ServiceRequest<ServiceVersion> addServiceVersionReq = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion1);
			ServiceResponse<ServiceVersion> addServiceVersionResp = registryServiceClient
					.addServiceVersion(service.getId(), addServiceVersionReq);
			Assert.assertEquals(addServiceVersionResp.getStatus(), Status.OK);
			Assert.assertNotNull(addServiceVersionResp.getPayload());

			
			ServiceResponse<Service> getServiceResp = registryServiceClient.getService(service.getId());
			Assert.assertEquals(getServiceResp.getStatus(), Status.OK);
			Assert.assertNotNull(getServiceResp.getPayload());
			Assert.assertEquals(getServiceResp.getPayload().getServiceVersions()
					.size(), 1);
		
			service = getServiceResp.getPayload();
			
			String updatedName = "NEW_NAME_" + now;
			String updatedCategory = ServiceCategoryType.BIZ.toString();
			String updatedDesc = "NEW_DESC";
			String updatedDomain = ServiceDomainType.B2C.toString();
			String updatedOwner = "NEW_OWNER";
			String updatedStatus = StatusType.INACTIVE.toString();
			String updatedUsage = ServiceUseType.EXTERNAL.toString();
			service.setCategory(updatedCategory);
			service.setDescription(updatedDesc);
			service.setDomain(updatedDomain);
			service.setName(updatedName);
			service.setOwner(updatedOwner);
			service.setStatus(updatedStatus);
			service.setUsage(updatedUsage);
			ServiceRequest<Service> updateRequest = new ServiceRequest<Service>(
					new ServiceHeader(), service);

			ServiceResponse<Service> updateResp = registryServiceClient
					.updateService(updateRequest);

			Assert.assertEquals(updateResp.getStatus(), Status.OK);
			Assert.assertNotNull(updateResp.getPayload());
			Assert.assertEquals(updateResp.getPayload().getServiceVersions()
					.size(), 1);
			Assert.assertEquals(updateResp.getPayload().getServiceVersions()
					.get(0).getSerVersion(), serviceVersion1.getSerVersion());
			Assert.assertEquals(updateResp.getPayload().getName(), updatedName);
			Assert.assertEquals(updateResp.getPayload().getCategory(),
					updatedCategory);
			Assert.assertEquals(updateResp.getPayload().getDescription(),
					updatedDesc);
			Assert.assertEquals(updateResp.getPayload().getDomain(),
					updatedDomain);
			Assert.assertEquals(updateResp.getPayload().getOwner(),
					updatedOwner);
			Assert.assertEquals(updateResp.getPayload().getStatus(),
					updatedStatus);
			Assert.assertEquals(updateResp.getPayload().getUsage(),
					updatedUsage);
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testUpdateServiceExistingWithServiceVersion()
			throws Exception {
		try {
			Service service = newService(cmdbArtifacts.get(artifactIndex++).getCode());

			ServiceRequest<Service> newServiceRequest = new ServiceRequest<Service>(
					new ServiceHeader(), service);
			ServiceResponse<Service> addedServiceResponse = registryServiceClient
					.addService(newServiceRequest);
			Assert.assertEquals(addedServiceResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse.getPayload());
			service = addedServiceResponse.getPayload();
			Assert.assertEquals(service.getServiceVersions().size(), 0);
			Assert.assertEquals(service.getNotificationFor().size(), 2);
				
			// Add ServiceVersion to test it is not affected by update Service
			ServiceVersion serviceVersion1 = newServiceVersion();
			ServiceRequest<ServiceVersion> addServiceVersionReq = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion1);
			ServiceResponse<ServiceVersion> addServiceVersionResp = registryServiceClient
					.addServiceVersion(service.getId(), addServiceVersionReq);
			Assert.assertEquals(addServiceVersionResp.getStatus(), Status.OK);
			Assert.assertNotNull(addServiceVersionResp.getPayload());
			
			ServiceResponse<Service> getServicResp = registryServiceClient.getService(service.getId());
			Assert.assertEquals(getServicResp.getStatus(), Status.OK);
			Assert.assertNotNull(getServicResp.getPayload());
			service = getServicResp.getPayload();
			Assert.assertEquals(service.getServiceVersions().size(), 1);
			Assert.assertEquals(service.getNotificationFor().size(), 2);
			service.setModifiedBy("Test Modifier");
			service.setDescription("test_desc");
			
			serviceVersion1 = service.getServiceVersions().get(0);
			serviceVersion1.setSerVersion("3.0.0");
			ServiceVersion serviceVersion2 = newServiceVersion();
			serviceVersion2.setSerVersion(TEST_SERVICE_VERSION_2);
			service.getServiceVersions().add(serviceVersion2);
			ServiceRequest<Service> updateServiceReq = new ServiceRequest<Service>(
					new ServiceHeader(), service);
			ServiceResponse<Service> updateServiceResp = registryServiceClient.updateService(updateServiceReq);
			Assert.assertEquals(updateServiceResp.getStatus(), Status.OK);
			Assert.assertNotNull(updateServiceResp.getPayload());
			Assert.assertEquals(updateServiceResp.getPayload().getServiceVersions().size(), 2);
			
			ServiceResponse<Service> getServiceResp = registryServiceClient.getService(service.getId());
			Assert.assertEquals(getServiceResp.getStatus(), Status.OK);
			Assert.assertNotNull(getServiceResp.getPayload());
			Assert.assertEquals(getServiceResp.getPayload().getServiceVersions().size(), 2);
			
			serviceVersion1 = getServiceVersion(getServiceResp.getPayload().getServiceVersions(), "3.0.0");
			Assert.assertNotNull(serviceVersion1);
				
			ServiceResponse<Service> updateResp = registryServiceClient.updateServiceStatus(service.getId(), "INACTIVATE","test_user");

			Assert.assertEquals(updateResp.getStatus(), Status.OK);
			Assert.assertNotNull(updateResp.getPayload());
			Assert.assertEquals(updateResp.getPayload().getServiceVersions()
					.size(), 2);
			Assert.assertEquals(updateResp.getPayload().getStatus(), StatusType.INACTIVE.toString());
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testActionServiceStatusExistingWithServiceVersion()
			throws Exception {
		try {
			Service service = newService(cmdbArtifacts.get(artifactIndex++).getCode());

			ServiceRequest<Service> newServiceRequest = new ServiceRequest<Service>(
					new ServiceHeader(), service);
			ServiceResponse<Service> addedServiceResponse = registryServiceClient
					.addService(newServiceRequest);
			Assert.assertEquals(addedServiceResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse.getPayload());
			service = addedServiceResponse.getPayload();
			Assert.assertEquals(service.getServiceVersions().size(), 0);
			
			// Add ServiceVersion to test it is not affected by update Service
			ServiceVersion serviceVersion1 = newServiceVersion();
			ServiceRequest<ServiceVersion> addServiceVersionReq = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion1);
			ServiceResponse<ServiceVersion> addServiceVersionResp = registryServiceClient
					.addServiceVersion(service.getId(), addServiceVersionReq);
			Assert.assertEquals(addServiceVersionResp.getStatus(), Status.OK);
			Assert.assertNotNull(addServiceVersionResp.getPayload());
			
			ServiceResponse<Service> getServicResp = registryServiceClient.getService(service.getId());
			Assert.assertEquals(getServicResp.getStatus(), Status.OK);
			Assert.assertNotNull(getServicResp.getPayload());
			service = getServicResp.getPayload();
			service.setModifiedBy("Test Modifier");
			
			ServiceVersion serviceVersion2 = newServiceVersion();
			serviceVersion2.setSerVersion(TEST_SERVICE_VERSION_2);
			service.getServiceVersions().add(serviceVersion2);
			ServiceRequest<Service> updateServiceReq = new ServiceRequest<Service>(
					new ServiceHeader(), service);
			ServiceResponse<Service> updateServiceResp = registryServiceClient.updateService(updateServiceReq);
			Assert.assertEquals(updateServiceResp.getStatus(), Status.OK);
			Assert.assertNotNull(updateServiceResp.getPayload());
			Assert.assertEquals(updateServiceResp.getPayload().getServiceVersions().size(), 2);
			
			ServiceResponse<Service> getServiceResp = registryServiceClient.getService(service.getId());
			Assert.assertEquals(getServiceResp.getStatus(), Status.OK);
			Assert.assertNotNull(getServiceResp.getPayload());
			Assert.assertEquals(getServiceResp.getPayload().getServiceVersions().size(), 2);
			
			ServiceResponse<Service> updateResp = registryServiceClient
					.updateServiceStatus(service.getId(), "INACTIVATE","test_user");

			Assert.assertEquals(updateResp.getStatus(), Status.OK);
			Assert.assertNotNull(updateResp.getPayload());
			Assert.assertEquals(updateResp.getPayload().getServiceVersions()
					.size(), 2);
			Assert.assertEquals(updateResp.getPayload().getStatus(), StatusType.INACTIVE.toString());
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testUpdateServiceExcludesServiceVersion() throws Exception {
		try {
			long now = System.currentTimeMillis();
			Service service = newService(cmdbArtifacts.get(artifactIndex++).getCode());

			ServiceRequest<Service> newServiceRequest = new ServiceRequest<Service>(
					new ServiceHeader(), service);
			ServiceResponse<Service> addedServiceResponse = registryServiceClient
					.addService(newServiceRequest);
			Assert.assertEquals(addedServiceResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse.getPayload());
			service = addedServiceResponse.getPayload();

			// Add ServiceVersion to test it is excluded by update Service
			ServiceVersion serviceVersion = newServiceVersion();
			service.getServiceVersions().add(serviceVersion);

			String updatedName = "NEW_NAME_" + now;
			String updatedCategory = ServiceCategoryType.BIZ.toString();
			String updatedDesc = "NEW_DESC";
			String updatedDomain = ServiceDomainType.B2C.toString();
			String updatedOwner = "NEW_OWNER";
			String updatedStatus = StatusType.INACTIVE.toString();
			String updatedUsage = ServiceUseType.EXTERNAL.toString();
			service.setCategory(updatedCategory);
			service.setDescription(updatedDesc);
			service.setDomain(updatedDomain);
			service.setName(updatedName);
			service.setOwner(updatedOwner);
			service.setStatus(updatedStatus);
			service.setUsage(updatedUsage);
			ServiceRequest<Service> updateRequest = new ServiceRequest<Service>(
					new ServiceHeader(), service);

			ServiceResponse<Service> updateResp = registryServiceClient
					.updateService(updateRequest);

			Assert.assertEquals(updateResp.getStatus(), Status.OK);
			Assert.assertNotNull(updateResp.getPayload());
			Assert.assertEquals(updateResp.getPayload().getServiceVersions().size(), 1);
			Assert.assertEquals(updateResp.getPayload().getName(), updatedName);
			Assert.assertEquals(updateResp.getPayload().getCategory(),
					updatedCategory);
			Assert.assertEquals(updateResp.getPayload().getDescription(),
					updatedDesc);
			Assert.assertEquals(updateResp.getPayload().getDomain(),
					updatedDomain);
			Assert.assertEquals(updateResp.getPayload().getOwner(),
					updatedOwner);
			Assert.assertEquals(updateResp.getPayload().getStatus(),
					updatedStatus);
			Assert.assertEquals(updateResp.getPayload().getUsage(),
					updatedUsage);
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testUpdateServiceAddIfNotFound() throws Exception {
		try {
			Service service = newService(cmdbArtifacts.get(artifactIndex++).getCode());

			ServiceRequest<Service> newServiceRequest = new ServiceRequest<Service>(
					new ServiceHeader(), service);
			ServiceResponse<Service> addedServiceResponse = registryServiceClient
					.updateService(newServiceRequest);
			Assert.assertEquals(addedServiceResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse.getPayload());
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testUpdateServiceCheckDuplicateNameSameEnv() throws Exception {
		try {
			Service service1 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			String name = service1.getName();

			ServiceRequest<Service> newServiceRequest1 = new ServiceRequest<Service>(
					new ServiceHeader(), service1);
			ServiceResponse<Service> addedServiceResponse1 = registryServiceClient
					.addService(newServiceRequest1);
			Assert.assertEquals(addedServiceResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse1.getPayload());

			Service service2 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceRequest<Service> newServiceRequest2 = new ServiceRequest<Service>(
					new ServiceHeader(), service2);
			ServiceResponse<Service> addedServiceResponse2 = registryServiceClient
					.addService(newServiceRequest2);
			Assert.assertEquals(addedServiceResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse2.getPayload());

			service2 = addedServiceResponse2.getPayload();
			service2.setName(name);
			ServiceRequest<Service> updateRequest = new ServiceRequest<Service>(
					new ServiceHeader(), service2);
			ServiceResponse<Service> updateResp = registryServiceClient
					.updateService(updateRequest);
			Assert.assertEquals(updateResp.getStatus(), Status.FAIL);
			Assert.assertNull(updateResp.getPayload());
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.assertTrue(true, ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testUpdateServiceCheckDuplicateNameDifferentEnv() throws Exception {
		try {
			Service service1 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			String name = service1.getName();

			ServiceRequest<Service> newServiceRequest1 = new ServiceRequest<Service>(
					new ServiceHeader(), service1);
			ServiceResponse<Service> addedServiceResponse1 = registryServiceClient
					.addService(newServiceRequest1);
			Assert.assertEquals(addedServiceResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse1.getPayload());

			Service service2 = newService(cmdbArtifacts.get(artifactIndex++).getCode());service2.setEnvironment("dev");
			ServiceRequest<Service> newServiceRequest2 = new ServiceRequest<Service>(
					new ServiceHeader(), service2);
			ServiceResponse<Service> addedServiceResponse2 = registryServiceClient
					.addService(newServiceRequest2);
			Assert.assertEquals(addedServiceResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse2.getPayload());

			service2 = addedServiceResponse2.getPayload();
			service2.setName(name);
			ServiceRequest<Service> updateRequest = new ServiceRequest<Service>(
					new ServiceHeader(), service2);
			ServiceResponse<Service> updateResp = registryServiceClient
					.updateService(updateRequest);
			Assert.assertEquals(updateResp.getStatus(), Status.OK);
			Assert.assertNotNull(updateResp.getPayload());
			Assert.assertEquals(updateResp.getPayload().getEnvironment(), "dev");
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.assertTrue(true, ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testGetServiceVersionsByAvailabilityTier() throws Exception {
		try {
			Service service1 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceVersion serviceVersion11 = newServiceVersion();
			serviceVersion11.setSerVersion(TEST_SERVICE_VERSION_1);
			serviceVersion11.setAvailabilityTier(AvailabilityTierType.TIER1.toString());
			service1.getServiceVersions().add(serviceVersion11);
			
			ServiceVersion serviceVersion12 = newServiceVersion();
			serviceVersion12.setSerVersion(TEST_SERVICE_VERSION_2);
			serviceVersion12.setAvailabilityTier(AvailabilityTierType.TIER2.toString());
			service1.getServiceVersions().add(serviceVersion12);

			ServiceRequest<Service> newServiceRequest1 = new ServiceRequest<Service>(
					new ServiceHeader(), service1);
			ServiceResponse<Service> addedServiceResponse1 = registryServiceClient
					.addService(newServiceRequest1);
			Assert.assertEquals(addedServiceResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse1.getPayload());

			service1 = addedServiceResponse1.getPayload();
			
			Service service2 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceVersion serviceVersion21 = newServiceVersion();
			serviceVersion21.setSerVersion(TEST_SERVICE_VERSION_1);
			serviceVersion21.setAvailabilityTier(AvailabilityTierType.TIER1.toString());
			service2.getServiceVersions().add(serviceVersion21);
			
			ServiceVersion serviceVersion22 = newServiceVersion();
			serviceVersion22.setSerVersion(TEST_SERVICE_VERSION_2);
			serviceVersion22.setAvailabilityTier(AvailabilityTierType.TIER2.toString());
			service2.getServiceVersions().add(serviceVersion22);

			ServiceRequest<Service> newServiceRequest2 = new ServiceRequest<Service>(
					new ServiceHeader(), service2);
			ServiceResponse<Service> addedServiceResponse2 = registryServiceClient
					.addService(newServiceRequest2);
			Assert.assertEquals(addedServiceResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse2.getPayload());

			service2 = addedServiceResponse2.getPayload();
			
			Service service3 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceVersion serviceVersion31 = newServiceVersion();
			serviceVersion31.setSerVersion(TEST_SERVICE_VERSION_1);
			serviceVersion31.setAvailabilityTier(AvailabilityTierType.TIER2.toString());
			service3.getServiceVersions().add(serviceVersion31);
			
			ServiceVersion serviceVersion32 = newServiceVersion();
			serviceVersion32.setSerVersion(TEST_SERVICE_VERSION_2);
			serviceVersion32.setAvailabilityTier(AvailabilityTierType.TIER2.toString());
			service3.getServiceVersions().add(serviceVersion32);

			ServiceRequest<Service> newServiceRequest3 = new ServiceRequest<Service>(
					new ServiceHeader(), service3);
			ServiceResponse<Service> addedServiceResponse3 = registryServiceClient
					.addService(newServiceRequest3);
			Assert.assertEquals(addedServiceResponse3.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse3.getPayload());

			service3 = addedServiceResponse3.getPayload();
			
			ServiceResponse<ServiceList> getTierServiceVersionsResp = registryServiceClient.searchServices(SearchFieldType.AVAILABILITY_TIER.toString(), AvailabilityTierType.TIER1.toString());
	
			Assert.assertEquals(getTierServiceVersionsResp.getStatus(), Status.OK);
			Assert.assertNotNull(getTierServiceVersionsResp.getPayload());
		
			service1 = getService(getTierServiceVersionsResp.getPayload().getServices(), service1.getName());
			Assert.assertNotNull(service1);
			Assert.assertEquals(service1.getServiceVersions().size(), 1);
	
			service2 = getService(getTierServiceVersionsResp.getPayload().getServices(), service2.getName());
			Assert.assertNotNull(service2);
			Assert.assertEquals(service2.getServiceVersions().size(), 1);
	
			service3 = getService(getTierServiceVersionsResp.getPayload().getServices(), service3.getName());
			Assert.assertNull(service3);
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testGetServiceVersionsByESBReference() throws Exception {
		try {
			Service service1 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceVersion serviceVersion11 = newServiceVersion();
			serviceVersion11.setSerVersion(TEST_SERVICE_VERSION_1);
			serviceVersion11.setEsbReference("ESB_REFERENCE1");
			service1.getServiceVersions().add(serviceVersion11);
			
			ServiceVersion serviceVersion12 = newServiceVersion();
			serviceVersion12.setSerVersion(TEST_SERVICE_VERSION_2);
			serviceVersion12.setEsbReference("ESB_REFERENCE2");
			service1.getServiceVersions().add(serviceVersion12);

			ServiceRequest<Service> newServiceRequest1 = new ServiceRequest<Service>(
					new ServiceHeader(), service1);
			ServiceResponse<Service> addedServiceResponse1 = registryServiceClient
					.addService(newServiceRequest1);
			Assert.assertEquals(addedServiceResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse1.getPayload());

			service1 = addedServiceResponse1.getPayload();
			
			Service service2 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceVersion serviceVersion21 = newServiceVersion();
			serviceVersion21.setSerVersion(TEST_SERVICE_VERSION_1);
			serviceVersion21.setEsbReference("ESB_REFERENCE1");
			service2.getServiceVersions().add(serviceVersion21);
			
			ServiceVersion serviceVersion22 = newServiceVersion();
			serviceVersion22.setSerVersion(TEST_SERVICE_VERSION_2);
			serviceVersion22.setEsbReference("ESB_REFERENCE2");
			service2.getServiceVersions().add(serviceVersion22);

			ServiceRequest<Service> newServiceRequest2 = new ServiceRequest<Service>(
					new ServiceHeader(), service2);
			ServiceResponse<Service> addedServiceResponse2 = registryServiceClient
					.addService(newServiceRequest2);
			Assert.assertEquals(addedServiceResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse2.getPayload());

			service2 = addedServiceResponse2.getPayload();
			
			Service service3 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceVersion serviceVersion31 = newServiceVersion();
			serviceVersion31.setSerVersion(TEST_SERVICE_VERSION_1);
			serviceVersion31.setEsbReference("ESB_REFERENCE2");
			service3.getServiceVersions().add(serviceVersion31);
			
			ServiceVersion serviceVersion32 = newServiceVersion();
			serviceVersion32.setSerVersion(TEST_SERVICE_VERSION_2);
			serviceVersion32.setEsbReference("ESB_REFERENCE2");
			service3.getServiceVersions().add(serviceVersion32);

			ServiceRequest<Service> newServiceRequest3 = new ServiceRequest<Service>(
					new ServiceHeader(), service3);
			ServiceResponse<Service> addedServiceResponse3 = registryServiceClient
					.addService(newServiceRequest3);
			Assert.assertEquals(addedServiceResponse3.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse3.getPayload());

			service3 = addedServiceResponse3.getPayload();
			
			ServiceResponse<ServiceList> getEsbRefServiceVersionsResp = registryServiceClient.searchServices(SearchFieldType.ESB_REFERENCE.toString(), "ESB_REFERENCE1");
		
			Assert.assertEquals(getEsbRefServiceVersionsResp.getStatus(), Status.OK);
			Assert.assertNotNull(getEsbRefServiceVersionsResp.getPayload());
		
			service1 = getService(getEsbRefServiceVersionsResp.getPayload().getServices(), service1.getName());
			Assert.assertNotNull(service1);
			Assert.assertEquals(service1.getServiceVersions().size(), 1);
	
			service2 = getService(getEsbRefServiceVersionsResp.getPayload().getServices(), service2.getName());
			Assert.assertNotNull(service2);
			Assert.assertEquals(service2.getServiceVersions().size(), 1);
	
			service3 = getService(getEsbRefServiceVersionsResp.getPayload().getServices(), service3.getName());
			Assert.assertNull(service3);
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testDeleteService() throws Exception {
		try {
			Service service = newService(cmdbArtifacts.get(artifactIndex++).getCode());

			ServiceRequest<Service> newServiceRequest = new ServiceRequest<Service>(
					new ServiceHeader(), service);
			ServiceResponse<Service> addedServiceResponse = registryServiceClient
					.addService(newServiceRequest);
			Assert.assertEquals(addedServiceResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse.getPayload());

			ServiceResponse<Service> deleteResp = registryServiceClient
					.updateServiceStatus(addedServiceResponse.getPayload().getId(), "DELETE","test_user");

			Assert.assertEquals(deleteResp.getStatus(), Status.OK);
			Assert.assertNotNull(deleteResp.getPayload());
			Assert.assertEquals(deleteResp.getPayload().getStatus(),
					StatusType.DELETED.toString());

			ServiceResponse<ServiceList> servicesResp = registryServiceClient
					.getServices();
			Assert.assertEquals(servicesResp.getStatus(), Status.OK);
			Assert.assertNotNull(servicesResp.getPayload());
			Assert.assertNotNull(servicesResp.getPayload().getServices());

			Service deletedService = getService(servicesResp.getPayload()
					.getServices(), addedServiceResponse.getPayload().getName());
			Assert.assertNotNull(deletedService);
			Assert.assertEquals(deletedService.getStatus(),
					StatusType.DELETED.toString());

		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testFindServices() throws Exception {
		try {
			Service service1 = newService(cmdbArtifacts.get(artifactIndex++).getCode());

			ServiceRequest<Service> newServiceRequest1 = new ServiceRequest<Service>(
					new ServiceHeader(), service1);
			ServiceResponse<Service> addedServiceResponse1 = registryServiceClient
					.addService(newServiceRequest1);
			Assert.assertEquals(addedServiceResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse1.getPayload());

			Service service2 = newService(cmdbArtifacts.get(artifactIndex++).getCode());

			ServiceRequest<Service> newServiceRequest2 = new ServiceRequest<Service>(
					new ServiceHeader(), service2);
			ServiceResponse<Service> addedServiceResponse2 = registryServiceClient
					.addService(newServiceRequest2);
			Assert.assertEquals(addedServiceResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse2.getPayload());

			ServiceResponse<ServiceList> findResp = registryServiceClient
					.findServices(service1.getName());

			Assert.assertEquals(findResp.getStatus(), Status.OK);
			Assert.assertNotNull(findResp.getPayload());
			Service expected = getService(findResp.getPayload().getServices(),
					service1.getName());
			Assert.assertNotNull(expected);
			Service nonExpected = getService(findResp.getPayload()
					.getServices(), service2.getName());
			Assert.assertNull(nonExpected);
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testGetServiceVersion() throws Exception {
		try {
			Service service = newService(cmdbArtifacts.get(artifactIndex++).getCode());

			ServiceRequest<Service> newServiceRequest = new ServiceRequest<Service>(
					new ServiceHeader(), service);
			ServiceResponse<Service> addedServiceResponse = registryServiceClient
					.addService(newServiceRequest);
			Assert.assertEquals(addedServiceResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse.getPayload());

			service = addedServiceResponse.getPayload();
			ServiceVersion serviceVersion = newServiceVersion();
			ServiceRequest<ServiceVersion> addServiceVersionRequest = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion);
			ServiceResponse<ServiceVersion> addServiceVersionResp = registryServiceClient
					.addServiceVersion(service.getId(),
							addServiceVersionRequest);
			Assert.assertEquals(addServiceVersionResp.getStatus(), Status.OK);
			Assert.assertNotNull(addServiceVersionResp.getPayload());

			ServiceResponse<ServiceVersion> getResp = registryServiceClient
					.getServiceVersion(addedServiceResponse.getPayload()
							.getId(), serviceVersion.getSerVersion());
			Assert.assertEquals(getResp.getStatus(), Status.OK);
			Assert.assertNotNull(getResp.getPayload());
			Assert.assertFalse(getResp.getPayload().getAttributes().isEmpty());
			Assert.assertEquals(getResp.getPayload().getAttributes().size(), serviceVersion.getAttributes().size());
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testAddServiceVersion() throws Exception {
		try {
			Service service = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceRequest<Service> newServiceRequest = new ServiceRequest<Service>(
					new ServiceHeader(), service);
			ServiceResponse<Service> addedServiceResponse = registryServiceClient
					.addService(newServiceRequest);
			Assert.assertEquals(addedServiceResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse.getPayload());

			service = addedServiceResponse.getPayload();
			ServiceVersion serviceVersion = newServiceVersion();
			ServiceRequest<ServiceVersion> addServiceVersionReq = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion);

			ServiceResponse<ServiceVersion> addServiceVersionRes = registryServiceClient
					.addServiceVersion(service.getId(), addServiceVersionReq);
			Assert.assertEquals(addServiceVersionRes.getStatus(), Status.OK);
			Assert.assertNotNull(addServiceVersionRes.getPayload());
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testAddServiceVersionAttributes() throws Exception {
		try {
			Service service = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceRequest<Service> newServiceRequest = new ServiceRequest<Service>(
					new ServiceHeader(), service);
			ServiceResponse<Service> addedServiceResponse = registryServiceClient
					.addService(newServiceRequest);
			Assert.assertEquals(addedServiceResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse.getPayload());

			service = addedServiceResponse.getPayload();
			ServiceVersion serviceVersion = newServiceVersion();
			
			Attribute attr1 = new Attribute();
			attr1.setName("ATTRIBUTE_NAME1");
			attr1.setValue("ATTRIBUTE_VALUE1");
			serviceVersion.getAttributes().add(attr1);
			Attribute attr2 = new Attribute();
			attr2.setName("ATTRIBUTE_NAME2");
			attr2.setValue("ATTRIBUTE_VALUE2");
			serviceVersion.getAttributes().add(attr2);
			
			ServiceRequest<ServiceVersion> addServiceVersionReq = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion);

			ServiceResponse<ServiceVersion> addServiceVersionRes = registryServiceClient
					.addServiceVersion(service.getId(), addServiceVersionReq);
			Assert.assertEquals(addServiceVersionRes.getStatus(), Status.OK);
			Assert.assertNotNull(addServiceVersionRes.getPayload());
			Assert.assertNotNull(addServiceVersionRes.getPayload().getAttributes());
			Assert.assertEquals(addServiceVersionRes.getPayload().getAttributes().size(), serviceVersion.getAttributes().size());
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testUpdateServiceVersionAttributes() throws Exception {
		try {
			Service service = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceRequest<Service> newServiceRequest = new ServiceRequest<Service>(
					new ServiceHeader(), service);
			ServiceResponse<Service> addedServiceResponse = registryServiceClient
					.addService(newServiceRequest);
			Assert.assertEquals(addedServiceResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse.getPayload());

			service = addedServiceResponse.getPayload();
			ServiceVersion serviceVersion = newServiceVersion();
			
			Attribute attr1 = new Attribute();
			attr1.setName("ATTRIBUTE_NAME1");
			attr1.setValue("ATTRIBUTE_VALUE1");
			serviceVersion.getAttributes().add(attr1);
			Attribute attr2 = new Attribute();
			attr2.setName("ATTRIBUTE_NAME2");
			attr2.setValue("ATTRIBUTE_VALUE2");
			serviceVersion.getAttributes().add(attr2);
			
			ServiceRequest<ServiceVersion> addServiceVersionReq = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion);

			ServiceResponse<ServiceVersion> addServiceVersionRes = registryServiceClient
					.addServiceVersion(service.getId(), addServiceVersionReq);
			Assert.assertEquals(addServiceVersionRes.getStatus(), Status.OK);
			Assert.assertNotNull(addServiceVersionRes.getPayload());
			Assert.assertNotNull(addServiceVersionRes.getPayload().getAttributes());
			Assert.assertEquals(addServiceVersionRes.getPayload().getAttributes().size(), serviceVersion.getAttributes().size());
			
			serviceVersion = addServiceVersionRes.getPayload();
			serviceVersion.getAttributes().clear();
			attr1 = new Attribute();
			attr1.setName("ATTRIBUTE_NAME1");
			attr1.setValue("ATTRIBUTE_VALUE11");
			serviceVersion.getAttributes().add(attr1);
			Attribute attr3 = new Attribute();
			attr3.setName("ATTRIBUTE_NAME3");
			attr3.setValue("ATTRIBUTE_VALUE3");
			serviceVersion.getAttributes().add(attr3);
			
			ServiceRequest<ServiceVersion> updateServiceVersionReq = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion);

			ServiceResponse<ServiceVersion> updateServiceVersionRes = registryServiceClient
					.updateServiceVersion(service.getId(), updateServiceVersionReq);
			Assert.assertEquals(updateServiceVersionRes.getStatus(), Status.OK);
			Assert.assertNotNull(updateServiceVersionRes.getPayload());
			Assert.assertNotNull(updateServiceVersionRes.getPayload().getAttributes());
			Assert.assertEquals(updateServiceVersionRes.getPayload().getAttributes().size(), serviceVersion.getAttributes().size());
			
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testAddServiceVersionWithQoSAndPolicies() throws Exception {
		try {
			
			Policy policy1 = newPolicy();
			ServiceRequest<Policy> addPolicyReq1 = new ServiceRequest<Policy>(new ServiceHeader(), policy1);
			ServiceResponse<Policy> addPolicyResp1 = policyServiceClient.addPolicy(addPolicyReq1);
			Assert.assertEquals(addPolicyResp1.getStatus(), Status.OK);
			Assert.assertNotNull(addPolicyResp1.getPayload());
			policy1 = addPolicyResp1.getPayload();
		
			Policy policy2 = newPolicy();
			ServiceRequest<Policy> addPolicyReq2 = new ServiceRequest<Policy>(new ServiceHeader(), policy2);
			ServiceResponse<Policy> addPolicyResp2 = policyServiceClient.addPolicy(addPolicyReq2);
			Assert.assertEquals(addPolicyResp2.getStatus(), Status.OK);
			Assert.assertNotNull(addPolicyResp2.getPayload());
			policy2 = addPolicyResp2.getPayload();
		
			Service service = newService(cmdbArtifacts.get(artifactIndex++).getCode());

			ServiceRequest<Service> newServiceRequest = new ServiceRequest<Service>(
					new ServiceHeader(), service);
			ServiceResponse<Service> addedServiceResponse = registryServiceClient
					.addService(newServiceRequest);
			Assert.assertEquals(addedServiceResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse.getPayload());

			service = addedServiceResponse.getPayload();
			ServiceVersion serviceVersion = newServiceVersion();
			
			QoS qos11 = addQoS();
			QoS qos22 = addQoS();
			serviceVersion.getQoSParameters().add(qos11);
			serviceVersion.getQoSParameters().add(qos22);
			
			Policy addPolicy1 = new Policy();
			addPolicy1.setId(policy1.getId());
			Policy addPolicy2 = new Policy();
			addPolicy2.setId(policy2.getId());
			
			serviceVersion.getPolicies().add(addPolicy1);
			serviceVersion.getPolicies().add(addPolicy2);
			
			ServiceRequest<ServiceVersion> addServiceVersionReq = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion);

			ServiceResponse<ServiceVersion> addServiceVersionRes = registryServiceClient
					.addServiceVersion(service.getId(), addServiceVersionReq);
			Assert.assertEquals(addServiceVersionRes.getStatus(), Status.OK);
			Assert.assertNotNull(addServiceVersionRes.getPayload());
			Assert.assertTrue(!addServiceVersionRes.getPayload().getQoSParameters().isEmpty());
			Assert.assertEquals(addServiceVersionRes.getPayload().getQoSParameters().size(), 2);
			Assert.assertEquals(addServiceVersionRes.getPayload().getPolicies().size(), 2);
			ServiceResponse<ServiceVersion> getServiceVersionRes = registryServiceClient.getServiceVersion(service.getId(), serviceVersion.getSerVersion());
			Assert.assertEquals(getServiceVersionRes.getStatus(), Status.OK);
			Assert.assertNotNull(getServiceVersionRes.getPayload());
			Assert.assertEquals(addServiceVersionRes.getPayload().getPolicies().size(), 2);
			Assert.assertEquals(getServiceVersionRes.getPayload().getQoSParameters().size(), 2);
			
			ServiceResponse<ServiceList> getServicesRes = registryServiceClient.getServices();
			Assert.assertEquals(getServicesRes.getStatus(), Status.OK);
			Assert.assertNotNull(getServicesRes.getPayload());
			Assert.assertTrue(!getServicesRes.getPayload().getServices().isEmpty());
			Service serviceResult = getService(getServicesRes.getPayload().getServices(), service.getName());
			Assert.assertNotNull(serviceResult);
			ServiceVersion serviceVersionResult = getServiceVersion(serviceResult.getServiceVersions(), serviceVersion.getSerVersion());
			Assert.assertEquals(serviceResult.getServiceVersions().size(), 1);
			Assert.assertEquals(serviceVersionResult.getQoSParameters().size(), 2);
			Assert.assertEquals(serviceVersionResult.getPolicies().size(), 2);
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testAddServiceVersionWithQoSMaster() throws Exception {
		try {
			
			Policy policy1 = newPolicy();
			ServiceRequest<Policy> addPolicyReq1 = new ServiceRequest<Policy>(new ServiceHeader(), policy1);
			ServiceResponse<Policy> addPolicyResp1 = policyServiceClient.addPolicy(addPolicyReq1);
			Assert.assertEquals(addPolicyResp1.getStatus(), Status.OK);
			Assert.assertNotNull(addPolicyResp1.getPayload());
			policy1 = addPolicyResp1.getPayload();
		
			Policy policy2 = newPolicy();
			ServiceRequest<Policy> addPolicyReq2 = new ServiceRequest<Policy>(new ServiceHeader(), policy2);
			ServiceResponse<Policy> addPolicyResp2 = policyServiceClient.addPolicy(addPolicyReq2);
			Assert.assertEquals(addPolicyResp2.getStatus(), Status.OK);
			Assert.assertNotNull(addPolicyResp2.getPayload());
			policy2 = addPolicyResp2.getPayload();
			
			QoS qos11 = addQoS();
			QoS qos22 = addQoS();
			
			Service service = newService(cmdbArtifacts.get(artifactIndex++).getCode());

			ServiceRequest<Service> newServiceRequest = new ServiceRequest<Service>(
					new ServiceHeader(), service);
			ServiceResponse<Service> addedServiceResponse = registryServiceClient
					.addService(newServiceRequest);
			Assert.assertEquals(addedServiceResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse.getPayload());

			service = addedServiceResponse.getPayload();
			ServiceVersion serviceVersion = newServiceVersion();

			serviceVersion.getQoSParameters().add(qos11);
			serviceVersion.getQoSParameters().add(qos22);
			
			serviceVersion.getPolicies().add(policy1);
			serviceVersion.getPolicies().add(policy2);
			
			ServiceRequest<ServiceVersion> addServiceVersionReq = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion);

			ServiceResponse<ServiceVersion> addServiceVersionRes = registryServiceClient
					.addServiceVersion(service.getId(), addServiceVersionReq);
			Assert.assertEquals(addServiceVersionRes.getStatus(), Status.OK);
			Assert.assertNotNull(addServiceVersionRes.getPayload());
			Assert.assertEquals(addServiceVersionRes.getPayload().getPolicies().size(), 2);
			Assert.assertEquals(addServiceVersionRes.getPayload().getQoSParameters().size(), 2);
			
			ServiceResponse<ServiceVersion> getServiceVersionRes = registryServiceClient.getServiceVersion(service.getId(), serviceVersion.getSerVersion());
			Assert.assertEquals(getServiceVersionRes.getStatus(), Status.OK);
			Assert.assertNotNull(getServiceVersionRes.getPayload());
			Assert.assertEquals(addServiceVersionRes.getPayload().getPolicies().size(), 2);
			
			Assert.assertEquals(getServiceVersionRes.getPayload().getQoSParameters().size(), 2);
			QoS getQqs11 = getQoS(getServiceVersionRes.getPayload().getQoSParameters(), qos11.getId());
			Assert.assertNotNull(getQqs11);
			Assert.assertEquals(getQqs11.getValue(), qos11.getValue());
			Assert.assertEquals(getQqs11.getName(), qos11.getName());
			QoS getQos22 = getQoS(getServiceVersionRes.getPayload().getQoSParameters(), qos22.getId());
			Assert.assertNotNull(getQos22);
			Assert.assertEquals(getQos22.getValue(), qos22.getValue());
			Assert.assertEquals(getQos22.getName(), qos22.getName());
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testUpdateServiceVersionWithUnchangeQoSAndPolicy() throws Exception {
		try {
			
			Policy policy1 = newPolicy();
			ServiceRequest<Policy> addPolicyReq1 = new ServiceRequest<Policy>(new ServiceHeader(), policy1);
			ServiceResponse<Policy> addPolicyResp1 = policyServiceClient.addPolicy(addPolicyReq1);
			Assert.assertEquals(addPolicyResp1.getStatus(), Status.OK);
			Assert.assertNotNull(addPolicyResp1.getPayload());
			policy1 = addPolicyResp1.getPayload();
		
			Policy policy2 = newPolicy();
			ServiceRequest<Policy> addPolicyReq2 = new ServiceRequest<Policy>(new ServiceHeader(), policy2);
			ServiceResponse<Policy> addPolicyResp2 = policyServiceClient.addPolicy(addPolicyReq2);
			Assert.assertEquals(addPolicyResp2.getStatus(), Status.OK);
			Assert.assertNotNull(addPolicyResp2.getPayload());
			policy2 = addPolicyResp2.getPayload();
			
			Service service = newService(cmdbArtifacts.get(artifactIndex++).getCode());

			ServiceRequest<Service> newServiceRequest = new ServiceRequest<Service>(
					new ServiceHeader(), service);
			ServiceResponse<Service> addedServiceResponse = registryServiceClient
					.addService(newServiceRequest);
			Assert.assertEquals(addedServiceResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse.getPayload());

			service = addedServiceResponse.getPayload();
			ServiceVersion serviceVersion = newServiceVersion();
		
			QoS qos1 = addQoS();
			QoS qos2 = addQoS();
			serviceVersion.getQoSParameters().add(qos1);
			serviceVersion.getQoSParameters().add(qos2);
					
			serviceVersion.getPolicies().add(policy1);
			serviceVersion.getPolicies().add(policy2);
			
			ServiceRequest<ServiceVersion> addServiceVersionReq = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion);

			ServiceResponse<ServiceVersion> addServiceVersionRes = registryServiceClient
					.addServiceVersion(service.getId(), addServiceVersionReq);
			Assert.assertEquals(addServiceVersionRes.getStatus(), Status.OK);
			Assert.assertNotNull(addServiceVersionRes.getPayload());
	
			Assert.assertTrue(!addServiceVersionRes.getPayload().getQoSParameters().isEmpty());
			Assert.assertEquals(addServiceVersionRes.getPayload().getQoSParameters().size(), 2);
			Assert.assertEquals(addServiceVersionRes.getPayload().getPolicies().size(), 2);
			
			ServiceResponse<ServiceVersion> getServiceVersionRes = registryServiceClient.getServiceVersion(service.getId(), serviceVersion.getSerVersion());
			Assert.assertEquals(getServiceVersionRes.getStatus(), Status.OK);
			Assert.assertNotNull(getServiceVersionRes.getPayload());
	
			Assert.assertEquals(getServiceVersionRes.getPayload().getQoSParameters().size(), 2);
			Assert.assertEquals(addServiceVersionRes.getPayload().getPolicies().size(), 2);
			
			serviceVersion = addServiceVersionRes.getPayload();
			serviceVersion.setSerVersion(TEST_SERVICE_VERSION_2);
			ServiceRequest<ServiceVersion> updateServiceVersionReq = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion);
			ServiceResponse<ServiceVersion> updateServiceVersionResp = registryServiceClient
					.updateServiceVersion(service.getId(), updateServiceVersionReq);
			Assert.assertEquals(updateServiceVersionResp.getStatus(), Status.OK);
			Assert.assertNotNull(updateServiceVersionResp.getPayload());
			Assert.assertEquals(updateServiceVersionResp.getPayload().getSerVersion(), TEST_SERVICE_VERSION_2);
			
			Assert.assertTrue(!updateServiceVersionResp.getPayload().getQoSParameters().isEmpty());
			Assert.assertEquals(updateServiceVersionResp.getPayload().getQoSParameters().size(), 2);
			Assert.assertEquals(updateServiceVersionResp.getPayload().getPolicies().size(), 2);
			
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testUpdateServiceVersionStatusWithUnchangeQoSAndPolicy() throws Exception {
		try {
			
			Policy policy1 = newPolicy();
			ServiceRequest<Policy> addPolicyReq1 = new ServiceRequest<Policy>(new ServiceHeader(), policy1);
			ServiceResponse<Policy> addPolicyResp1 = policyServiceClient.addPolicy(addPolicyReq1);
			Assert.assertEquals(addPolicyResp1.getStatus(), Status.OK);
			Assert.assertNotNull(addPolicyResp1.getPayload());
			policy1 = addPolicyResp1.getPayload();
		
			Policy policy2 = newPolicy();
			ServiceRequest<Policy> addPolicyReq2 = new ServiceRequest<Policy>(new ServiceHeader(), policy2);
			ServiceResponse<Policy> addPolicyResp2 = policyServiceClient.addPolicy(addPolicyReq2);
			Assert.assertEquals(addPolicyResp2.getStatus(), Status.OK);
			Assert.assertNotNull(addPolicyResp2.getPayload());
			policy2 = addPolicyResp2.getPayload();
			
			Service service = newService(cmdbArtifacts.get(artifactIndex++).getCode());

			ServiceRequest<Service> newServiceRequest = new ServiceRequest<Service>(
					new ServiceHeader(), service);
			ServiceResponse<Service> addedServiceResponse = registryServiceClient
					.addService(newServiceRequest);
			Assert.assertEquals(addedServiceResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse.getPayload());

			service = addedServiceResponse.getPayload();
			ServiceVersion serviceVersion = newServiceVersion();
			
			QoS qos1 = addQoS();
			QoS qos2 = addQoS();
			serviceVersion.getQoSParameters().add(qos1);
			serviceVersion.getQoSParameters().add(qos2);
			
			serviceVersion.getPolicies().add(policy1);
			serviceVersion.getPolicies().add(policy2);
			
			ServiceRequest<ServiceVersion> addServiceVersionReq = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion);

			ServiceResponse<ServiceVersion> addServiceVersionRes = registryServiceClient
					.addServiceVersion(service.getId(), addServiceVersionReq);
			Assert.assertEquals(addServiceVersionRes.getStatus(), Status.OK);
			Assert.assertNotNull(addServiceVersionRes.getPayload());
		
			Assert.assertTrue(!addServiceVersionRes.getPayload().getQoSParameters().isEmpty());
			Assert.assertEquals(addServiceVersionRes.getPayload().getQoSParameters().size(), 2);
			Assert.assertEquals(addServiceVersionRes.getPayload().getPolicies().size(), 2);
			
			ServiceResponse<ServiceVersion> getServiceVersionRes = registryServiceClient.getServiceVersion(service.getId(), serviceVersion.getSerVersion());
			Assert.assertEquals(getServiceVersionRes.getStatus(), Status.OK);
			Assert.assertNotNull(getServiceVersionRes.getPayload());
		
			Assert.assertTrue(!addServiceVersionRes.getPayload().getQoSParameters().isEmpty());
			Assert.assertEquals(addServiceVersionRes.getPayload().getQoSParameters().size(), 2);
			Assert.assertEquals(addServiceVersionRes.getPayload().getPolicies().size(), 2);
			
			serviceVersion = addServiceVersionRes.getPayload();
			ServiceResponse<ServiceVersion> updateServiceVersionResp = registryServiceClient
					.updateServiceVersionStatus(serviceVersion.getId(), "INACTIVATE","test_user");
			Assert.assertEquals(updateServiceVersionResp.getStatus(), Status.OK);
			Assert.assertNotNull(updateServiceVersionResp.getPayload());
			Assert.assertEquals(updateServiceVersionResp.getPayload().getStatus(), StatusType.INACTIVE.toString());
			
			Assert.assertTrue(!addServiceVersionRes.getPayload().getQoSParameters().isEmpty());
			Assert.assertEquals(addServiceVersionRes.getPayload().getQoSParameters().size(), 2);
		
			Assert.assertEquals(updateServiceVersionResp.getPayload().getPolicies().size(), 2);
			
			ServiceResponse<ServiceVersion> getServiceVersionResponse = registryServiceClient.getServiceVersion(service.getId(), updateServiceVersionResp.getPayload().getSerVersion());
		
			Assert.assertTrue(!addServiceVersionRes.getPayload().getQoSParameters().isEmpty());
			Assert.assertEquals(addServiceVersionRes.getPayload().getQoSParameters().size(), 2);
		
			Assert.assertEquals(getServiceVersionResponse.getPayload().getPolicies().size(), 2);
			Assert.assertEquals(getServiceVersionResponse.getPayload().getStatus(), StatusType.INACTIVE.toString());
				
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testUpdateServiceVersionWithAddQoSAndPolicy() throws Exception {
		try {
			
			/*NotificationDestination notificationDestination = newNotificationDestination();notificationDestination.setType("EMAIL");
			ServiceRequest<NotificationDestination> notifReq = new ServiceRequest<NotificationDestination>(
					new ServiceHeader(), notificationDestination);
			ServiceResponse<NotificationDestination> notifResp = notificationDestinationServiceClient.addNotificationDestination(notifReq);
			Assert.assertEquals(notifResp.getStatus(), Status.OK);
			Assert.assertNotNull(notifResp.getPayload());*/

			Policy policy1 = newPolicy();policy1.setName(policy1.getName()+"_1");
			ServiceRequest<Policy> addPolicyReq1 = new ServiceRequest<Policy>(new ServiceHeader(), policy1);
			ServiceResponse<Policy> addPolicyResp1 = policyServiceClient.addPolicy(addPolicyReq1);
			Assert.assertEquals(addPolicyResp1.getStatus(), Status.OK);
			Assert.assertNotNull(addPolicyResp1.getPayload());
			policy1 = addPolicyResp1.getPayload();
		
			Policy policy2 = newPolicy();policy2.setName(policy2.getName()+"_2");
			ServiceRequest<Policy> addPolicyReq2 = new ServiceRequest<Policy>(new ServiceHeader(), policy2);
			ServiceResponse<Policy> addPolicyResp2 = policyServiceClient.addPolicy(addPolicyReq2);
			Assert.assertEquals(addPolicyResp2.getStatus(), Status.OK);
			Assert.assertNotNull(addPolicyResp2.getPayload());
			policy2 = addPolicyResp2.getPayload();
			
			Service service = newService(cmdbArtifacts.get(artifactIndex++).getCode());service.setOwner("sbonde@walmartlabs.com");service.setNotificationRequested(true);
			//service.getNotificationTypes().add(notificationDestination.getName());
			service.getNotificationTypes().add(NotificationDestinationType.EMAIL.toString());
			service.getNotificationFor().clear();
			service.getNotificationFor().add(AuditType.ADD_SERVICE_VERSION_QOS.toString());
			ServiceRequest<Service> newServiceRequest = new ServiceRequest<Service>(
					new ServiceHeader(), service);
			ServiceResponse<Service> addedServiceResponse = registryServiceClient
					.addService(newServiceRequest);
			Assert.assertEquals(addedServiceResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse.getPayload());

			service = addedServiceResponse.getPayload();
			ServiceVersion serviceVersion = newServiceVersion();
		
			QoS qos1 = addQoS();
			serviceVersion.getQoSParameters().add(qos1);
			
			serviceVersion.getPolicies().add(policy1);
			serviceVersion.getPolicies().add(policy2);
			
			QoS qos2 = addQoS();
			serviceVersion.getQoSParameters().add(qos2);
					
			ServiceRequest<ServiceVersion> addServiceVersionReq = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion);

			ServiceResponse<ServiceVersion> addServiceVersionRes = registryServiceClient
					.addServiceVersion(service.getId(), addServiceVersionReq);
			Assert.assertEquals(addServiceVersionRes.getStatus(), Status.OK);
			Assert.assertNotNull(addServiceVersionRes.getPayload());
		
			Assert.assertTrue(!addServiceVersionRes.getPayload().getQoSParameters().isEmpty());
			Assert.assertEquals(addServiceVersionRes.getPayload().getQoSParameters().size(), 2);
			Assert.assertEquals(addServiceVersionRes.getPayload().getPolicies().size(), 2);
			
			ServiceResponse<ServiceVersion> getServiceVersionRes = registryServiceClient.getServiceVersion(service.getId(), serviceVersion.getSerVersion());
			Assert.assertEquals(getServiceVersionRes.getStatus(), Status.OK);
			Assert.assertNotNull(getServiceVersionRes.getPayload());
		
			Assert.assertEquals(getServiceVersionRes.getPayload().getQoSParameters().size(), 2);
			Assert.assertEquals(addServiceVersionRes.getPayload().getPolicies().size(), 2);
			
			
			Policy policy3 = newPolicy();policy3.setName(policy3.getName()+"_3");
			ServiceRequest<Policy> addPolicyReq3 = new ServiceRequest<Policy>(new ServiceHeader(), policy3);
			ServiceResponse<Policy> addPolicyResp3 = policyServiceClient.addPolicy(addPolicyReq3);
			Assert.assertEquals(addPolicyResp3.getStatus(), Status.OK);
			Assert.assertNotNull(addPolicyResp3.getPayload());
			policy3 = addPolicyResp3.getPayload();
	
			serviceVersion = addServiceVersionRes.getPayload();
			serviceVersion.getPolicies().add(policy3);
			
			QoS qos3 = addQoS();
			serviceVersion.getQoSParameters().add(qos3);
			
			serviceVersion.setSerVersion(TEST_SERVICE_VERSION_2);
			ServiceRequest<ServiceVersion> updateServiceVersionReq = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion);
			ServiceResponse<ServiceVersion> updateServiceVersionResp = registryServiceClient
					.updateServiceVersion(service.getId(), updateServiceVersionReq);
			Assert.assertEquals(updateServiceVersionResp.getStatus(), Status.OK);
			Assert.assertNotNull(updateServiceVersionResp.getPayload());
			Assert.assertEquals(updateServiceVersionResp.getPayload().getSerVersion(), TEST_SERVICE_VERSION_2);
			
			Assert.assertTrue(!updateServiceVersionResp.getPayload().getQoSParameters().isEmpty());
			Assert.assertEquals(updateServiceVersionResp.getPayload().getQoSParameters().size(), 3);
			Assert.assertEquals(updateServiceVersionResp.getPayload().getPolicies().size(), 3);
			
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testUpdateServiceVersionWithAddDeleteQoSAndPolicy() throws Exception {
		try {
			
			Policy policy1 = newPolicy();policy1.setName(policy1.getName()+"_1");
			ServiceRequest<Policy> addPolicyReq1 = new ServiceRequest<Policy>(new ServiceHeader(), policy1);
			ServiceResponse<Policy> addPolicyResp1 = policyServiceClient.addPolicy(addPolicyReq1);
			Assert.assertEquals(addPolicyResp1.getStatus(), Status.OK);
			Assert.assertNotNull(addPolicyResp1.getPayload());
			policy1 = addPolicyResp1.getPayload();
		
			Policy policy2 = newPolicy();policy2.setName(policy2.getName()+"_2");
			ServiceRequest<Policy> addPolicyReq2 = new ServiceRequest<Policy>(new ServiceHeader(), policy2);
			ServiceResponse<Policy> addPolicyResp2 = policyServiceClient.addPolicy(addPolicyReq2);
			Assert.assertEquals(addPolicyResp2.getStatus(), Status.OK);
			Assert.assertNotNull(addPolicyResp2.getPayload());
			policy2 = addPolicyResp2.getPayload();
			
			Service service = newService(cmdbArtifacts.get(artifactIndex++).getCode());

			ServiceRequest<Service> newServiceRequest = new ServiceRequest<Service>(
					new ServiceHeader(), service);
			ServiceResponse<Service> addedServiceResponse = registryServiceClient
					.addService(newServiceRequest);
			Assert.assertEquals(addedServiceResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse.getPayload());

			service = addedServiceResponse.getPayload();
			ServiceVersion serviceVersion = newServiceVersion();
			
			QoS qos1 = addQoS();
			QoS qos2 = addQoS();
		
			serviceVersion.getQoSParameters().add(qos1);
			serviceVersion.getQoSParameters().add(qos2);
			
			serviceVersion.getPolicies().add(policy1);
			serviceVersion.getPolicies().add(policy2);
			
			ServiceRequest<ServiceVersion> addServiceVersionReq = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion);

			ServiceResponse<ServiceVersion> addServiceVersionRes = registryServiceClient
					.addServiceVersion(service.getId(), addServiceVersionReq);
			Assert.assertEquals(addServiceVersionRes.getStatus(), Status.OK);
			Assert.assertNotNull(addServiceVersionRes.getPayload());
	
			Assert.assertTrue(!addServiceVersionRes.getPayload().getQoSParameters().isEmpty());
			Assert.assertEquals(addServiceVersionRes.getPayload().getQoSParameters().size(), 2);
			Assert.assertEquals(addServiceVersionRes.getPayload().getPolicies().size(), 2);
			
			ServiceResponse<ServiceVersion> getServiceVersionRes = registryServiceClient.getServiceVersion(service.getId(), serviceVersion.getSerVersion());
			Assert.assertEquals(getServiceVersionRes.getStatus(), Status.OK);
			Assert.assertNotNull(getServiceVersionRes.getPayload());
	
			Assert.assertEquals(getServiceVersionRes.getPayload().getQoSParameters().size(), 2);
			Assert.assertEquals(addServiceVersionRes.getPayload().getPolicies().size(), 2);
			
			
			Policy policy3 = newPolicy();policy3.setName(policy3.getName()+"_3");
			ServiceRequest<Policy> addPolicyReq3 = new ServiceRequest<Policy>(new ServiceHeader(), policy3);
			ServiceResponse<Policy> addPolicyResp3 = policyServiceClient.addPolicy(addPolicyReq3);
			Assert.assertEquals(addPolicyResp3.getStatus(), Status.OK);
			Assert.assertNotNull(addPolicyResp3.getPayload());
			policy3 = addPolicyResp3.getPayload();
			
			//Remove policy2 and Add policy3
			List<Policy> policies = new ArrayList<Policy>(0);
			policies.add(policy1);
			policies.add(policy3);
			serviceVersion = addServiceVersionRes.getPayload();
			serviceVersion.setPolicies(policies);
			
			QoS qos3 = addQoS();
		
			List<QoS> qosParams = new ArrayList<QoS>(0);
			QoS qosUpdate = serviceVersion.getQoSParameters().get(0);
			QoS qosDelete = serviceVersion.getQoSParameters().get(1);
			String newValue = qosUpdate.getValue()+"_UPDATED";
			qosUpdate.setValue(newValue);
			qosParams.add(qosUpdate);
			qosParams.add(qos3);
			serviceVersion.setQoSParameters(qosParams);
			
			serviceVersion.setSerVersion(TEST_SERVICE_VERSION_2);
			ServiceRequest<ServiceVersion> updateServiceVersionReq = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion);
			
			ServiceResponse<ServiceVersion> updateServiceVersionResp = registryServiceClient
					.updateServiceVersion(service.getId(), updateServiceVersionReq);
			
			Assert.assertEquals(updateServiceVersionResp.getStatus(), Status.OK);
			Assert.assertNotNull(updateServiceVersionResp.getPayload());
			Assert.assertEquals(updateServiceVersionResp.getPayload().getSerVersion(), TEST_SERVICE_VERSION_2);
			
			Assert.assertTrue(!updateServiceVersionResp.getPayload().getQoSParameters().isEmpty());
			Assert.assertEquals(updateServiceVersionResp.getPayload().getQoSParameters().size(), 2);
			
			Assert.assertEquals(updateServiceVersionResp.getPayload().getPolicies().size(), 2);
		
			qosUpdate = getQoS(updateServiceVersionResp.getPayload().getQoSParameters(), qosUpdate.getId());
			Assert.assertNotNull(qosUpdate);
			Assert.assertEquals(qosUpdate.getValue(), newValue);
			
			qosDelete = getQoS(updateServiceVersionResp.getPayload().getQoSParameters(), qosDelete.getId());
			Assert.assertNull(qosDelete);
		
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testAddServiceVersionCheckDuplicate() throws Exception {
		try {
			Service service = newService(cmdbArtifacts.get(artifactIndex++).getCode());

			ServiceRequest<Service> newServiceRequest = new ServiceRequest<Service>(
					new ServiceHeader(), service);
			ServiceResponse<Service> addedServiceResponse = registryServiceClient
					.addService(newServiceRequest);
			Assert.assertEquals(addedServiceResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse.getPayload());
			service = addedServiceResponse.getPayload();

			ServiceVersion serviceVersion1 = newServiceVersion();
			ServiceRequest<ServiceVersion> addServiceVersionReq1 = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion1);
			ServiceResponse<ServiceVersion> addServiceVersionResp1 = registryServiceClient
					.addServiceVersion(service.getId(), addServiceVersionReq1);
			Assert.assertEquals(addServiceVersionResp1.getStatus(), Status.OK);
			Assert.assertNotNull(addServiceVersionResp1.getPayload());

			// Add another service version with existing 1.0.0
			ServiceVersion serviceVersion2 = newServiceVersion();
			ServiceRequest<ServiceVersion> addServiceVersionReq2 = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion2);
			ServiceResponse<ServiceVersion> addServiceVersionResp2 = registryServiceClient
					.addServiceVersion(service.getId(), addServiceVersionReq2);
			Assert.assertEquals(addServiceVersionResp2.getStatus(), Status.FAIL);
			Assert.assertNull(addServiceVersionResp2.getPayload());
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.assertTrue(true, ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testUpdateServiceVersionBasicFields() {
		try {
			
			NotificationDestination notificationDestination = newNotificationDestination();notificationDestination.setType("EMAIL");notificationDestination.setName("EMAIL");
			ServiceRequest<NotificationDestination> notifReq = new ServiceRequest<NotificationDestination>(
					new ServiceHeader(), notificationDestination);
			ServiceResponse<NotificationDestination> notifResp = notificationDestinationServiceClient.addNotificationDestination(notifReq);
			Assert.assertEquals(notifResp.getStatus(), Status.OK);
			Assert.assertNotNull(notifResp.getPayload());

			Service service = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			service.setNotificationRequested(true);
			service.getNotificationFor().add(AuditType.UPDATE_SERVICE_VERSION.toString());
			service.getNotificationTypes().add(notifResp.getPayload().getName());
			ServiceRequest<Service> newServiceRequest = new ServiceRequest<Service>(
					new ServiceHeader(), service);
			ServiceResponse<Service> addedServiceResponse = registryServiceClient
					.addService(newServiceRequest);
			Service addedService = addedServiceResponse.getPayload();
			Assert.assertEquals(addedServiceResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedService);

			ServiceVersion serviceVersion = newServiceVersion();
			addedService.getServiceVersions().add(serviceVersion);

			ServiceRequest<ServiceVersion> addServiceVersionReq = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion);
			ServiceResponse<ServiceVersion> addedServiceVersionResp = registryServiceClient
					.addServiceVersion(addedService.getId(),
							addServiceVersionReq);
			Assert.assertEquals(addedServiceVersionResp.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceVersionResp.getPayload());

			// update all basic fields
			Calendar cal1 = Calendar.getInstance(); 
			Calendar cal2 = Calendar.getInstance(); 
			cal2.setTimeInMillis(cal1.getTimeInMillis());
			cal2.add(Calendar.MONTH, 1);
		
			Timestamp updateActivationStartDate = new Timestamp(
					cal1.getTimeInMillis());
			Timestamp updateActivationEndDate = new Timestamp(
					cal2.getTimeInMillis());
			Timestamp updatePublicationDate = new Timestamp(
					cal1.getTimeInMillis());
			
			String updatedEsbReference = "ESB_REF1";
			String updatedSerVersion = "2.0.0";
			serviceVersion = addedServiceVersionResp.getPayload();
			serviceVersion.setActivationStartDate(updateActivationStartDate);
			serviceVersion.setActivationEndDate(updateActivationEndDate);
			serviceVersion.setAvailabilityTier(AvailabilityTierType.TIER2
					.toString());
			serviceVersion.setEnvironment(EnvironmentType.QA.toString());
			serviceVersion.setEsbReference(updatedEsbReference);
			serviceVersion.setPublicationDate(updatePublicationDate);
			serviceVersion.setSerVersion(updatedSerVersion);
			serviceVersion.setStatus(StatusType.INACTIVE.toString());

			ServiceRequest<ServiceVersion> updateServiceVersionReq = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion);
			ServiceResponse<ServiceVersion> updateServiceVersionResp = registryServiceClient
					.updateServiceVersion(addedService.getId(),
							updateServiceVersionReq);
			ServiceVersion updatedServiceVersion = updateServiceVersionResp
					.getPayload();

			Assert.assertEquals(updateServiceVersionResp.getStatus(), Status.OK);
			Assert.assertNotNull(updatedServiceVersion);
			Assert.assertEquals(updatedServiceVersion.getActivationStartDate(),
					updateActivationStartDate);
			Assert.assertEquals(updatedServiceVersion.getActivationEndDate(),
					updateActivationEndDate);
			Assert.assertEquals(updatedServiceVersion.getPublicationDate(),
					updatePublicationDate);
			Assert.assertEquals(updatedServiceVersion.getAvailabilityTier(),
					AvailabilityTierType.TIER2.toString());
			Assert.assertEquals(updatedServiceVersion.getEnvironment(),
					EnvironmentType.QA.toString());
			Assert.assertEquals(updatedServiceVersion.getEsbReference(),
					updatedEsbReference);
			Assert.assertEquals(updatedServiceVersion.getSerVersion(),
					updatedSerVersion);
			Assert.assertEquals(updatedServiceVersion.getStatus(),
					StatusType.INACTIVE.toString());
	
			ServiceResponse<ServiceVersion> getServiceVersionReq = registryServiceClient.getServiceVersion(addedService.getId(), updatedSerVersion);
			Assert.assertEquals(getServiceVersionReq.getStatus(), Status.OK);
			Assert.assertNotNull(getServiceVersionReq.getPayload());
			Assert.assertEquals(getServiceVersionReq.getPayload().getActivationStartDate(),
					updateActivationStartDate);
			Assert.assertEquals(getServiceVersionReq.getPayload().getActivationEndDate(),
					updateActivationEndDate);
			
		} catch (Exception ex) {
			Assert.fail(ex.getMessage());
		}
	}
	
	

	@Test(enabled = true)
	public void testUpdateServiceVersionUpdateUrl() {
		try {
			Service service = newService(cmdbArtifacts.get(artifactIndex++).getCode());

			ServiceRequest<Service> newServiceRequest = new ServiceRequest<Service>(
					new ServiceHeader(), service);
			ServiceResponse<Service> addedServiceResponse = registryServiceClient
					.addService(newServiceRequest);
			Service addedService = addedServiceResponse.getPayload();
			Assert.assertEquals(addedServiceResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedService);

			ServiceVersion serviceVersion = newServiceVersion();
			addedService.getServiceVersions().add(serviceVersion);
			
			Url apiDocUrl = new Url();
			apiDocUrl.setType(UrlType.API_DOC.toString());
			apiDocUrl.setUrl("https://confluence.walmart.com/display/PGPSOA/Using+SOARI+E2E+Empty+Maven+Archetype");
			serviceVersion.getUrls().add(apiDocUrl);
			Url apiSampleCode = new Url();
			apiSampleCode.setType(UrlType.API_SAMPLE_CLIENT_CODE.toString());
			apiSampleCode.setUrl("https://gecgithub01.walmart.com/platform/soa-ri/tree/development/registry");
			serviceVersion.getUrls().add(apiSampleCode);

			ServiceRequest<ServiceVersion> addServiceVersionReq = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion);
			ServiceResponse<ServiceVersion> addedServiceVersionResp = registryServiceClient
					.addServiceVersion(addedService.getId(),
							addServiceVersionReq);
			Assert.assertEquals(addedServiceVersionResp.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceVersionResp.getPayload());

			serviceVersion = addedServiceVersionResp.getPayload();
			// delete AlternateEndPointUrl
			String updatedUrlValue = "UPDATED_URL";
			List<Url> urls = new ArrayList<Url>(0);
			for (Url url : serviceVersion.getUrls()) {
				if (UrlType.ENDPOINT_ALTERNATE.toString().equalsIgnoreCase(
						url.getType())) {
					continue;
				}
				if (UrlType.ENDPOINT.toString().equalsIgnoreCase(url.getType())) {
					// update the url
					url.setUrl(updatedUrlValue);
				}
				urls.add(url);
			}
			// Add Contract Url
			Url url = new Url();
			url.setType(UrlType.CONTRACT.toString());
			url.setUrl("TEST_CONTRACT_URL");
			urls.add(url);
			serviceVersion.setUrls(urls);

			ServiceRequest<ServiceVersion> updateServiceVersionReq = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion);
			ServiceResponse<ServiceVersion> updateServiceVersionResp = registryServiceClient
					.updateServiceVersion(addedService.getId(),
							updateServiceVersionReq);

			Assert.assertEquals(updateServiceVersionResp.getStatus(), Status.OK);
			ServiceVersion updatedServiceVersion = updateServiceVersionResp
					.getPayload();

			Assert.assertNotNull(updatedServiceVersion);
			Assert.assertEquals(updatedServiceVersion.getUrls().size(), 4);
			Url deletedUrl = getUrl(updatedServiceVersion.getUrls(),
					UrlType.ENDPOINT_ALTERNATE.toString());
			Assert.assertNull(deletedUrl);
			Url updatedUrl = getUrl(updatedServiceVersion.getUrls(),
					UrlType.ENDPOINT.toString());
			Assert.assertNotNull(updatedUrl);
			Assert.assertEquals(updatedUrl.getUrl(), updatedUrlValue);
			Url addedUrl = getUrl(updatedServiceVersion.getUrls(),
					UrlType.CONTRACT.toString());
			Assert.assertNotNull(addedUrl);
			apiDocUrl = getUrl(updatedServiceVersion.getUrls(),
					UrlType.API_DOC.toString());
			Assert.assertNotNull(apiDocUrl);
			apiSampleCode = getUrl(updatedServiceVersion.getUrls(),
					UrlType.API_SAMPLE_CLIENT_CODE.toString());
			Assert.assertNotNull(apiSampleCode);
			
		} catch (Exception ex) {
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testUpdateServiceVersionUrl() {
		try {
			Service service = newService(cmdbArtifacts.get(artifactIndex++).getCode());

			ServiceRequest<Service> newServiceRequest = new ServiceRequest<Service>(
					new ServiceHeader(), service);
			ServiceResponse<Service> addedServiceResponse = registryServiceClient
					.addService(newServiceRequest);
			Service addedService = addedServiceResponse.getPayload();
			Assert.assertEquals(addedServiceResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedService);

			ServiceVersion serviceVersion = newServiceVersion();
			addedService.getServiceVersions().add(serviceVersion);
			
			
			serviceVersion.getUrls().clear();
			Url urlApiDoc = new Url();
			urlApiDoc.setType(UrlType.API_DOC.toString());
			urlApiDoc.setUrl("https://confluence.walmart.com/display/PGPSOA/Using+SOARI+E2E+Empty+Maven+Archetype");
			serviceVersion.getUrls().add(urlApiDoc);
		
			ServiceRequest<ServiceVersion> addServiceVersionReq = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion);
			ServiceResponse<ServiceVersion> addedServiceVersionResp = registryServiceClient
					.addServiceVersion(addedService.getId(),
							addServiceVersionReq);
			Assert.assertEquals(addedServiceVersionResp.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceVersionResp.getPayload());

			serviceVersion = addedServiceVersionResp.getPayload();
			Assert.assertFalse(serviceVersion.getUrls().isEmpty());
			
			urlApiDoc = serviceVersion.getUrls().get(0);
			serviceVersion.getUrls().clear();
			urlApiDoc.setUrl("xyz");
		
			serviceVersion.getUrls().add(urlApiDoc);

			ServiceRequest<ServiceVersion> updateServiceVersionReq = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion);
			ServiceResponse<ServiceVersion> updateServiceVersionResp = registryServiceClient
					.updateServiceVersion(addedService.getId(),
							updateServiceVersionReq);

			Assert.assertEquals(updateServiceVersionResp.getStatus(), Status.OK);
			ServiceVersion updatedServiceVersion = updateServiceVersionResp
					.getPayload();

			Assert.assertNotNull(updatedServiceVersion);
			Assert.assertEquals(updatedServiceVersion.getUrls().size(), 1);
		} catch (Exception ex) {
			Assert.fail(ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testUpdateServiceVersionWithQoS() throws Exception {
		try {
			Service service = newService(cmdbArtifacts.get(artifactIndex++).getCode());

			ServiceRequest<Service> newServiceRequest = new ServiceRequest<Service>(
					new ServiceHeader(), service);
			ServiceResponse<Service> addedServiceResponse = registryServiceClient
					.addService(newServiceRequest);
			Service addedService = addedServiceResponse.getPayload();
			Assert.assertEquals(addedServiceResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedService);

			ServiceVersion serviceVersion = newServiceVersion();
			ServiceRequest<ServiceVersion> addServiceVersionReq = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion);
			ServiceResponse<ServiceVersion> addedServiceVersionResponse = registryServiceClient
					.addServiceVersion(addedService.getId(),
							addServiceVersionReq);

			serviceVersion = addedServiceVersionResponse.getPayload();
			Assert.assertEquals(addedServiceVersionResponse.getStatus(),
					Status.OK);
			Assert.assertNotNull(serviceVersion);
			
			QoS qos11 = newQoS();
			ServiceRequest<QoS> addQosReq1 = new ServiceRequest<QoS>(new ServiceHeader(), qos11);
			ServiceResponse<QoS> addQosResp1 = qosServiceClient.addQoS(addQosReq1);
			Assert.assertEquals(addQosResp1.getStatus(), Status.OK);
			Assert.assertNotNull(addQosResp1.getPayload());
			qos11 = addQosResp1.getPayload();
		
			serviceVersion.setSerVersion(TEST_SERVICE_VERSION_2);
			
			QoS qos = new QoS();
			qos.setName(qos11.getName());
			qos.setValue("test_qos_value");
			qos.setId(qos11.getId());
			
			serviceVersion.getQoSParameters().add(qos);
			ServiceRequest<ServiceVersion> updateServiceVersionReq = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion);

			ServiceResponse<ServiceVersion> updateServiceVersionRes = registryServiceClient
					.updateServiceVersion(addedService.getId(),
							updateServiceVersionReq);

			Assert.assertEquals(updateServiceVersionRes.getStatus(), Status.OK);
			Assert.assertNotNull(updateServiceVersionRes.getPayload());
			Assert.assertEquals(updateServiceVersionRes.getPayload()
					.getSerVersion(), TEST_SERVICE_VERSION_2);

			ServiceResponse<ServiceVersion> getServiceVersionRes = registryServiceClient
					.getServiceVersion(addedServiceResponse.getPayload()
							.getId(), serviceVersion.getSerVersion());
			Assert.assertEquals(getServiceVersionRes.getStatus(), Status.OK);
			Assert.assertNotNull(getServiceVersionRes.getPayload());
		
			Assert.assertNotNull(getServiceVersionRes.getPayload().getQoSParameters());
			Assert.assertTrue(!getServiceVersionRes.getPayload()
					.getQoSParameters().isEmpty());
			Assert.assertEquals(getServiceVersionRes.getPayload().getQoSParameters().size(), 1);
			

		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testUpdateServiceVersionRetainQoS() throws Exception {
		try {
			Service service = newService(cmdbArtifacts.get(artifactIndex++).getCode());

			ServiceRequest<Service> newServiceRequest = new ServiceRequest<Service>(
					new ServiceHeader(), service);
			ServiceResponse<Service> addedServiceResponse = registryServiceClient
					.addService(newServiceRequest);
			Service addedService = addedServiceResponse.getPayload();
			Assert.assertEquals(addedServiceResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedService);

			ServiceVersion serviceVersion = newServiceVersion();
			ServiceRequest<ServiceVersion> addServiceVersionReq = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion);
			ServiceResponse<ServiceVersion> addedServiceVersionResponse = registryServiceClient
					.addServiceVersion(addedService.getId(),
							addServiceVersionReq);

			serviceVersion = addedServiceVersionResponse.getPayload();
			Assert.assertEquals(addedServiceVersionResponse.getStatus(),
					Status.OK);
			Assert.assertNotNull(serviceVersion);

			// Add QoS
			QoS qosParameter = addQoS();
			ServiceRequest<QoS> addQoSReq = new ServiceRequest<QoS>(
					new ServiceHeader(), qosParameter);
			ServiceResponse<QoS> addedQoSResponse = registryServiceClient
					.addServiceVersionParameter(serviceVersion.getId(),
							addQoSReq);
			Assert.assertEquals(addedQoSResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedQoSResponse.getPayload());
			
			serviceVersion.getQoSParameters().add(qosParameter);
			// Update ServiceVersion
			serviceVersion.setSerVersion(TEST_SERVICE_VERSION_2);

			ServiceRequest<ServiceVersion> updateServiceVersionReq = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion);

			ServiceResponse<ServiceVersion> updateServiceVersionRes = registryServiceClient
					.updateServiceVersion(addedService.getId(),
							updateServiceVersionReq);

			Assert.assertEquals(updateServiceVersionRes.getStatus(), Status.OK);
			Assert.assertNotNull(updateServiceVersionRes.getPayload());
			Assert.assertEquals(updateServiceVersionRes.getPayload()
					.getSerVersion(), TEST_SERVICE_VERSION_2);
			Assert.assertTrue(!updateServiceVersionRes.getPayload()
					.getQoSParameters().isEmpty());
		
			ServiceResponse<ServiceVersion> getServiceVersionRes = registryServiceClient
					.getServiceVersion(addedServiceResponse.getPayload()
							.getId(), serviceVersion.getSerVersion());
			Assert.assertEquals(getServiceVersionRes.getStatus(), Status.OK);
			Assert.assertNotNull(getServiceVersionRes.getPayload());
			Assert.assertTrue(!getServiceVersionRes.getPayload()
					.getQoSParameters().isEmpty());
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testUpdateServiceVersionCheckDuplicate() throws Exception {
		try {
			Service service = newService(cmdbArtifacts.get(artifactIndex++).getCode());

			ServiceRequest<Service> newServiceRequest = new ServiceRequest<Service>(
					new ServiceHeader(), service);
			ServiceResponse<Service> addedServiceResponse = registryServiceClient
					.addService(newServiceRequest);
			Service addedService = addedServiceResponse.getPayload();
			Assert.assertEquals(addedServiceResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedService);

			ServiceVersion serviceVersion1 = newServiceVersion();
			ServiceRequest<ServiceVersion> newServiceVersionRequest1 = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion1);
			ServiceResponse<ServiceVersion> addServiceVersionResponse1 = registryServiceClient
					.addServiceVersion(addedService.getId(),
							newServiceVersionRequest1);
			serviceVersion1 = addServiceVersionResponse1.getPayload();
			Assert.assertEquals(addServiceVersionResponse1.getStatus(),
					Status.OK);
			Assert.assertNotNull(serviceVersion1);

			ServiceVersion serviceVersion2 = newServiceVersion();
			serviceVersion2.setSerVersion(TEST_SERVICE_VERSION_2);
			ServiceRequest<ServiceVersion> newServiceVersionRequest2 = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion2);
			ServiceResponse<ServiceVersion> addServiceVersionResponse2 = registryServiceClient
					.addServiceVersion(addedService.getId(),
							newServiceVersionRequest2);
			serviceVersion2 = addServiceVersionResponse2.getPayload();
			Assert.assertEquals(addServiceVersionResponse2.getStatus(),
					Status.OK);
			Assert.assertNotNull(serviceVersion2);

			// try changing version to the existing one
			serviceVersion2.setSerVersion(serviceVersion1.getSerVersion());

			ServiceRequest<ServiceVersion> updateServiceVersionReq = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion2);
			ServiceResponse<ServiceVersion> updateServiceVersionRes = registryServiceClient
					.updateServiceVersion(addedService.getId(),
							updateServiceVersionReq);
			Assert.assertEquals(updateServiceVersionRes.getStatus(),
					Status.FAIL);
			Assert.assertNull(updateServiceVersionRes.getPayload());
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.assertTrue(true, ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testUpdateServiceVersionAddIfNotFound() throws Exception {
		try {
			Service service = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceRequest<Service> newServiceRequest = new ServiceRequest<Service>(
					new ServiceHeader(), service);
			ServiceResponse<Service> addedServiceResponse = registryServiceClient
					.addService(newServiceRequest);
			Service addedService = addedServiceResponse.getPayload();
			Assert.assertEquals(addedServiceResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedService);

			String serviceId = addedServiceResponse.getPayload().getId();

			// Create ServiceVersion as it doesn't exists
			ServiceVersion serviceVersion = newServiceVersion();
			ServiceRequest<ServiceVersion> updateServiceVersionReq = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion);
			ServiceResponse<ServiceVersion> updateServiceVersionRes = registryServiceClient
					.updateServiceVersion(serviceId, updateServiceVersionReq);
			Assert.assertEquals(updateServiceVersionRes.getStatus(), Status.OK);
			Assert.assertNotNull(updateServiceVersionRes.getPayload());
			Assert.assertEquals(updateServiceVersionRes.getPayload()
					.getSerVersion(), TEST_SERVICE_VERSION_1);

			ServiceResponse<ServiceVersion> getServiceVersionRes = registryServiceClient
					.getServiceVersion(addedServiceResponse.getPayload()
							.getId(), serviceVersion.getSerVersion());
			Assert.assertEquals(getServiceVersionRes.getStatus(), Status.OK);
			Assert.assertNotNull(getServiceVersionRes.getPayload());

		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testDeleteServiceVersion() throws Exception {
		try {
			Service service = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceRequest<Service> newServiceRequest = new ServiceRequest<Service>(
					new ServiceHeader(), service);
			ServiceResponse<Service> addedServiceResponse = registryServiceClient
					.addService(newServiceRequest);
			Assert.assertEquals(addedServiceResponse.getStatus(), Status.OK);
			service = addedServiceResponse.getPayload();
			Assert.assertNotNull(service);

			ServiceVersion serviceVersion = newServiceVersion();
			ServiceRequest<ServiceVersion> newServiceVersionRequest = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion);
			ServiceResponse<ServiceVersion> addedServiceVersionResponse = registryServiceClient
					.addServiceVersion(service.getId(),
							newServiceVersionRequest);

			Assert.assertEquals(addedServiceVersionResponse.getStatus(),
					Status.OK);
			Assert.assertNotNull(addedServiceVersionResponse.getPayload());
			serviceVersion = addedServiceVersionResponse.getPayload();

			ServiceResponse<ServiceVersion> deleteServiceVersionResp = registryServiceClient
					.updateServiceVersionStatus(serviceVersion.getId(), "DELETE","test_user");

			Assert.assertEquals(deleteServiceVersionResp.getStatus(), Status.OK);
			Assert.assertNotNull(deleteServiceVersionResp.getPayload());

			ServiceResponse<ServiceVersion> getServiceVersionRes = registryServiceClient
					.getServiceVersion(service.getId(),
							serviceVersion.getSerVersion());
			Assert.assertEquals(getServiceVersionRes.getStatus(), Status.OK);
			Assert.assertNotNull(getServiceVersionRes.getPayload());
			Assert.assertEquals(getServiceVersionRes.getPayload().getStatus(),
					StatusType.DELETED.toString());

		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testGetServiceVersionParameters() throws Exception {
		try {
			Service service = newService(cmdbArtifacts.get(artifactIndex++).getCode());

			ServiceRequest<Service> newServiceRequest = new ServiceRequest<Service>(
					new ServiceHeader(), service);
			ServiceResponse<Service> addedServiceResponse = registryServiceClient
					.addService(newServiceRequest);
			Assert.assertEquals(addedServiceResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse.getPayload());
			Assert.assertNotNull(addedServiceResponse.getPayload()
					.getServiceVersions());
			Assert.assertEquals(addedServiceResponse.getPayload()
					.getServiceVersions().size(), 0);
			service = addedServiceResponse.getPayload();

			ServiceVersion serviceVersion = newServiceVersion();
			ServiceRequest<ServiceVersion> addServiceVersionRequest = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion);
			ServiceResponse<ServiceVersion> addServiceVersionResponse = registryServiceClient
					.addServiceVersion(service.getId(),
							addServiceVersionRequest);
			Assert.assertEquals(addServiceVersionResponse.getStatus(),
					Status.OK);
			Assert.assertNotNull(addServiceVersionResponse.getPayload());

			serviceVersion = addServiceVersionResponse.getPayload();
			QoS qosParameter1 = addQoS();
			ServiceRequest<QoS> addQoSRequest1 = new ServiceRequest<QoS>(
					new ServiceHeader(), qosParameter1);
			ServiceResponse<QoS> addQoSResponse1 = registryServiceClient
					.addServiceVersionParameter(serviceVersion.getId(),
							addQoSRequest1);
			Assert.assertEquals(addQoSResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addQoSResponse1.getPayload());

			QoS qosParameter2 = addQoS();
			ServiceRequest<QoS> addQoSRequest2 = new ServiceRequest<QoS>(
					new ServiceHeader(), qosParameter2);
			ServiceResponse<QoS> addQoSResponse2 = registryServiceClient
					.addServiceVersionParameter(serviceVersion.getId(),
							addQoSRequest2);
			Assert.assertEquals(addQoSResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addQoSResponse2.getPayload());

			ServiceResponse<QoSList> getQoSResp = registryServiceClient
					.getServiceVersionParameters(serviceVersion.getId());
			Assert.assertEquals(getQoSResp.getStatus(), Status.OK);
			Assert.assertNotNull(getQoSResp.getPayload());
			Assert.assertTrue(!getQoSResp.getPayload().getQosList()
					.isEmpty());
			Assert.assertEquals(getQoSResp.getPayload().getQosList()
					.size(), 2);
			
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testAddServiceVersionParameters() throws Exception {
		try {
			Service service = newService(cmdbArtifacts.get(artifactIndex++).getCode());

			ServiceRequest<Service> newServiceRequest = new ServiceRequest<Service>(
					new ServiceHeader(), service);
			ServiceResponse<Service> addedServiceResponse = registryServiceClient
					.addService(newServiceRequest);
			Assert.assertEquals(addedServiceResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse.getPayload());
			Assert.assertNotNull(addedServiceResponse.getPayload()
					.getServiceVersions());
			Assert.assertEquals(addedServiceResponse.getPayload()
					.getServiceVersions().size(), 0);
			service = addedServiceResponse.getPayload();

			ServiceVersion serviceVersion = newServiceVersion();
			ServiceRequest<ServiceVersion> addServiceVersionRequest = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion);
			ServiceResponse<ServiceVersion> addServiceVersionResponse = registryServiceClient
					.addServiceVersion(service.getId(),
							addServiceVersionRequest);
			Assert.assertEquals(addServiceVersionResponse.getStatus(),
					Status.OK);
			Assert.assertNotNull(addServiceVersionResponse.getPayload());

			serviceVersion = addServiceVersionResponse.getPayload();
			QoS qosParameter1 = addQoS();
			ServiceRequest<QoS> addQoSRequest1 = new ServiceRequest<QoS>(
					new ServiceHeader(), qosParameter1);
			ServiceResponse<QoS> addQoSResponse1 = registryServiceClient
					.addServiceVersionParameter(serviceVersion.getId(),
							addQoSRequest1);
			Assert.assertEquals(addQoSResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addQoSResponse1.getPayload());

			QoS qosParameter2 = addQoS();
			ServiceRequest<QoS> addQoSRequest2 = new ServiceRequest<QoS>(
					new ServiceHeader(), qosParameter2);
			ServiceResponse<QoS> addQoSResponse2 = registryServiceClient
					.addServiceVersionParameter(serviceVersion.getId(),
							addQoSRequest2);
			Assert.assertEquals(addQoSResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addQoSResponse2.getPayload());
			
			ServiceResponse<ServiceVersion> getServiceVersionResponse = registryServiceClient.getServiceVersion(service.getId(), serviceVersion.getSerVersion());
			Assert.assertEquals(getServiceVersionResponse.getStatus(), Status.OK);
			Assert.assertNotNull(getServiceVersionResponse.getPayload());
			Assert.assertNotNull(getServiceVersionResponse.getPayload().getQoSParameters());
			Assert.assertEquals(getServiceVersionResponse.getPayload().getQoSParameters().size(), 2);
			QoS addedQoS1 = getQoS(getServiceVersionResponse.getPayload().getQoSParameters(), qosParameter1.getId());
			QoS addedQoS2 = getQoS(getServiceVersionResponse.getPayload().getQoSParameters(), qosParameter2.getId());
			Assert.assertNotNull(addedQoS1);
			Assert.assertEquals(addedQoS1.getName(), qosParameter1.getName());
			Assert.assertEquals(addedQoS1.getValue(), qosParameter1.getValue());
			Assert.assertNotNull(addedQoS2);
			Assert.assertNotNull(addedQoS2.getCreatedAt());
			Assert.assertNotNull(addedQoS2.getCreatedBy());
			Assert.assertEquals(addedQoS2.getName(), qosParameter2.getName());
			Assert.assertEquals(addedQoS2.getValue(), qosParameter2.getValue());
		
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testAddServiceVersionParametersCheckDuplicate()
			throws Exception {
		try {
			Service service = newService(cmdbArtifacts.get(artifactIndex++).getCode());

			ServiceRequest<Service> newServiceRequest = new ServiceRequest<Service>(
					new ServiceHeader(), service);
			ServiceResponse<Service> addedServiceResponse = registryServiceClient
					.addService(newServiceRequest);
			Assert.assertEquals(addedServiceResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse.getPayload());
			Assert.assertNotNull(addedServiceResponse.getPayload()
					.getServiceVersions());
			Assert.assertEquals(addedServiceResponse.getPayload()
					.getServiceVersions().size(), 0);
			service = addedServiceResponse.getPayload();

			ServiceVersion serviceVersion = newServiceVersion();
			ServiceRequest<ServiceVersion> addServiceVersionRequest = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion);
			ServiceResponse<ServiceVersion> addServiceVersionResponse = registryServiceClient
					.addServiceVersion(service.getId(),
							addServiceVersionRequest);
			Assert.assertEquals(addServiceVersionResponse.getStatus(),
					Status.OK);
			Assert.assertNotNull(addServiceVersionResponse.getPayload());

			serviceVersion = addServiceVersionResponse.getPayload();
			QoS qosParameter1 = addQoS();
			ServiceRequest<QoS> addQoSRequest1 = new ServiceRequest<QoS>(
					new ServiceHeader(), qosParameter1);
			ServiceResponse<QoS> addQoSResponse1 = registryServiceClient
					.addServiceVersionParameter(serviceVersion.getId(),
							addQoSRequest1);
			Assert.assertEquals(addQoSResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addQoSResponse1.getPayload());

			QoS qosParameter2 = addQoS();
			qosParameter2.setName(qosParameter1.getName());
			ServiceRequest<QoS> addQoSRequest2 = new ServiceRequest<QoS>(
					new ServiceHeader(), qosParameter2);
			ServiceResponse<QoS> addQoSResponse2 = registryServiceClient
					.addServiceVersionParameter(serviceVersion.getId(),
							addQoSRequest2);
			Assert.assertEquals(addQoSResponse2.getStatus(), Status.FAIL);
			Assert.assertNull(addQoSResponse2.getPayload());

		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.assertTrue(true, ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testUpdateServiceVersionParameter() throws Exception {
		try {
			Service service = newService(cmdbArtifacts.get(artifactIndex++).getCode());

			ServiceRequest<Service> newServiceRequest = new ServiceRequest<Service>(
					new ServiceHeader(), service);
			ServiceResponse<Service> addedServiceResponse = registryServiceClient
					.addService(newServiceRequest);
			Assert.assertEquals(addedServiceResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse.getPayload());
			Assert.assertNotNull(addedServiceResponse.getPayload()
					.getServiceVersions());
			Assert.assertEquals(addedServiceResponse.getPayload()
					.getServiceVersions().size(), 0);
			service = addedServiceResponse.getPayload();

			ServiceVersion serviceVersion = newServiceVersion();
			ServiceRequest<ServiceVersion> addServiceVersionRequest = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion);
			ServiceResponse<ServiceVersion> addServiceVersionResponse = registryServiceClient
					.addServiceVersion(service.getId(),
							addServiceVersionRequest);
			Assert.assertEquals(addServiceVersionResponse.getStatus(),
					Status.OK);
			Assert.assertNotNull(addServiceVersionResponse.getPayload());

			serviceVersion = addServiceVersionResponse.getPayload();
			QoS qosParameter1 = addQoS();
			ServiceRequest<QoS> addQoSRequest1 = new ServiceRequest<QoS>(
					new ServiceHeader(), qosParameter1);
			ServiceResponse<QoS> addQoSResponse1 = registryServiceClient
					.addServiceVersionParameter(serviceVersion.getId(),
							addQoSRequest1);
			Assert.assertEquals(addQoSResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addQoSResponse1.getPayload());

			QoS qosParameterToUpdate = addQoSResponse1.getPayload();
			long now = System.currentTimeMillis();
			String updatedValue = TEST_QoS_VALUE + now;
			qosParameterToUpdate.setValue(updatedValue);
			qosParameterToUpdate.setModifiedBy("Sanjay");
		
			ServiceRequest<QoS> updateQoSReq = new ServiceRequest<QoS>(
					new ServiceHeader(), qosParameterToUpdate);
			ServiceResponse<QoS> updateQoSResp = registryServiceClient
					.updateServiceVersionParameter(serviceVersion.getId(),
							updateQoSReq);

			Assert.assertEquals(updateQoSResp.getStatus(), Status.OK);
			Assert.assertNotNull(updateQoSResp.getPayload());
			Assert.assertEquals(updateQoSResp.getPayload()
					.getName(), qosParameterToUpdate.getName());

			ServiceResponse<ServiceVersion> getServiceVersionResp = registryServiceClient
					.getServiceVersion(addedServiceResponse.getPayload()
							.getId(), serviceVersion.getSerVersion());
			Assert.assertEquals(getServiceVersionResp.getStatus(), Status.OK);
			Assert.assertNotNull(getServiceVersionResp.getPayload());
			QoS actual = getQoS(getServiceVersionResp
					.getPayload().getQoSParameters(),
					qosParameterToUpdate.getId());
			Assert.assertNotNull(actual);
			//Assert.assertNotNull(actual.getModifiedAt());
			Assert.assertEquals(actual.getModifiedBy(), qosParameterToUpdate.getModifiedBy());
			Assert.assertEquals(actual.getValue(), updatedValue);
			Assert.assertEquals(actual.getName(), qosParameterToUpdate.getName());
		
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testUpdateServiceVersionParameterAddIfNotFound()
			throws Exception {
		try {
			Service service = newService(cmdbArtifacts.get(artifactIndex++).getCode());

			ServiceRequest<Service> newServiceRequest = new ServiceRequest<Service>(
					new ServiceHeader(), service);
			ServiceResponse<Service> addedServiceResponse = registryServiceClient
					.addService(newServiceRequest);
			Assert.assertEquals(addedServiceResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse.getPayload());
			Assert.assertNotNull(addedServiceResponse.getPayload()
					.getServiceVersions());
			Assert.assertEquals(addedServiceResponse.getPayload()
					.getServiceVersions().size(), 0);
			service = addedServiceResponse.getPayload();

			ServiceVersion serviceVersion = newServiceVersion();
			ServiceRequest<ServiceVersion> addServiceVersionRequest = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion);
			ServiceResponse<ServiceVersion> addServiceVersionResponse = registryServiceClient
					.addServiceVersion(service.getId(),
							addServiceVersionRequest);
			Assert.assertEquals(addServiceVersionResponse.getStatus(),
					Status.OK);
			Assert.assertNotNull(addServiceVersionResponse.getPayload());

			serviceVersion = addServiceVersionResponse.getPayload();
			QoS qosParameter = addQoS();
			ServiceRequest<QoS> updateQoSRequest = new ServiceRequest<QoS>(
					new ServiceHeader(), qosParameter);
			ServiceResponse<QoS> updateQoSResponse = registryServiceClient
					.updateServiceVersionParameter(serviceVersion.getId(),
							updateQoSRequest);
			Assert.assertEquals(updateQoSResponse.getStatus(), Status.OK);
			Assert.assertNotNull(updateQoSResponse.getPayload());

			ServiceResponse<ServiceVersion> getServiceVersionResp = registryServiceClient
					.getServiceVersion(service.getId(),
							serviceVersion.getSerVersion());
			Assert.assertEquals(getServiceVersionResp.getStatus(), Status.OK);
			Assert.assertNotNull(getServiceVersionResp.getPayload());
			QoS actual = getQoS(getServiceVersionResp
					.getPayload().getQoSParameters(),
					qosParameter.getId());
			Assert.assertNotNull(actual);
			Assert.assertEquals(actual.getName(),
					qosParameter.getName());
			Assert.assertEquals(actual.getValue(),
					qosParameter.getValue());
			Assert.assertEquals(actual.getStatus(), qosParameter.getStatus());

		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}


	@Test(enabled = true)
	public void testDeleteServiceVersionParameter() throws Exception {
		try {
			Service service = newService(cmdbArtifacts.get(artifactIndex++).getCode());

			ServiceRequest<Service> newServiceRequest = new ServiceRequest<Service>(
					new ServiceHeader(), service);
			ServiceResponse<Service> addedServiceResponse = registryServiceClient
					.addService(newServiceRequest);
			Assert.assertEquals(addedServiceResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse.getPayload());
			Assert.assertNotNull(addedServiceResponse.getPayload()
					.getServiceVersions());
			service = addedServiceResponse.getPayload();

			ServiceVersion serviceVersion = newServiceVersion();
			ServiceRequest<ServiceVersion> addServiceVersionRequest = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion);
			ServiceResponse<ServiceVersion> addServiceVersionResponse = registryServiceClient
					.addServiceVersion(service.getId(),
							addServiceVersionRequest);
			Assert.assertEquals(addServiceVersionResponse.getStatus(),
					Status.OK);
			Assert.assertNotNull(addServiceVersionResponse.getPayload());

			serviceVersion = addServiceVersionResponse.getPayload();
			QoS qosParameter = addQoS();
			ServiceRequest<QoS> addQoSRequest = new ServiceRequest<QoS>(
					new ServiceHeader(), qosParameter);
			ServiceResponse<QoS> addQoSResponse = registryServiceClient
					.addServiceVersionParameter(serviceVersion.getId(),
							addQoSRequest);
			Assert.assertEquals(addQoSResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addQoSResponse.getPayload());
			qosParameter = addQoSResponse.getPayload();

			ServiceResponse<QoS> deleteQoSResponse = registryServiceClient
					.deleteServiceVersionParameter(serviceVersion.getId(), qosParameter.getId());
			Assert.assertEquals(deleteQoSResponse.getStatus(), Status.OK);
			Assert.assertNull(deleteQoSResponse.getPayload());

			ServiceResponse<QoSList> getQoSListResponse = registryServiceClient
					.getServiceVersionParameters(serviceVersion.getId());
			Assert.assertEquals(getQoSListResponse.getStatus(), Status.OK);
			Assert.assertNotNull(getQoSListResponse.getPayload());

			QoS deletedQosParameter = getQoS(
					getQoSListResponse.getPayload().getQosList(),
					qosParameter.getId());
			Assert.assertNull(deletedQosParameter);
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testAddServiceVersionPolicy() throws Exception {
		try {
			Service service = newService(cmdbArtifacts.get(artifactIndex++).getCode());

			ServiceRequest<Service> newServiceRequest = new ServiceRequest<Service>(
					new ServiceHeader(), service);
			ServiceResponse<Service> addedServiceResponse = registryServiceClient
					.addService(newServiceRequest);
			Assert.assertEquals(addedServiceResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse.getPayload());
			service = addedServiceResponse.getPayload();

			ServiceVersion serviceVersion = newServiceVersion();
			ServiceRequest<ServiceVersion> addServiceVersionReq = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion);
			ServiceResponse<ServiceVersion> addedServiceVersionResp = registryServiceClient
					.addServiceVersion(service.getId(), addServiceVersionReq);
			Assert.assertEquals(addedServiceVersionResp.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceVersionResp.getPayload());
			serviceVersion = addedServiceVersionResp.getPayload();
			// Create Policy
			Policy policy = newPolicy();
			ServiceRequest<Policy> addPolicyReq = new ServiceRequest<Policy>(
					new ServiceHeader(), policy);

			ServiceResponse<Policy> addPolicyResp = policyServiceClient
					.addPolicy(addPolicyReq);

			Assert.assertEquals(addPolicyResp.getStatus(), Status.OK);
			Assert.assertNotNull(addPolicyResp.getPayload());

			ServiceResponse<ServiceVersion> addServiceversionPolicyResp = registryServiceClient
					.addServiceVersionPolicy(serviceVersion.getId(),
							addPolicyResp.getPayload().getId());
			Assert.assertEquals(addServiceversionPolicyResp.getStatus(),
					Status.OK);
			Assert.assertNotNull(addServiceversionPolicyResp.getPayload());
			Assert.assertTrue(!addServiceversionPolicyResp.getPayload()
					.getPolicies().isEmpty());
			for(Policy policyVar:addServiceversionPolicyResp.getPayload().getPolicies())
				System.out.println(policyVar.getName());
			
			//Change the added policy
			Policy policyToUpdate = addPolicyResp.getPayload();
			long now = System.currentTimeMillis();
			String updatedName = TEST_POLICY_NAME + now;
			policyToUpdate.setName(updatedName);
			policyToUpdate.setStatus(StatusType.INACTIVE.toString());
			policyToUpdate.setModifiedBy("Test Modifier");
			
			ServiceRequest<Policy> updateReq = new ServiceRequest<Policy>(
					new ServiceHeader(), policyToUpdate);
			ServiceResponse<Policy> updatePolicyResp = policyServiceClient.updatePolicy(updateReq);
			Assert.assertEquals(updatePolicyResp.getStatus(), Status.OK);
			Assert.assertNotNull(updatePolicyResp.getPayload());
			Assert.assertEquals(updatePolicyResp.getPayload().getName(), updatedName);
			
			//Fetch the policy from the service version
			ServiceResponse<ServiceVersion> getServiceVersion = registryServiceClient
					.getServiceVersion(addedServiceResponse.getPayload()
							.getId(), serviceVersion.getSerVersion());
			for(Policy policyVar:getServiceVersion.getPayload().getPolicies())
				System.out.println(policyVar.getName());

		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testGetServiceVersionPolicies() throws Exception {
		try {
			Service service = newService(cmdbArtifacts.get(artifactIndex++).getCode());

			ServiceRequest<Service> newServiceRequest = new ServiceRequest<Service>(
					new ServiceHeader(), service);
			ServiceResponse<Service> addedServiceResponse = registryServiceClient
					.addService(newServiceRequest);
			Assert.assertEquals(addedServiceResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse.getPayload());
			service = addedServiceResponse.getPayload();

			ServiceVersion serviceVersion = newServiceVersion();
			ServiceRequest<ServiceVersion> addServiceVersionReq = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion);
			ServiceResponse<ServiceVersion> addedServiceVersionResp = registryServiceClient
					.addServiceVersion(service.getId(), addServiceVersionReq);
			Assert.assertEquals(addedServiceVersionResp.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceVersionResp.getPayload());
			serviceVersion = addedServiceVersionResp.getPayload();

			// Create Policy1
			Policy policy1 = newPolicy();
			ServiceRequest<Policy> addPolicyReq1 = new ServiceRequest<Policy>(
					new ServiceHeader(), policy1);

			ServiceResponse<Policy> addPolicyResp1 = policyServiceClient
					.addPolicy(addPolicyReq1);

			Assert.assertEquals(addPolicyResp1.getStatus(), Status.OK);
			Assert.assertNotNull(addPolicyResp1.getPayload());

			ServiceResponse<ServiceVersion> addServiceVersionPolicyResp1 = registryServiceClient
					.addServiceVersionPolicy(serviceVersion.getId(),
							addPolicyResp1.getPayload().getId());
			Assert.assertEquals(addServiceVersionPolicyResp1.getStatus(),
					Status.OK);
			Assert.assertNotNull(addServiceVersionPolicyResp1.getPayload());
			Assert.assertTrue(!addServiceVersionPolicyResp1.getPayload()
					.getPolicies().isEmpty());

			// Create Policy2

			Policy policy2 = newPolicy();
			ServiceRequest<Policy> addPolicyReq2 = new ServiceRequest<Policy>(
					new ServiceHeader(), policy2);

			ServiceResponse<Policy> addPolicyResp2 = policyServiceClient
					.addPolicy(addPolicyReq2);

			Assert.assertEquals(addPolicyResp2.getStatus(), Status.OK);
			Assert.assertNotNull(addPolicyResp2.getPayload());

			ServiceResponse<ServiceVersion> addServiceVersionPolicyResp2 = registryServiceClient
					.addServiceVersionPolicy(serviceVersion.getId(),
							addPolicyResp2.getPayload().getId());
			Assert.assertEquals(addServiceVersionPolicyResp2.getStatus(),
					Status.OK);
			Assert.assertNotNull(addServiceVersionPolicyResp2.getPayload());
			Assert.assertTrue(!addServiceVersionPolicyResp2.getPayload()
					.getPolicies().isEmpty());

			ServiceResponse<PolicyList> getServiceVersionPoliciesResp = registryServiceClient
					.getServiceVersionPolicies(serviceVersion.getId());
			Assert.assertEquals(getServiceVersionPoliciesResp.getStatus(),
					Status.OK);
			Assert.assertNotNull(getServiceVersionPoliciesResp.getPayload());
			Assert.assertEquals(getServiceVersionPoliciesResp.getPayload()
					.getPolicies().size(), 2);

		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testDeleteServiceVersionPolicy() throws Exception {
		try {
			Service service = newService(cmdbArtifacts.get(artifactIndex++).getCode());

			ServiceRequest<Service> newServiceRequest = new ServiceRequest<Service>(
					new ServiceHeader(), service);
			ServiceResponse<Service> addedServiceResponse = registryServiceClient
					.addService(newServiceRequest);
			Assert.assertEquals(addedServiceResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse.getPayload());
			service = addedServiceResponse.getPayload();

			ServiceVersion serviceVersion = newServiceVersion();
			ServiceRequest<ServiceVersion> addServiceVersionReq = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion);
			ServiceResponse<ServiceVersion> addedServiceVersionResp = registryServiceClient
					.addServiceVersion(service.getId(), addServiceVersionReq);
			Assert.assertEquals(addedServiceVersionResp.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceVersionResp.getPayload());
			serviceVersion = addedServiceVersionResp.getPayload();

			// Create Policy1
			Policy policy1 = newPolicy();
			ServiceRequest<Policy> addPolicyReq1 = new ServiceRequest<Policy>(
					new ServiceHeader(), policy1);

			ServiceResponse<Policy> addPolicyResp1 = policyServiceClient
					.addPolicy(addPolicyReq1);

			Assert.assertEquals(addPolicyResp1.getStatus(), Status.OK);
			Assert.assertNotNull(addPolicyResp1.getPayload());

			ServiceResponse<ServiceVersion> addServiceVersionPolicyResp1 = registryServiceClient
					.addServiceVersionPolicy(serviceVersion.getId(),
							addPolicyResp1.getPayload().getId());
			Assert.assertEquals(addServiceVersionPolicyResp1.getStatus(),
					Status.OK);
			Assert.assertNotNull(addServiceVersionPolicyResp1.getPayload());
			Assert.assertTrue(!addServiceVersionPolicyResp1.getPayload()
					.getPolicies().isEmpty());

			// Create Policy2

			Policy policy2 = newPolicy();
			ServiceRequest<Policy> addPolicyReq2 = new ServiceRequest<Policy>(
					new ServiceHeader(), policy2);

			ServiceResponse<Policy> addPolicyResp2 = policyServiceClient
					.addPolicy(addPolicyReq2);

			Assert.assertEquals(addPolicyResp2.getStatus(), Status.OK);
			Assert.assertNotNull(addPolicyResp2.getPayload());
			policy2 = addPolicyResp2.getPayload();

			ServiceResponse<ServiceVersion> addServiceVersionPolicyResp2 = registryServiceClient
					.addServiceVersionPolicy(serviceVersion.getId(),
							policy2.getId());
			Assert.assertEquals(addServiceVersionPolicyResp2.getStatus(),
					Status.OK);
			Assert.assertNotNull(addServiceVersionPolicyResp2.getPayload());
			Assert.assertTrue(!addServiceVersionPolicyResp2.getPayload()
					.getPolicies().isEmpty());

			ServiceResponse<ServiceVersion> deleteServiceVersionPolicyResp = registryServiceClient
					.deleteServiceVersionPolicy(serviceVersion.getId(),
							policy2.getId());
			Assert.assertEquals(deleteServiceVersionPolicyResp.getStatus(),
					Status.OK);
			Assert.assertNotNull(deleteServiceVersionPolicyResp.getPayload());

			ServiceResponse<PolicyList> getServiceVersionPoliciesResp = registryServiceClient
					.getServiceVersionPolicies(serviceVersion.getId());
			Assert.assertEquals(getServiceVersionPoliciesResp.getStatus(),
					Status.OK);
			Assert.assertNotNull(getServiceVersionPoliciesResp.getPayload());
			Assert.assertEquals(getServiceVersionPoliciesResp.getPayload()
					.getPolicies().size(), 1);

		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}

	private boolean contains(List<Service> services, String id) {
		for (Service service : services) {
			if (service.getId().equals(id)) {
				return true;
			}
		}
		return false;
	}

	private Url getUrl(List<Url> urls, String type) {
		for (Url url : urls) {
			if (url.getType().equalsIgnoreCase(type)) {
				return url;
			}
		}
		return null;
	}
	
}
