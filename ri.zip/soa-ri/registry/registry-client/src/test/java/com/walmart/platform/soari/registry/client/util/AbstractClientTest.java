package com.walmart.platform.soari.registry.client.util;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.UUID;

import org.apache.commons.lang.math.RandomUtils;
import org.testng.Assert;

import com.walmart.platform.kernel.exception.layers.service.ServiceException;
import com.walmart.platform.soa.common.service.wrappers.ServiceHeader;
import com.walmart.platform.soa.common.service.wrappers.ServiceRequest;
import com.walmart.platform.soa.common.service.wrappers.ServiceResponse;
import com.walmart.platform.soa.common.service.wrappers.Status;
import com.walmart.platform.soa.policy.definition.model.ContextType;
import com.walmart.platform.soari.registry.client.AuditServiceClient;
import com.walmart.platform.soari.registry.client.ConsumerServiceClient;
import com.walmart.platform.soari.registry.client.DefaultPolicyServiceClient;
import com.walmart.platform.soari.registry.client.DefaultQoSServiceClient;
import com.walmart.platform.soari.registry.client.NotificationDestinationServiceClient;
import com.walmart.platform.soari.registry.client.PolicyServiceClient;
import com.walmart.platform.soari.registry.client.QoSServiceClient;
import com.walmart.platform.soari.registry.client.RegistryHealthCheckServiceClient;
import com.walmart.platform.soari.registry.client.RegistryOptionServiceClient;
import com.walmart.platform.soari.registry.client.RegistryServiceClient;
import com.walmart.platform.soari.registry.client.DashboardServiceClient;
import com.walmart.platform.soari.registry.common.dto.Attribute;
import com.walmart.platform.soari.registry.common.dto.Consumer;
import com.walmart.platform.soari.registry.common.dto.DefaultPolicy;
import com.walmart.platform.soari.registry.common.dto.DefaultQoS;
import com.walmart.platform.soari.registry.common.dto.NotificationDestination;
import com.walmart.platform.soari.registry.common.dto.Policy;
import com.walmart.platform.soari.registry.common.dto.QoS;
import com.walmart.platform.soari.registry.common.dto.RegistryOption;
import com.walmart.platform.soari.registry.common.dto.Service;
import com.walmart.platform.soari.registry.common.dto.ServiceVersion;
import com.walmart.platform.soari.registry.common.dto.Subscription;
import com.walmart.platform.soari.registry.common.dto.SubscriptionRequest;
import com.walmart.platform.soari.registry.common.dto.Url;
import com.walmart.platform.soari.registry.common.enums.AuditType;
import com.walmart.platform.soari.registry.common.enums.AvailabilityTierType;
import com.walmart.platform.soari.registry.common.enums.EnvironmentType;
import com.walmart.platform.soari.registry.common.enums.FlowType;
import com.walmart.platform.soari.registry.common.enums.NotificationDestinationType;
import com.walmart.platform.soari.registry.common.enums.PolicyType;
import com.walmart.platform.soari.registry.common.enums.ServiceCategoryType;
import com.walmart.platform.soari.registry.common.enums.ServiceCommunicationType;
import com.walmart.platform.soari.registry.common.enums.ServiceDomainType;
import com.walmart.platform.soari.registry.common.enums.ServiceUseType;
import com.walmart.platform.soari.registry.common.enums.StatusType;
import com.walmart.platform.soari.registry.common.enums.UrlType;
import com.walmart.platform.test.AbstractClientServerTest;

public abstract class AbstractClientTest extends AbstractClientServerTest {
	
	protected RegistryServiceClient registryServiceClient;
	protected PolicyServiceClient policyServiceClient;
	protected DefaultPolicyServiceClient defaultPolicyServiceClient;
	protected ConsumerServiceClient consumerServiceClient;
	protected NotificationDestinationServiceClient notificationDestinationServiceClient;
	protected QoSServiceClient qosServiceClient;
	protected DefaultQoSServiceClient defaultQosServiceClient;
	protected RegistryOptionServiceClient registryOptionServiceClient;
	protected AuditServiceClient auditServiceClient;
	protected RegistryHealthCheckServiceClient registryHealthCheckServiceClient;
	protected DashboardServiceClient dashboardServiceClient;
	private static final String HOST_STRING = "http://localhost:"+PlatformJAXRSHttpServer.PORT+"/registry-app/services";
	
	public static final String TEST_SERVICE_APPLICATION_ID = "TEST_SERVICE_RAPPLICATION_ID";
	public static final String TEST_SERVICE_DESCRIPTION = "TEST_SERVICE_DESCRIPTION";
	public static final String TEST_MAINTENANCE_CREATED_BY = "TEST_USER";
	public static final String TEST_SERVICE_NAME = "TEST_SERVICE_NAME";
	public static final String TEST_SERVICE_OWNER = "TEST_SERVICE_OWNER";
	public static final String TEST_SERVICE_VERSION_1 = "1.0.0";
	public static final String TEST_SERVICE_VERSION_2 = "2.0.0";
	
	public static final String TEST_END_POINT_URL = "http:\\endpoint.url";
	public static final String TEST_ESB_PROXY_URL = "http:\\esbproxy.url";
	public static final String TEST_END_POINT_URL_ALTERNATE = "http:\\alternateendpoint.url";
	public static final String TEST_CONTRACT_URL = "http:\\contract.url";
	public static final String TEST_ESB_ALTERNATE = "http:\\esbalternate.url";
	public static final String TEST_LOCAL_ENDPOINT = "http:\\localendpoint.url";
	public static final String TEST_API_DOC_URL = "http:\\apidoc.url";
	public static final String TEST_API_SAMPLE_CLIENT_CODE = "http:\\samplecode.url";
	
	public static final String TEST_QoS_NAME = "TEST_QoS_NAME";
	public static final String TEST_QoS_VALUE = "TEST_QoS_VALUE";
	public static final String TEST_QoS_PARENT_ID = "TEST_QoS_PARENT_ID";
	
	public static final String TEST_POLICY_NAME = "TEST_POLICY";
	public static final String TEST_NOTIFICATION_DESTINATION_NAME = "TEST_NOTIFICATION_DEST";
	protected static final String TEST_POLICY_VERSION1 = "TEST_POLICY_VERSION1";
	protected static final String TEST_POLICY_URL = "TEST_POLICY_URL";
	protected String TEST_CREATED_BY_USER = "TEST_CREATED_BY_USER"; 
	protected String TEST_MODIFIED_BY_USER = "TEST_MODIFIED_BY_USER"; 
	protected List<RegistryOption> cmdbArtifacts = new ArrayList<RegistryOption>(0);
	protected List<RegistryOption> jiraProjects = new ArrayList<RegistryOption>(0);
	protected List<RegistryOption> cmdbEnvironments = new ArrayList<RegistryOption>(0);
	
	 static {
			System.setProperty("com.walmart.platform.config.localConfigLocation",
					"");
			System.setProperty("com.walmart.platform.config.runOnEnv",
					"default");
	 }
	 
	protected void init(){
		registryServiceClient = new RegistryServiceClient(HOST_STRING);
		policyServiceClient = new PolicyServiceClient(HOST_STRING);
		defaultPolicyServiceClient = new DefaultPolicyServiceClient(HOST_STRING);
		consumerServiceClient = new ConsumerServiceClient(HOST_STRING);
		notificationDestinationServiceClient = new NotificationDestinationServiceClient(HOST_STRING);
		qosServiceClient = new QoSServiceClient(HOST_STRING);
		defaultQosServiceClient = new DefaultQoSServiceClient(HOST_STRING);
		registryOptionServiceClient = new RegistryOptionServiceClient(HOST_STRING);
		auditServiceClient = new AuditServiceClient(HOST_STRING);
		registryHealthCheckServiceClient = new RegistryHealthCheckServiceClient(HOST_STRING);
		dashboardServiceClient = new DashboardServiceClient(HOST_STRING);
	}
	
	protected Policy newPolicy() {
		long now = System.currentTimeMillis();
		int random = RandomUtils.nextInt(10);
		Policy policy = new Policy();
		policy.setDescription("TEST_POLICY_DESCRPTION");
		policy.setType(PolicyType.SLA.toString());
		//policy.setData("TEST_POLICY".getBytes());
		policy.setData(getSamplePolicyData());
		policy.setStatus(StatusType.ACTIVE.toString());
		policy.setName(TEST_POLICY_NAME+now+random);
		policy.setOrder(1);
		policy.setFlow(FlowType.REQUEST.toString());
		policy.setCreatedBy("Test Creator");
		policy.setContext(ContextType.SERVICE.toString());
		//policy.setModifiedBy("Test");
		return policy;
	}
	
	protected DefaultPolicy newDefaultPolicy() {
		long now = System.currentTimeMillis();
		int random = RandomUtils.nextInt(10);
		DefaultPolicy policy = new DefaultPolicy();
		policy.setDescription("TEST_POLICY_DESCRPTION");
		policy.setType(PolicyType.SLA.toString());
		//policy.setData("TEST_POLICY".getBytes());
		policy.setData(getSamplePolicyData());
		policy.setStatus(StatusType.ACTIVE.toString());
		policy.setName(TEST_POLICY_NAME+now+random);
		policy.setOrder(1);
		policy.setFlow(FlowType.REQUEST.toString());
		//policy.setCreatedBy("Test Creator");
		policy.setContext(ContextType.SERVICE.toString());
		//policy.setModifiedBy("Test");
		return policy;
	}

	protected Consumer newConsumer() {
		Consumer consumer = new Consumer();
		consumer.setConsumerId(UUID.randomUUID().toString().replace("-", ""));
		consumer.setCreatedBy("Test Creator");
		return consumer;
	}
	
	protected SubscriptionRequest newSubscription(ServiceVersion serviceVersion, Consumer consumer) {
		SubscriptionRequest subscription = new SubscriptionRequest();
		subscription.setCommunicationType(ServiceCommunicationType.ESB_PROXY.toString());
		subscription.setConsumerId(consumer.getConsumerId());
		subscription.setCreatedBy("Test Creator");
		subscription.setServiceVersionId(serviceVersion.getId());
		subscription.setStatus(StatusType.ACTIVE.toString());
		return subscription;
	}
	
	protected List<Url> newUrls() {
		List<Url> urls = new ArrayList<Url>(0);
		Url url = new Url();
		url.setType(UrlType.ENDPOINT.toString());
		url.setUrl(TEST_END_POINT_URL);
		urls.add(url);
		url = new Url();
		url.setType(UrlType.ENDPOINT_ALTERNATE.toString());
		url.setUrl(TEST_END_POINT_URL_ALTERNATE);
		urls.add(url);
		url = new Url();
		url.setType(UrlType.ESB_PROXY.toString());
		url.setUrl(TEST_ESB_PROXY_URL);
		urls.add(url);
		url = new Url();
		url.setType(UrlType.CONTRACT.toString());
		url.setUrl(TEST_CONTRACT_URL);
		urls.add(url);
		url = new Url();
		url.setType(UrlType.API_DOC.toString());
		url.setUrl(TEST_API_DOC_URL);
		urls.add(url);
		url = new Url();
		url.setType(UrlType.API_SAMPLE_CLIENT_CODE.toString());
		url.setUrl(TEST_API_SAMPLE_CLIENT_CODE);
		urls.add(url);
		url = new Url();
		url.setType(UrlType.ESB_ALTERNATE.toString());
		url.setUrl(TEST_ESB_ALTERNATE);
		urls.add(url);
		url = new Url();
		url.setType(UrlType.LOCAL_ENDPOINT.toString());
		url.setUrl(TEST_LOCAL_ENDPOINT);
		urls.add(url);
		return urls;
	}
	
	protected Attribute getAttribute(List<Attribute> attributes, String type) {
		for(Attribute attribute : attributes) {
			if(attribute.getName().equals(type)) {
				return attribute;
			}
		}
		return null;
	}
	
	protected NotificationDestination newNotificationDestination() {
		long now = System.currentTimeMillis();
		int random = RandomUtils.nextInt(10);
		NotificationDestination notificationDestination = new NotificationDestination();
		notificationDestination.setType(NotificationDestinationType.JMS.toString());
		notificationDestination.setStatus(StatusType.ACTIVE.toString());
		notificationDestination.setName(TEST_NOTIFICATION_DESTINATION_NAME+now+random);
		notificationDestination.setAvailabilityTier(AvailabilityTierType.TIER1.toString());
		notificationDestination.setEnvironment(EnvironmentType.DEV.toString());
		notificationDestination.setUrl("TEST_URL");
		notificationDestination.setCreatedBy("Test");
		notificationDestination.setModifiedBy("Test");
		return notificationDestination;
	}

	protected NotificationDestination addNotificationDestination(String name) throws ServiceException{
		NotificationDestination notificationDestination = newNotificationDestination();
		notificationDestination.setName(name);
		ServiceRequest<NotificationDestination> newNotificationDestinationRequest = new ServiceRequest<NotificationDestination>(
				new ServiceHeader(), notificationDestination);
		ServiceResponse<NotificationDestination> addedNotificationDestinationResponse = notificationDestinationServiceClient
				.addNotificationDestination(newNotificationDestinationRequest);
		Assert.assertEquals(addedNotificationDestinationResponse.getStatus(), Status.OK);
		Assert.assertNotNull(addedNotificationDestinationResponse.getPayload());
		return addedNotificationDestinationResponse.getPayload();
	}
	
	/*protected NotificationDestination addEmailNotificationDestination(String name) throws ServiceException{
		NotificationDestination notificationDestination = newNotificationDestination();
		notificationDestination.setType(NotificationDestinationType.EMAIL.toString());
		notificationDestination.setName(name);
		ServiceRequest<NotificationDestination> newNotificationDestinationRequest = new ServiceRequest<NotificationDestination>(
				new ServiceHeader(), notificationDestination);
		ServiceResponse<NotificationDestination> addedNotificationDestinationResponse = notificationDestinationServiceClient
				.addNotificationDestination(newNotificationDestinationRequest);
		Assert.assertEquals(addedNotificationDestinationResponse.getStatus(), Status.OK);
		Assert.assertNotNull(addedNotificationDestinationResponse.getPayload());
		return addedNotificationDestinationResponse.getPayload();
	}
	
	protected NotificationDestination addJIRANotificationDestination(String name) throws ServiceException{
		NotificationDestination notificationDestination = newNotificationDestination();
		notificationDestination.setType(NotificationDestinationType.JIRA.toString());
		notificationDestination.setName(name);
		ServiceRequest<NotificationDestination> newNotificationDestinationRequest = new ServiceRequest<NotificationDestination>(
				new ServiceHeader(), notificationDestination);
		ServiceResponse<NotificationDestination> addedNotificationDestinationResponse = notificationDestinationServiceClient
				.addNotificationDestination(newNotificationDestinationRequest);
		Assert.assertEquals(addedNotificationDestinationResponse.getStatus(), Status.OK);
		Assert.assertNotNull(addedNotificationDestinationResponse.getPayload());
		return addedNotificationDestinationResponse.getPayload();
	}*/
	
	protected Service newService(String artfactId) {
		int random = RandomUtils.nextInt();
		//int random2 = RandomUtils.nextInt();
		Service service = new Service();
		//long now = System.currentTimeMillis();
		service.setEnvironment("DEFAULT");
		service.setStatus(StatusType.ACTIVE.toString());
		service.setApplicationId(artfactId);
		service.setCategory(ServiceCategoryType.DATA.toString());
		service.setDescription(TEST_SERVICE_DESCRIPTION);
		service.setName(TEST_SERVICE_NAME+random);
		service.setOwner(TEST_SERVICE_OWNER);
		service.setDomain(ServiceDomainType.B2B.toString());
		service.setUsage(ServiceUseType.INTERNAL.toString());
		service.setCreatedBy("Test");
		service.setModifiedBy("Test");
		service.getNotificationFor().add(AuditType.ADD_SERVICE.toString());
		service.getNotificationFor().add(AuditType.ADD_POLICY.toString());
		return service;
	}
	
	protected Service newService(String artfactId, String environment) {
		Service service = newService(artfactId);
		service.setEnvironment(environment);
		return service;
	}
	
	protected ServiceVersion newServiceVersion() {
		ServiceVersion serviceVersion = new ServiceVersion();
		serviceVersion.setStatus(StatusType.ACTIVE.toString());
		Calendar cal1 = Calendar.getInstance(); 
		Calendar cal2 = Calendar.getInstance(); 
		cal2.setTimeInMillis(cal1.getTimeInMillis());
		cal2.add(Calendar.MONTH, 1);

		serviceVersion.setActivationStartDate(new Timestamp(cal1.getTimeInMillis()));
		serviceVersion.setActivationEndDate(new Timestamp(cal2.getTimeInMillis()));
		serviceVersion.setAvailabilityTier(AvailabilityTierType.TIER1.toString());
		serviceVersion.setEsbReference("ESB_REF1");
		serviceVersion.setEnvironment("DEV");
		serviceVersion.setPublicationDate(new Timestamp(System.currentTimeMillis()));
		serviceVersion.setSerVersion(TEST_SERVICE_VERSION_1);
		//serviceVersion.setService(service);
		//serviceVersion.setQoSs(qosParameters);
		serviceVersion.setStatus("ACTIVE");
		Url endPonitUrl = new Url();
		endPonitUrl.setType(UrlType.ENDPOINT.toString());
		endPonitUrl.setUrl(TEST_END_POINT_URL);
		serviceVersion.getUrls().add(endPonitUrl);
		Url endPonitUrlAlternate = new Url();
		endPonitUrlAlternate.setType(UrlType.ENDPOINT_ALTERNATE.toString());
		endPonitUrlAlternate.setUrl(TEST_END_POINT_URL_ALTERNATE);
		serviceVersion.getUrls().add(endPonitUrlAlternate);
	
		serviceVersion.setCreatedBy("Test");
		serviceVersion.setModifiedBy("Test");
		
		serviceVersion.getAttributes().add(new Attribute("Attribute1", "Value1"));
		serviceVersion.getAttributes().add(new Attribute("Attribute2", "Value2"));
		
		return serviceVersion;
	}
	
	/*protected QOS newQoS() {
		QOS qosParameter = new QOS();
		long now = System.currentTimeMillis();
		qosParameter.setName(TEST_QoS_NAME+now);
		qosParameter.setValue(TEST_QoS_VALUE);
		return qosParameter;
	}*/

	protected QoS newQoS() {
		long now = System.currentTimeMillis();
		int random = RandomUtils.nextInt(10);
		QoS qos = new QoS();
		qos.setDescription("TEST_QOS_DESCRPTION"+now+random);
		qos.setType("SLA");
		qos.setStatus(StatusType.ACTIVE.toString());
		qos.setName(TEST_QoS_NAME+now+random);
		qos.setCreatedBy(TEST_CREATED_BY_USER);
		return qos;
	}
	
	protected DefaultQoS newDefaultQoS() {
		long now = System.currentTimeMillis();
		int random = RandomUtils.nextInt(10);
		DefaultQoS qos = new DefaultQoS();
		
		qos.setDescription("TEST_QOS_DESCRPTION"+now+random);
		qos.setType("SLA");
		qos.setStatus(StatusType.ACTIVE.toString());
		qos.setName(TEST_QoS_NAME+now+random);
		qos.setCategory("BIZ");
		qos.setEnvironment("default");
		qos.setValue("VALUE"+now);
		
		return qos;
	}
	
	protected boolean existsParameter(List<QoS> qosParameters, String paramName) {
		for(QoS qosParameter : qosParameters) {
			if(paramName.equals(qosParameter.getName())) {
				return true;
			}
		}
		return false;
	}
	
	protected QoS getQoS(List<QoS> qosParameters, String id) {
		for(QoS qosParameter : qosParameters) {
			if(id.equals(qosParameter.getId())) {
				return qosParameter;
			}
		}
		return null;
	}

	protected Policy getPolicy(List<Policy> policies, String id) {
		for(Policy policy : policies) {
			if(id.equals(policy.getId())) {
				return policy;
			}
		}
		return null;
	}

	protected boolean existsVersion(List<ServiceVersion> serviceVersions, String serVersion) {
		for(ServiceVersion serviceVersion : serviceVersions) {
			if(serVersion.equals(serviceVersion.getSerVersion())) {
				return true;
			}
		}
		return false;
	}
	
	protected ServiceVersion getServiceVersion(List<ServiceVersion> serviceVersions, String serVersion) {
		for(ServiceVersion serviceVersion : serviceVersions) {
			if(serVersion.equals(serviceVersion.getSerVersion())) {
				return serviceVersion;
			}
		}
		return null;
	}
	
	protected Subscription getSubscriptionByServiceVersionId(List<Subscription> subscriptions, String serviceVersionId) {
		for(Subscription subscription : subscriptions) {
			if(subscription.getServiceVersionId().equals(serviceVersionId)) {
				return subscription;
			}
		}
		return null;
	}
	
	protected List<String> getAlternateUrls(List<Attribute> attributes) {
		List<String> alternateUrls = new ArrayList<String>(0);
		for(Attribute attribute : attributes) {
			if(UrlType.ENDPOINT_ALTERNATE.toString().equals(attribute.getName())) {
				alternateUrls.add(attribute.getValue());
			}
		}
		return alternateUrls;
	}
	
	protected Service getService(List<Service> services, String name) {
		for(Service service : services) {
			if(name.equals(service.getName())) {
				return service;
			}
		}
		return null;
	}
	protected Service getServiceById(List<Service> services, String id) {
		for(Service service : services) {
			if(service.getId().equals(id)) {
				return service;
			}
		}
		return null;
	}

	protected QoS addQoS() throws Exception {
		QoS qos = newQoS();
		ServiceRequest<QoS> newQoSRequest = new ServiceRequest<QoS>(
				new ServiceHeader(), qos);
		ServiceResponse<QoS> addedQoSResponse = qosServiceClient
				.addQoS(newQoSRequest);
		Assert.assertEquals(addedQoSResponse.getStatus(), Status.OK);
		Assert.assertNotNull(addedQoSResponse.getPayload());
		qos =  addedQoSResponse.getPayload();
		qos.setValue(TEST_QoS_VALUE);
		return qos;
	}
	
	protected static String getSamplePolicyData(){
		StringBuffer sb = new StringBuffer();
		sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
		sb.append("<!--Max error count alert policy -->");
		sb.append("<p:PolicyDefinition type=\"SLA\" order=\"2\" flow=\"RESPONSE\" ");
		sb.append("	xmlns:p=\"http://platform.walmart.com/soa/policy/definition/model\"");
		sb.append("	xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"");
		sb.append("	xsi:schemaLocation=\"http://platform.walmart.com/soa/policy/definition/model policy-schema.xsd \">");
		sb.append(" <Rule id=\"max_error_alert_policy\">");
		sb.append(" <if leftTerm=\"REQUEST_ERROR_COUNT\" op=\"&gt;\" rightTerm=\"QOS_MAX_ERROR_ALERT\" />");
		sb.append(" <then>");
		sb.append(" <action>");
		sb.append(" <type>ALERT</type>");
		sb.append(" <value>true</value>");
		sb.append(" </action>");
		sb.append(" </then>");
		sb.append(" </Rule>");
		sb.append("</p:PolicyDefinition>");
		return sb.toString();
	}
	
	protected boolean equals(ServiceVersion src, ServiceVersion dest) {
		
		return true;
	}
	protected static Consumer getConsumer(List<Consumer> consumers, String consumerId) {
		for(Consumer consumer : consumers) {
			if(consumerId.equals(consumer.getConsumerId())) {
				return consumer;
			}
		}
		return null;
	}
	protected Consumer getConsumerById(List<Consumer> consumers, String id) {
		for(Consumer consumer : consumers) {
			if(consumer.getId().equals(id)) {
				return consumer;
			}
		}
		return null;
	}


}
