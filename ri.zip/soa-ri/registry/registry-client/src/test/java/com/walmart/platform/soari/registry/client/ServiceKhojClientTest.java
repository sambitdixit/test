package com.walmart.platform.soari.registry.client;

import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.core.MediaType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.walmart.platform.soa.common.HeaderElements;
import com.walmart.platform.soa.common.service.wrappers.ServiceHeader;
import com.walmart.platform.soa.common.service.wrappers.ServiceRequest;
import com.walmart.platform.soa.common.service.wrappers.ServiceResponse;
import com.walmart.platform.soa.common.service.wrappers.Status;
import com.walmart.platform.soa.http.client.PlatformHttpClient;
import com.walmart.platform.soa.service.khoj.client.KhojDirectory;
import com.walmart.platform.soari.registry.client.util.AbstractClientTest;
import com.walmart.platform.soari.registry.client.util.PlatformJAXRSHttpServer;
import com.walmart.platform.soari.registry.common.dto.Consumer;
import com.walmart.platform.soari.registry.common.dto.ConsumerList;
import com.walmart.platform.soari.registry.common.dto.RegistryOptionList;
import com.walmart.platform.soari.registry.common.dto.Service;
import com.walmart.platform.soari.registry.common.dto.ServiceList;
import com.walmart.platform.soari.registry.common.dto.ServiceSearchBean;
import com.walmart.platform.soari.registry.common.dto.ServiceVersion;
import com.walmart.platform.soari.registry.common.dto.Subscription;
import com.walmart.platform.soari.registry.common.dto.SubscriptionList;
import com.walmart.platform.soari.registry.common.dto.SubscriptionRequest;
import com.walmart.platform.soari.registry.common.dto.Url;
import com.walmart.platform.soari.registry.common.enums.RegistryPolicyCodeType;
import com.walmart.platform.soari.registry.common.enums.StatusType;
import com.walmart.platform.soari.registry.common.enums.UrlType;

public class ServiceKhojClientTest extends AbstractClientTest {
	private static final Logger LOG = LoggerFactory
			.getLogger(ServiceKhojClientTest.class);

	int artifactIndex = 0;
	private KhojDirectory directory = KhojDirectory.getInstance();
	private String host;

	@BeforeClass
	public void startServers() throws Exception {
		Assert.assertTrue(launchServer(PlatformJAXRSHttpServer.class, true),
				"server did not launch correctly");
		init();
		ServiceResponse<RegistryOptionList> gerRegistryOptionResp = registryOptionServiceClient
				.getOptionsByType(RegistryPolicyCodeType.CMDB_ARTIFACT);
		Assert.assertEquals(gerRegistryOptionResp.getStatus(), Status.OK);
		Assert.assertNotNull(gerRegistryOptionResp.getPayload());
		Assert.assertNotNull(gerRegistryOptionResp.getPayload().getOptions());
		Assert.assertFalse(gerRegistryOptionResp.getPayload().getOptions()
				.isEmpty());
		cmdbArtifacts.addAll(gerRegistryOptionResp.getPayload().getOptions());

		gerRegistryOptionResp = registryOptionServiceClient
				.getOptionsByType(RegistryPolicyCodeType.JIRA_PROJECT);
		Assert.assertEquals(gerRegistryOptionResp.getStatus(), Status.OK);
		Assert.assertNotNull(gerRegistryOptionResp.getPayload());
		Assert.assertNotNull(gerRegistryOptionResp.getPayload().getOptions());
		Assert.assertFalse(gerRegistryOptionResp.getPayload().getOptions()
				.isEmpty());
		jiraProjects.addAll(gerRegistryOptionResp.getPayload().getOptions());
		host = "http://localhost:"
				+ System.getProperty("testutil.ports.jaxrs-http");
		directory.setKhojUrlForEnv("default", host);
	}

	@SuppressWarnings({ "unchecked", "deprecation" })
	@Test(enabled = true)
	public void testAddSubscriptions() throws Exception {
		try {
			Consumer consumer = newConsumer();

			ServiceRequest<Consumer> newConsumerRequest = new ServiceRequest<Consumer>(
					new ServiceHeader(), consumer);
			ServiceResponse<Consumer> addedConsumerResponse = consumerServiceClient
					.addConsumer(newConsumerRequest);
			Assert.assertEquals(addedConsumerResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedConsumerResponse.getPayload());
			Assert.assertEquals(addedConsumerResponse.getPayload()
					.getConsumerId(), consumer.getConsumerId());

			consumer = addedConsumerResponse.getPayload();

			Service service1 = newService(cmdbArtifacts.get(artifactIndex++)
					.getCode());
			service1.setEnvironment("default");
			service1.setOwner("sbonde@walmartlabs.com");
			service1.setJiraProject("PGPSOA");
			ServiceVersion serviceVersion1 = newServiceVersion();
			serviceVersion1.getUrls().clear();
			Url esbUrl = new Url();
			esbUrl.setType(UrlType.ESB_PROXY.toString());
			esbUrl.setUrl(host + "/registry-app/services");
			serviceVersion1.getUrls().add(esbUrl);
			serviceVersion1.setSerVersion("1.0.0");
			service1.getServiceVersions().add(serviceVersion1);

			ServiceVersion serviceVersion2 = newServiceVersion();
			serviceVersion2.setSerVersion("1.0.1");
			service1.getServiceVersions().add(serviceVersion2);

			ServiceRequest<Service> newServiceRequest = new ServiceRequest<Service>(
					new ServiceHeader(), service1);
			ServiceResponse<Service> addedServiceResponse = registryServiceClient
					.addService(newServiceRequest);
			Assert.assertEquals(addedServiceResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse.getPayload());
			Assert.assertEquals(addedServiceResponse.getPayload()
					.getServiceVersions().size(), service1.getServiceVersions()
					.size());

			service1 = addedServiceResponse.getPayload();
			serviceVersion1 = getServiceVersion(service1.getServiceVersions(),
					serviceVersion1.getSerVersion());
			Subscription subscription1 = (Subscription) newSubscription(
					serviceVersion1, consumer);

			ServiceRequest<SubscriptionRequest> addSubscriptionRequest = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription1);
			ServiceResponse<Subscription> addSubscriptionsResp = consumerServiceClient
					.addSubscription(consumer.getConsumerId(),
							addSubscriptionRequest);
			Assert.assertEquals(addSubscriptionsResp.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp.getPayload());

			ServiceResponse<ConsumerList> getConsumersResp = consumerServiceClient
					.getConsumers();
			Assert.assertEquals(getConsumersResp.getStatus(), Status.OK);
			Assert.assertNotNull(getConsumersResp.getPayload());
			Assert.assertNotNull(getConsumersResp.getPayload().getConsumers());
			Assert.assertFalse(getConsumersResp.getPayload().getConsumers()
					.isEmpty());

			consumer = getConsumer(
					getConsumersResp.getPayload().getConsumers(),
					consumer.getConsumerId());
			Assert.assertNotNull(getConsumersResp.getPayload().getConsumers());

			Subscription actual = getSubscriptionByServiceVersionId(
					consumer.getSubscriptions(), serviceVersion1.getId());
			Assert.assertNotNull(actual);
			Assert.assertEquals(actual.getConsumerId(),
					subscription1.getConsumerId());
			Assert.assertEquals(actual.getCommunicationType(),
					subscription1.getCommunicationType());
			Assert.assertEquals(actual.getEnvironment(),
					service1.getEnvironment());
			Assert.assertEquals(actual.getServiceId(), service1.getId());
			Assert.assertEquals(actual.getServiceName(), service1.getName());
			Assert.assertEquals(actual.getServiceVersionId(),
					serviceVersion1.getId());
			Assert.assertEquals(actual.getStatus(), "INACTIVE");
			Assert.assertEquals(actual.getVersionNumber(),
					serviceVersion1.getSerVersion());

			ServiceSearchBean search = new ServiceSearchBean();
			search.setConsumerId(actual.getConsumerId());
			search.setSerVersion(actual.getVersionNumber());
			search.setName(actual.getServiceName());
			ServiceResponse<SubscriptionList> searchSubscriptionResp = consumerServiceClient
					.searchSubscriptions(search);
			Assert.assertEquals(searchSubscriptionResp.getStatus(), Status.OK);
			Assert.assertNotNull(searchSubscriptionResp.getPayload());
			Assert.assertNotNull(searchSubscriptionResp.getPayload()
					.getSubscriptions());
			Assert.assertFalse(searchSubscriptionResp.getPayload()
					.getSubscriptions().isEmpty());

			ServiceResponse<Subscription> activateSubscriptionResp = consumerServiceClient
					.updateSubscriptionStatus(actual.getId(), "ACTIVATE",
							"sbonde@walmartlabs.com");
			Assert.assertEquals(activateSubscriptionResp.getStatus(), Status.OK);
			Assert.assertNotNull(activateSubscriptionResp.getPayload());
			Assert.assertEquals(activateSubscriptionResp.getPayload()
					.getStatus(), StatusType.ACTIVE.toString());

			PlatformHttpClient httpClient = PlatformHttpClient.getInstance();
			httpClient.setExtraClass(new Class[] { String.class, Service.class,
					ServiceList.class });

			Map<String, String> headers = new HashMap<String, String>();
			setMandatoryHeaders(headers, serviceVersion1.getSerVersion(),
					actual.getServiceName());
			headers.put(HeaderElements.CONSUMER_ID, actual.getConsumerId());
			headers.put(HeaderElements.SERVICE_DISCOVERY_STRATEGY,
					HeaderElements.DiscoveryStrategy.CONSUMER.toString());

			httpClient.setAcceptType(MediaType.APPLICATION_XML);
			httpClient.setContentType(MediaType.APPLICATION_XML);
			ServiceResponse<ServiceList> response = httpClient.get(
					"/registry/service", null, headers, ServiceResponse.class,
					ServiceList.class);

			Assert.assertEquals(response.getStatus(), Status.OK);
			Assert.assertNotNull(response.getPayload());
			Assert.assertNotNull(response.getPayload().getServices());
			Assert.assertFalse(response.getPayload().getServices().isEmpty());
			service1 = getServiceById(response.getPayload().getServices(),
					service1.getId());
		} catch (Exception ex) {
			ex.printStackTrace();
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}

	}

	private void setMandatoryHeaders(Map<String, String> headers,
			String version, String name) {
		headers.put(HeaderElements.CONSUMER_AUTH_TOKEN, "ahha%&!^!)(!&");
		headers.put(HeaderElements.CONSUMER_GUID,
				"841bfe07c3bb46dba6cee0ffdd5b4ffd");
		headers.put(HeaderElements.SERVICE_VERSION, version);
		headers.put(HeaderElements.SERVICE_ENV, "default");
		headers.put(HeaderElements.SERVICE_NAME, name);
	}

}
