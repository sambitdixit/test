package com.walmart.platform.soari.registry.client;

import org.apache.cxf.common.util.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.walmart.platform.soa.common.service.wrappers.ServiceHeader;
import com.walmart.platform.soa.common.service.wrappers.ServiceRequest;
import com.walmart.platform.soa.common.service.wrappers.ServiceResponse;
import com.walmart.platform.soa.common.service.wrappers.Status;
import com.walmart.platform.soari.registry.client.util.AbstractClientTest;
import com.walmart.platform.soari.registry.client.util.PlatformJAXRSHttpServer;
import com.walmart.platform.soari.registry.common.dto.AuditList;
import com.walmart.platform.soari.registry.common.dto.Consumer;
import com.walmart.platform.soari.registry.common.dto.ConsumerList;
import com.walmart.platform.soari.registry.common.dto.Policy;
import com.walmart.platform.soari.registry.common.dto.QoS;
import com.walmart.platform.soari.registry.common.dto.RegistryOptionList;
import com.walmart.platform.soari.registry.common.dto.Service;
import com.walmart.platform.soari.registry.common.dto.ServiceList;
import com.walmart.platform.soari.registry.common.dto.ServiceSearchBean;
import com.walmart.platform.soari.registry.common.dto.ServiceVersion;
import com.walmart.platform.soari.registry.common.dto.ServiceVersionSubscription;
import com.walmart.platform.soari.registry.common.dto.Subscription;
import com.walmart.platform.soari.registry.common.dto.SubscriptionList;
import com.walmart.platform.soari.registry.common.dto.SubscriptionRequest;
import com.walmart.platform.soari.registry.common.dto.Url;
import com.walmart.platform.soari.registry.common.enums.EnvironmentType;
import com.walmart.platform.soari.registry.common.enums.NotificationDestinationType;
import com.walmart.platform.soari.registry.common.enums.RegistryPolicyCodeType;
import com.walmart.platform.soari.registry.common.enums.ServiceCommunicationType;
import com.walmart.platform.soari.registry.common.enums.StatusType;
import com.walmart.platform.soari.registry.common.enums.UrlType;

public class ConsumerSubscriptionServiceClientTest extends AbstractClientTest {
	private static final Logger LOG = LoggerFactory
			.getLogger(ConsumerSubscriptionServiceClientTest.class);

	int artifactIndex = 0;
	
	@BeforeClass
	public void startServers() throws Exception {
		Assert.assertTrue(launchServer(PlatformJAXRSHttpServer.class, true),
				"server did not launch correctly");
		init();
		ServiceResponse<RegistryOptionList> gerRegistryOptionResp = registryOptionServiceClient.getOptionsByType(RegistryPolicyCodeType.CMDB_ARTIFACT);
		Assert.assertEquals(gerRegistryOptionResp.getStatus(), Status.OK);
		Assert.assertNotNull(gerRegistryOptionResp.getPayload());
		Assert.assertNotNull(gerRegistryOptionResp.getPayload().getOptions());
		Assert.assertFalse(gerRegistryOptionResp.getPayload().getOptions().isEmpty());
		cmdbArtifacts.addAll(gerRegistryOptionResp.getPayload().getOptions());
		
		/*gerRegistryOptionResp = registryOptionServiceClient.getOptionsByType(RegistryPolicyCodeType.JIRA_PROJECT);
		Assert.assertEquals(gerRegistryOptionResp.getStatus(), Status.OK);
		Assert.assertNotNull(gerRegistryOptionResp.getPayload());
		Assert.assertNotNull(gerRegistryOptionResp.getPayload().getOptions());
		Assert.assertFalse(gerRegistryOptionResp.getPayload().getOptions().isEmpty());
		jiraProjects.addAll(gerRegistryOptionResp.getPayload().getOptions());*/
	}

	@Test(enabled = true)
	public void testAddSubscriptions() throws Exception {
		try {
			Consumer consumer = newConsumer();
			
			ServiceRequest<Consumer> newConsumerRequest = new ServiceRequest<Consumer>(
					new ServiceHeader(), consumer);
			ServiceResponse<Consumer> addedConsumerResponse = consumerServiceClient
					.addConsumer(newConsumerRequest);
			Assert.assertEquals(addedConsumerResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedConsumerResponse.getPayload());
			Assert.assertEquals(addedConsumerResponse.getPayload().getConsumerId(), consumer.getConsumerId());
			
			consumer = addedConsumerResponse.getPayload();
			
			Service service1 = newService(cmdbArtifacts.get(artifactIndex++).getCode());service1.setOwner("sbonde@walmartlabs.com");
		//	service1.setJiraProject("PGPSOA");
			ServiceVersion serviceVersion1 = newServiceVersion();
			serviceVersion1.setSerVersion("1.0.0");
			service1.getServiceVersions().add(serviceVersion1);
		
			ServiceVersion serviceVersion2 = newServiceVersion();
			serviceVersion2.setSerVersion("1.0.1");
			service1.getServiceVersions().add(serviceVersion2);
		
			ServiceRequest<Service> newServiceRequest = new ServiceRequest<Service>(
					new ServiceHeader(), service1);
			ServiceResponse<Service> addedServiceResponse = registryServiceClient
					.addService(newServiceRequest);
			Assert.assertEquals(addedServiceResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse.getPayload());
			Assert.assertEquals(addedServiceResponse.getPayload().getServiceVersions().size(), service1.getServiceVersions().size());
			
			service1 = addedServiceResponse.getPayload();
			serviceVersion1 = getServiceVersion(service1.getServiceVersions(), serviceVersion1.getSerVersion());
			SubscriptionRequest subscription1 =  newSubscription(serviceVersion1, consumer);
			
			ServiceRequest<SubscriptionRequest> addSubscriptionRequest = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription1);
			ServiceResponse<Subscription> addSubscriptionsResp = consumerServiceClient.addSubscription(consumer.getConsumerId(), addSubscriptionRequest);
			Assert.assertEquals(addSubscriptionsResp.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp.getPayload());
			
			ServiceResponse<ConsumerList> getConsumersResp = consumerServiceClient.getConsumers();
			Assert.assertEquals(getConsumersResp.getStatus(), Status.OK);
			Assert.assertNotNull(getConsumersResp.getPayload());
			Assert.assertNotNull(getConsumersResp.getPayload().getConsumers());
			Assert.assertFalse(getConsumersResp.getPayload().getConsumers().isEmpty());
			
			consumer = getConsumer(getConsumersResp.getPayload().getConsumers(), consumer.getConsumerId());
			Assert.assertNotNull(getConsumersResp.getPayload().getConsumers());
			
			Subscription actual = getSubscriptionByServiceVersionId(consumer.getSubscriptions(), serviceVersion1.getId());
			Assert.assertNotNull(actual);
			Assert.assertEquals(actual.getConsumerId(), subscription1.getConsumerId());
			Assert.assertEquals(actual.getCommunicationType(), subscription1.getCommunicationType());
			Assert.assertEquals(actual.getEnvironment(), service1.getEnvironment());
			Assert.assertEquals(actual.getServiceId(), service1.getId());
			Assert.assertEquals(actual.getServiceName(), service1.getName());
			Assert.assertEquals(actual.getServiceVersionId(), serviceVersion1.getId());
			Assert.assertEquals(actual.getStatus(), "INACTIVE");
			Assert.assertEquals(actual.getVersionNumber(), serviceVersion1.getSerVersion());
														
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testAddSubscriptionsUsingServiceNameVersion() throws Exception {
		try {
			Consumer consumer = newConsumer();
			
			ServiceRequest<Consumer> newConsumerRequest = new ServiceRequest<Consumer>(
					new ServiceHeader(), consumer);
			ServiceResponse<Consumer> addedConsumerResponse = consumerServiceClient
					.addConsumer(newConsumerRequest);
			Assert.assertEquals(addedConsumerResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedConsumerResponse.getPayload());
			Assert.assertEquals(addedConsumerResponse.getPayload().getConsumerId(), consumer.getConsumerId());
			
			consumer = addedConsumerResponse.getPayload();
			
			Service service1 = newService(cmdbArtifacts.get(artifactIndex++).getCode());service1.setOwner("sbonde@walmartlabs.com");
		//	service1.setJiraProject("PGPSOA");
			ServiceVersion serviceVersion1 = newServiceVersion();
			serviceVersion1.setSerVersion("1.0.0");
			service1.getServiceVersions().add(serviceVersion1);
		
			ServiceVersion serviceVersion2 = newServiceVersion();
			serviceVersion2.setSerVersion("1.0.1");
			service1.getServiceVersions().add(serviceVersion2);
		
			ServiceRequest<Service> newServiceRequest = new ServiceRequest<Service>(
					new ServiceHeader(), service1);
			ServiceResponse<Service> addedServiceResponse = registryServiceClient
					.addService(newServiceRequest);
			Assert.assertEquals(addedServiceResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse.getPayload());
			Assert.assertEquals(addedServiceResponse.getPayload().getServiceVersions().size(), service1.getServiceVersions().size());
			
			service1 = addedServiceResponse.getPayload();
			serviceVersion1 = getServiceVersion(service1.getServiceVersions(), serviceVersion1.getSerVersion());
			SubscriptionRequest subscription1 =  newSubscription(serviceVersion1, consumer);
			
			
			ServiceVersionSubscription serviceVersionSubsciption = new ServiceVersionSubscription();
			serviceVersionSubsciption.setServiceName(service1.getName());
			serviceVersionSubsciption.setVersionNumber(serviceVersion1.getSerVersion());
			serviceVersionSubsciption.setEnvironment(service1.getEnvironment());
			serviceVersionSubsciption.setConsumerId(consumer.getConsumerId());
			serviceVersionSubsciption.setCommunicationType(ServiceCommunicationType.ESB_PROXY.toString());
			serviceVersionSubsciption.setCreatedBy("test_user");
			
			ServiceRequest<ServiceVersionSubscription> addSubscriptionRequest = new ServiceRequest<ServiceVersionSubscription>(
					new ServiceHeader(), serviceVersionSubsciption);
			ServiceResponse<Subscription> addSubscriptionsResp = consumerServiceClient.addSubscription(addSubscriptionRequest);
			Assert.assertEquals(addSubscriptionsResp.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp.getPayload());
			
			ServiceResponse<ConsumerList> getConsumersResp = consumerServiceClient.getConsumers();
			Assert.assertEquals(getConsumersResp.getStatus(), Status.OK);
			Assert.assertNotNull(getConsumersResp.getPayload());
			Assert.assertNotNull(getConsumersResp.getPayload().getConsumers());
			Assert.assertFalse(getConsumersResp.getPayload().getConsumers().isEmpty());
			
			consumer = getConsumer(getConsumersResp.getPayload().getConsumers(), consumer.getConsumerId());
			Assert.assertNotNull(getConsumersResp.getPayload().getConsumers());
			
			Subscription actual = getSubscriptionByServiceVersionId(consumer.getSubscriptions(), serviceVersion1.getId());
			Assert.assertNotNull(actual);
			Assert.assertEquals(actual.getConsumerId(), subscription1.getConsumerId());
			Assert.assertEquals(actual.getCommunicationType(), subscription1.getCommunicationType());
			Assert.assertEquals(actual.getEnvironment(), service1.getEnvironment());
			Assert.assertEquals(actual.getServiceId(), service1.getId());
			Assert.assertEquals(actual.getServiceName(), service1.getName());
			Assert.assertEquals(actual.getServiceVersionId(), serviceVersion1.getId());
			Assert.assertEquals(actual.getStatus(), "INACTIVE");
			Assert.assertEquals(actual.getVersionNumber(), serviceVersion1.getSerVersion());
														
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	@Test(enabled = true)
	public void testSubscriptionRequestUrl() throws Exception {
		try {
			Consumer consumer = newConsumer();
			ServiceRequest<Consumer> newConsumerRequest = new ServiceRequest<Consumer>(
					new ServiceHeader(), consumer);
			ServiceResponse<Consumer> addedConsumerResponse = consumerServiceClient
					.addConsumer(newConsumerRequest);
			Assert.assertEquals(addedConsumerResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedConsumerResponse.getPayload());
			Assert.assertEquals(addedConsumerResponse.getPayload().getConsumerId(), consumer.getConsumerId());
			
			consumer = addedConsumerResponse.getPayload();
			
			Service service1 = newService(cmdbArtifacts.get(artifactIndex++).getCode());service1.setOwner("sbonde@walmartlabs.com");
			
			ServiceVersion serviceVersion1 = newServiceVersion();
			serviceVersion1.getUrls().clear();
			Url esbUrl = new Url();
			esbUrl.setType(UrlType.ESB_PROXY.toString());
			esbUrl.setUrl(TEST_ESB_PROXY_URL);
			serviceVersion1.getUrls().add(esbUrl);
			Url endPointUrl = new Url();
			endPointUrl.setType(UrlType.ENDPOINT.toString());
			endPointUrl.setUrl(TEST_END_POINT_URL);
			serviceVersion1.getUrls().add(endPointUrl);
			Url alternateEedPointUrl1 = new Url();
			alternateEedPointUrl1.setType(UrlType.ENDPOINT_ALTERNATE.toString());
			alternateEedPointUrl1.setUrl(TEST_END_POINT_URL_ALTERNATE+"2");
			Url alternateEedPointUrl2 = new Url();
			alternateEedPointUrl2.setType(UrlType.ENDPOINT_ALTERNATE.toString());
			alternateEedPointUrl2.setUrl(TEST_END_POINT_URL_ALTERNATE+"2");
			serviceVersion1.getUrls().add(alternateEedPointUrl2);
			serviceVersion1.setSerVersion("1.0.0");
			service1.getServiceVersions().add(serviceVersion1);
		
			ServiceVersion serviceVersion2 = newServiceVersion();
			serviceVersion2.getUrls().clear();
			serviceVersion2.getUrls().add(esbUrl);
			serviceVersion2.getUrls().add(endPointUrl);
			serviceVersion2.getUrls().add(alternateEedPointUrl1);
			serviceVersion2.getUrls().add(alternateEedPointUrl2);
			
			serviceVersion2.setSerVersion("1.0.1");
			service1.getServiceVersions().add(serviceVersion2);
		
			ServiceRequest<Service> newServiceRequest = new ServiceRequest<Service>(
					new ServiceHeader(), service1);
			ServiceResponse<Service> addedServiceResponse = registryServiceClient
					.addService(newServiceRequest);
			Assert.assertEquals(addedServiceResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse.getPayload());
			Assert.assertEquals(addedServiceResponse.getPayload().getServiceVersions().size(), service1.getServiceVersions().size());
			
			service1 = addedServiceResponse.getPayload();
			serviceVersion1 = getServiceVersion(service1.getServiceVersions(), serviceVersion1.getSerVersion());
			SubscriptionRequest subscription1 =  newSubscription(serviceVersion1, consumer);
			subscription1.setCommunicationType(ServiceCommunicationType.ESB_PROXY.toString());
			
			ServiceRequest<SubscriptionRequest> addSubscriptionRequest1 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription1);
			ServiceResponse<Subscription> addSubscriptionsResp1 = consumerServiceClient.addSubscription(consumer.getConsumerId(), addSubscriptionRequest1);
			Assert.assertEquals(addSubscriptionsResp1.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp1.getPayload());
			
			serviceVersion2 = getServiceVersion(service1.getServiceVersions(), serviceVersion2.getSerVersion());
			SubscriptionRequest subscription2 =  newSubscription(serviceVersion2, consumer);
			subscription2.setCommunicationType(ServiceCommunicationType.DIRECT.toString());
		
			ServiceRequest<SubscriptionRequest> addSubscriptionRequest2 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription2);
			ServiceResponse<Subscription> addSubscriptionsResp2 = consumerServiceClient.addSubscription(consumer.getConsumerId(), addSubscriptionRequest2);
			Assert.assertEquals(addSubscriptionsResp2.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp2.getPayload());
			
			ServiceResponse<ConsumerList> getConsumersResp = consumerServiceClient.getConsumers();
			Assert.assertEquals(getConsumersResp.getStatus(), Status.OK);
			Assert.assertNotNull(getConsumersResp.getPayload());
			Assert.assertNotNull(getConsumersResp.getPayload().getConsumers());
			Assert.assertFalse(getConsumersResp.getPayload().getConsumers().isEmpty());
			
			consumer = getConsumer(getConsumersResp.getPayload().getConsumers(), consumer.getConsumerId());
			Assert.assertNotNull(getConsumersResp.getPayload().getConsumers());
			
			Subscription actual1 = getSubscriptionByServiceVersionId(consumer.getSubscriptions(), serviceVersion1.getId());
			Assert.assertNotNull(actual1);
			Assert.assertEquals(actual1.getConsumerId(), subscription1.getConsumerId());
			Assert.assertEquals(actual1.getCommunicationType(), subscription1.getCommunicationType());
			Assert.assertEquals(actual1.getEnvironment(), service1.getEnvironment());
			Assert.assertEquals(actual1.getServiceId(), service1.getId());
			Assert.assertEquals(actual1.getServiceName(), service1.getName());
			Assert.assertEquals(actual1.getServiceVersionId(), serviceVersion1.getId());
			Assert.assertEquals(actual1.getStatus(), "INACTIVE");
			Assert.assertEquals(actual1.getVersionNumber(), serviceVersion1.getSerVersion());
			Assert.assertEquals(actual1.getRequestUrl(), esbUrl.getUrl());	
			
			Subscription actual2 = getSubscriptionByServiceVersionId(consumer.getSubscriptions(), serviceVersion2.getId());
			Assert.assertNotNull(actual2);
			Assert.assertEquals(actual2.getConsumerId(), subscription2.getConsumerId());
			Assert.assertEquals(actual2.getCommunicationType(), subscription2.getCommunicationType());
			Assert.assertEquals(actual2.getEnvironment(), service1.getEnvironment());
			Assert.assertEquals(actual2.getServiceId(), service1.getId());
			Assert.assertEquals(actual2.getServiceName(), service1.getName());
			Assert.assertEquals(actual2.getServiceVersionId(), serviceVersion2.getId());
			Assert.assertEquals(actual2.getStatus(), "INACTIVE");
			Assert.assertEquals(actual2.getVersionNumber(), serviceVersion2.getSerVersion());
			Assert.assertEquals(actual2.getRequestUrl(), endPointUrl.getUrl());	
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	
	@Test(enabled = true)
	public void testAddSubscriptionsForMultipleConsumers() throws Exception {
		try {
			Consumer consumer1 = newConsumer();
			
			ServiceRequest<Consumer> newConsumerRequest = new ServiceRequest<Consumer>(
					new ServiceHeader(), consumer1);
			ServiceResponse<Consumer> addedConsumerResponse = consumerServiceClient
					.addConsumer(newConsumerRequest);
			Assert.assertEquals(addedConsumerResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedConsumerResponse.getPayload());
			Assert.assertEquals(addedConsumerResponse.getPayload().getConsumerId(), consumer1.getConsumerId());
			
			consumer1 = addedConsumerResponse.getPayload();
			
			Service service1 = newService(cmdbArtifacts.get(artifactIndex++).getCode());service1.setOwner("sbonde@walmartlabs.com");
			ServiceVersion serviceVersion1 = newServiceVersion();
			serviceVersion1.setSerVersion("1.0.0");
			service1.getServiceVersions().add(serviceVersion1);
		
			ServiceVersion serviceVersion2 = newServiceVersion();
			serviceVersion2.setSerVersion("1.0.1");
			service1.getServiceVersions().add(serviceVersion2);
		
			ServiceRequest<Service> newServiceRequest = new ServiceRequest<Service>(
					new ServiceHeader(), service1);
			ServiceResponse<Service> addedServiceResponse = registryServiceClient
					.addService(newServiceRequest);
			Assert.assertEquals(addedServiceResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse.getPayload());
			Assert.assertEquals(addedServiceResponse.getPayload().getServiceVersions().size(), service1.getServiceVersions().size());
			
			service1 = addedServiceResponse.getPayload();
			serviceVersion1 = getServiceVersion(service1.getServiceVersions(), serviceVersion1.getSerVersion());
			SubscriptionRequest subscription1 =  newSubscription(serviceVersion1, consumer1);
			
			ServiceRequest<SubscriptionRequest> addSubscriptionRequest = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription1);
			ServiceResponse<Subscription> addSubscriptionsResp = consumerServiceClient.addSubscription(consumer1.getConsumerId(), addSubscriptionRequest);
			Assert.assertEquals(addSubscriptionsResp.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp.getPayload());
			
			ServiceResponse<ConsumerList> getConsumersResp = consumerServiceClient.getConsumers();
			Assert.assertEquals(getConsumersResp.getStatus(), Status.OK);
			Assert.assertNotNull(getConsumersResp.getPayload());
			Assert.assertNotNull(getConsumersResp.getPayload().getConsumers());
			Assert.assertFalse(getConsumersResp.getPayload().getConsumers().isEmpty());
			
			consumer1 = getConsumer(getConsumersResp.getPayload().getConsumers(), consumer1.getConsumerId());
			Assert.assertNotNull(getConsumersResp.getPayload().getConsumers());
			
			Subscription actual = getSubscriptionByServiceVersionId(consumer1.getSubscriptions(), serviceVersion1.getId());
			Assert.assertNotNull(actual);
			Assert.assertEquals(actual.getConsumerId(), subscription1.getConsumerId());
			Assert.assertEquals(actual.getCommunicationType(), subscription1.getCommunicationType());
			Assert.assertEquals(actual.getEnvironment(), service1.getEnvironment());
			Assert.assertEquals(actual.getServiceId(), service1.getId());
			Assert.assertEquals(actual.getServiceName(), service1.getName());
			Assert.assertEquals(actual.getServiceVersionId(), serviceVersion1.getId());
			Assert.assertEquals(actual.getStatus(), "INACTIVE");
			Assert.assertEquals(actual.getVersionNumber(), serviceVersion1.getSerVersion());
			
			ServiceRequest<SubscriptionRequest> addSubscriptionRequest2 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription1);
			ServiceResponse<Subscription> addSubscriptionsResp2 = consumerServiceClient.addSubscription(consumer1.getConsumerId(), addSubscriptionRequest2);
			Assert.assertEquals(addSubscriptionsResp2.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp2.getPayload());
														
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.assertTrue(true, ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testAddSubscriptionsDuplicate() throws Exception {
		try {
			Consumer consumer = newConsumer();
			
			ServiceRequest<Consumer> newConsumerRequest = new ServiceRequest<Consumer>(
					new ServiceHeader(), consumer);
			ServiceResponse<Consumer> addedConsumerResponse = consumerServiceClient
					.addConsumer(newConsumerRequest);
			Assert.assertEquals(addedConsumerResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedConsumerResponse.getPayload());
			Assert.assertEquals(addedConsumerResponse.getPayload().getConsumerId(), consumer.getConsumerId());
			
			consumer = addedConsumerResponse.getPayload();
			
			Service service1 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceVersion serviceVersion1 = newServiceVersion();
			serviceVersion1.setSerVersion("1.0.0");
			service1.getServiceVersions().add(serviceVersion1);
		
			ServiceVersion serviceVersion2 = newServiceVersion();
			serviceVersion2.setSerVersion("1.0.1");
			service1.getServiceVersions().add(serviceVersion2);
		
			ServiceRequest<Service> newServiceRequest = new ServiceRequest<Service>(
					new ServiceHeader(), service1);
			ServiceResponse<Service> addedServiceResponse = registryServiceClient
					.addService(newServiceRequest);
			Assert.assertEquals(addedServiceResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse.getPayload());
			Assert.assertEquals(addedServiceResponse.getPayload().getServiceVersions().size(), service1.getServiceVersions().size());
			
			service1 = addedServiceResponse.getPayload();
			serviceVersion1 = getServiceVersion(service1.getServiceVersions(), serviceVersion1.getSerVersion());
			SubscriptionRequest subscription1 =  newSubscription(serviceVersion1, consumer);
		
			//Try adding new subscription for same version for same consumer
			serviceVersion2 = getServiceVersion(service1.getServiceVersions(), serviceVersion2.getSerVersion());
			SubscriptionRequest subscription2 =  newSubscription(serviceVersion1, consumer);
		
			ServiceRequest<SubscriptionRequest> addSubscriptionRequest1 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription1);
			ServiceResponse<Subscription> addSubscriptionsResp1 = consumerServiceClient.addSubscription(consumer.getConsumerId(), addSubscriptionRequest1);
			Assert.assertEquals(addSubscriptionsResp1.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp1.getPayload());
	
			ServiceRequest<SubscriptionRequest> addSubscriptionRequest2 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription2);
			ServiceResponse<Subscription> addSubscriptionsResp2 = consumerServiceClient.addSubscription(consumer.getConsumerId(), addSubscriptionRequest2);
			Assert.assertEquals(addSubscriptionsResp2.getStatus(), Status.FAIL);
	
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.assertTrue(true, ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testAddMoreSubscriptions() throws Exception {
		try {
			Consumer consumer = newConsumer();
			
			ServiceRequest<Consumer> newConsumerRequest = new ServiceRequest<Consumer>(
					new ServiceHeader(), consumer);
			ServiceResponse<Consumer> addedConsumerResponse = consumerServiceClient
					.addConsumer(newConsumerRequest);
			Assert.assertEquals(addedConsumerResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedConsumerResponse.getPayload());
			Assert.assertEquals(addedConsumerResponse.getPayload().getConsumerId(), consumer.getConsumerId());
			
			consumer = addedConsumerResponse.getPayload();
			
			Service service1 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceVersion serviceVersion11 = newServiceVersion();
			serviceVersion11.setSerVersion("1.0.0");
			service1.getServiceVersions().add(serviceVersion11);
		
			ServiceVersion serviceVersion12 = newServiceVersion();
			serviceVersion12.setSerVersion("1.0.1");
			service1.getServiceVersions().add(serviceVersion12);
		
			ServiceRequest<Service> newServiceRequest1 = new ServiceRequest<Service>(
					new ServiceHeader(), service1);
			ServiceResponse<Service> addedServiceResponse1 = registryServiceClient
					.addService(newServiceRequest1);
			Assert.assertEquals(addedServiceResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse1.getPayload());
			Assert.assertEquals(addedServiceResponse1.getPayload().getServiceVersions().size(), service1.getServiceVersions().size());
			
			service1 = addedServiceResponse1.getPayload();
			serviceVersion11 = getServiceVersion(service1.getServiceVersions(), serviceVersion11.getSerVersion());
			SubscriptionRequest subscription11 =  newSubscription(serviceVersion11, consumer);
			
			serviceVersion12 = getServiceVersion(service1.getServiceVersions(), serviceVersion12.getSerVersion());
			SubscriptionRequest subscription12 =  newSubscription(serviceVersion12, consumer);
		
			ServiceRequest<SubscriptionRequest> addSubscriptionsRequest1 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription11);
			ServiceResponse<Subscription> addSubscriptionsResp1 = consumerServiceClient.addSubscription(consumer.getConsumerId(), addSubscriptionsRequest1);
			Assert.assertEquals(addSubscriptionsResp1.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp1.getPayload());
			
			ServiceRequest<SubscriptionRequest> addSubscriptionsRequest2 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription12);
			ServiceResponse<Subscription> addSubscriptionsResp2 = consumerServiceClient.addSubscription(consumer.getConsumerId(), addSubscriptionsRequest2);
			Assert.assertEquals(addSubscriptionsResp2.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp2.getPayload());
		
			//Add more subscriptions
			Service service2 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceVersion serviceVersion21 = newServiceVersion();
			serviceVersion21.setSerVersion("1.0.0");
			service2.getServiceVersions().add(serviceVersion21);
		
			ServiceVersion serviceVersion22 = newServiceVersion();
			serviceVersion22.setSerVersion("1.0.1");
			service2.getServiceVersions().add(serviceVersion22);
		
			ServiceRequest<Service> newServiceRequest2 = new ServiceRequest<Service>(
					new ServiceHeader(), service2);
			ServiceResponse<Service> addedServiceResponse2 = registryServiceClient
					.addService(newServiceRequest2);
			Assert.assertEquals(addedServiceResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse2.getPayload());
			Assert.assertEquals(addedServiceResponse2.getPayload().getServiceVersions().size(), service2.getServiceVersions().size());
			
			service2 = addedServiceResponse2.getPayload();
			serviceVersion21 = getServiceVersion(service2.getServiceVersions(), serviceVersion21.getSerVersion());
			SubscriptionRequest subscription21 =  newSubscription(serviceVersion21, consumer);
			
			serviceVersion22 = getServiceVersion(service2.getServiceVersions(), serviceVersion22.getSerVersion());
			SubscriptionRequest subscription22 =  newSubscription(serviceVersion22, consumer);
			
			ServiceRequest<SubscriptionRequest> addSubscriptionsRequest21 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription21);
			ServiceResponse<Subscription> addSubscriptionsResp21 = consumerServiceClient.addSubscription(consumer.getConsumerId(), addSubscriptionsRequest21);
			Assert.assertEquals(addSubscriptionsResp21.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp21.getPayload());

			ServiceRequest<SubscriptionRequest> addSubscriptionsRequest22 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription22);
			ServiceResponse<Subscription> addSubscriptionsResp22 = consumerServiceClient.addSubscription(consumer.getConsumerId(), addSubscriptionsRequest22);
			Assert.assertEquals(addSubscriptionsResp22.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp22.getPayload());

		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testUpdateSubscription() throws Exception {
		try {
			Consumer consumer = newConsumer();
			
			ServiceRequest<Consumer> newConsumerRequest = new ServiceRequest<Consumer>(
					new ServiceHeader(), consumer);
			ServiceResponse<Consumer> addedConsumerResponse = consumerServiceClient
					.addConsumer(newConsumerRequest);
			Assert.assertEquals(addedConsumerResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedConsumerResponse.getPayload());
			Assert.assertEquals(addedConsumerResponse.getPayload().getConsumerId(), consumer.getConsumerId());
			
			consumer = addedConsumerResponse.getPayload();
			
			Service service1 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceVersion serviceVersion1 = newServiceVersion();
			serviceVersion1.setSerVersion("1.0.0");
			service1.getServiceVersions().add(serviceVersion1);
		
			ServiceVersion serviceVersion2 = newServiceVersion();
			serviceVersion2.setSerVersion("1.0.1");
			service1.getServiceVersions().add(serviceVersion2);
		
			ServiceRequest<Service> newServiceRequest = new ServiceRequest<Service>(
					new ServiceHeader(), service1);
			ServiceResponse<Service> addedServiceResponse = registryServiceClient
					.addService(newServiceRequest);
			Assert.assertEquals(addedServiceResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse.getPayload());
			Assert.assertEquals(addedServiceResponse.getPayload().getServiceVersions().size(), service1.getServiceVersions().size());
			
			service1 = addedServiceResponse.getPayload();
			serviceVersion1 = getServiceVersion(service1.getServiceVersions(), serviceVersion1.getSerVersion());
			SubscriptionRequest subscription1 =  newSubscription(serviceVersion1, consumer);
			
			ServiceRequest<SubscriptionRequest> addSubscriptionRequest = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription1);
			ServiceResponse<Subscription> addSubscriptionsResp = consumerServiceClient.addSubscription(consumer.getConsumerId(), addSubscriptionRequest);
			Assert.assertEquals(addSubscriptionsResp.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp.getPayload());
			
			serviceVersion2 = getServiceVersion(service1.getServiceVersions(), serviceVersion2.getSerVersion());
			SubscriptionRequest subscription2 =  newSubscription(serviceVersion2, consumer);
			
			ServiceRequest<SubscriptionRequest> addSubscriptionRequest2 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription2);
			ServiceResponse<Subscription> addSubscriptionsResp2 = consumerServiceClient.addSubscription(consumer.getConsumerId(), addSubscriptionRequest2);
			Assert.assertEquals(addSubscriptionsResp2.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp2.getPayload());
			
			ServiceResponse<SubscriptionList> getSubscriptionsResp = consumerServiceClient.getSubscriptions(consumer.getConsumerId());
			Assert.assertEquals(getSubscriptionsResp.getStatus(), Status.OK);
			Assert.assertNotNull(getSubscriptionsResp.getPayload());
			Assert.assertEquals(getSubscriptionsResp.getPayload().getSubscriptions().size(), 2);
			
			Subscription sub1 = getSubscriptionByServiceVersionId(getSubscriptionsResp.getPayload().getSubscriptions(), serviceVersion1.getId());
			Assert.assertNotNull(sub1);
			
			SubscriptionRequest updateSubscription1 = new SubscriptionRequest();
			updateSubscription1.setId(sub1.getId());
			updateSubscription1.setCommunicationType(ServiceCommunicationType.DIRECT.toString());
			updateSubscription1.setConsumerId(sub1.getConsumerId());
			updateSubscription1.setModifiedBy("Test Modifier");
			updateSubscription1.setServiceVersionId(sub1.getServiceVersionId());
			updateSubscription1.setStatus(sub1.getStatus());
			
			//update subscription
			//subscription1.setCommunicationType(ServiceCommunicationType.DIRECT.toString());
			ServiceRequest<SubscriptionRequest> updateSubscriptionreq = new ServiceRequest<SubscriptionRequest>(new ServiceHeader(), updateSubscription1);
			ServiceResponse<Subscription> updateSubscriptionResp = consumerServiceClient.updateSubscription(updateSubscriptionreq);
			Assert.assertEquals(updateSubscriptionResp.getStatus(), Status.OK);
			Assert.assertNotNull(updateSubscriptionResp.getPayload());
			Assert.assertEquals(updateSubscriptionResp.getPayload().getCommunicationType(), ServiceCommunicationType.DIRECT.toString());
			
			ServiceResponse<AuditList> getAuditresp1 = auditServiceClient.getAuditByEntityId(serviceVersion1.getId(), 5);
			Assert.assertEquals(getAuditresp1.getStatus(), Status.OK);
			Assert.assertFalse(getAuditresp1.getPayload().getAuditList().isEmpty());
		
			ServiceResponse<AuditList> getAuditresp2 = auditServiceClient.getAuditByEntityId(consumer.getId(), 5);
			Assert.assertEquals(getAuditresp2.getStatus(), Status.OK);
			Assert.assertFalse(getAuditresp2.getPayload().getAuditList().isEmpty());
		
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			ex.printStackTrace();
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testAddConsumerSubscriptions() throws Exception {
		try {
			Consumer consumer = newConsumer();
			
			ServiceRequest<Consumer> newConsumerRequest = new ServiceRequest<Consumer>(
					new ServiceHeader(), consumer);
			ServiceResponse<Consumer> addedConsumerResponse = consumerServiceClient
					.addConsumer(newConsumerRequest);
			Assert.assertEquals(addedConsumerResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedConsumerResponse.getPayload());
			Assert.assertEquals(addedConsumerResponse.getPayload().getConsumerId(), consumer.getConsumerId());
			
			consumer = addedConsumerResponse.getPayload();
			
			Service service1 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceVersion serviceVersion1 = newServiceVersion();
			serviceVersion1.setSerVersion("1.0.0");
			service1.getServiceVersions().add(serviceVersion1);
		
			ServiceVersion serviceVersion2 = newServiceVersion();
			serviceVersion2.setSerVersion("1.0.1");
			service1.getServiceVersions().add(serviceVersion2);
		
			ServiceRequest<Service> newServiceRequest = new ServiceRequest<Service>(
					new ServiceHeader(), service1);
			ServiceResponse<Service> addedServiceResponse = registryServiceClient
					.addService(newServiceRequest);
			Assert.assertEquals(addedServiceResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse.getPayload());
			Assert.assertEquals(addedServiceResponse.getPayload().getServiceVersions().size(), service1.getServiceVersions().size());
			
			service1 = addedServiceResponse.getPayload();
			serviceVersion1 = getServiceVersion(service1.getServiceVersions(), serviceVersion1.getSerVersion());
			SubscriptionRequest subscription1 = newSubscription(serviceVersion1, consumer);
			
			ServiceRequest<SubscriptionRequest> addSubscriptionsRequest = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription1);
			ServiceResponse<Subscription> addSubscriptionsResp = consumerServiceClient.addSubscription(consumer.getConsumerId(), addSubscriptionsRequest);
			Assert.assertEquals(addSubscriptionsResp.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp.getPayload());
			
			ServiceResponse<ConsumerList> getConsumersResp = consumerServiceClient.getConsumers();
			Assert.assertEquals(getConsumersResp.getStatus(), Status.OK);
			Assert.assertNotNull(getConsumersResp.getPayload());
			Assert.assertNotNull(getConsumersResp.getPayload().getConsumers());
			Assert.assertFalse(getConsumersResp.getPayload().getConsumers().isEmpty());
				
			consumer = getConsumerById(getConsumersResp.getPayload().getConsumers(), consumer.getId());
			
			Subscription actual = getSubscriptionByServiceVersionId(consumer.getSubscriptions(), serviceVersion1.getId());
			
			Assert.assertNotNull(actual);
			Assert.assertEquals(actual.getConsumerId(), subscription1.getConsumerId());
			Assert.assertEquals(actual.getCommunicationType(), subscription1.getCommunicationType());
			Assert.assertEquals(actual.getEnvironment(), service1.getEnvironment());
			Assert.assertEquals(actual.getServiceId(), service1.getId());
			Assert.assertEquals(actual.getServiceName(), service1.getName());
			Assert.assertEquals(actual.getServiceVersionId(), serviceVersion1.getId());
			Assert.assertEquals(actual.getStatus(), "INACTIVE");
			Assert.assertEquals(actual.getVersionNumber(), serviceVersion1.getSerVersion());
		
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testUpdateSubscriptionInvalidUpdateConsumer() throws Exception {
		try {
			Consumer consumer1 = newConsumer();
			
			ServiceRequest<Consumer> newConsumerRequest1 = new ServiceRequest<Consumer>(
					new ServiceHeader(), consumer1);
			ServiceResponse<Consumer> addedConsumerResponse1 = consumerServiceClient
					.addConsumer(newConsumerRequest1);
			Assert.assertEquals(addedConsumerResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedConsumerResponse1.getPayload());
			Assert.assertEquals(addedConsumerResponse1.getPayload().getConsumerId(), consumer1.getConsumerId());
			
			consumer1 = addedConsumerResponse1.getPayload();
			
			Consumer consumer2 = newConsumer();
			
			ServiceRequest<Consumer> newConsumerRequest2 = new ServiceRequest<Consumer>(
					new ServiceHeader(), consumer2);
			ServiceResponse<Consumer> addedConsumerResponse2 = consumerServiceClient
					.addConsumer(newConsumerRequest2);
			Assert.assertEquals(addedConsumerResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedConsumerResponse2.getPayload());
			Assert.assertEquals(addedConsumerResponse2.getPayload().getConsumerId(), consumer2.getConsumerId());
			
			consumer2 = addedConsumerResponse2.getPayload();
			
			Service service1 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceVersion serviceVersion1 = newServiceVersion();
			serviceVersion1.setSerVersion("1.0.0");
			service1.getServiceVersions().add(serviceVersion1);
		
			ServiceVersion serviceVersion2 = newServiceVersion();
			serviceVersion2.setSerVersion("1.0.1");
			service1.getServiceVersions().add(serviceVersion2);
		
			ServiceRequest<Service> newServiceRequest = new ServiceRequest<Service>(
					new ServiceHeader(), service1);
			ServiceResponse<Service> addedServiceResponse = registryServiceClient
					.addService(newServiceRequest);
			Assert.assertEquals(addedServiceResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse.getPayload());
			Assert.assertEquals(addedServiceResponse.getPayload().getServiceVersions().size(), service1.getServiceVersions().size());
			
			service1 = addedServiceResponse.getPayload();
			serviceVersion1 = getServiceVersion(service1.getServiceVersions(), serviceVersion1.getSerVersion());
			SubscriptionRequest subscription1 =  newSubscription(serviceVersion1, consumer1);
			
			ServiceRequest<SubscriptionRequest> addSubscriptionRequest = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription1);
			ServiceResponse<Subscription> addSubscriptionsResp = consumerServiceClient.addSubscription(consumer1.getConsumerId(), addSubscriptionRequest);
			Assert.assertEquals(addSubscriptionsResp.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp.getPayload());
			
			serviceVersion2 = getServiceVersion(service1.getServiceVersions(), serviceVersion2.getSerVersion());
			SubscriptionRequest subscription2 =  newSubscription(serviceVersion2, consumer1);
			
			ServiceRequest<SubscriptionRequest> addSubscriptionRequest2 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription2);
			ServiceResponse<Subscription> addSubscriptionsResp2 = consumerServiceClient.addSubscription(consumer1.getConsumerId(), addSubscriptionRequest2);
			Assert.assertEquals(addSubscriptionsResp2.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp2.getPayload());
			
			ServiceResponse<SubscriptionList> getSubscriptionsResp = consumerServiceClient.getSubscriptions(consumer1.getConsumerId());
			Assert.assertEquals(getSubscriptionsResp.getStatus(), Status.OK);
			Assert.assertNotNull(getSubscriptionsResp.getPayload());
			Assert.assertEquals(getSubscriptionsResp.getPayload().getSubscriptions().size(), 2);
			
			subscription1 = getSubscriptionByServiceVersionId(getSubscriptionsResp.getPayload().getSubscriptions(), serviceVersion1.getId());
			
			//update subscription
			subscription1.setCommunicationType(ServiceCommunicationType.DIRECT.toString());
			//Invalid consumer id update
			subscription1.setConsumerId(consumer2.getConsumerId());
			ServiceRequest<SubscriptionRequest> updateSubscriptionreq = new ServiceRequest<SubscriptionRequest>(new ServiceHeader(), subscription1);
			ServiceResponse<Subscription> updateSubscriptionResp = consumerServiceClient.updateSubscription(updateSubscriptionreq);
			Assert.assertEquals(updateSubscriptionResp.getStatus(), Status.OK);
		
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.assertTrue(true, ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testUpdateSubscriptionInvalidUpdateServiceVersion() throws Exception {
		try {
			Consumer consumer1 = newConsumer();
			
			ServiceRequest<Consumer> newConsumerRequest1 = new ServiceRequest<Consumer>(
					new ServiceHeader(), consumer1);
			ServiceResponse<Consumer> addedConsumerResponse1 = consumerServiceClient
					.addConsumer(newConsumerRequest1);
			Assert.assertEquals(addedConsumerResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedConsumerResponse1.getPayload());
			Assert.assertEquals(addedConsumerResponse1.getPayload().getConsumerId(), consumer1.getConsumerId());
			
			consumer1 = addedConsumerResponse1.getPayload();
			
			Service service1 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceVersion serviceVersion1 = newServiceVersion();
			serviceVersion1.setSerVersion("1.0.0");
			service1.getServiceVersions().add(serviceVersion1);
		
			ServiceVersion serviceVersion2 = newServiceVersion();
			serviceVersion2.setSerVersion("1.0.1");
			service1.getServiceVersions().add(serviceVersion2);
		
			ServiceRequest<Service> newServiceRequest = new ServiceRequest<Service>(
					new ServiceHeader(), service1);
			ServiceResponse<Service> addedServiceResponse = registryServiceClient
					.addService(newServiceRequest);
			Assert.assertEquals(addedServiceResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse.getPayload());
			Assert.assertEquals(addedServiceResponse.getPayload().getServiceVersions().size(), service1.getServiceVersions().size());
			
			service1 = addedServiceResponse.getPayload();
			serviceVersion1 = getServiceVersion(service1.getServiceVersions(), serviceVersion1.getSerVersion());
			SubscriptionRequest subscription1 =  newSubscription(serviceVersion1, consumer1);
			
			ServiceRequest<SubscriptionRequest> addSubscriptionRequest = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription1);
			ServiceResponse<Subscription> addSubscriptionsResp = consumerServiceClient.addSubscription(consumer1.getConsumerId(), addSubscriptionRequest);
			Assert.assertEquals(addSubscriptionsResp.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp.getPayload());
			
			serviceVersion2 = getServiceVersion(service1.getServiceVersions(), serviceVersion2.getSerVersion());
			SubscriptionRequest subscription2 =  newSubscription(serviceVersion2, consumer1);
			
			ServiceRequest<SubscriptionRequest> addSubscriptionRequest2 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription2);
			ServiceResponse<Subscription> addSubscriptionsResp2 = consumerServiceClient.addSubscription(consumer1.getConsumerId(), addSubscriptionRequest2);
			Assert.assertEquals(addSubscriptionsResp2.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp2.getPayload());
			
			ServiceResponse<SubscriptionList> getSubscriptionsResp = consumerServiceClient.getSubscriptions(consumer1.getConsumerId());
			Assert.assertEquals(getSubscriptionsResp.getStatus(), Status.OK);
			Assert.assertNotNull(getSubscriptionsResp.getPayload());
			Assert.assertEquals(getSubscriptionsResp.getPayload().getSubscriptions().size(), 2);
			
			subscription1 = getSubscriptionByServiceVersionId(getSubscriptionsResp.getPayload().getSubscriptions(), serviceVersion1.getId());
			subscription1 = getSubscriptionByServiceVersionId(getSubscriptionsResp.getPayload().getSubscriptions(), serviceVersion1.getId());
				
			//update subscription
			subscription1.setCommunicationType(ServiceCommunicationType.DIRECT.toString());
			//Invalid service version id update
			subscription1.setServiceVersionId(serviceVersion2.getId());
			ServiceRequest<SubscriptionRequest> updateSubscriptionreq = new ServiceRequest<SubscriptionRequest>(new ServiceHeader(), subscription1);
			ServiceResponse<Subscription> updateSubscriptionResp = consumerServiceClient.updateSubscription(updateSubscriptionreq);
			Assert.assertEquals(updateSubscriptionResp.getStatus(), Status.OK);
		
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.assertTrue(true, ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testUpdateSubscriptionDuplicate() throws Exception {
		try {
			Consumer consumer = newConsumer();
			
			ServiceRequest<Consumer> newConsumerRequest = new ServiceRequest<Consumer>(
					new ServiceHeader(), consumer);
			ServiceResponse<Consumer> addedConsumerResponse = consumerServiceClient
					.addConsumer(newConsumerRequest);
			Assert.assertEquals(addedConsumerResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedConsumerResponse.getPayload());
			Assert.assertEquals(addedConsumerResponse.getPayload().getConsumerId(), consumer.getConsumerId());
			
			consumer = addedConsumerResponse.getPayload();
			
			Service service1 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceVersion serviceVersion1 = newServiceVersion();
			serviceVersion1.setSerVersion("1.0.0");
			service1.getServiceVersions().add(serviceVersion1);
		
			ServiceVersion serviceVersion2 = newServiceVersion();
			serviceVersion2.setSerVersion("1.0.1");
			service1.getServiceVersions().add(serviceVersion2);
		
			ServiceRequest<Service> newServiceRequest = new ServiceRequest<Service>(
					new ServiceHeader(), service1);
			ServiceResponse<Service> addedServiceResponse = registryServiceClient
					.addService(newServiceRequest);
			Assert.assertEquals(addedServiceResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse.getPayload());
			Assert.assertEquals(addedServiceResponse.getPayload().getServiceVersions().size(), service1.getServiceVersions().size());
			
			service1 = addedServiceResponse.getPayload();
			serviceVersion1 = getServiceVersion(service1.getServiceVersions(), serviceVersion1.getSerVersion());
			SubscriptionRequest subscription1 =  newSubscription(serviceVersion1, consumer);
			
			ServiceRequest<SubscriptionRequest> addSubscriptionRequest = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription1);
			ServiceResponse<Subscription> addSubscriptionsResp = consumerServiceClient.addSubscription(consumer.getConsumerId(), addSubscriptionRequest);
			Assert.assertEquals(addSubscriptionsResp.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp.getPayload());
			
			serviceVersion2 = getServiceVersion(service1.getServiceVersions(), serviceVersion2.getSerVersion());
			SubscriptionRequest subscription2 =  newSubscription(serviceVersion2, consumer);
			
			ServiceRequest<SubscriptionRequest> addSubscriptionRequest2 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription2);
			ServiceResponse<Subscription> addSubscriptionsResp2 = consumerServiceClient.addSubscription(consumer.getConsumerId(), addSubscriptionRequest2);
			Assert.assertEquals(addSubscriptionsResp2.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp2.getPayload());
			
			ServiceResponse<SubscriptionList> getSubscriptionsResp = consumerServiceClient.getSubscriptions(consumer.getConsumerId());
			Assert.assertEquals(getSubscriptionsResp.getStatus(), Status.OK);
			Assert.assertNotNull(getSubscriptionsResp.getPayload());
			Assert.assertEquals(getSubscriptionsResp.getPayload().getSubscriptions().size(), 2);
			
			subscription1 = getSubscriptionByServiceVersionId(getSubscriptionsResp.getPayload().getSubscriptions(), serviceVersion1.getId());
			
			//update subscription
			subscription1.setCommunicationType(ServiceCommunicationType.DIRECT.toString());
			subscription1.setServiceVersionId(serviceVersion2.getId());
			
			ServiceRequest<SubscriptionRequest> updateSubscriptionreq = new ServiceRequest<SubscriptionRequest>(new ServiceHeader(), subscription1);
			ServiceResponse<Subscription> updateSubscriptionResp = consumerServiceClient.updateSubscription(updateSubscriptionreq);
			Assert.assertEquals(updateSubscriptionResp.getStatus(), Status.FAIL);
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.assertTrue(true, ex.getMessage());
		}
	}


	@Test(enabled = true)
	public void testActivateSubscriptions() throws Exception {
		try {
			Consumer consumer = newConsumer();
			
			ServiceRequest<Consumer> newConsumerRequest = new ServiceRequest<Consumer>(
					new ServiceHeader(), consumer);
			ServiceResponse<Consumer> addedConsumerResponse = consumerServiceClient
					.addConsumer(newConsumerRequest);
			Assert.assertEquals(addedConsumerResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedConsumerResponse.getPayload());
			Assert.assertEquals(addedConsumerResponse.getPayload().getConsumerId(), consumer.getConsumerId());
			
			consumer = addedConsumerResponse.getPayload();
			
			Service service1 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceVersion serviceVersion11 = newServiceVersion();
			serviceVersion11.setSerVersion("1.0.0");
			service1.getServiceVersions().add(serviceVersion11);
		
			ServiceVersion serviceVersion12 = newServiceVersion();
			serviceVersion12.setSerVersion("1.0.1");
			service1.getServiceVersions().add(serviceVersion12);
		
			ServiceRequest<Service> newServiceRequest1 = new ServiceRequest<Service>(
					new ServiceHeader(), service1);
			ServiceResponse<Service> addedServiceResponse1 = registryServiceClient
					.addService(newServiceRequest1);
			Assert.assertEquals(addedServiceResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse1.getPayload());
			Assert.assertEquals(addedServiceResponse1.getPayload().getServiceVersions().size(), service1.getServiceVersions().size());
			
			service1 = addedServiceResponse1.getPayload();
			serviceVersion11 = getServiceVersion(service1.getServiceVersions(), serviceVersion11.getSerVersion());
			SubscriptionRequest subscription11 =  newSubscription(serviceVersion11, consumer);
			
			serviceVersion12 = getServiceVersion(service1.getServiceVersions(), serviceVersion12.getSerVersion());
			SubscriptionRequest subscription12 =  newSubscription(serviceVersion12, consumer);
		
			ServiceRequest<SubscriptionRequest> addSubscriptionsRequest1 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription11);
			ServiceResponse<Subscription> addSubscriptionsResp1 = consumerServiceClient.addSubscription(consumer.getConsumerId(), addSubscriptionsRequest1);
			Assert.assertEquals(addSubscriptionsResp1.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp1.getPayload());
		
			ServiceRequest<SubscriptionRequest> addSubscriptionsRequest2 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription12);
			ServiceResponse<Subscription> addSubscriptionsResp2 = consumerServiceClient.addSubscription(consumer.getConsumerId(), addSubscriptionsRequest2);
			Assert.assertEquals(addSubscriptionsResp2.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp2.getPayload());
		
			Subscription activateSubscription = addSubscriptionsResp1.getPayload();
			
			ServiceResponse<Subscription> activateSubscriptionsResp = consumerServiceClient.updateSubscriptionStatus(activateSubscription.getId(), "ACTIVATE", "test_user");
			Assert.assertEquals(activateSubscriptionsResp.getStatus(), Status.OK);
			
			Subscription activatedSubscription = activateSubscriptionsResp.getPayload();
			
			Assert.assertNotNull(activatedSubscription);
			Assert.assertEquals(activatedSubscription.getStatus(), StatusType.ACTIVE.toString());
				
			ServiceResponse<SubscriptionList> getSubscriptionReq = consumerServiceClient.getSubscriptions(consumer.getConsumerId());
			Assert.assertEquals(getSubscriptionReq.getStatus(), Status.OK);
			Assert.assertNotNull(getSubscriptionReq.getPayload());
			Assert.assertNotNull(getSubscriptionReq.getPayload().getSubscriptions());
			Assert.assertFalse(getSubscriptionReq.getPayload().getSubscriptions().isEmpty());
			
			activatedSubscription = getSubscriptionByServiceVersionId(getSubscriptionReq.getPayload().getSubscriptions(), activatedSubscription.getServiceVersionId());
			Assert.assertNotNull(activatedSubscription);
			Assert.assertEquals(activatedSubscription.getStatus(), StatusType.ACTIVE.toString());
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testInActivateSubscriptions() throws Exception {
		try {
			Consumer consumer = newConsumer();
			
			ServiceRequest<Consumer> newConsumerRequest = new ServiceRequest<Consumer>(
					new ServiceHeader(), consumer);
			ServiceResponse<Consumer> addedConsumerResponse = consumerServiceClient
					.addConsumer(newConsumerRequest);
			Assert.assertEquals(addedConsumerResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedConsumerResponse.getPayload());
			Assert.assertEquals(addedConsumerResponse.getPayload().getConsumerId(), consumer.getConsumerId());
			
			consumer = addedConsumerResponse.getPayload();
			
			Service service1 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceVersion serviceVersion11 = newServiceVersion();
			serviceVersion11.setSerVersion("1.0.0");
			service1.getServiceVersions().add(serviceVersion11);
		
			ServiceVersion serviceVersion12 = newServiceVersion();
			serviceVersion12.setSerVersion("1.0.1");
			service1.getServiceVersions().add(serviceVersion12);
		
			ServiceRequest<Service> newServiceRequest1 = new ServiceRequest<Service>(
					new ServiceHeader(), service1);
			ServiceResponse<Service> addedServiceResponse1 = registryServiceClient
					.addService(newServiceRequest1);
			Assert.assertEquals(addedServiceResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse1.getPayload());
			Assert.assertEquals(addedServiceResponse1.getPayload().getServiceVersions().size(), service1.getServiceVersions().size());
			
			service1 = addedServiceResponse1.getPayload();
			serviceVersion11 = getServiceVersion(service1.getServiceVersions(), serviceVersion11.getSerVersion());
			SubscriptionRequest subscription11 =  newSubscription(serviceVersion11, consumer);
			
			serviceVersion12 = getServiceVersion(service1.getServiceVersions(), serviceVersion12.getSerVersion());
			SubscriptionRequest subscription12 =  newSubscription(serviceVersion12, consumer);
		
			ServiceRequest<SubscriptionRequest> addSubscriptionsRequest1 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription11);
			ServiceResponse<Subscription> addSubscriptionsResp1 = consumerServiceClient.addSubscription(consumer.getConsumerId(), addSubscriptionsRequest1);
			Assert.assertEquals(addSubscriptionsResp1.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp1.getPayload());
		
			ServiceRequest<SubscriptionRequest> addSubscriptionsRequest2 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription12);
			ServiceResponse<Subscription> addSubscriptionsResp2 = consumerServiceClient.addSubscription(consumer.getConsumerId(), addSubscriptionsRequest2);
			Assert.assertEquals(addSubscriptionsResp2.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp2.getPayload());
		
			Subscription activateSubscription = addSubscriptionsResp1.getPayload();
			
			//Activate
			
			ServiceResponse<Subscription> activateSubscriptionsResp = consumerServiceClient.updateSubscriptionStatus(activateSubscription.getId(), "ACTIVATE", "test_user");
			Assert.assertEquals(activateSubscriptionsResp.getStatus(), Status.OK);
			
			Subscription activatedSubscription = activateSubscriptionsResp.getPayload();
			
			Assert.assertNotNull(activatedSubscription);
			Assert.assertEquals(activatedSubscription.getStatus(), StatusType.ACTIVE.toString());
				
			ServiceResponse<SubscriptionList> getSubscriptionReq = consumerServiceClient.getSubscriptions(consumer.getConsumerId());
			Assert.assertEquals(getSubscriptionReq.getStatus(), Status.OK);
			Assert.assertNotNull(getSubscriptionReq.getPayload());
			Assert.assertNotNull(getSubscriptionReq.getPayload().getSubscriptions());
			Assert.assertFalse(getSubscriptionReq.getPayload().getSubscriptions().isEmpty());
			
			activatedSubscription = getSubscriptionByServiceVersionId(getSubscriptionReq.getPayload().getSubscriptions(), activatedSubscription.getServiceVersionId());
			Assert.assertNotNull(activatedSubscription);
			Assert.assertEquals(activatedSubscription.getStatus(), StatusType.ACTIVE.toString());

			//Deactivate
			
			ServiceResponse<Subscription> deactivateSubscriptionsResp = consumerServiceClient.updateSubscriptionStatus(activatedSubscription.getId(), "INACTIVATE", "test_user");
			Assert.assertEquals(deactivateSubscriptionsResp.getStatus(), Status.OK);
			
			Subscription deactivatedSubscription = deactivateSubscriptionsResp.getPayload();
			
			Assert.assertNotNull(deactivatedSubscription);
			Assert.assertEquals(deactivatedSubscription.getStatus(), StatusType.INACTIVE.toString());
				
			ServiceResponse<SubscriptionList> getSubscriptionReq2 = consumerServiceClient.getSubscriptions(consumer.getConsumerId());
			Assert.assertEquals(getSubscriptionReq2.getStatus(), Status.OK);
			Assert.assertNotNull(getSubscriptionReq2.getPayload());
			Assert.assertNotNull(getSubscriptionReq2.getPayload().getSubscriptions());
			Assert.assertFalse(getSubscriptionReq2.getPayload().getSubscriptions().isEmpty());
			
			deactivatedSubscription = getSubscriptionByServiceVersionId(getSubscriptionReq2.getPayload().getSubscriptions(), deactivatedSubscription.getServiceVersionId());
			Assert.assertNotNull(deactivatedSubscription);
			Assert.assertEquals(deactivatedSubscription.getStatus(), StatusType.INACTIVE.toString());

		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testInActivateSubscriptionAlreadyInactive() throws Exception {
		try {
			Consumer consumer = newConsumer();
			
			ServiceRequest<Consumer> newConsumerRequest = new ServiceRequest<Consumer>(
					new ServiceHeader(), consumer);
			ServiceResponse<Consumer> addedConsumerResponse = consumerServiceClient
					.addConsumer(newConsumerRequest);
			Assert.assertEquals(addedConsumerResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedConsumerResponse.getPayload());
			Assert.assertEquals(addedConsumerResponse.getPayload().getConsumerId(), consumer.getConsumerId());
			
			consumer = addedConsumerResponse.getPayload();
			
			Service service1 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceVersion serviceVersion11 = newServiceVersion();
			serviceVersion11.setSerVersion("1.0.0");
			service1.getServiceVersions().add(serviceVersion11);
		
			ServiceVersion serviceVersion12 = newServiceVersion();
			serviceVersion12.setSerVersion("1.0.1");
			service1.getServiceVersions().add(serviceVersion12);
		
			ServiceRequest<Service> newServiceRequest1 = new ServiceRequest<Service>(
					new ServiceHeader(), service1);
			ServiceResponse<Service> addedServiceResponse1 = registryServiceClient
					.addService(newServiceRequest1);
			Assert.assertEquals(addedServiceResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse1.getPayload());
			Assert.assertEquals(addedServiceResponse1.getPayload().getServiceVersions().size(), service1.getServiceVersions().size());
			
			service1 = addedServiceResponse1.getPayload();
			serviceVersion11 = getServiceVersion(service1.getServiceVersions(), serviceVersion11.getSerVersion());
			SubscriptionRequest subscription11 =  newSubscription(serviceVersion11, consumer);
			
			serviceVersion12 = getServiceVersion(service1.getServiceVersions(), serviceVersion12.getSerVersion());
			SubscriptionRequest subscription12 =  newSubscription(serviceVersion12, consumer);
		
			ServiceRequest<SubscriptionRequest> addSubscriptionsRequest1 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription11);
			ServiceResponse<Subscription> addSubscriptionsResp1 = consumerServiceClient.addSubscription(consumer.getConsumerId(), addSubscriptionsRequest1);
			Assert.assertEquals(addSubscriptionsResp1.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp1.getPayload());
		
			ServiceRequest<SubscriptionRequest> addSubscriptionsRequest2 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription12);
			ServiceResponse<Subscription> addSubscriptionsResp2 = consumerServiceClient.addSubscription(consumer.getConsumerId(), addSubscriptionsRequest2);
			Assert.assertEquals(addSubscriptionsResp2.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp2.getPayload());
		
			Subscription activateSubscription = addSubscriptionsResp1.getPayload();
			
			ServiceResponse<Subscription> activateSubscriptionsResp = consumerServiceClient.updateSubscriptionStatus(activateSubscription.getId(), "INACTIVATE", "test_user");
			Assert.assertEquals(activateSubscriptionsResp.getStatus(), Status.FAIL);
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.assertTrue(true, ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testDeleteSubscription() throws Exception {
		try {
			Consumer consumer = newConsumer();
			
			ServiceRequest<Consumer> newConsumerRequest = new ServiceRequest<Consumer>(
					new ServiceHeader(), consumer);
			ServiceResponse<Consumer> addedConsumerResponse = consumerServiceClient
					.addConsumer(newConsumerRequest);
			Assert.assertEquals(addedConsumerResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedConsumerResponse.getPayload());
			Assert.assertEquals(addedConsumerResponse.getPayload().getConsumerId(), consumer.getConsumerId());
			
			consumer = addedConsumerResponse.getPayload();
			
			Service service1 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceVersion serviceVersion11 = newServiceVersion();
			serviceVersion11.setSerVersion("1.0.0");
			service1.getServiceVersions().add(serviceVersion11);
		
			ServiceVersion serviceVersion12 = newServiceVersion();
			serviceVersion12.setSerVersion("1.0.1");
			service1.getServiceVersions().add(serviceVersion12);
		
			ServiceRequest<Service> newServiceRequest1 = new ServiceRequest<Service>(
					new ServiceHeader(), service1);
			ServiceResponse<Service> addedServiceResponse1 = registryServiceClient
					.addService(newServiceRequest1);
			Assert.assertEquals(addedServiceResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse1.getPayload());
			Assert.assertEquals(addedServiceResponse1.getPayload().getServiceVersions().size(), service1.getServiceVersions().size());
			
			service1 = addedServiceResponse1.getPayload();
			serviceVersion11 = getServiceVersion(service1.getServiceVersions(), serviceVersion11.getSerVersion());
			SubscriptionRequest subscription11 =  newSubscription(serviceVersion11, consumer);
			
			serviceVersion12 = getServiceVersion(service1.getServiceVersions(), serviceVersion12.getSerVersion());
			SubscriptionRequest subscription12 =  newSubscription(serviceVersion12, consumer);
		
			ServiceRequest<SubscriptionRequest> addSubscriptionsRequest1 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription11);
			ServiceResponse<Subscription> addSubscriptionsResp1 = consumerServiceClient.addSubscription(consumer.getConsumerId(), addSubscriptionsRequest1);
			Assert.assertEquals(addSubscriptionsResp1.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp1.getPayload());
		
			ServiceRequest<SubscriptionRequest> addSubscriptionsRequest2 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription12);
			ServiceResponse<Subscription> addSubscriptionsResp2 = consumerServiceClient.addSubscription(consumer.getConsumerId(), addSubscriptionsRequest2);
			Assert.assertEquals(addSubscriptionsResp2.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp2.getPayload());
		
			Subscription deleteSubscription = addSubscriptionsResp1.getPayload();
			
			ServiceResponse<Subscription> deleteSubscriptionsResp = consumerServiceClient.deleteSubscription(deleteSubscription.getId(), "test_user");
			Assert.assertEquals(deleteSubscriptionsResp.getStatus(), Status.OK);
			Assert.assertNull(deleteSubscriptionsResp.getPayload());
			
			//Delete subscription should not be present
			ServiceResponse<SubscriptionList> getSubscriptionReq = consumerServiceClient.getSubscriptions(consumer.getConsumerId());
			Assert.assertEquals(getSubscriptionReq.getStatus(), Status.OK);
			Assert.assertNotNull(getSubscriptionReq.getPayload());
			Assert.assertNotNull(getSubscriptionReq.getPayload().getSubscriptions());
			Assert.assertFalse(getSubscriptionReq.getPayload().getSubscriptions().isEmpty());
			
			Subscription deletedSubscription = getSubscriptionByServiceVersionId(getSubscriptionReq.getPayload().getSubscriptions(), deleteSubscription.getServiceVersionId());
			Assert.assertNull(deletedSubscription);
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testAddSubscriptionsNewConsumer() throws Exception {
		try {
			Consumer consumer = newConsumer();
			Service service1 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceVersion serviceVersion1 = newServiceVersion();
			serviceVersion1.setSerVersion("1.0.0");
			service1.getServiceVersions().add(serviceVersion1);
		
			ServiceVersion serviceVersion2 = newServiceVersion();
			serviceVersion2.setSerVersion("1.0.1");
			service1.getServiceVersions().add(serviceVersion2);
		
			ServiceRequest<Service> newServiceRequest = new ServiceRequest<Service>(
					new ServiceHeader(), service1);
			ServiceResponse<Service> addedServiceResponse = registryServiceClient
					.addService(newServiceRequest);
			Assert.assertEquals(addedServiceResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse.getPayload());
			Assert.assertEquals(addedServiceResponse.getPayload().getServiceVersions().size(), service1.getServiceVersions().size());
			
			service1 = addedServiceResponse.getPayload();
			serviceVersion1 = getServiceVersion(service1.getServiceVersions(), serviceVersion1.getSerVersion());
			SubscriptionRequest subscription1 =  newSubscription(serviceVersion1, consumer);
			
			ServiceRequest<SubscriptionRequest> addSubscriptionsRequest = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription1);
			ServiceResponse<Subscription> addSubscriptionsResp = consumerServiceClient.addSubscription(consumer.getConsumerId(), addSubscriptionsRequest);
			Assert.assertEquals(addSubscriptionsResp.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp.getPayload());
			
			
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testSearchSubscriptions() throws Exception {
		try {
			Consumer consumer1 = newConsumer();
			
			ServiceRequest<Consumer> newConsumerRequest1 = new ServiceRequest<Consumer>(
					new ServiceHeader(), consumer1);
			ServiceResponse<Consumer> addedConsumerResponse1 = consumerServiceClient
					.addConsumer(newConsumerRequest1);
			Assert.assertEquals(addedConsumerResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedConsumerResponse1.getPayload());
			Assert.assertEquals(addedConsumerResponse1.getPayload().getConsumerId(), consumer1.getConsumerId());
			
			consumer1 = addedConsumerResponse1.getPayload();
			
			Service service1 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceVersion serviceVersion11 = newServiceVersion();
			serviceVersion11.setSerVersion("1.0.0");
			service1.getServiceVersions().add(serviceVersion11);
		
			ServiceVersion serviceVersion12 = newServiceVersion();
			serviceVersion12.setSerVersion("1.0.1");
			service1.getServiceVersions().add(serviceVersion12);
		
			ServiceRequest<Service> newServiceRequest1 = new ServiceRequest<Service>(
					new ServiceHeader(), service1);
			ServiceResponse<Service> addedServiceResponse1 = registryServiceClient
					.addService(newServiceRequest1);
			Assert.assertEquals(addedServiceResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse1.getPayload());
			Assert.assertEquals(addedServiceResponse1.getPayload().getServiceVersions().size(), service1.getServiceVersions().size());
			
			service1 = addedServiceResponse1.getPayload();
			serviceVersion11 = getServiceVersion(service1.getServiceVersions(), serviceVersion11.getSerVersion());
			SubscriptionRequest subscription11 =  newSubscription(serviceVersion11, consumer1);
			
			serviceVersion12 = getServiceVersion(service1.getServiceVersions(), serviceVersion12.getSerVersion());
			SubscriptionRequest subscription12 =  newSubscription(serviceVersion12, consumer1);
		
			ServiceRequest<SubscriptionRequest> addSubscriptionsRequest1 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription11);
			ServiceResponse<Subscription> addSubscriptionsResp1 = consumerServiceClient.addSubscription(consumer1.getConsumerId(), addSubscriptionsRequest1);
			Assert.assertEquals(addSubscriptionsResp1.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp1.getPayload());
			
			ServiceRequest<SubscriptionRequest> addSubscriptionsRequest2 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription12);
			ServiceResponse<Subscription> addSubscriptionsResp2 = consumerServiceClient.addSubscription(consumer1.getConsumerId(), addSubscriptionsRequest2);
			Assert.assertEquals(addSubscriptionsResp2.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp2.getPayload());
			
			//Add more subscriptions
			Service service2 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceVersion serviceVersion21 = newServiceVersion();
			serviceVersion21.setSerVersion("1.0.0");
			service2.getServiceVersions().add(serviceVersion21);
		
			ServiceVersion serviceVersion22 = newServiceVersion();
			serviceVersion22.setSerVersion("1.0.1");
			serviceVersion22.getUrls().clear();
			Url endpointUrl = new Url();
			endpointUrl.setType(UrlType.ENDPOINT.toString());
			endpointUrl.setUrl(TEST_END_POINT_URL);
			serviceVersion22.getUrls().add(endpointUrl);
			service2.getServiceVersions().add(serviceVersion22);
		
			ServiceRequest<Service> newServiceRequest2 = new ServiceRequest<Service>(
					new ServiceHeader(), service2);
			ServiceResponse<Service> addedServiceResponse2 = registryServiceClient
					.addService(newServiceRequest2);
			Assert.assertEquals(addedServiceResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse2.getPayload());
			Assert.assertEquals(addedServiceResponse2.getPayload().getServiceVersions().size(), service2.getServiceVersions().size());
			
			service2 = addedServiceResponse2.getPayload();
			serviceVersion21 = getServiceVersion(service2.getServiceVersions(), serviceVersion21.getSerVersion());
			SubscriptionRequest subscription21 =  newSubscription(serviceVersion21, consumer1);
			
			serviceVersion22 = getServiceVersion(service2.getServiceVersions(), serviceVersion22.getSerVersion());
			SubscriptionRequest subscription22 =  newSubscription(serviceVersion22, consumer1);
			subscription22.setCommunicationType(ServiceCommunicationType.DIRECT.toString());
			
			ServiceRequest<SubscriptionRequest> addSubscriptionsRequest21 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription21);
			ServiceResponse<Subscription> addSubscriptionsResp21 = consumerServiceClient.addSubscription(consumer1.getConsumerId(), addSubscriptionsRequest21);
			Assert.assertEquals(addSubscriptionsResp21.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp21.getPayload());

			ServiceRequest<SubscriptionRequest> addSubscriptionsRequest22 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription22);
			ServiceResponse<Subscription> addSubscriptionsResp22 = consumerServiceClient.addSubscription(consumer1.getConsumerId(), addSubscriptionsRequest22);
			Assert.assertEquals(addSubscriptionsResp22.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp22.getPayload());
			
			
			//Consumer2
			Consumer consumer2 = newConsumer();
			
			ServiceRequest<Consumer> newConsumerRequest2 = new ServiceRequest<Consumer>(
					new ServiceHeader(), consumer2);
			ServiceResponse<Consumer> addedConsumerResponse2 = consumerServiceClient
					.addConsumer(newConsumerRequest2);
			Assert.assertEquals(addedConsumerResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedConsumerResponse2.getPayload());
			Assert.assertEquals(addedConsumerResponse2.getPayload().getConsumerId(), consumer2.getConsumerId());
			
			consumer2 = addedConsumerResponse2.getPayload();
			
			Service service3 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceVersion serviceVersion31 = newServiceVersion();
			serviceVersion31.setSerVersion("1.0.0");
			serviceVersion31.getUrls().clear();
			Url esbUrl = new Url();
			esbUrl.setType(UrlType.ESB_PROXY.toString());
			esbUrl.setUrl(TEST_ESB_PROXY_URL);
			serviceVersion31.getUrls().add(esbUrl);
			service3.getServiceVersions().add(serviceVersion31);
		
			ServiceRequest<Service> newServiceRequest3 = new ServiceRequest<Service>(
					new ServiceHeader(), service3);
			ServiceResponse<Service> addedServiceResponse3 = registryServiceClient
					.addService(newServiceRequest3);
			Assert.assertEquals(addedServiceResponse3.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse3.getPayload());
			Assert.assertEquals(addedServiceResponse3.getPayload().getServiceVersions().size(), service3.getServiceVersions().size());
			
			service3 = addedServiceResponse3.getPayload();
			serviceVersion31 = getServiceVersion(service3.getServiceVersions(), serviceVersion31.getSerVersion());
			SubscriptionRequest subscription31 =  newSubscription(serviceVersion31, consumer2);
			subscription31.setCommunicationType(ServiceCommunicationType.ESB_PROXY.toString());
			
			ServiceRequest<SubscriptionRequest> addSubscriptionsRequest3 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription31);
			ServiceResponse<Subscription> addSubscriptionsResp3 = consumerServiceClient.addSubscription(consumer2.getConsumerId(), addSubscriptionsRequest3);
			Assert.assertEquals(addSubscriptionsResp3.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp3.getPayload());
			
			//
			ServiceResponse<SubscriptionList> searchSubscriptionResp = consumerServiceClient.searchSubscriptions(null);
			Assert.assertEquals(searchSubscriptionResp.getStatus(), Status.OK);
			Assert.assertNotNull(searchSubscriptionResp.getPayload());
			Assert.assertFalse(searchSubscriptionResp.getPayload().getSubscriptions().isEmpty());
			subscription11 = getSubscriptionByServiceVersionId(searchSubscriptionResp.getPayload().getSubscriptions(), serviceVersion11.getId());
			Assert.assertNotNull(subscription11);
			
			subscription12 = getSubscriptionByServiceVersionId(searchSubscriptionResp.getPayload().getSubscriptions(), serviceVersion12.getId());
			Assert.assertNotNull(subscription12);
			
			subscription21 = getSubscriptionByServiceVersionId(searchSubscriptionResp.getPayload().getSubscriptions(), serviceVersion21.getId());
			Assert.assertNotNull(subscription21);
			
			Subscription sub22 = getSubscriptionByServiceVersionId(searchSubscriptionResp.getPayload().getSubscriptions(), serviceVersion22.getId());
			Assert.assertNotNull(sub22);
			Assert.assertEquals(sub22.getRequestUrl(), TEST_END_POINT_URL);
				
			Subscription sub31 = getSubscriptionByServiceVersionId(searchSubscriptionResp.getPayload().getSubscriptions(), serviceVersion31.getId());
			Assert.assertNotNull(sub31);
			Assert.assertEquals(sub31.getRequestUrl(), TEST_ESB_PROXY_URL);

			Assert.assertEquals(sub31.getApplicationId(), service3.getApplicationId());
			Assert.assertEquals(sub31.getServiceStatus(), service3.getStatus());
			Assert.assertEquals(sub31.getServiceCategory(), service3.getCategory());
			Assert.assertEquals(sub31.getServiceUsage(), service3.getUsage());
			Assert.assertEquals(sub31.getServiceDomain(), service3.getDomain());
			Assert.assertEquals(sub31.getServiceOwner(), service3.getOwner());
			Assert.assertEquals(sub31.getServiceVersionStatus(), serviceVersion31.getStatus());
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	
	@Test(enabled = true)
	public void testSearchSubscriptionServiceVersionsByConsumerId() throws Exception {
		try {
			Consumer consumer1 = newConsumer();
			
			ServiceRequest<Consumer> newConsumerRequest1 = new ServiceRequest<Consumer>(
					new ServiceHeader(), consumer1);
			ServiceResponse<Consumer> addedConsumerResponse1 = consumerServiceClient
					.addConsumer(newConsumerRequest1);
			Assert.assertEquals(addedConsumerResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedConsumerResponse1.getPayload());
			Assert.assertEquals(addedConsumerResponse1.getPayload().getConsumerId(), consumer1.getConsumerId());
			
			consumer1 = addedConsumerResponse1.getPayload();
			
			Service service1 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceVersion serviceVersion11 = newServiceVersion();
			serviceVersion11.setSerVersion("1.0.0");
			service1.getServiceVersions().add(serviceVersion11);
		
			ServiceVersion serviceVersion12 = newServiceVersion();
			serviceVersion12.setSerVersion("1.0.1");
			service1.getServiceVersions().add(serviceVersion12);
		
			ServiceRequest<Service> newServiceRequest1 = new ServiceRequest<Service>(
					new ServiceHeader(), service1);
			ServiceResponse<Service> addedServiceResponse1 = registryServiceClient
					.addService(newServiceRequest1);
			Assert.assertEquals(addedServiceResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse1.getPayload());
			Assert.assertEquals(addedServiceResponse1.getPayload().getServiceVersions().size(), service1.getServiceVersions().size());
			
			service1 = addedServiceResponse1.getPayload();
			serviceVersion11 = getServiceVersion(service1.getServiceVersions(), serviceVersion11.getSerVersion());
			SubscriptionRequest subscription11 =  newSubscription(serviceVersion11, consumer1);
			
			serviceVersion12 = getServiceVersion(service1.getServiceVersions(), serviceVersion12.getSerVersion());
			SubscriptionRequest subscription12 =  newSubscription(serviceVersion12, consumer1);
		
			ServiceRequest<SubscriptionRequest> addSubscriptionsRequest1 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription11);
			ServiceResponse<Subscription> addSubscriptionsResp1 = consumerServiceClient.addSubscription(consumer1.getConsumerId(), addSubscriptionsRequest1);
			Assert.assertEquals(addSubscriptionsResp1.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp1.getPayload());
			
			ServiceRequest<SubscriptionRequest> addSubscriptionsRequest2 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription12);
			ServiceResponse<Subscription> addSubscriptionsResp2 = consumerServiceClient.addSubscription(consumer1.getConsumerId(), addSubscriptionsRequest2);
			Assert.assertEquals(addSubscriptionsResp2.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp2.getPayload());
			
			//Add more subscriptions
			Service service2 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceVersion serviceVersion21 = newServiceVersion();
			serviceVersion21.setSerVersion("1.0.0");
			service2.getServiceVersions().add(serviceVersion21);
		
			ServiceVersion serviceVersion22 = newServiceVersion();
			serviceVersion22.setSerVersion("1.0.1");
			service2.getServiceVersions().add(serviceVersion22);
		
			ServiceRequest<Service> newServiceRequest2 = new ServiceRequest<Service>(
					new ServiceHeader(), service2);
			ServiceResponse<Service> addedServiceResponse2 = registryServiceClient
					.addService(newServiceRequest2);
			Assert.assertEquals(addedServiceResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse2.getPayload());
			Assert.assertEquals(addedServiceResponse2.getPayload().getServiceVersions().size(), service2.getServiceVersions().size());
			
			service2 = addedServiceResponse2.getPayload();
			serviceVersion21 = getServiceVersion(service2.getServiceVersions(), serviceVersion21.getSerVersion());
			SubscriptionRequest subscription21 =  newSubscription(serviceVersion21, consumer1);
			subscription21.setCommunicationType(ServiceCommunicationType.ESB_PROXY.toString());
			
			serviceVersion22 = getServiceVersion(service2.getServiceVersions(), serviceVersion22.getSerVersion());
			SubscriptionRequest subscription22 =  newSubscription(serviceVersion22, consumer1);
			subscription22.setCommunicationType(ServiceCommunicationType.DIRECT.toString());
			
			ServiceRequest<SubscriptionRequest> addSubscriptionsRequest21 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription21);
			ServiceResponse<Subscription> addSubscriptionsResp21 = consumerServiceClient.addSubscription(consumer1.getConsumerId(), addSubscriptionsRequest21);
			Assert.assertEquals(addSubscriptionsResp21.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp21.getPayload());

			ServiceRequest<SubscriptionRequest> addSubscriptionsRequest22 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription22);
			ServiceResponse<Subscription> addSubscriptionsResp22 = consumerServiceClient.addSubscription(consumer1.getConsumerId(), addSubscriptionsRequest22);
			Assert.assertEquals(addSubscriptionsResp22.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp22.getPayload());
			
			
			//Consumer2
			Consumer consumer2 = newConsumer();
			
			ServiceRequest<Consumer> newConsumerRequest2 = new ServiceRequest<Consumer>(
					new ServiceHeader(), consumer2);
			ServiceResponse<Consumer> addedConsumerResponse2 = consumerServiceClient
					.addConsumer(newConsumerRequest2);
			Assert.assertEquals(addedConsumerResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedConsumerResponse2.getPayload());
			Assert.assertEquals(addedConsumerResponse2.getPayload().getConsumerId(), consumer2.getConsumerId());
			
			consumer2 = addedConsumerResponse2.getPayload();
			
			Service service3 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceVersion serviceVersion31 = newServiceVersion();
			serviceVersion31.setSerVersion("1.0.0");
			service3.getServiceVersions().add(serviceVersion31);
		
			ServiceRequest<Service> newServiceRequest3 = new ServiceRequest<Service>(
					new ServiceHeader(), service3);
			ServiceResponse<Service> addedServiceResponse3 = registryServiceClient
					.addService(newServiceRequest3);
			Assert.assertEquals(addedServiceResponse3.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse3.getPayload());
			Assert.assertEquals(addedServiceResponse3.getPayload().getServiceVersions().size(), service3.getServiceVersions().size());
			
			service3 = addedServiceResponse3.getPayload();
			serviceVersion31 = getServiceVersion(service3.getServiceVersions(), serviceVersion31.getSerVersion());
			SubscriptionRequest subscription31 =  newSubscription(serviceVersion31, consumer2);
			
			ServiceRequest<SubscriptionRequest> addSubscriptionsRequest3 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription31);
			ServiceResponse<Subscription> addSubscriptionsResp3 = consumerServiceClient.addSubscription(consumer2.getConsumerId(), addSubscriptionsRequest3);
			Assert.assertEquals(addSubscriptionsResp3.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp3.getPayload());
			
			//
			ServiceSearchBean search = new ServiceSearchBean();
			search.setConsumerId(consumer1.getConsumerId());
			
			ServiceResponse<ServiceList> searchServiceResp = registryServiceClient.searchServices(search);
			Assert.assertEquals(searchServiceResp.getStatus(), Status.OK);
			Assert.assertNotNull(searchServiceResp.getPayload());
			Assert.assertFalse(searchServiceResp.getPayload().getServices().isEmpty());
			service1 = getServiceById(searchServiceResp.getPayload().getServices(), service1.getId());
			Assert.assertNotNull(service1);
			Assert.assertNotNull(getServiceVersion(service1.getServiceVersions(), serviceVersion11.getSerVersion()));
			Assert.assertNotNull(getServiceVersion(service1.getServiceVersions(), serviceVersion12.getSerVersion()));
					
			service2 = getServiceById(searchServiceResp.getPayload().getServices(), service2.getId());
			Assert.assertNotNull(service2);
			Assert.assertNotNull(getServiceVersion(service1.getServiceVersions(), serviceVersion21.getSerVersion()));
			Assert.assertNotNull(getServiceVersion(service1.getServiceVersions(), serviceVersion22.getSerVersion()));
		
			service3 = getServiceById(searchServiceResp.getPayload().getServices(), service3.getId());
			Assert.assertNull(service3);
			
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testSearchSubscriptionServiceVersionsByConsumerIdAndCommType() throws Exception {
		try {
			Consumer consumer = newConsumer();
			
			ServiceRequest<Consumer> newConsumerRequest = new ServiceRequest<Consumer>(
					new ServiceHeader(), consumer);
			ServiceResponse<Consumer> addedConsumerResponse = consumerServiceClient
					.addConsumer(newConsumerRequest);
			Assert.assertEquals(addedConsumerResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedConsumerResponse.getPayload());
			Assert.assertEquals(addedConsumerResponse.getPayload().getConsumerId(), consumer.getConsumerId());
			
			consumer = addedConsumerResponse.getPayload();
			
			Service service1 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceVersion serviceVersion11 = newServiceVersion();
			serviceVersion11.setSerVersion("1.0.0");
			service1.getServiceVersions().add(serviceVersion11);
		
			ServiceVersion serviceVersion12 = newServiceVersion();
			serviceVersion12.setSerVersion("1.0.1");
			service1.getServiceVersions().add(serviceVersion12);
		
			ServiceRequest<Service> newServiceRequest1 = new ServiceRequest<Service>(
					new ServiceHeader(), service1);
			ServiceResponse<Service> addedServiceResponse1 = registryServiceClient
					.addService(newServiceRequest1);
			Assert.assertEquals(addedServiceResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse1.getPayload());
			Assert.assertEquals(addedServiceResponse1.getPayload().getServiceVersions().size(), service1.getServiceVersions().size());
			
			service1 = addedServiceResponse1.getPayload();
			serviceVersion11 = getServiceVersion(service1.getServiceVersions(), serviceVersion11.getSerVersion());
			SubscriptionRequest subscription11 =  newSubscription(serviceVersion11, consumer);
			subscription11.setCommunicationType(ServiceCommunicationType.ESB_PROXY.toString());
			
			serviceVersion12 = getServiceVersion(service1.getServiceVersions(), serviceVersion12.getSerVersion());
			SubscriptionRequest subscription12 =  newSubscription(serviceVersion12, consumer);
			subscription12.setCommunicationType(ServiceCommunicationType.DIRECT.toString());
			
			ServiceRequest<SubscriptionRequest> addSubscriptionsRequest1 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription11);
			ServiceResponse<Subscription> addSubscriptionsResp1 = consumerServiceClient.addSubscription(consumer.getConsumerId(), addSubscriptionsRequest1);
			Assert.assertEquals(addSubscriptionsResp1.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp1.getPayload());
			
			ServiceRequest<SubscriptionRequest> addSubscriptionsRequest2 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription12);
			ServiceResponse<Subscription> addSubscriptionsResp2 = consumerServiceClient.addSubscription(consumer.getConsumerId(), addSubscriptionsRequest2);
			Assert.assertEquals(addSubscriptionsResp2.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp2.getPayload());
		
			//Add more subscriptions
			Service service2 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceVersion serviceVersion21 = newServiceVersion();
			serviceVersion21.setSerVersion("1.0.0");
			service2.getServiceVersions().add(serviceVersion21);
		
			ServiceVersion serviceVersion22 = newServiceVersion();
			serviceVersion22.setSerVersion("1.0.1");
			service2.getServiceVersions().add(serviceVersion22);
		
			ServiceVersion serviceVersion23 = newServiceVersion();
			serviceVersion23.setSerVersion("1.0.2");
			service2.getServiceVersions().add(serviceVersion23);
			
			ServiceRequest<Service> newServiceRequest2 = new ServiceRequest<Service>(
					new ServiceHeader(), service2);
			ServiceResponse<Service> addedServiceResponse2 = registryServiceClient
					.addService(newServiceRequest2);
			Assert.assertEquals(addedServiceResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse2.getPayload());
			Assert.assertEquals(addedServiceResponse2.getPayload().getServiceVersions().size(), service2.getServiceVersions().size());
			
			service2 = addedServiceResponse2.getPayload();
			serviceVersion21 = getServiceVersion(service2.getServiceVersions(), serviceVersion21.getSerVersion());
			SubscriptionRequest subscription21 =  newSubscription(serviceVersion21, consumer);
			subscription21.setCommunicationType(ServiceCommunicationType.ESB_PROXY.toString());
			
			serviceVersion22 = getServiceVersion(service2.getServiceVersions(), serviceVersion22.getSerVersion());
			SubscriptionRequest subscription22 =  newSubscription(serviceVersion22, consumer);
			subscription22.setCommunicationType(ServiceCommunicationType.DIRECT.toString());
			
			serviceVersion23 = getServiceVersion(service2.getServiceVersions(), serviceVersion23.getSerVersion());
			SubscriptionRequest subscription23 =  newSubscription(serviceVersion23, consumer);
			subscription23.setCommunicationType(ServiceCommunicationType.LOCAL.toString());
			
			ServiceRequest<SubscriptionRequest> addSubscriptionsRequest21 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription21);
			ServiceResponse<Subscription> addSubscriptionsResp21 = consumerServiceClient.addSubscription(consumer.getConsumerId(), addSubscriptionsRequest21);
			Assert.assertEquals(addSubscriptionsResp21.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp21.getPayload());

			ServiceRequest<SubscriptionRequest> addSubscriptionsRequest22 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription22);
			ServiceResponse<Subscription> addSubscriptionsResp22 = consumerServiceClient.addSubscription(consumer.getConsumerId(), addSubscriptionsRequest22);
			Assert.assertEquals(addSubscriptionsResp22.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp22.getPayload());
			
			ServiceRequest<SubscriptionRequest> addSubscriptionsRequest23 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription23);
			ServiceResponse<Subscription> addSubscriptionsResp23 = consumerServiceClient.addSubscription(consumer.getConsumerId(), addSubscriptionsRequest23);
			Assert.assertEquals(addSubscriptionsResp23.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp23.getPayload());
			
			ServiceSearchBean search = new ServiceSearchBean();
			search.setConsumerId(consumer.getConsumerId());
			search.setCommunicationType(ServiceCommunicationType.ESB_PROXY.toString());
			
			ServiceResponse<ServiceList> searchServiceResp = registryServiceClient.searchServices(search);
			Assert.assertEquals(searchServiceResp.getStatus(), Status.OK);
			Assert.assertNotNull(searchServiceResp.getPayload());
			Assert.assertEquals(searchServiceResp.getPayload().getServices().size(), 2);
			service1 = getServiceById(searchServiceResp.getPayload().getServices(), service1.getId());
			Assert.assertNotNull(service1);
			Assert.assertNotNull(getServiceVersion(service1.getServiceVersions(), serviceVersion11.getSerVersion()));
			Assert.assertNull(getServiceVersion(service1.getServiceVersions(), serviceVersion12.getSerVersion()));
					
			service2 = getServiceById(searchServiceResp.getPayload().getServices(), service2.getId());
			Assert.assertNotNull(service2);
			Assert.assertNotNull(getServiceVersion(service1.getServiceVersions(), serviceVersion21.getSerVersion()));
			Assert.assertNull(getServiceVersion(service1.getServiceVersions(), serviceVersion22.getSerVersion()));
			Assert.assertNull(getServiceVersion(service1.getServiceVersions(), serviceVersion23.getSerVersion()));
			
			search = new ServiceSearchBean();
			search.setConsumerId(consumer.getConsumerId());
			search.setCommunicationType(ServiceCommunicationType.LOCAL.toString());
			
			searchServiceResp = registryServiceClient.searchServices(search);
			Assert.assertEquals(searchServiceResp.getStatus(), Status.OK);
			Assert.assertNotNull(searchServiceResp.getPayload());
			Assert.assertEquals(searchServiceResp.getPayload().getServices().size(), 1);
			service1 = getServiceById(searchServiceResp.getPayload().getServices(), service1.getId());
			Assert.assertNull(service1);
					
			service2 = getServiceById(searchServiceResp.getPayload().getServices(), service2.getId());
			Assert.assertNotNull(service2);
			Assert.assertNull(getServiceVersion(service2.getServiceVersions(), serviceVersion21.getSerVersion()));
			Assert.assertNull(getServiceVersion(service2.getServiceVersions(), serviceVersion22.getSerVersion()));
			Assert.assertNotNull(getServiceVersion(service2.getServiceVersions(), serviceVersion23.getSerVersion()));
			
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testSearchSubscriptionServiceVersionsByConsumerIdAndCommTypeAndEnvironment() throws Exception {
		try {
			Consumer consumer = newConsumer();
			
			ServiceRequest<Consumer> newConsumerRequest = new ServiceRequest<Consumer>(
					new ServiceHeader(), consumer);
			ServiceResponse<Consumer> addedConsumerResponse = consumerServiceClient
					.addConsumer(newConsumerRequest);
			Assert.assertEquals(addedConsumerResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedConsumerResponse.getPayload());
			Assert.assertEquals(addedConsumerResponse.getPayload().getConsumerId(), consumer.getConsumerId());
			
			consumer = addedConsumerResponse.getPayload();
			
			Service service1 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceVersion serviceVersion11 = newServiceVersion();
			serviceVersion11.setSerVersion("1.0.0");
			service1.getServiceVersions().add(serviceVersion11);
			service1.setEnvironment(EnvironmentType.QA.toString());
		
			ServiceVersion serviceVersion12 = newServiceVersion();
			serviceVersion12.setSerVersion("1.0.1");
			service1.getServiceVersions().add(serviceVersion12);
		
			ServiceRequest<Service> newServiceRequest1 = new ServiceRequest<Service>(
					new ServiceHeader(), service1);
			ServiceResponse<Service> addedServiceResponse1 = registryServiceClient
					.addService(newServiceRequest1);
			Assert.assertEquals(addedServiceResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse1.getPayload());
			Assert.assertEquals(addedServiceResponse1.getPayload().getServiceVersions().size(), service1.getServiceVersions().size());
			
			service1 = addedServiceResponse1.getPayload();
			serviceVersion11 = getServiceVersion(service1.getServiceVersions(), serviceVersion11.getSerVersion());
			SubscriptionRequest subscription11 =  newSubscription(serviceVersion11, consumer);
			subscription11.setCommunicationType(ServiceCommunicationType.ESB_PROXY.toString());
			
			serviceVersion12 = getServiceVersion(service1.getServiceVersions(), serviceVersion12.getSerVersion());
			SubscriptionRequest subscription12 =  newSubscription(serviceVersion12, consumer);
			subscription12.setCommunicationType(ServiceCommunicationType.DIRECT.toString());
			
			ServiceRequest<SubscriptionRequest> addSubscriptionsRequest1 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription11);
			ServiceResponse<Subscription> addSubscriptionsResp1 = consumerServiceClient.addSubscription(consumer.getConsumerId(), addSubscriptionsRequest1);
			Assert.assertEquals(addSubscriptionsResp1.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp1.getPayload());
			
			ServiceRequest<SubscriptionRequest> addSubscriptionsRequest2 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription12);
			ServiceResponse<Subscription> addSubscriptionsResp2 = consumerServiceClient.addSubscription(consumer.getConsumerId(), addSubscriptionsRequest2);
			Assert.assertEquals(addSubscriptionsResp2.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp2.getPayload());
		
			//Add more subscriptions
			Service service2 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			service2.setEnvironment(EnvironmentType.BUILD.toString());
			ServiceVersion serviceVersion21 = newServiceVersion();
			serviceVersion21.setSerVersion("1.0.0");
			service2.getServiceVersions().add(serviceVersion21);
		
			ServiceVersion serviceVersion22 = newServiceVersion();
			serviceVersion22.setSerVersion("1.0.1");
			service2.getServiceVersions().add(serviceVersion22);
		
			ServiceRequest<Service> newServiceRequest2 = new ServiceRequest<Service>(
					new ServiceHeader(), service2);
			ServiceResponse<Service> addedServiceResponse2 = registryServiceClient
					.addService(newServiceRequest2);
			Assert.assertEquals(addedServiceResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse2.getPayload());
			Assert.assertEquals(addedServiceResponse2.getPayload().getServiceVersions().size(), service2.getServiceVersions().size());
			
			service2 = addedServiceResponse2.getPayload();
			serviceVersion21 = getServiceVersion(service2.getServiceVersions(), serviceVersion21.getSerVersion());
			SubscriptionRequest subscription21 =  newSubscription(serviceVersion21, consumer);
			subscription21.setCommunicationType(ServiceCommunicationType.ESB_PROXY.toString());
			
			serviceVersion22 = getServiceVersion(service2.getServiceVersions(), serviceVersion22.getSerVersion());
			SubscriptionRequest subscription22 =  newSubscription(serviceVersion22, consumer);
			subscription22.setCommunicationType(ServiceCommunicationType.DIRECT.toString());
			
			ServiceRequest<SubscriptionRequest> addSubscriptionsRequest21 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription21);
			ServiceResponse<Subscription> addSubscriptionsResp21 = consumerServiceClient.addSubscription(consumer.getConsumerId(), addSubscriptionsRequest21);
			Assert.assertEquals(addSubscriptionsResp21.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp21.getPayload());

			ServiceRequest<SubscriptionRequest> addSubscriptionsRequest22 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription22);
			ServiceResponse<Subscription> addSubscriptionsResp22 = consumerServiceClient.addSubscription(consumer.getConsumerId(), addSubscriptionsRequest22);
			Assert.assertEquals(addSubscriptionsResp22.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp22.getPayload());
			
			ServiceSearchBean search = new ServiceSearchBean();
			search.setConsumerId(consumer.getConsumerId());
			search.setCommunicationType(ServiceCommunicationType.ESB_PROXY.toString());
			search.setEnvironment(EnvironmentType.QA.toString());
			
			ServiceResponse<ServiceList> searchServiceResp = registryServiceClient.searchServices(search);
			Assert.assertEquals(searchServiceResp.getStatus(), Status.OK);
			Assert.assertNotNull(searchServiceResp.getPayload());
			Assert.assertEquals(searchServiceResp.getPayload().getServices().size(), 1);
			service1 = getServiceById(searchServiceResp.getPayload().getServices(), service1.getId());
			Assert.assertNotNull(service1);
			
			Assert.assertNotNull(getServiceVersion(service1.getServiceVersions(), serviceVersion11.getSerVersion()));
			Assert.assertNull(getServiceVersion(service1.getServiceVersions(), serviceVersion12.getSerVersion()));
					
			service2 = getServiceById(searchServiceResp.getPayload().getServices(), service2.getId());
			Assert.assertNull(service2);
			
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testSearchSubscriptionByServiceNameAndEnv() throws Exception {
		try {
			Consumer consumer1 = newConsumer();
			ServiceRequest<Consumer> newConsumerRequest1 = new ServiceRequest<Consumer>(new ServiceHeader(), consumer1);
			ServiceResponse<Consumer> addedConsumerResponse1 = consumerServiceClient.addConsumer(newConsumerRequest1);
			Assert.assertEquals(addedConsumerResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedConsumerResponse1.getPayload());
			Assert.assertEquals(addedConsumerResponse1.getPayload().getConsumerId(), consumer1.getConsumerId());
			
			consumer1 = addedConsumerResponse1.getPayload();
			
			Service service1 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceVersion serviceVersion11 = newServiceVersion();
			serviceVersion11.setSerVersion("1.0.0");
			service1.getServiceVersions().add(serviceVersion11);
		
			ServiceVersion serviceVersion12 = newServiceVersion();
			serviceVersion12.setSerVersion("1.0.1");
			service1.getServiceVersions().add(serviceVersion12);
		
			ServiceRequest<Service> newServiceRequest1 = new ServiceRequest<Service>(new ServiceHeader(), service1);
			ServiceResponse<Service> addedServiceResponse1 = registryServiceClient.addService(newServiceRequest1);
			Assert.assertEquals(addedServiceResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse1.getPayload());
			Assert.assertEquals(addedServiceResponse1.getPayload().getServiceVersions().size(), service1.getServiceVersions().size());
			
			service1 = addedServiceResponse1.getPayload();
			serviceVersion11 = getServiceVersion(service1.getServiceVersions(), serviceVersion11.getSerVersion());
			SubscriptionRequest subscription11 =  newSubscription(serviceVersion11, consumer1);
			subscription11.setCommunicationType(ServiceCommunicationType.ESB_PROXY.toString());
			
			serviceVersion12 = getServiceVersion(service1.getServiceVersions(), serviceVersion12.getSerVersion());
			SubscriptionRequest subscription12 =  newSubscription(serviceVersion12, consumer1);
			subscription12.setCommunicationType(ServiceCommunicationType.DIRECT.toString());
		
			ServiceRequest<SubscriptionRequest> addSubscriptionsRequest1 = new ServiceRequest<SubscriptionRequest>(	new ServiceHeader(), subscription11);
			ServiceResponse<Subscription> addSubscriptionsResp1 = consumerServiceClient.addSubscription(consumer1.getConsumerId(), addSubscriptionsRequest1);
			Assert.assertEquals(addSubscriptionsResp1.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp1.getPayload());
			
			ServiceRequest<SubscriptionRequest> addSubscriptionsRequest2 = new ServiceRequest<SubscriptionRequest>(new ServiceHeader(), subscription12);
			ServiceResponse<Subscription> addSubscriptionsResp2 = consumerServiceClient.addSubscription(consumer1.getConsumerId(), addSubscriptionsRequest2);
			Assert.assertEquals(addSubscriptionsResp2.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp2.getPayload());
			
			//Add more subscriptions
			Service service2 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceVersion serviceVersion21 = newServiceVersion();
			serviceVersion21.setSerVersion("1.0.0");
			service2.getServiceVersions().add(serviceVersion21);
		
			ServiceVersion serviceVersion22 = newServiceVersion();
			serviceVersion22.setSerVersion("1.0.1");
			service2.getServiceVersions().add(serviceVersion22);
		
			ServiceRequest<Service> newServiceRequest2 = new ServiceRequest<Service>(new ServiceHeader(), service2);
			ServiceResponse<Service> addedServiceResponse2 = registryServiceClient.addService(newServiceRequest2);
			Assert.assertEquals(addedServiceResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse2.getPayload());
			Assert.assertEquals(addedServiceResponse2.getPayload().getServiceVersions().size(), service2.getServiceVersions().size());
			
			service2 = addedServiceResponse2.getPayload();
			serviceVersion21 = getServiceVersion(service2.getServiceVersions(), serviceVersion21.getSerVersion());
			SubscriptionRequest subscription21 =  newSubscription(serviceVersion21, consumer1);
			subscription21.setCommunicationType(ServiceCommunicationType.ESB_PROXY.toString());
			
			serviceVersion22 = getServiceVersion(service2.getServiceVersions(), serviceVersion22.getSerVersion());
			SubscriptionRequest subscription22 =  newSubscription(serviceVersion22, consumer1);
			subscription22.setCommunicationType(ServiceCommunicationType.DIRECT.toString());
			
			ServiceRequest<SubscriptionRequest> addSubscriptionsRequest21 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription21);
			ServiceResponse<Subscription> addSubscriptionsResp21 = consumerServiceClient.addSubscription(consumer1.getConsumerId(), addSubscriptionsRequest21);
			Assert.assertEquals(addSubscriptionsResp21.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp21.getPayload());
	
			ServiceRequest<SubscriptionRequest> addSubscriptionsRequest22 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription22);
			ServiceResponse<Subscription> addSubscriptionsResp22 = consumerServiceClient.addSubscription(consumer1.getConsumerId(), addSubscriptionsRequest22);
			Assert.assertEquals(addSubscriptionsResp22.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp22.getPayload());
			
			
			//Consumer2
			Consumer consumer2 = newConsumer();
			
			ServiceRequest<Consumer> newConsumerRequest2 = new ServiceRequest<Consumer>(new ServiceHeader(), consumer2);
			ServiceResponse<Consumer> addedConsumerResponse2 = consumerServiceClient.addConsumer(newConsumerRequest2);
			Assert.assertEquals(addedConsumerResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedConsumerResponse2.getPayload());
			Assert.assertEquals(addedConsumerResponse2.getPayload().getConsumerId(), consumer2.getConsumerId());
			
			consumer2 = addedConsumerResponse2.getPayload();
			
			Service service3 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceVersion serviceVersion31 = newServiceVersion();
			serviceVersion31.setSerVersion("1.0.0");
			service3.getServiceVersions().add(serviceVersion31);
		
			ServiceRequest<Service> newServiceRequest3 = new ServiceRequest<Service>(new ServiceHeader(), service3);
			ServiceResponse<Service> addedServiceResponse3 = registryServiceClient.addService(newServiceRequest3);
			Assert.assertEquals(addedServiceResponse3.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse3.getPayload());
			Assert.assertEquals(addedServiceResponse3.getPayload().getServiceVersions().size(), service3.getServiceVersions().size());
			
			service3 = addedServiceResponse3.getPayload();
			serviceVersion31 = getServiceVersion(service3.getServiceVersions(), serviceVersion31.getSerVersion());
			SubscriptionRequest subscription31 =  newSubscription(serviceVersion31, consumer2);
			
			ServiceRequest<SubscriptionRequest> addSubscriptionsRequest3 = new ServiceRequest<SubscriptionRequest>(new ServiceHeader(), subscription31);
			ServiceResponse<Subscription> addSubscriptionsResp3 = consumerServiceClient.addSubscription(consumer2.getConsumerId(), addSubscriptionsRequest3);
			Assert.assertEquals(addSubscriptionsResp3.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp3.getPayload());
			
			//
			ServiceSearchBean search = new ServiceSearchBean();
			search.setName(TEST_SERVICE_NAME);
			search.setEnvironment("DEFAULT");
			ServiceResponse<SubscriptionList> searchSubscriptionsResp = consumerServiceClient.searchSubscriptions(search);
			System.out.println("SearchSubscriptionResponse:: " + searchSubscriptionsResp );
			
			Assert.assertEquals(searchSubscriptionsResp.getStatus(), Status.OK);
			Assert.assertNotNull(searchSubscriptionsResp.getPayload());
			Assert.assertFalse(searchSubscriptionsResp.getPayload().getSubscriptions().isEmpty());
		
			subscription11 = getSubscriptionByServiceVersionId(searchSubscriptionsResp.getPayload().getSubscriptions(), serviceVersion11.getId());
			Assert.assertNotNull(subscription11);
					
			subscription12 = getSubscriptionByServiceVersionId(searchSubscriptionsResp.getPayload().getSubscriptions(), serviceVersion12.getId());
			Assert.assertNotNull(subscription12);
				
			subscription21 = getSubscriptionByServiceVersionId(searchSubscriptionsResp.getPayload().getSubscriptions(), serviceVersion21.getId());
			Assert.assertNotNull(subscription21);
					
			subscription22 = getSubscriptionByServiceVersionId(searchSubscriptionsResp.getPayload().getSubscriptions(), serviceVersion22.getId());
			Assert.assertNotNull(subscription22);
	
			subscription31 = getSubscriptionByServiceVersionId(searchSubscriptionsResp.getPayload().getSubscriptions(), serviceVersion31.getId());
			Assert.assertNotNull(subscription31);
		
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testSearchServiceVersionsVersionNumber() throws Exception {
		try {
			Consumer consumer = newConsumer();
			
			ServiceRequest<Consumer> newConsumerRequest = new ServiceRequest<Consumer>(
					new ServiceHeader(), consumer);
			ServiceResponse<Consumer> addedConsumerResponse = consumerServiceClient
					.addConsumer(newConsumerRequest);
			Assert.assertEquals(addedConsumerResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedConsumerResponse.getPayload());
			Assert.assertEquals(addedConsumerResponse.getPayload().getConsumerId(), consumer.getConsumerId());
			
			consumer = addedConsumerResponse.getPayload();
			
			Service service1 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceVersion serviceVersion11 = newServiceVersion();
			serviceVersion11.setSerVersion("1.0.0");
			service1.getServiceVersions().add(serviceVersion11);
			service1.setEnvironment(EnvironmentType.QA.toString());
		
			ServiceVersion serviceVersion12 = newServiceVersion();
			serviceVersion12.setSerVersion("1.0.1");
			service1.getServiceVersions().add(serviceVersion12);
		
			ServiceRequest<Service> newServiceRequest1 = new ServiceRequest<Service>(
					new ServiceHeader(), service1);
			ServiceResponse<Service> addedServiceResponse1 = registryServiceClient
					.addService(newServiceRequest1);
			Assert.assertEquals(addedServiceResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse1.getPayload());
			Assert.assertEquals(addedServiceResponse1.getPayload().getServiceVersions().size(), service1.getServiceVersions().size());
			
			service1 = addedServiceResponse1.getPayload();
			serviceVersion11 = getServiceVersion(service1.getServiceVersions(), serviceVersion11.getSerVersion());
			SubscriptionRequest subscription11 =  newSubscription(serviceVersion11, consumer);
			subscription11.setCommunicationType(ServiceCommunicationType.ESB_PROXY.toString());
			
			serviceVersion12 = getServiceVersion(service1.getServiceVersions(), serviceVersion12.getSerVersion());
			SubscriptionRequest subscription12 =  newSubscription(serviceVersion12, consumer);
			subscription12.setCommunicationType(ServiceCommunicationType.DIRECT.toString());
			
			ServiceRequest<SubscriptionRequest> addSubscriptionsRequest1 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription11);
			ServiceResponse<Subscription> addSubscriptionsResp1 = consumerServiceClient.addSubscription(consumer.getConsumerId(), addSubscriptionsRequest1);
			Assert.assertEquals(addSubscriptionsResp1.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp1.getPayload());
			
			ServiceRequest<SubscriptionRequest> addSubscriptionsRequest2 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription12);
			ServiceResponse<Subscription> addSubscriptionsResp2 = consumerServiceClient.addSubscription(consumer.getConsumerId(), addSubscriptionsRequest2);
			Assert.assertEquals(addSubscriptionsResp2.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp2.getPayload());
		
			//Add more subscriptions
			Service service2 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			service2.setEnvironment(EnvironmentType.BUILD.toString());
			ServiceVersion serviceVersion21 = newServiceVersion();
			serviceVersion21.setSerVersion("1.0.0");
			service2.getServiceVersions().add(serviceVersion21);
		
			ServiceVersion serviceVersion22 = newServiceVersion();
			serviceVersion22.setSerVersion("1.0.1");
			service2.getServiceVersions().add(serviceVersion22);
		
			ServiceRequest<Service> newServiceRequest2 = new ServiceRequest<Service>(
					new ServiceHeader(), service2);
			ServiceResponse<Service> addedServiceResponse2 = registryServiceClient
					.addService(newServiceRequest2);
			Assert.assertEquals(addedServiceResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse2.getPayload());
			Assert.assertEquals(addedServiceResponse2.getPayload().getServiceVersions().size(), service2.getServiceVersions().size());
			
			service2 = addedServiceResponse2.getPayload();
			serviceVersion21 = getServiceVersion(service2.getServiceVersions(), serviceVersion21.getSerVersion());
			SubscriptionRequest subscription21 =  newSubscription(serviceVersion21, consumer);
			subscription21.setCommunicationType(ServiceCommunicationType.ESB_PROXY.toString());
			
			serviceVersion22 = getServiceVersion(service2.getServiceVersions(), serviceVersion22.getSerVersion());
			SubscriptionRequest subscription22 =  newSubscription(serviceVersion22, consumer);
			subscription22.setCommunicationType(ServiceCommunicationType.DIRECT.toString());
			
			ServiceRequest<SubscriptionRequest> addSubscriptionsRequest21 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription21);
			ServiceResponse<Subscription> addSubscriptionsResp21 = consumerServiceClient.addSubscription(consumer.getConsumerId(), addSubscriptionsRequest21);
			Assert.assertEquals(addSubscriptionsResp21.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp21.getPayload());

			ServiceRequest<SubscriptionRequest> addSubscriptionsRequest22 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription22);
			ServiceResponse<Subscription> addSubscriptionsResp22 = consumerServiceClient.addSubscription(consumer.getConsumerId(), addSubscriptionsRequest22);
			Assert.assertEquals(addSubscriptionsResp22.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp22.getPayload());
			
			ServiceSearchBean search = new ServiceSearchBean();
			search.setSerVersion("1.0.0");
			
			ServiceResponse<ServiceList> searchServiceResp = registryServiceClient.searchServices(search);
			Assert.assertEquals(searchServiceResp.getStatus(), Status.OK);
			Assert.assertNotNull(searchServiceResp.getPayload());
			Assert.assertFalse(searchServiceResp.getPayload().getServices().isEmpty());
			service1 = getServiceById(searchServiceResp.getPayload().getServices(), service1.getId());
			Assert.assertNotNull(service1);
			
			Assert.assertNotNull(getServiceVersion(service1.getServiceVersions(), serviceVersion11.getSerVersion()));
			Assert.assertNull(getServiceVersion(service1.getServiceVersions(), serviceVersion12.getSerVersion()));
					
			service2 = getServiceById(searchServiceResp.getPayload().getServices(), service2.getId());
			Assert.assertNotNull(service2);
			Assert.assertNotNull(getServiceVersion(service2.getServiceVersions(), serviceVersion21.getSerVersion()));
			Assert.assertNull(getServiceVersion(service2.getServiceVersions(), serviceVersion22.getSerVersion()));
			
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testSearchServiceVersionsVersionNumberAndEnvironment() throws Exception {
		try {
			Consumer consumer = newConsumer();
			
			ServiceRequest<Consumer> newConsumerRequest = new ServiceRequest<Consumer>(
					new ServiceHeader(), consumer);
			ServiceResponse<Consumer> addedConsumerResponse = consumerServiceClient
					.addConsumer(newConsumerRequest);
			Assert.assertEquals(addedConsumerResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedConsumerResponse.getPayload());
			Assert.assertEquals(addedConsumerResponse.getPayload().getConsumerId(), consumer.getConsumerId());
			
			consumer = addedConsumerResponse.getPayload();
			
			Service service1 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceVersion serviceVersion11 = newServiceVersion();
			serviceVersion11.setSerVersion("1.0.0");
			service1.getServiceVersions().add(serviceVersion11);
			service1.setEnvironment(EnvironmentType.QA.toString());
		
			ServiceVersion serviceVersion12 = newServiceVersion();
			serviceVersion12.setSerVersion("1.0.1");
			service1.getServiceVersions().add(serviceVersion12);
		
			ServiceRequest<Service> newServiceRequest1 = new ServiceRequest<Service>(
					new ServiceHeader(), service1);
			ServiceResponse<Service> addedServiceResponse1 = registryServiceClient
					.addService(newServiceRequest1);
			Assert.assertEquals(addedServiceResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse1.getPayload());
			Assert.assertEquals(addedServiceResponse1.getPayload().getServiceVersions().size(), service1.getServiceVersions().size());
			
			service1 = addedServiceResponse1.getPayload();
			serviceVersion11 = getServiceVersion(service1.getServiceVersions(), serviceVersion11.getSerVersion());
			SubscriptionRequest subscription11 =  newSubscription(serviceVersion11, consumer);
			subscription11.setCommunicationType(ServiceCommunicationType.ESB_PROXY.toString());
			
			serviceVersion12 = getServiceVersion(service1.getServiceVersions(), serviceVersion12.getSerVersion());
			SubscriptionRequest subscription12 =  newSubscription(serviceVersion12, consumer);
			subscription12.setCommunicationType(ServiceCommunicationType.DIRECT.toString());
			
			ServiceRequest<SubscriptionRequest> addSubscriptionsRequest1 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription11);
			ServiceResponse<Subscription> addSubscriptionsResp1 = consumerServiceClient.addSubscription(consumer.getConsumerId(), addSubscriptionsRequest1);
			Assert.assertEquals(addSubscriptionsResp1.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp1.getPayload());
			
			ServiceRequest<SubscriptionRequest> addSubscriptionsRequest2 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription12);
			ServiceResponse<Subscription> addSubscriptionsResp2 = consumerServiceClient.addSubscription(consumer.getConsumerId(), addSubscriptionsRequest2);
			Assert.assertEquals(addSubscriptionsResp2.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp2.getPayload());
		
			//Add more subscriptions
			Service service2 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			service2.setEnvironment(EnvironmentType.BUILD.toString());
			ServiceVersion serviceVersion21 = newServiceVersion();
			serviceVersion21.setSerVersion("1.0.0");
			service2.getServiceVersions().add(serviceVersion21);
		
			ServiceVersion serviceVersion22 = newServiceVersion();
			serviceVersion22.setSerVersion("1.0.1");
			service2.getServiceVersions().add(serviceVersion22);
		
			ServiceRequest<Service> newServiceRequest2 = new ServiceRequest<Service>(
					new ServiceHeader(), service2);
			ServiceResponse<Service> addedServiceResponse2 = registryServiceClient
					.addService(newServiceRequest2);
			Assert.assertEquals(addedServiceResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse2.getPayload());
			Assert.assertEquals(addedServiceResponse2.getPayload().getServiceVersions().size(), service2.getServiceVersions().size());
			
			service2 = addedServiceResponse2.getPayload();
			serviceVersion21 = getServiceVersion(service2.getServiceVersions(), serviceVersion21.getSerVersion());
			SubscriptionRequest subscription21 =  newSubscription(serviceVersion21, consumer);
			subscription21.setCommunicationType(ServiceCommunicationType.ESB_PROXY.toString());
			
			serviceVersion22 = getServiceVersion(service2.getServiceVersions(), serviceVersion22.getSerVersion());
			SubscriptionRequest subscription22 =  newSubscription(serviceVersion22, consumer);
			subscription22.setCommunicationType(ServiceCommunicationType.DIRECT.toString());
			
			ServiceRequest<SubscriptionRequest> addSubscriptionsRequest21 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription21);
			ServiceResponse<Subscription> addSubscriptionsResp21 = consumerServiceClient.addSubscription(consumer.getConsumerId(), addSubscriptionsRequest21);
			Assert.assertEquals(addSubscriptionsResp21.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp21.getPayload());

			ServiceRequest<SubscriptionRequest> addSubscriptionsRequest22 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription22);
			ServiceResponse<Subscription> addSubscriptionsResp22 = consumerServiceClient.addSubscription(consumer.getConsumerId(), addSubscriptionsRequest22);
			Assert.assertEquals(addSubscriptionsResp22.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp22.getPayload());
			
			ServiceSearchBean search = new ServiceSearchBean();
			search.setSerVersion("1.0.0");
			search.setEnvironment(EnvironmentType.QA.toString());
			long st = System.currentTimeMillis();
			ServiceResponse<ServiceList> searchServiceResp = registryServiceClient.searchServices(search);
			long et = System.currentTimeMillis();
			
			System.out.println("SearchServiceResponse:: time taken = " + (et-st) + "Response == " + searchServiceResp);
			
			Assert.assertEquals(searchServiceResp.getStatus(), Status.OK);
			Assert.assertNotNull(searchServiceResp.getPayload());
			Assert.assertFalse(searchServiceResp.getPayload().getServices().isEmpty());
			service1 = getServiceById(searchServiceResp.getPayload().getServices(), service1.getId());
			Assert.assertNotNull(service1);
			
			Assert.assertNotNull(getServiceVersion(service1.getServiceVersions(), serviceVersion11.getSerVersion()));
			Assert.assertNull(getServiceVersion(service1.getServiceVersions(), serviceVersion12.getSerVersion()));
					
			service2 = getServiceById(searchServiceResp.getPayload().getServices(), service2.getId());
			Assert.assertNull(service2);
			
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testSearchSubscriptionByCommunicationType() throws Exception {
		try {
			Consumer consumer1 = newConsumer();
			
			ServiceRequest<Consumer> newConsumerRequest1 = new ServiceRequest<Consumer>(
					new ServiceHeader(), consumer1);
			ServiceResponse<Consumer> addedConsumerResponse1 = consumerServiceClient
					.addConsumer(newConsumerRequest1);
			Assert.assertEquals(addedConsumerResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedConsumerResponse1.getPayload());
			Assert.assertEquals(addedConsumerResponse1.getPayload().getConsumerId(), consumer1.getConsumerId());
			
			consumer1 = addedConsumerResponse1.getPayload();
			
			Service service1 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceVersion serviceVersion11 = newServiceVersion();
			serviceVersion11.setSerVersion("1.0.0");
			service1.getServiceVersions().add(serviceVersion11);
		
			ServiceVersion serviceVersion12 = newServiceVersion();
			serviceVersion12.setSerVersion("1.0.1");
			service1.getServiceVersions().add(serviceVersion12);
		
			ServiceRequest<Service> newServiceRequest1 = new ServiceRequest<Service>(
					new ServiceHeader(), service1);
			ServiceResponse<Service> addedServiceResponse1 = registryServiceClient
					.addService(newServiceRequest1);
			Assert.assertEquals(addedServiceResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse1.getPayload());
			Assert.assertEquals(addedServiceResponse1.getPayload().getServiceVersions().size(), service1.getServiceVersions().size());
			
			service1 = addedServiceResponse1.getPayload();
			serviceVersion11 = getServiceVersion(service1.getServiceVersions(), serviceVersion11.getSerVersion());
			SubscriptionRequest subscription11 =  newSubscription(serviceVersion11, consumer1);
			subscription11.setCommunicationType(ServiceCommunicationType.ESB_PROXY.toString());
			
			serviceVersion12 = getServiceVersion(service1.getServiceVersions(), serviceVersion12.getSerVersion());
			SubscriptionRequest subscription12 =  newSubscription(serviceVersion12, consumer1);
			subscription12.setCommunicationType(ServiceCommunicationType.DIRECT.toString());
		
			ServiceRequest<SubscriptionRequest> addSubscriptionsRequest1 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription11);
			ServiceResponse<Subscription> addSubscriptionsResp1 = consumerServiceClient.addSubscription(consumer1.getConsumerId(), addSubscriptionsRequest1);
			Assert.assertEquals(addSubscriptionsResp1.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp1.getPayload());
			
			ServiceRequest<SubscriptionRequest> addSubscriptionsRequest2 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription12);
			ServiceResponse<Subscription> addSubscriptionsResp2 = consumerServiceClient.addSubscription(consumer1.getConsumerId(), addSubscriptionsRequest2);
			Assert.assertEquals(addSubscriptionsResp2.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp2.getPayload());
			
			//Add more subscriptions
			Service service2 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceVersion serviceVersion21 = newServiceVersion();
			serviceVersion21.setSerVersion("1.0.0");
			service2.getServiceVersions().add(serviceVersion21);
		
			ServiceVersion serviceVersion22 = newServiceVersion();
			serviceVersion22.setSerVersion("1.0.1");
			service2.getServiceVersions().add(serviceVersion22);
		
			ServiceRequest<Service> newServiceRequest2 = new ServiceRequest<Service>(
					new ServiceHeader(), service2);
			ServiceResponse<Service> addedServiceResponse2 = registryServiceClient
					.addService(newServiceRequest2);
			Assert.assertEquals(addedServiceResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse2.getPayload());
			Assert.assertEquals(addedServiceResponse2.getPayload().getServiceVersions().size(), service2.getServiceVersions().size());
			
			service2 = addedServiceResponse2.getPayload();
			serviceVersion21 = getServiceVersion(service2.getServiceVersions(), serviceVersion21.getSerVersion());
			SubscriptionRequest subscription21 =  newSubscription(serviceVersion21, consumer1);
			subscription21.setCommunicationType(ServiceCommunicationType.ESB_PROXY.toString());
			
			serviceVersion22 = getServiceVersion(service2.getServiceVersions(), serviceVersion22.getSerVersion());
			SubscriptionRequest subscription22 =  newSubscription(serviceVersion22, consumer1);
			subscription22.setCommunicationType(ServiceCommunicationType.DIRECT.toString());
			
			ServiceRequest<SubscriptionRequest> addSubscriptionsRequest21 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription21);
			ServiceResponse<Subscription> addSubscriptionsResp21 = consumerServiceClient.addSubscription(consumer1.getConsumerId(), addSubscriptionsRequest21);
			Assert.assertEquals(addSubscriptionsResp21.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp21.getPayload());

			ServiceRequest<SubscriptionRequest> addSubscriptionsRequest22 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription22);
			ServiceResponse<Subscription> addSubscriptionsResp22 = consumerServiceClient.addSubscription(consumer1.getConsumerId(), addSubscriptionsRequest22);
			Assert.assertEquals(addSubscriptionsResp22.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp22.getPayload());
			
			
			//Consumer2
			Consumer consumer2 = newConsumer();
			
			ServiceRequest<Consumer> newConsumerRequest2 = new ServiceRequest<Consumer>(
					new ServiceHeader(), consumer2);
			ServiceResponse<Consumer> addedConsumerResponse2 = consumerServiceClient
					.addConsumer(newConsumerRequest2);
			Assert.assertEquals(addedConsumerResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedConsumerResponse2.getPayload());
			Assert.assertEquals(addedConsumerResponse2.getPayload().getConsumerId(), consumer2.getConsumerId());
			
			consumer2 = addedConsumerResponse2.getPayload();
			
			Service service3 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceVersion serviceVersion31 = newServiceVersion();
			serviceVersion31.setSerVersion("1.0.0");
			service3.getServiceVersions().add(serviceVersion31);
		
			ServiceRequest<Service> newServiceRequest3 = new ServiceRequest<Service>(
					new ServiceHeader(), service3);
			ServiceResponse<Service> addedServiceResponse3 = registryServiceClient
					.addService(newServiceRequest3);
			Assert.assertEquals(addedServiceResponse3.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse3.getPayload());
			Assert.assertEquals(addedServiceResponse3.getPayload().getServiceVersions().size(), service3.getServiceVersions().size());
			
			service3 = addedServiceResponse3.getPayload();
			serviceVersion31 = getServiceVersion(service3.getServiceVersions(), serviceVersion31.getSerVersion());
			SubscriptionRequest subscription31 =  newSubscription(serviceVersion31, consumer2);
			
			ServiceRequest<SubscriptionRequest> addSubscriptionsRequest3 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription31);
			ServiceResponse<Subscription> addSubscriptionsResp3 = consumerServiceClient.addSubscription(consumer2.getConsumerId(), addSubscriptionsRequest3);
			Assert.assertEquals(addSubscriptionsResp3.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp3.getPayload());
			
			//
			ServiceSearchBean search = new ServiceSearchBean();
			search.setCommunicationType(ServiceCommunicationType.ESB_PROXY.toString());
			
			ServiceResponse<SubscriptionList> searchSubscriptionsResp = consumerServiceClient.searchSubscriptions(search);
			
			Assert.assertEquals(searchSubscriptionsResp.getStatus(), Status.OK);
			Assert.assertNotNull(searchSubscriptionsResp.getPayload());
			Assert.assertFalse(searchSubscriptionsResp.getPayload().getSubscriptions().isEmpty());
		
			subscription11 = getSubscriptionByServiceVersionId(searchSubscriptionsResp.getPayload().getSubscriptions(), serviceVersion11.getId());
			Assert.assertNotNull(subscription11);
					
			subscription12 = getSubscriptionByServiceVersionId(searchSubscriptionsResp.getPayload().getSubscriptions(), serviceVersion12.getId());
			Assert.assertNull(subscription12);
				
			subscription21 = getSubscriptionByServiceVersionId(searchSubscriptionsResp.getPayload().getSubscriptions(), serviceVersion21.getId());
			Assert.assertNotNull(subscription21);
					
			subscription22 = getSubscriptionByServiceVersionId(searchSubscriptionsResp.getPayload().getSubscriptions(), serviceVersion22.getId());
			Assert.assertNull(subscription22);

			subscription31 = getSubscriptionByServiceVersionId(searchSubscriptionsResp.getPayload().getSubscriptions(), serviceVersion31.getId());
			Assert.assertNotNull(subscription31);
		
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testSearchSubscriptionByConsumerIdCommunicationType() throws Exception {
		try {
			Consumer consumer1 = newConsumer();
			
			ServiceRequest<Consumer> newConsumerRequest1 = new ServiceRequest<Consumer>(
					new ServiceHeader(), consumer1);
			ServiceResponse<Consumer> addedConsumerResponse1 = consumerServiceClient
					.addConsumer(newConsumerRequest1);
			Assert.assertEquals(addedConsumerResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedConsumerResponse1.getPayload());
			Assert.assertEquals(addedConsumerResponse1.getPayload().getConsumerId(), consumer1.getConsumerId());
			
			consumer1 = addedConsumerResponse1.getPayload();
			
			Service service1 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceVersion serviceVersion11 = newServiceVersion();
			serviceVersion11.setSerVersion("1.0.0");
			service1.getServiceVersions().add(serviceVersion11);
		
			ServiceVersion serviceVersion12 = newServiceVersion();
			serviceVersion12.setSerVersion("1.0.1");
			service1.getServiceVersions().add(serviceVersion12);
		
			ServiceRequest<Service> newServiceRequest1 = new ServiceRequest<Service>(
					new ServiceHeader(), service1);
			ServiceResponse<Service> addedServiceResponse1 = registryServiceClient
					.addService(newServiceRequest1);
			Assert.assertEquals(addedServiceResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse1.getPayload());
			Assert.assertEquals(addedServiceResponse1.getPayload().getServiceVersions().size(), service1.getServiceVersions().size());
			
			service1 = addedServiceResponse1.getPayload();
			serviceVersion11 = getServiceVersion(service1.getServiceVersions(), serviceVersion11.getSerVersion());
			SubscriptionRequest subscription11 =  newSubscription(serviceVersion11, consumer1);
			subscription11.setCommunicationType(ServiceCommunicationType.ESB_PROXY.toString());
			
			serviceVersion12 = getServiceVersion(service1.getServiceVersions(), serviceVersion12.getSerVersion());
			SubscriptionRequest subscription12 =  newSubscription(serviceVersion12, consumer1);
			subscription12.setCommunicationType(ServiceCommunicationType.DIRECT.toString());
		
			ServiceRequest<SubscriptionRequest> addSubscriptionsRequest1 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription11);
			ServiceResponse<Subscription> addSubscriptionsResp1 = consumerServiceClient.addSubscription(consumer1.getConsumerId(), addSubscriptionsRequest1);
			Assert.assertEquals(addSubscriptionsResp1.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp1.getPayload());
			
			ServiceRequest<SubscriptionRequest> addSubscriptionsRequest2 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription12);
			ServiceResponse<Subscription> addSubscriptionsResp2 = consumerServiceClient.addSubscription(consumer1.getConsumerId(), addSubscriptionsRequest2);
			Assert.assertEquals(addSubscriptionsResp2.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp2.getPayload());
			
			//Add more subscriptions
			Service service2 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceVersion serviceVersion21 = newServiceVersion();
			serviceVersion21.setSerVersion("1.0.0");
			service2.getServiceVersions().add(serviceVersion21);
		
			ServiceVersion serviceVersion22 = newServiceVersion();
			serviceVersion22.setSerVersion("1.0.1");
			service2.getServiceVersions().add(serviceVersion22);
		
			ServiceRequest<Service> newServiceRequest2 = new ServiceRequest<Service>(
					new ServiceHeader(), service2);
			ServiceResponse<Service> addedServiceResponse2 = registryServiceClient
					.addService(newServiceRequest2);
			Assert.assertEquals(addedServiceResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse2.getPayload());
			Assert.assertEquals(addedServiceResponse2.getPayload().getServiceVersions().size(), service2.getServiceVersions().size());
			
			service2 = addedServiceResponse2.getPayload();
			serviceVersion21 = getServiceVersion(service2.getServiceVersions(), serviceVersion21.getSerVersion());
			SubscriptionRequest subscription21 =  newSubscription(serviceVersion21, consumer1);
			subscription21.setCommunicationType(ServiceCommunicationType.ESB_PROXY.toString());
			
			serviceVersion22 = getServiceVersion(service2.getServiceVersions(), serviceVersion22.getSerVersion());
			SubscriptionRequest subscription22 =  newSubscription(serviceVersion22, consumer1);
			subscription22.setCommunicationType(ServiceCommunicationType.DIRECT.toString());
			
			ServiceRequest<SubscriptionRequest> addSubscriptionsRequest21 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription21);
			ServiceResponse<Subscription> addSubscriptionsResp21 = consumerServiceClient.addSubscription(consumer1.getConsumerId(), addSubscriptionsRequest21);
			Assert.assertEquals(addSubscriptionsResp21.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp21.getPayload());

			ServiceRequest<SubscriptionRequest> addSubscriptionsRequest22 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription22);
			ServiceResponse<Subscription> addSubscriptionsResp22 = consumerServiceClient.addSubscription(consumer1.getConsumerId(), addSubscriptionsRequest22);
			Assert.assertEquals(addSubscriptionsResp22.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp22.getPayload());
			
			
			//Consumer2
			Consumer consumer2 = newConsumer();
			
			ServiceRequest<Consumer> newConsumerRequest2 = new ServiceRequest<Consumer>(
					new ServiceHeader(), consumer2);
			ServiceResponse<Consumer> addedConsumerResponse2 = consumerServiceClient
					.addConsumer(newConsumerRequest2);
			Assert.assertEquals(addedConsumerResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedConsumerResponse2.getPayload());
			Assert.assertEquals(addedConsumerResponse2.getPayload().getConsumerId(), consumer2.getConsumerId());
			
			consumer2 = addedConsumerResponse2.getPayload();
			
			Service service3 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceVersion serviceVersion31 = newServiceVersion();
			serviceVersion31.setSerVersion("1.0.0");
			service3.getServiceVersions().add(serviceVersion31);
		
			ServiceRequest<Service> newServiceRequest3 = new ServiceRequest<Service>(
					new ServiceHeader(), service3);
			ServiceResponse<Service> addedServiceResponse3 = registryServiceClient
					.addService(newServiceRequest3);
			Assert.assertEquals(addedServiceResponse3.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse3.getPayload());
			Assert.assertEquals(addedServiceResponse3.getPayload().getServiceVersions().size(), service3.getServiceVersions().size());
			
			service3 = addedServiceResponse3.getPayload();
			serviceVersion31 = getServiceVersion(service3.getServiceVersions(), serviceVersion31.getSerVersion());
			SubscriptionRequest subscription31 =  newSubscription(serviceVersion31, consumer2);
			
			ServiceRequest<SubscriptionRequest> addSubscriptionsRequest3 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription31);
			ServiceResponse<Subscription> addSubscriptionsResp3 = consumerServiceClient.addSubscription(consumer2.getConsumerId(), addSubscriptionsRequest3);
			Assert.assertEquals(addSubscriptionsResp3.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp3.getPayload());
			
			//
			ServiceSearchBean search = new ServiceSearchBean();
			search.setCommunicationType(ServiceCommunicationType.ESB_PROXY.toString());
			search.setConsumerId(consumer1.getConsumerId());
			
			ServiceResponse<SubscriptionList> searchSubscriptionsResp = consumerServiceClient.searchSubscriptions(search);
			
			Assert.assertEquals(searchSubscriptionsResp.getStatus(), Status.OK);
			Assert.assertNotNull(searchSubscriptionsResp.getPayload());
			Assert.assertFalse(searchSubscriptionsResp.getPayload().getSubscriptions().isEmpty());
		
			subscription11 = getSubscriptionByServiceVersionId(searchSubscriptionsResp.getPayload().getSubscriptions(), serviceVersion11.getId());
			Assert.assertNotNull(subscription11);
					
			subscription12 = getSubscriptionByServiceVersionId(searchSubscriptionsResp.getPayload().getSubscriptions(), serviceVersion12.getId());
			Assert.assertNull(subscription12);
				
			subscription21 = getSubscriptionByServiceVersionId(searchSubscriptionsResp.getPayload().getSubscriptions(), serviceVersion21.getId());
			Assert.assertNotNull(subscription21);
					
			subscription22 = getSubscriptionByServiceVersionId(searchSubscriptionsResp.getPayload().getSubscriptions(), serviceVersion22.getId());
			Assert.assertNull(subscription22);

			subscription31 = getSubscriptionByServiceVersionId(searchSubscriptionsResp.getPayload().getSubscriptions(), serviceVersion31.getId());
			Assert.assertNull(subscription31);
		
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testSearchSubscriptionByConsumerIdCommunicationTypeAndSubscriptionStatus() throws Exception {
		try {
			Consumer consumer1 = newConsumer();
			
			ServiceRequest<Consumer> newConsumerRequest1 = new ServiceRequest<Consumer>(
					new ServiceHeader(), consumer1);
			ServiceResponse<Consumer> addedConsumerResponse1 = consumerServiceClient
					.addConsumer(newConsumerRequest1);
			Assert.assertEquals(addedConsumerResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedConsumerResponse1.getPayload());
			Assert.assertEquals(addedConsumerResponse1.getPayload().getConsumerId(), consumer1.getConsumerId());
			
			consumer1 = addedConsumerResponse1.getPayload();
			
			Service service1 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceVersion serviceVersion11 = newServiceVersion();
			serviceVersion11.setSerVersion("1.0.0");
			service1.getServiceVersions().add(serviceVersion11);
		
			ServiceVersion serviceVersion12 = newServiceVersion();
			serviceVersion12.setSerVersion("1.0.1");
			service1.getServiceVersions().add(serviceVersion12);
		
			ServiceRequest<Service> newServiceRequest1 = new ServiceRequest<Service>(
					new ServiceHeader(), service1);
			ServiceResponse<Service> addedServiceResponse1 = registryServiceClient
					.addService(newServiceRequest1);
			Assert.assertEquals(addedServiceResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse1.getPayload());
			Assert.assertEquals(addedServiceResponse1.getPayload().getServiceVersions().size(), service1.getServiceVersions().size());
			
			service1 = addedServiceResponse1.getPayload();
			serviceVersion11 = getServiceVersion(service1.getServiceVersions(), serviceVersion11.getSerVersion());
			SubscriptionRequest subscription11 =  newSubscription(serviceVersion11, consumer1);
			subscription11.setCommunicationType(ServiceCommunicationType.ESB_PROXY.toString());
			
			serviceVersion12 = getServiceVersion(service1.getServiceVersions(), serviceVersion12.getSerVersion());
			SubscriptionRequest subscription12 =  newSubscription(serviceVersion12, consumer1);
			subscription12.setCommunicationType(ServiceCommunicationType.DIRECT.toString());
		
			ServiceRequest<SubscriptionRequest> addSubscriptionsRequest1 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription11);
			ServiceResponse<Subscription> addSubscriptionsResp1 = consumerServiceClient.addSubscription(consumer1.getConsumerId(), addSubscriptionsRequest1);
			Assert.assertEquals(addSubscriptionsResp1.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp1.getPayload());
			
			ServiceRequest<SubscriptionRequest> addSubscriptionsRequest2 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription12);
			ServiceResponse<Subscription> addSubscriptionsResp2 = consumerServiceClient.addSubscription(consumer1.getConsumerId(), addSubscriptionsRequest2);
			Assert.assertEquals(addSubscriptionsResp2.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp2.getPayload());
			
			//Add more subscriptions
			Service service2 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceVersion serviceVersion21 = newServiceVersion();
			serviceVersion21.setSerVersion("1.0.0");
			service2.getServiceVersions().add(serviceVersion21);
		
			ServiceVersion serviceVersion22 = newServiceVersion();
			serviceVersion22.setSerVersion("1.0.1");
			service2.getServiceVersions().add(serviceVersion22);
		
			ServiceRequest<Service> newServiceRequest2 = new ServiceRequest<Service>(
					new ServiceHeader(), service2);
			ServiceResponse<Service> addedServiceResponse2 = registryServiceClient
					.addService(newServiceRequest2);
			Assert.assertEquals(addedServiceResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse2.getPayload());
			Assert.assertEquals(addedServiceResponse2.getPayload().getServiceVersions().size(), service2.getServiceVersions().size());
			
			service2 = addedServiceResponse2.getPayload();
			serviceVersion21 = getServiceVersion(service2.getServiceVersions(), serviceVersion21.getSerVersion());
			SubscriptionRequest subscription21 =  newSubscription(serviceVersion21, consumer1);
			subscription21.setCommunicationType(ServiceCommunicationType.ESB_PROXY.toString());
			
			serviceVersion22 = getServiceVersion(service2.getServiceVersions(), serviceVersion22.getSerVersion());
			SubscriptionRequest subscription22 =  newSubscription(serviceVersion22, consumer1);
			subscription22.setCommunicationType(ServiceCommunicationType.DIRECT.toString());
			
			ServiceRequest<SubscriptionRequest> addSubscriptionsRequest21 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription21);
			ServiceResponse<Subscription> addSubscriptionsResp21 = consumerServiceClient.addSubscription(consumer1.getConsumerId(), addSubscriptionsRequest21);
			Assert.assertEquals(addSubscriptionsResp21.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp21.getPayload());
			
			subscription21 = addSubscriptionsResp21.getPayload();
			ServiceResponse<Subscription> activateSubscriptionResp21 = consumerServiceClient.updateSubscriptionStatus(subscription21.getId(), "ACTIVATE", TEST_MODIFIED_BY_USER);
			Assert.assertEquals(activateSubscriptionResp21.getStatus(), Status.OK);
			Assert.assertNotNull(activateSubscriptionResp21.getPayload());
			subscription21 = activateSubscriptionResp21.getPayload();
			
			ServiceRequest<SubscriptionRequest> addSubscriptionsRequest22 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription22);
			ServiceResponse<Subscription> addSubscriptionsResp22 = consumerServiceClient.addSubscription(consumer1.getConsumerId(), addSubscriptionsRequest22);
			Assert.assertEquals(addSubscriptionsResp22.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp22.getPayload());
			
			
			//Consumer2
			Consumer consumer2 = newConsumer();
			
			ServiceRequest<Consumer> newConsumerRequest2 = new ServiceRequest<Consumer>(
					new ServiceHeader(), consumer2);
			ServiceResponse<Consumer> addedConsumerResponse2 = consumerServiceClient
					.addConsumer(newConsumerRequest2);
			Assert.assertEquals(addedConsumerResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedConsumerResponse2.getPayload());
			Assert.assertEquals(addedConsumerResponse2.getPayload().getConsumerId(), consumer2.getConsumerId());
			
			consumer2 = addedConsumerResponse2.getPayload();
			
			Service service3 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceVersion serviceVersion31 = newServiceVersion();
			serviceVersion31.setSerVersion("1.0.0");
			service3.getServiceVersions().add(serviceVersion31);
		
			ServiceRequest<Service> newServiceRequest3 = new ServiceRequest<Service>(
					new ServiceHeader(), service3);
			ServiceResponse<Service> addedServiceResponse3 = registryServiceClient
					.addService(newServiceRequest3);
			Assert.assertEquals(addedServiceResponse3.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse3.getPayload());
			Assert.assertEquals(addedServiceResponse3.getPayload().getServiceVersions().size(), service3.getServiceVersions().size());
			
			service3 = addedServiceResponse3.getPayload();
			serviceVersion31 = getServiceVersion(service3.getServiceVersions(), serviceVersion31.getSerVersion());
			SubscriptionRequest subscription31 =  newSubscription(serviceVersion31, consumer2);
			
			ServiceRequest<SubscriptionRequest> addSubscriptionsRequest3 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription31);
			ServiceResponse<Subscription> addSubscriptionsResp3 = consumerServiceClient.addSubscription(consumer2.getConsumerId(), addSubscriptionsRequest3);
			Assert.assertEquals(addSubscriptionsResp3.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp3.getPayload());
			
			//
			ServiceSearchBean search = new ServiceSearchBean();
			search.setCommunicationType(ServiceCommunicationType.ESB_PROXY.toString());
			search.setConsumerId(consumer1.getConsumerId());
			search.setSubscriptonStatus("INACTIVE");
			
			ServiceResponse<SubscriptionList> searchSubscriptionsResp = consumerServiceClient.searchSubscriptions(search);
			
			Assert.assertEquals(searchSubscriptionsResp.getStatus(), Status.OK);
			Assert.assertNotNull(searchSubscriptionsResp.getPayload());
			Assert.assertFalse(searchSubscriptionsResp.getPayload().getSubscriptions().isEmpty());
		
			Subscription actual11 = getSubscriptionByServiceVersionId(searchSubscriptionsResp.getPayload().getSubscriptions(), serviceVersion11.getId());
			Assert.assertNotNull(actual11);
					
			subscription12 = getSubscriptionByServiceVersionId(searchSubscriptionsResp.getPayload().getSubscriptions(), serviceVersion12.getId());
			Assert.assertNull(subscription12);
				
			//ACTIVE subscription
			subscription21 = getSubscriptionByServiceVersionId(searchSubscriptionsResp.getPayload().getSubscriptions(), serviceVersion21.getId());
			Assert.assertNull(subscription21);
					
			subscription22 = getSubscriptionByServiceVersionId(searchSubscriptionsResp.getPayload().getSubscriptions(), serviceVersion22.getId());
			Assert.assertNull(subscription22);

			subscription31 = getSubscriptionByServiceVersionId(searchSubscriptionsResp.getPayload().getSubscriptions(), serviceVersion31.getId());
			Assert.assertNull(subscription31);
		
			Assert.assertEquals(actual11.getConsumerId(), consumer1.getConsumerId());
			Assert.assertEquals(actual11.getCommunicationType(), subscription11.getCommunicationType());
			Assert.assertEquals(actual11.getEnvironment(), service1.getEnvironment());
			Assert.assertEquals(actual11.getServiceId(), service1.getId());
			Assert.assertEquals(actual11.getServiceName(), service1.getName());
			Assert.assertEquals(actual11.getServiceVersionId(), serviceVersion11.getId());
			Assert.assertEquals(actual11.getStatus(), "INACTIVE");
			Assert.assertEquals(actual11.getVersionNumber(), serviceVersion11.getSerVersion());
		
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testGetSubscriptionWithQoSAndPolicy() throws Exception {
		try {
			
			Policy policy1 = newPolicy();
			ServiceRequest<Policy> addPolicyReq1 = new ServiceRequest<Policy>(new ServiceHeader(), policy1);
			ServiceResponse<Policy> addPolicyResp1 = policyServiceClient.addPolicy(addPolicyReq1);
			Assert.assertEquals(addPolicyResp1.getStatus(), Status.OK);
			Assert.assertNotNull(addPolicyResp1.getPayload());
			policy1 = addPolicyResp1.getPayload();
		
			Policy policy2 = newPolicy();
			ServiceRequest<Policy> addPolicyReq2 = new ServiceRequest<Policy>(new ServiceHeader(), policy2);
			ServiceResponse<Policy> addPolicyResp2 = policyServiceClient.addPolicy(addPolicyReq2);
			Assert.assertEquals(addPolicyResp2.getStatus(), Status.OK);
			Assert.assertNotNull(addPolicyResp2.getPayload());
			policy2 = addPolicyResp2.getPayload();
		
			Consumer consumer = newConsumer();
			
			ServiceRequest<Consumer> newConsumerRequest = new ServiceRequest<Consumer>(
					new ServiceHeader(), consumer);
			ServiceResponse<Consumer> addedConsumerResponse = consumerServiceClient
					.addConsumer(newConsumerRequest);
			Assert.assertEquals(addedConsumerResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedConsumerResponse.getPayload());
			Assert.assertEquals(addedConsumerResponse.getPayload().getConsumerId(), consumer.getConsumerId());
		
			QoS qos11 = addQoS();
			QoS qos22 = addQoS();
		
			consumer = addedConsumerResponse.getPayload();
			
			Service service1 = newService(cmdbArtifacts.get(artifactIndex++).getCode());service1.setOwner("sbonde@walmartlabs.com");
			ServiceVersion serviceVersion1 = newServiceVersion();
			serviceVersion1.setSerVersion("1.0.0");
			
			serviceVersion1.getPolicies().add(policy1);
			serviceVersion1.getPolicies().add(policy2);
			serviceVersion1.getQoSParameters().add(qos11);
			serviceVersion1.getQoSParameters().add(qos22);
			service1.getServiceVersions().add(serviceVersion1);
		
			ServiceVersion serviceVersion2 = newServiceVersion();
			serviceVersion2.setSerVersion("1.0.1");
			service1.getServiceVersions().add(serviceVersion2);
		
			ServiceRequest<Service> newServiceRequest = new ServiceRequest<Service>(
					new ServiceHeader(), service1);
			ServiceResponse<Service> addedServiceResponse = registryServiceClient
					.addService(newServiceRequest);
			Assert.assertEquals(addedServiceResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse.getPayload());
			Assert.assertEquals(addedServiceResponse.getPayload().getServiceVersions().size(), service1.getServiceVersions().size());
			
			service1 = addedServiceResponse.getPayload();
			serviceVersion1 = getServiceVersion(service1.getServiceVersions(), serviceVersion1.getSerVersion());
			SubscriptionRequest subscription1 =  newSubscription(serviceVersion1, consumer);
			
			
			ServiceRequest<SubscriptionRequest> addSubscriptionRequest = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription1);
			ServiceResponse<Subscription> addSubscriptionsResp = consumerServiceClient.addSubscription(consumer.getConsumerId(), addSubscriptionRequest);
			Assert.assertEquals(addSubscriptionsResp.getStatus(), Status.OK);
			Subscription sub1 = addSubscriptionsResp.getPayload();
			Assert.assertNotNull(sub1);
			Assert.assertNotNull(sub1.getQosParameters());
			Assert.assertFalse(sub1.getQosParameters().isEmpty());
			Assert.assertEquals(sub1.getQosParameters().size(), 2);
			Assert.assertFalse(StringUtils.isEmpty(sub1.getQosParameters().get(0).getValue()));
			Assert.assertFalse(StringUtils.isEmpty(sub1.getQosParameters().get(1).getValue()));
			Assert.assertNotNull(sub1.getPolicies());
			Assert.assertFalse(sub1.getPolicies().isEmpty());
			Assert.assertEquals(sub1.getPolicies().size(), 2);
		
			ServiceResponse<ConsumerList> getConsumersResp = consumerServiceClient.getConsumers();
			Assert.assertEquals(getConsumersResp.getStatus(), Status.OK);
			Assert.assertNotNull(getConsumersResp.getPayload());
			Assert.assertNotNull(getConsumersResp.getPayload().getConsumers());
			Assert.assertFalse(getConsumersResp.getPayload().getConsumers().isEmpty());
			
			consumer = getConsumer(getConsumersResp.getPayload().getConsumers(), consumer.getConsumerId());
			Assert.assertNotNull(getConsumersResp.getPayload().getConsumers());
			
			Subscription actual = getSubscriptionByServiceVersionId(consumer.getSubscriptions(), serviceVersion1.getId());
			Assert.assertNotNull(actual);
			Assert.assertEquals(actual.getConsumerId(), subscription1.getConsumerId());
			Assert.assertEquals(actual.getCommunicationType(), subscription1.getCommunicationType());
			Assert.assertEquals(actual.getEnvironment(), service1.getEnvironment());
			Assert.assertEquals(actual.getServiceId(), service1.getId());
			Assert.assertEquals(actual.getServiceName(), service1.getName());
			Assert.assertEquals(actual.getServiceVersionId(), serviceVersion1.getId());
			Assert.assertEquals(actual.getStatus(), "INACTIVE");
			Assert.assertEquals(actual.getVersionNumber(), serviceVersion1.getSerVersion());
			Assert.assertNotNull(actual.getQosParameters());
			Assert.assertFalse(actual.getQosParameters().isEmpty());
			Assert.assertEquals(actual.getQosParameters().size(), 2);
			Assert.assertFalse(StringUtils.isEmpty(actual.getQosParameters().get(0).getValue()));
			Assert.assertFalse(StringUtils.isEmpty(actual.getQosParameters().get(1).getValue()));
			Assert.assertFalse(StringUtils.isEmpty(actual.getQosParameters().get(0).getCreatedBy()));
			Assert.assertFalse(StringUtils.isEmpty(actual.getQosParameters().get(1).getCreatedBy()));
			Assert.assertNotNull(actual.getPolicies());
			Assert.assertFalse(actual.getPolicies().isEmpty());
			Assert.assertEquals(actual.getPolicies().size(), 2);
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	/*@Test(enabled = true)
	public void testAddSubscriptionJIRANotification() throws Exception {
		try {
			Consumer consumer = newConsumer();
			
			ServiceRequest<Consumer> newConsumerRequest = new ServiceRequest<Consumer>(
					new ServiceHeader(), consumer);
			ServiceResponse<Consumer> addedConsumerResponse = consumerServiceClient
					.addConsumer(newConsumerRequest);
			Assert.assertEquals(addedConsumerResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedConsumerResponse.getPayload());
			Assert.assertEquals(addedConsumerResponse.getPayload().getConsumerId(), consumer.getConsumerId());
			
			consumer = addedConsumerResponse.getPayload();
			
			//NotificationDestination notification = addJIRANotificationDestination(NotificationDestinationType.JIRA.toString());
			
			Service service1 = newService(cmdbArtifacts.get(artifactIndex++).getCode());service1.setOwner("sbonde@walmartlabs.com");
			service1.setJiraProject("PGPSOA");
			//service1.getNotificationTypes().add(notification.getName());
			service1.getNotificationTypes().add(NotificationDestinationType.JIRA.toString());
			ServiceVersion serviceVersion1 = newServiceVersion();
			serviceVersion1.setSerVersion("1.0.0");
			service1.getServiceVersions().add(serviceVersion1);
		
			ServiceVersion serviceVersion2 = newServiceVersion();
			serviceVersion2.setSerVersion("1.0.1");
			service1.getServiceVersions().add(serviceVersion2);
		
			ServiceRequest<Service> newServiceRequest = new ServiceRequest<Service>(
					new ServiceHeader(), service1);
			ServiceResponse<Service> addedServiceResponse = registryServiceClient
					.addService(newServiceRequest);
			Assert.assertEquals(addedServiceResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse.getPayload());
			Assert.assertEquals(addedServiceResponse.getPayload().getServiceVersions().size(), service1.getServiceVersions().size());
			
			service1 = addedServiceResponse.getPayload();
			serviceVersion1 = getServiceVersion(service1.getServiceVersions(), serviceVersion1.getSerVersion());
			SubscriptionRequest subscription1 =  newSubscription(serviceVersion1, consumer);
			
			ServiceRequest<SubscriptionRequest> addSubscriptionRequest = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription1);
			ServiceResponse<Subscription> addSubscriptionsResp = consumerServiceClient.addSubscription(consumer.getConsumerId(), addSubscriptionRequest);
			Assert.assertEquals(addSubscriptionsResp.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp.getPayload());
			
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}*/
}
