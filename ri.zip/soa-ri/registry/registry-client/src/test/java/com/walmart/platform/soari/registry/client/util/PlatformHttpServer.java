package com.walmart.platform.soari.registry.client.util;

import com.walmart.platform.test.AbstractJettyServer;


public class PlatformHttpServer extends AbstractJettyServer {
	public PlatformHttpServer() {
		super("/META-INF/httpclient");
	}

	public static void main(String[] args) {
		try {
			PlatformHttpServer s = new PlatformHttpServer();
			s.start();
		} catch (Exception ex) {
			System.exit(-1);
		} finally {
		}
	}

}