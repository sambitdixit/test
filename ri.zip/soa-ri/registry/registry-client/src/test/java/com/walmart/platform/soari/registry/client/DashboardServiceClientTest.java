package com.walmart.platform.soari.registry.client;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.walmart.platform.soa.common.service.wrappers.ServiceHeader;
import com.walmart.platform.soa.common.service.wrappers.ServiceRequest;
import com.walmart.platform.soa.common.service.wrappers.ServiceResponse;
import com.walmart.platform.soa.common.service.wrappers.Status;
import com.walmart.platform.soari.registry.client.util.AbstractClientTest;
import com.walmart.platform.soari.registry.client.util.PlatformJAXRSHttpServer;
import com.walmart.platform.soari.registry.common.dto.Consumer;
import com.walmart.platform.soari.registry.common.dto.RegistryOptionList;
import com.walmart.platform.soari.registry.common.dto.Service;
import com.walmart.platform.soari.registry.common.dto.ServiceVersion;
import com.walmart.platform.soari.registry.common.dto.Subscription;
import com.walmart.platform.soari.registry.common.dto.SubscriptionRequest;
import com.walmart.platform.soari.registry.common.dto.Url;
import com.walmart.platform.soari.registry.common.enums.RegistryPolicyCodeType;
import com.walmart.platform.soari.registry.common.enums.ReportType;
import com.walmart.platform.soari.registry.common.enums.ServiceCommunicationType;
import com.walmart.platform.soari.registry.common.enums.UrlType;

public class DashboardServiceClientTest extends AbstractClientTest {
	int artifactIndex = 0;
	int environmentIndex = 0;

	@BeforeClass
	public void startServers() throws Exception {
		Assert.assertTrue(launchServer(PlatformJAXRSHttpServer.class, true),
				"server did not launch correctly");
		init();
		ServiceResponse<RegistryOptionList> getCmdbArtifactResp = registryOptionServiceClient.getOptionsByType(RegistryPolicyCodeType.CMDB_ARTIFACT);
		Assert.assertEquals(getCmdbArtifactResp.getStatus(), Status.OK);
		Assert.assertNotNull(getCmdbArtifactResp.getPayload());
		Assert.assertNotNull(getCmdbArtifactResp.getPayload().getOptions());
		Assert.assertFalse(getCmdbArtifactResp.getPayload().getOptions().isEmpty());
		cmdbArtifacts.addAll(getCmdbArtifactResp.getPayload().getOptions());
		ServiceResponse<RegistryOptionList> getJiraProjectResp = registryOptionServiceClient.getOptionsByType(RegistryPolicyCodeType.JIRA_PROJECT);
		Assert.assertEquals(getJiraProjectResp.getStatus(), Status.OK);
		Assert.assertNotNull(getJiraProjectResp.getPayload());
		Assert.assertNotNull(getJiraProjectResp.getPayload().getOptions());
		Assert.assertFalse(getJiraProjectResp.getPayload().getOptions().isEmpty());
		jiraProjects.addAll(getJiraProjectResp.getPayload().getOptions());
		ServiceResponse<RegistryOptionList> getCmdbEnvironmentsResp = registryOptionServiceClient.getOptionsByType(RegistryPolicyCodeType.CMDB_ENVIRONMENT);
		Assert.assertEquals(getCmdbEnvironmentsResp.getStatus(), Status.OK);
		Assert.assertNotNull(getCmdbEnvironmentsResp.getPayload());
		Assert.assertNotNull(getCmdbEnvironmentsResp.getPayload().getOptions());
		Assert.assertFalse(getCmdbEnvironmentsResp.getPayload().getOptions().isEmpty());
		cmdbEnvironments.addAll(getCmdbEnvironmentsResp.getPayload().getOptions());
	}
	
	@Test(enabled = true)
	public void testGetServiceCount() throws Exception {
		try {
		
			Service serviceQA = newService(cmdbArtifacts.get(artifactIndex++).getCode(), cmdbEnvironments.get(environmentIndex++).getCode());
			serviceQA.setJiraProject(jiraProjects.get(0).getCode());
			
			ServiceRequest<Service> newQAServiceRequest = new ServiceRequest<Service>(
					new ServiceHeader(), serviceQA);
			ServiceResponse<Service> addedQAServiceResponse = registryServiceClient
					.addService(newQAServiceRequest);
			Assert.assertEquals(addedQAServiceResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedQAServiceResponse.getPayload());
	
			Service serviceDEV = newService(cmdbArtifacts.get(artifactIndex++).getCode(), cmdbEnvironments.get(environmentIndex++).getCode());
			serviceDEV.setJiraProject(jiraProjects.get(0).getCode());
			
			ServiceRequest<Service> newDEVServiceRequest = new ServiceRequest<Service>(
					new ServiceHeader(), serviceDEV);
			ServiceResponse<Service> addedDEVServiceResponse = registryServiceClient
					.addService(newDEVServiceRequest);
			Assert.assertEquals(addedDEVServiceResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedDEVServiceResponse.getPayload());
			
			ServiceResponse<String> getServiceCountPerEnvReq = dashboardServiceClient.getReport(ReportType.SERVICES_PER_ENVIRONMENT);
			System.out.println("getServiceCountPerEnvReq = "+getServiceCountPerEnvReq.getPayload());
			Assert.assertEquals(getServiceCountPerEnvReq.getStatus(), Status.OK);
			Assert.assertNotNull(getServiceCountPerEnvReq.getPayload());
			Assert.assertFalse(getServiceCountPerEnvReq.getPayload().isEmpty());
			
			ServiceResponse<String> getEnvCountPerServiceReq = dashboardServiceClient.getReport(ReportType.ENVIRONMENTS_PER_SERVICE);
			System.out.println("getEnvCountPerServiceReq = "+getEnvCountPerServiceReq.getPayload());
			Assert.assertEquals(getEnvCountPerServiceReq.getStatus(), Status.OK);
			Assert.assertNotNull(getEnvCountPerServiceReq.getPayload());
			Assert.assertFalse(getEnvCountPerServiceReq.getPayload().isEmpty());
	
			ServiceResponse<String> getServiceCatCountPerEnvReq = dashboardServiceClient.getReport(ReportType.SERVICE_CATEGORIES_PER_ENVIRONMENT);
			System.out.println("getServiceCatCountPerEnvReq = "+getServiceCatCountPerEnvReq.getPayload());
			Assert.assertEquals(getServiceCatCountPerEnvReq.getStatus(), Status.OK);
			Assert.assertNotNull(getServiceCatCountPerEnvReq.getPayload());
			Assert.assertFalse(getServiceCatCountPerEnvReq.getPayload().isEmpty());
	
			ServiceResponse<String> getServiceCountPerMonthReq = dashboardServiceClient.getReport(ReportType.SERVICES_PER_MONTH);
			System.out.println("getServiceCountPerMonthReq = "+getServiceCountPerMonthReq.getPayload());
			Assert.assertEquals(getServiceCountPerMonthReq.getStatus(), Status.OK);
			Assert.assertNotNull(getServiceCountPerMonthReq.getPayload());
			Assert.assertFalse(getServiceCountPerMonthReq.getPayload().isEmpty());
		} catch (Exception ex) {
			ex.printStackTrace();
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testGetConsumerSubscriptionCount() throws Exception {
		try {
			Consumer consumer1 = newConsumer();
			
			ServiceRequest<Consumer> newConsumerRequest1 = new ServiceRequest<Consumer>(
					new ServiceHeader(), consumer1);
			ServiceResponse<Consumer> addedConsumerResponse1 = consumerServiceClient
					.addConsumer(newConsumerRequest1);
			Assert.assertEquals(addedConsumerResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedConsumerResponse1.getPayload());
			Assert.assertEquals(addedConsumerResponse1.getPayload().getConsumerId(), consumer1.getConsumerId());
			
			consumer1 = addedConsumerResponse1.getPayload();
			
			Service service1 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceVersion serviceVersion11 = newServiceVersion();
			serviceVersion11.setSerVersion("1.0.0");
			service1.getServiceVersions().add(serviceVersion11);
		
			ServiceVersion serviceVersion12 = newServiceVersion();
			serviceVersion12.setSerVersion("1.0.1");
			service1.getServiceVersions().add(serviceVersion12);
		
			ServiceRequest<Service> newServiceRequest1 = new ServiceRequest<Service>(
					new ServiceHeader(), service1);
			ServiceResponse<Service> addedServiceResponse1 = registryServiceClient
					.addService(newServiceRequest1);
			Assert.assertEquals(addedServiceResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse1.getPayload());
			Assert.assertEquals(addedServiceResponse1.getPayload().getServiceVersions().size(), service1.getServiceVersions().size());
			
			service1 = addedServiceResponse1.getPayload();
			serviceVersion11 = getServiceVersion(service1.getServiceVersions(), serviceVersion11.getSerVersion());
			Subscription subscription11 = (Subscription) newSubscription(serviceVersion11, consumer1);
			
			serviceVersion12 = getServiceVersion(service1.getServiceVersions(), serviceVersion12.getSerVersion());
			Subscription subscription12 = (Subscription) newSubscription(serviceVersion12, consumer1);
		
			ServiceRequest<SubscriptionRequest> addSubscriptionsRequest1 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription11);
			ServiceResponse<Subscription> addSubscriptionsResp1 = consumerServiceClient.addSubscription(consumer1.getConsumerId(), addSubscriptionsRequest1);
			Assert.assertEquals(addSubscriptionsResp1.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp1.getPayload());
			
			ServiceRequest<SubscriptionRequest> addSubscriptionsRequest2 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription12);
			ServiceResponse<Subscription> addSubscriptionsResp2 = consumerServiceClient.addSubscription(consumer1.getConsumerId(), addSubscriptionsRequest2);
			Assert.assertEquals(addSubscriptionsResp2.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp2.getPayload());
			
			//Add more subscriptions
			Service service2 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceVersion serviceVersion21 = newServiceVersion();
			serviceVersion21.setSerVersion("1.0.0");
			service2.getServiceVersions().add(serviceVersion21);
		
			ServiceVersion serviceVersion22 = newServiceVersion();
			serviceVersion22.setSerVersion("1.0.1");
			serviceVersion22.getUrls().clear();
			Url endpointUrl = new Url();
			endpointUrl.setType(UrlType.ENDPOINT.toString());
			endpointUrl.setUrl(TEST_END_POINT_URL);
			serviceVersion22.getUrls().add(endpointUrl);
			service2.getServiceVersions().add(serviceVersion22);
		
			ServiceRequest<Service> newServiceRequest2 = new ServiceRequest<Service>(
					new ServiceHeader(), service2);
			ServiceResponse<Service> addedServiceResponse2 = registryServiceClient
					.addService(newServiceRequest2);
			Assert.assertEquals(addedServiceResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse2.getPayload());
			Assert.assertEquals(addedServiceResponse2.getPayload().getServiceVersions().size(), service2.getServiceVersions().size());
			
			service2 = addedServiceResponse2.getPayload();
			serviceVersion21 = getServiceVersion(service2.getServiceVersions(), serviceVersion21.getSerVersion());
			Subscription subscription21 = (Subscription) newSubscription(serviceVersion21, consumer1);
			
			serviceVersion22 = getServiceVersion(service2.getServiceVersions(), serviceVersion22.getSerVersion());
			Subscription subscription22 = (Subscription) newSubscription(serviceVersion22, consumer1);
			subscription22.setCommunicationType(ServiceCommunicationType.DIRECT.toString());
			
			ServiceRequest<SubscriptionRequest> addSubscriptionsRequest21 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription21);
			ServiceResponse<Subscription> addSubscriptionsResp21 = consumerServiceClient.addSubscription(consumer1.getConsumerId(), addSubscriptionsRequest21);
			Assert.assertEquals(addSubscriptionsResp21.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp21.getPayload());

			ServiceRequest<SubscriptionRequest> addSubscriptionsRequest22 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription22);
			ServiceResponse<Subscription> addSubscriptionsResp22 = consumerServiceClient.addSubscription(consumer1.getConsumerId(), addSubscriptionsRequest22);
			Assert.assertEquals(addSubscriptionsResp22.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp22.getPayload());
			
			
			//Consumer2
			Consumer consumer2 = newConsumer();
			
			ServiceRequest<Consumer> newConsumerRequest2 = new ServiceRequest<Consumer>(
					new ServiceHeader(), consumer2);
			ServiceResponse<Consumer> addedConsumerResponse2 = consumerServiceClient
					.addConsumer(newConsumerRequest2);
			Assert.assertEquals(addedConsumerResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedConsumerResponse2.getPayload());
			Assert.assertEquals(addedConsumerResponse2.getPayload().getConsumerId(), consumer2.getConsumerId());
			
			consumer2 = addedConsumerResponse2.getPayload();
			
			Service service3 = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceVersion serviceVersion31 = newServiceVersion();
			serviceVersion31.setSerVersion("1.0.0");
			serviceVersion31.getUrls().clear();
			Url esbUrl = new Url();
			esbUrl.setType(UrlType.ESB_PROXY.toString());
			esbUrl.setUrl(TEST_ESB_PROXY_URL);
			serviceVersion31.getUrls().add(esbUrl);
			service3.getServiceVersions().add(serviceVersion31);
		
			ServiceRequest<Service> newServiceRequest3 = new ServiceRequest<Service>(
					new ServiceHeader(), service3);
			ServiceResponse<Service> addedServiceResponse3 = registryServiceClient
					.addService(newServiceRequest3);
			Assert.assertEquals(addedServiceResponse3.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse3.getPayload());
			Assert.assertEquals(addedServiceResponse3.getPayload().getServiceVersions().size(), service3.getServiceVersions().size());
			
			service3 = addedServiceResponse3.getPayload();
			serviceVersion31 = getServiceVersion(service3.getServiceVersions(), serviceVersion31.getSerVersion());
			Subscription subscription31 = (Subscription) newSubscription(serviceVersion31, consumer2);
			subscription31.setCommunicationType(ServiceCommunicationType.ESB_PROXY.toString());
			
			ServiceRequest<SubscriptionRequest> addSubscriptionsRequest3 = new ServiceRequest<SubscriptionRequest>(
					new ServiceHeader(), subscription31);
			ServiceResponse<Subscription> addSubscriptionsResp3 = consumerServiceClient.addSubscription(consumer2.getConsumerId(), addSubscriptionsRequest3);
			Assert.assertEquals(addSubscriptionsResp3.getStatus(), Status.OK);
			Assert.assertNotNull(addSubscriptionsResp3.getPayload());
			
			ServiceResponse<String> getConsumerCountPerEnvReq = dashboardServiceClient.getReport(ReportType.CONSUMERS_PER_ENVIRONMENT);
			System.out.println("getConsumerCountPerEnvReq = "+getConsumerCountPerEnvReq.getPayload());
			Assert.assertEquals(getConsumerCountPerEnvReq.getStatus(), Status.OK);
			Assert.assertNotNull(getConsumerCountPerEnvReq.getPayload());
			Assert.assertFalse(getConsumerCountPerEnvReq.getPayload().isEmpty());
		
			ServiceResponse<String> getConsumerSubCountPerEnvReq = dashboardServiceClient.getReport(ReportType.CUNSUMER_SUBSCRIPTIONS_PER_ENVIRONMENT);
			System.out.println("getConsumerSubCountPerEnvReq = "+getConsumerSubCountPerEnvReq.getPayload());
			Assert.assertEquals(getConsumerSubCountPerEnvReq.getStatus(), Status.OK);
			Assert.assertNotNull(getConsumerSubCountPerEnvReq.getPayload());
			Assert.assertFalse(getConsumerSubCountPerEnvReq.getPayload().isEmpty());
		
		} catch (Exception ex) {
			Assert.fail(ex.getMessage());
		}
	}

}
