package com.walmart.platform.soari.registry.client;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.walmart.platform.soa.common.service.wrappers.ServiceResponse;
import com.walmart.platform.soa.common.service.wrappers.Status;
import com.walmart.platform.soari.registry.client.util.AbstractClientTest;
import com.walmart.platform.soari.registry.client.util.PlatformJAXRSHttpServer;
import com.walmart.platform.soari.registry.common.dto.RegistryOption;
import com.walmart.platform.soari.registry.common.dto.RegistryOptionList;
import com.walmart.platform.soari.registry.common.enums.RegistryPolicyCodeType;

public class RegistryOptionServiceClientTest extends AbstractClientTest {
	private static final Logger LOG = LoggerFactory
			.getLogger(RegistryOptionServiceClientTest.class);

	@BeforeClass
	public void startServers() throws Exception {
		Assert.assertTrue(launchServer(PlatformJAXRSHttpServer.class, true),
				"server did not launch correctly");
		init();
	}
	
	@Test(enabled = true)
	public void testGetDashboardReportTypes() throws Exception {
		try {
			ServiceResponse<RegistryOptionList> getOptionReq = registryOptionServiceClient.getOptionsByType(RegistryPolicyCodeType.DASHBOARD_REPORT);
			Assert.assertEquals(getOptionReq.getStatus(), Status.OK);
			Assert.assertNotNull(getOptionReq.getPayload());
			Assert.assertNotNull(getOptionReq.getPayload().getOptions());
			Assert.assertFalse(getOptionReq.getPayload().getOptions().isEmpty());
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testGetNotificationTypes() throws Exception {
		try {
			ServiceResponse<RegistryOptionList> getOptionReq = registryOptionServiceClient.getOptionsByType(RegistryPolicyCodeType.NOTIFICATION_TYPE);
			Assert.assertEquals(getOptionReq.getStatus(), Status.OK);
			Assert.assertNotNull(getOptionReq.getPayload());
			Assert.assertNotNull(getOptionReq.getPayload().getOptions());
			Assert.assertFalse(getOptionReq.getPayload().getOptions().isEmpty());
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testGetMultipleOptionTypes() throws Exception {
		try {
			ServiceResponse<RegistryOptionList> getOptionReq = registryOptionServiceClient.getOptionsByType(RegistryPolicyCodeType.SERVICE_OPTION);
			Assert.assertEquals(getOptionReq.getStatus(), Status.OK);
			Assert.assertNotNull(getOptionReq.getPayload());
			Assert.assertNotNull(getOptionReq.getPayload().getOptions());
			Assert.assertFalse(getOptionReq.getPayload().getOptions().isEmpty());
			Assert.assertNotNull(getRegistryOption(getOptionReq.getPayload().getOptions(), RegistryPolicyCodeType.SERVICE_CATEGORY));
			Assert.assertNotNull(getRegistryOption(getOptionReq.getPayload().getOptions(), RegistryPolicyCodeType.SERVICE_DOMAIN));
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	protected RegistryOption getRegistryOption(List<RegistryOption> options, RegistryPolicyCodeType type) {
		for(RegistryOption option : options) {
			if(option.getType() == type) {
				return option;
			}
		}
		return null;
	}
	
	@Test(enabled = true)
	public void testGetPolicyTypes() throws Exception {
		try {
			ServiceResponse<RegistryOptionList> getOptionReq = registryOptionServiceClient.getOptionsByType(RegistryPolicyCodeType.POLICY_TYPE);
			Assert.assertEquals(getOptionReq.getStatus(), Status.OK);
			Assert.assertNotNull(getOptionReq.getPayload());
			Assert.assertNotNull(getOptionReq.getPayload().getOptions());
			Assert.assertFalse(getOptionReq.getPayload().getOptions().isEmpty());
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testGetQoSTypes() throws Exception {
		try {
			ServiceResponse<RegistryOptionList> getOptionReq = registryOptionServiceClient.getOptionsByType(RegistryPolicyCodeType.QoS_TYPE);
			Assert.assertEquals(getOptionReq.getStatus(), Status.OK);
			Assert.assertNotNull(getOptionReq.getPayload());
			Assert.assertNotNull(getOptionReq.getPayload().getOptions());
			Assert.assertFalse(getOptionReq.getPayload().getOptions().isEmpty());
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testGetServiceCategoryTypes() throws Exception {
		try {
			ServiceResponse<RegistryOptionList> getOptionReq = registryOptionServiceClient.getOptionsByType(RegistryPolicyCodeType.SERVICE_CATEGORY);
			Assert.assertEquals(getOptionReq.getStatus(), Status.OK);
			Assert.assertNotNull(getOptionReq.getPayload());
			Assert.assertNotNull(getOptionReq.getPayload().getOptions());
			Assert.assertFalse(getOptionReq.getPayload().getOptions().isEmpty());
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testGetServiceDomainTypes() throws Exception {
		try {
			ServiceResponse<RegistryOptionList> getOptionReq = registryOptionServiceClient.getOptionsByType(RegistryPolicyCodeType.SERVICE_DOMAIN);
			Assert.assertEquals(getOptionReq.getStatus(), Status.OK);
			Assert.assertNotNull(getOptionReq.getPayload());
			Assert.assertNotNull(getOptionReq.getPayload().getOptions());
			Assert.assertFalse(getOptionReq.getPayload().getOptions().isEmpty());
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testGetServiceUsageTypes() throws Exception {
		try {
			ServiceResponse<RegistryOptionList> getOptionReq = registryOptionServiceClient.getOptionsByType(RegistryPolicyCodeType.SERVICE_USAGE);
			Assert.assertEquals(getOptionReq.getStatus(), Status.OK);
			Assert.assertNotNull(getOptionReq.getPayload());
			Assert.assertNotNull(getOptionReq.getPayload().getOptions());
			Assert.assertFalse(getOptionReq.getPayload().getOptions().isEmpty());
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testGetStatusTypes() throws Exception {
		try {
			ServiceResponse<RegistryOptionList> getOptionReq = registryOptionServiceClient.getOptionsByType(RegistryPolicyCodeType.STATUS);
			Assert.assertEquals(getOptionReq.getStatus(), Status.OK);
			Assert.assertNotNull(getOptionReq.getPayload());
			Assert.assertNotNull(getOptionReq.getPayload().getOptions());
			Assert.assertFalse(getOptionReq.getPayload().getOptions().isEmpty());
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testGetChangeTypes() throws Exception {
		try {
			ServiceResponse<RegistryOptionList> getOptionReq = registryOptionServiceClient.getOptionsByType(RegistryPolicyCodeType.CHANGE_TYPE);
			Assert.assertEquals(getOptionReq.getStatus(), Status.OK);
			Assert.assertNotNull(getOptionReq.getPayload());
			Assert.assertNotNull(getOptionReq.getPayload().getOptions());
			Assert.assertFalse(getOptionReq.getPayload().getOptions().isEmpty());
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testGetEnvironmentTypes() throws Exception {
		try {
			ServiceResponse<RegistryOptionList> getOptionReq = registryOptionServiceClient.getOptionsByType(RegistryPolicyCodeType.CMDB_ENVIRONMENT);
			Assert.assertEquals(getOptionReq.getStatus(), Status.OK);
			Assert.assertNotNull(getOptionReq.getPayload());
			Assert.assertNotNull(getOptionReq.getPayload().getOptions());
			Assert.assertFalse(getOptionReq.getPayload().getOptions().isEmpty());
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	@Test(enabled = true)
	public void testGetArtifactIds() throws Exception {
		try {
			ServiceResponse<RegistryOptionList> getOptionReq = registryOptionServiceClient.getOptionsByType(RegistryPolicyCodeType.CMDB_ARTIFACT);
			Assert.assertEquals(getOptionReq.getStatus(), Status.OK);
			Assert.assertNotNull(getOptionReq.getPayload());
			Assert.assertNotNull(getOptionReq.getPayload().getOptions());
			Assert.assertFalse(getOptionReq.getPayload().getOptions().isEmpty());
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	/*@Test(enabled = true)
	public void testGetJIRAProjects() throws Exception {
		try {
			ServiceResponse<RegistryOptionList> getOptionReq = registryOptionServiceClient.getOptionsByType(RegistryPolicyCodeType.JIRA_PROJECT);
			Assert.assertEquals(getOptionReq.getStatus(), Status.OK);
			Assert.assertNotNull(getOptionReq.getPayload());
			Assert.assertNotNull(getOptionReq.getPayload().getOptions());
			Assert.assertFalse(getOptionReq.getPayload().getOptions().isEmpty());
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}*/
}
