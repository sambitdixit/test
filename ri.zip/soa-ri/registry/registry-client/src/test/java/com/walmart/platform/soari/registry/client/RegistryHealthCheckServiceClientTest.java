package com.walmart.platform.soari.registry.client;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.walmart.platform.kernel.exception.layers.service.ServiceException;
import com.walmart.platform.soa.common.service.wrappers.ServiceResponse;
import com.walmart.platform.soa.common.service.wrappers.Status;
import com.walmart.platform.soari.registry.client.util.AbstractClientTest;
import com.walmart.platform.soari.registry.client.util.PlatformJAXRSHttpServer;

public class RegistryHealthCheckServiceClientTest extends AbstractClientTest {
	private static final Logger LOG = LoggerFactory
			.getLogger(RegistryHealthCheckServiceClientTest.class);

	@BeforeClass
	public void startServers() throws Exception {
		Assert.assertTrue(launchServer(PlatformJAXRSHttpServer.class, true),
				"server did not launch correctly");
		init();
	}

	@Test(enabled = true)
	public void testGetOptionCount() throws Exception {
		try {
			ServiceResponse<Long> getOptionCountReq = registryHealthCheckServiceClient.getOptionCount();
			Assert.assertEquals(getOptionCountReq.getStatus(), Status.OK);
			Assert.assertNotNull(getOptionCountReq.getPayload());
			Assert.assertTrue(getOptionCountReq.getPayload() >=0);
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testGetCurrentEcvStatus() throws Exception {
		try {
			ServiceResponse<Integer> getEcvStatus = registryHealthCheckServiceClient.getCurrentEcvStatus();
			Assert.assertEquals(getEcvStatus.getStatus(), Status.OK);
			Assert.assertNotNull(getEcvStatus.getPayload());
			Assert.assertTrue(getEcvStatus.getPayload() == 200);
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	
	@Test(enabled = true)
	public void testUpdateEcvStatus() throws Exception {
		try {
			ServiceResponse<Integer> getEcvStatus = registryHealthCheckServiceClient.getCurrentEcvStatus();
			Assert.assertEquals(getEcvStatus.getStatus(), Status.OK);
			Assert.assertNotNull(getEcvStatus.getPayload());
			Assert.assertTrue(getEcvStatus.getPayload() == 200);
			
			ServiceResponse<Integer> updateEcvStatus = registryHealthCheckServiceClient.updateEcvStatus(400);
			Assert.assertEquals(updateEcvStatus.getStatus(), Status.OK);
			Assert.assertNotNull(updateEcvStatus.getPayload());
			
			ServiceResponse<Integer> getEcvStatusNew = registryHealthCheckServiceClient.getCurrentEcvStatus();
			Assert.assertEquals(getEcvStatusNew.getStatus(), Status.BAD_REQUEST);
			Assert.assertNotNull(getEcvStatusNew.getPayload());
			Assert.assertTrue(getEcvStatusNew.getPayload() == 400);
			
		} catch (ServiceException ex) {
			Assert.assertEquals(ex.getHttpStatusCode(), Status.BAD_REQUEST.getCode());
			LOG.error("service exception",ex);
			//Assert.fail(ex.getMessage());
		}
	}
}
