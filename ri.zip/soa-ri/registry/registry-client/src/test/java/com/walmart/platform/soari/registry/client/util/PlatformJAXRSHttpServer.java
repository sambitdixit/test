package com.walmart.platform.soari.registry.client.util;

import org.apache.cxf.Bus;
import org.apache.cxf.bus.spring.SpringBusFactory;

import com.walmart.platform.soari.registry.server.common.util.CommonConstants;
import com.walmart.platform.test.AbstractServerTest;
import com.walmart.platform.test.utils.PortUtil;

public class PlatformJAXRSHttpServer extends AbstractServerTest {
	public static final String PORT = PortUtil.getPortNumber("jaxrs-http");
	private static final String SERVER_CONFIG_FILE = "META-INF/jaxrs-http/server.xml";

	@Override
	@SuppressWarnings("unused")
	protected void run() {
		System.setProperty(CommonConstants.RUN_ON_ENV, "dev");
		SpringBusFactory bf = new SpringBusFactory();
		Bus bus = bf.createBus(SERVER_CONFIG_FILE);
		try {
			new PlatformJAXRSHttpServer();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public static void main(String[] args) {

		try {
			PlatformJAXRSHttpServer s = new PlatformJAXRSHttpServer();
			s.start();
		} catch (Exception ex) {
			System.exit(-1);
		} finally {
		}

	}
}
