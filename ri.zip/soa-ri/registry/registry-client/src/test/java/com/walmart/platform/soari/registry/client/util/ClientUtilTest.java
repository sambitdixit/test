package com.walmart.platform.soari.registry.client.util;

import org.testng.Assert;
import org.testng.annotations.Test;

public class ClientUtilTest {

  @Test
  public void buildBaseUrl() {
	 String url = "http://q1-soaregistry.glb.qa.walmart.com/registry-app/services/registry/";
	 Assert.assertEquals("http://q1-soaregistry.glb.qa.walmart.com/registry-app/services", ClientUtil.buildBaseUrl(url));
	 url = "http://q1-soaregistry.glb.qa.walmart.com/registry-app/services";
	 Assert.assertEquals("http://q1-soaregistry.glb.qa.walmart.com/registry-app/services", ClientUtil.buildBaseUrl(url));
	 
  }

  @Test
  public void replaceBlankSpaces() {
	  String s = "Test Here";
	  Assert.assertEquals("Test%20Here", ClientUtil.replaceBlankSpaces(s));
  }
  
  
}
