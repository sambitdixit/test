package com.walmart.platform.soari.registry.client;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.walmart.platform.soa.common.service.wrappers.ServiceHeader;
import com.walmart.platform.soa.common.service.wrappers.ServiceRequest;
import com.walmart.platform.soa.common.service.wrappers.ServiceResponse;
import com.walmart.platform.soa.common.service.wrappers.Status;
import com.walmart.platform.soari.registry.client.util.AbstractClientTest;
import com.walmart.platform.soari.registry.client.util.PlatformJAXRSHttpServer;
import com.walmart.platform.soari.registry.common.dto.QoS;
import com.walmart.platform.soari.registry.common.dto.QoSList;
import com.walmart.platform.soari.registry.common.enums.SearchFieldType;
import com.walmart.platform.soari.registry.common.enums.StatusType;

public class QoSServiceClientTest extends AbstractClientTest {

	private static final Logger LOG = LoggerFactory
			.getLogger(QoSServiceClientTest.class);

	@BeforeClass
	public void startServers() throws Exception {
		Assert.assertTrue(launchServer(PlatformJAXRSHttpServer.class, true),
				"server did not launch correctly");
		init();
	}

	@Test(enabled = true)
	public void testGetQoS() throws Exception {
		try {
			QoS qos1 = newQoS();
			ServiceRequest<QoS> newQoSRequest1 = new ServiceRequest<QoS>(
					new ServiceHeader(), qos1);
			ServiceResponse<QoS> addedQoSResponse1 = qosServiceClient
					.addQoS(newQoSRequest1);
			Assert.assertEquals(addedQoSResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedQoSResponse1.getPayload());
			qos1 = addedQoSResponse1.getPayload();
			
			QoS qos2 = newQoS();
			ServiceRequest<QoS> newQoSRequest2 = new ServiceRequest<QoS>(
					new ServiceHeader(), qos2);
			ServiceResponse<QoS> addedQoSResponse2 = qosServiceClient
					.addQoS(newQoSRequest2);
			Assert.assertEquals(addedQoSResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedQoSResponse2.getPayload());
			qos2 = addedQoSResponse2.getPayload();
			
			ServiceResponse<QoSList> getQoSResp = qosServiceClient
					.getQoS();
			Assert.assertEquals(getQoSResp.getStatus(), Status.OK);
			Assert.assertNotNull(getQoSResp.getPayload());
			Assert.assertTrue(!getQoSResp.getPayload().getQosList()
					.isEmpty());
			Assert.assertTrue(contains(getQoSResp.getPayload().getQosList(), qos1.getId()));
			Assert.assertTrue(contains(getQoSResp.getPayload().getQosList(), qos2.getId()));

		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testGetActiveQoSQueryParam() throws Exception {
		try {
			QoS qos1 = newQoS();
			ServiceRequest<QoS> newQoSRequest1 = new ServiceRequest<QoS>(
					new ServiceHeader(), qos1);
			ServiceResponse<QoS> addedQoSResponse1 = qosServiceClient
					.addQoS(newQoSRequest1);
			Assert.assertEquals(addedQoSResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedQoSResponse1.getPayload());
			qos1 = addedQoSResponse1.getPayload();
			
			QoS qos2 = newQoS();
			qos2.setStatus(StatusType.INACTIVE.toString());
			ServiceRequest<QoS> newQoSRequest2 = new ServiceRequest<QoS>(
					new ServiceHeader(), qos2);
			ServiceResponse<QoS> addedQoSResponse2 = qosServiceClient
					.addQoS(newQoSRequest2);
			Assert.assertEquals(addedQoSResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedQoSResponse2.getPayload());
			qos2 = addedQoSResponse2.getPayload();
			
			ServiceResponse<QoSList> getQoSResp = qosServiceClient.searchQoS(SearchFieldType.STATUS.toString(), StatusType.ACTIVE.toString());
			Assert.assertEquals(getQoSResp.getStatus(), Status.OK);
			Assert.assertNotNull(getQoSResp.getPayload());
			Assert.assertTrue(!getQoSResp.getPayload().getQosList()
					.isEmpty());
			Assert.assertTrue(contains(getQoSResp.getPayload().getQosList(), qos1.getId()));
			Assert.assertFalse(contains(getQoSResp.getPayload().getQosList(), qos2.getId()));
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	

	@Test(enabled = true)
	public void testGetAvailableQoSQueryParam() throws Exception {
		try {
			QoS qos1 = newQoS();
			ServiceRequest<QoS> newQoSRequest1 = new ServiceRequest<QoS>(
					new ServiceHeader(), qos1);
			ServiceResponse<QoS> addedQoSResponse1 = qosServiceClient
					.addQoS(newQoSRequest1);
			Assert.assertEquals(addedQoSResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedQoSResponse1.getPayload());
			qos1 = addedQoSResponse1.getPayload();
			
			QoS qos2 = newQoS();
			qos2.setStatus(StatusType.INACTIVE.toString());
			ServiceRequest<QoS> newQoSRequest2 = new ServiceRequest<QoS>(
					new ServiceHeader(), qos2);
			ServiceResponse<QoS> addedQoSResponse2 = qosServiceClient
					.addQoS(newQoSRequest2);
			Assert.assertEquals(addedQoSResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedQoSResponse2.getPayload());
			qos2 = addedQoSResponse2.getPayload();
			
			QoS qos3 = newQoS();
			qos2.setStatus(StatusType.DELETED.toString());
			ServiceRequest<QoS> newQoSRequest3 = new ServiceRequest<QoS>(
					new ServiceHeader(), qos3);
			ServiceResponse<QoS> addedQoSResponse3 = qosServiceClient
					.addQoS(newQoSRequest3);
			Assert.assertEquals(addedQoSResponse3.getStatus(), Status.OK);
			Assert.assertNotNull(addedQoSResponse3.getPayload());
			qos2 = addedQoSResponse3.getPayload();
			
			ServiceResponse<QoSList> getQoSResp = qosServiceClient.searchQoS(SearchFieldType.STATUS.toString(), StatusType.AVAILABLE.toString());
			
			Assert.assertEquals(getQoSResp.getStatus(), Status.OK);
			Assert.assertNotNull(getQoSResp.getPayload());
			Assert.assertTrue(!getQoSResp.getPayload().getQosList()
					.isEmpty());
			Assert.assertTrue(contains(getQoSResp.getPayload().getQosList(), qos1.getId()));
			Assert.assertTrue(contains(getQoSResp.getPayload().getQosList(), qos2.getId()));
			Assert.assertFalse(contains(getQoSResp.getPayload().getQosList(), qos3.getId()));
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	@Test(enabled = true)
	public void testSearchQoSByName() throws Exception {
		try {
			long now = System.currentTimeMillis();
			QoS qos1 = newQoS();
			qos1.setName("QoS1 "+now+" Test");
			ServiceRequest<QoS> newQoSRequest1 = new ServiceRequest<QoS>(
					new ServiceHeader(), qos1);
			ServiceResponse<QoS> addedQoSResponse1 = qosServiceClient
					.addQoS(newQoSRequest1);
			Assert.assertEquals(addedQoSResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedQoSResponse1.getPayload());

			QoS qos2 = newQoS();
			qos2.setName("QOS "+now+" Test");
			ServiceRequest<QoS> newQoSRequest2 = new ServiceRequest<QoS>(
					new ServiceHeader(), qos2);
			ServiceResponse<QoS> addedQoSResponse2 = qosServiceClient
					.addQoS(newQoSRequest2);
			Assert.assertEquals(addedQoSResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedQoSResponse2.getPayload());
			
			QoS qos3 = newQoS();
			long now2 = System.currentTimeMillis();
			qos3.setName("QoS3 "+now2+" Test");
			ServiceRequest<QoS> newQoSRequest3 = new ServiceRequest<QoS>(
					new ServiceHeader(), qos3);
			ServiceResponse<QoS> addedQoSResponse3 = qosServiceClient
					.addQoS(newQoSRequest3);
			Assert.assertEquals(addedQoSResponse3.getStatus(), Status.OK);
			Assert.assertNotNull(addedQoSResponse3.getPayload());

			ServiceResponse<QoSList> getQoSListResp = qosServiceClient.searchQoS(SearchFieldType.NAME.toString(),String.valueOf(now));
			Assert.assertEquals(getQoSListResp.getStatus(), Status.OK);
			Assert.assertNotNull(getQoSListResp.getPayload());
			Assert.assertTrue(contains(getQoSListResp.getPayload().getQosList(), addedQoSResponse1.getPayload().getId()));
			Assert.assertTrue(contains(getQoSListResp.getPayload().getQosList(), addedQoSResponse2.getPayload().getId()));
			Assert.assertFalse(contains(getQoSListResp.getPayload().getQosList(), addedQoSResponse3.getPayload().getId()));

		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testSearchQoSListByStatus() throws Exception {
		try {
			QoS qos1 = newQoS();
			ServiceRequest<QoS> newQoSRequest1 = new ServiceRequest<QoS>(
					new ServiceHeader(), qos1);
			ServiceResponse<QoS> addedQoSResponse1 = qosServiceClient
					.addQoS(newQoSRequest1);
			Assert.assertEquals(addedQoSResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedQoSResponse1.getPayload());

			QoS qos2 = newQoS();
			ServiceRequest<QoS> newQoSRequest2 = new ServiceRequest<QoS>(
					new ServiceHeader(), qos2);
			ServiceResponse<QoS> addedQoSResponse2 = qosServiceClient
					.addQoS(newQoSRequest2);
			Assert.assertEquals(addedQoSResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedQoSResponse2.getPayload());
			
			QoS qos3 = newQoS();
			qos3.setStatus(StatusType.DELETED.toString());
			ServiceRequest<QoS> newQoSRequest3 = new ServiceRequest<QoS>(
					new ServiceHeader(), qos3);
			ServiceResponse<QoS> addedQoSResponse3 = qosServiceClient
					.addQoS(newQoSRequest3);
			Assert.assertEquals(addedQoSResponse3.getStatus(), Status.OK);
			Assert.assertNotNull(addedQoSResponse3.getPayload());

			ServiceResponse<QoSList> getQoSListResp = qosServiceClient.searchQoS(SearchFieldType.STATUS.toString(),StatusType.ACTIVE.toString());
			Assert.assertEquals(getQoSListResp.getStatus(), Status.OK);
			Assert.assertNotNull(getQoSListResp.getPayload());
			
			Assert.assertTrue(contains(getQoSListResp.getPayload().getQosList(), addedQoSResponse1.getPayload().getId()));
			Assert.assertTrue(contains(getQoSListResp.getPayload().getQosList(), addedQoSResponse2.getPayload().getId()));
			Assert.assertFalse(contains(getQoSListResp.getPayload().getQosList(), addedQoSResponse3.getPayload().getId()));

		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testGetQoSById() throws Exception {
		try {
			QoS qos1 = newQoS();
			ServiceRequest<QoS> newQoSRequest1 = new ServiceRequest<QoS>(
					new ServiceHeader(), qos1);
			ServiceResponse<QoS> addedQoSResponse1 = qosServiceClient
					.addQoS(newQoSRequest1);
			Assert.assertEquals(addedQoSResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedQoSResponse1.getPayload());

			ServiceResponse<QoS> getQoSResp = qosServiceClient
					.getQoS(addedQoSResponse1.getPayload().getId());
			Assert.assertEquals(getQoSResp.getStatus(), Status.OK);
			Assert.assertNotNull(getQoSResp.getPayload());
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testAddQoS() throws Exception {
		try {
			QoS qos = newQoS();
			ServiceRequest<QoS> newQoSRequest = new ServiceRequest<QoS>(
					new ServiceHeader(), qos);
			ServiceResponse<QoS> addedQoSResponse = qosServiceClient
					.addQoS(newQoSRequest);
			Assert.assertEquals(addedQoSResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedQoSResponse.getPayload());
			Assert.assertNotNull(addedQoSResponse.getPayload().getCreatedAt());
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testUpdateQoS() throws Exception {
		try {
			QoS qos = newQoS();
			ServiceRequest<QoS> newQoSRequest = new ServiceRequest<QoS>(
					new ServiceHeader(), qos);
			ServiceResponse<QoS> addedQoSResponse = qosServiceClient
					.addQoS(newQoSRequest);
			Assert.assertEquals(addedQoSResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedQoSResponse.getPayload());
			Assert.assertNotNull(addedQoSResponse.getPayload().getCreatedAt());
			Assert.assertNotNull(addedQoSResponse.getPayload().getCreatedBy());
			Assert.assertEquals(addedQoSResponse.getPayload().getCreatedBy(), TEST_CREATED_BY_USER);
			
			QoS qosToUpdate = addedQoSResponse.getPayload();
			long now = System.currentTimeMillis();
			String updatedName = TEST_POLICY_NAME + now;
			qosToUpdate.setName(updatedName);
			qosToUpdate.setStatus(StatusType.INACTIVE.toString());
			qosToUpdate.setModifiedBy(TEST_MODIFIED_BY_USER);
			
			ServiceRequest<QoS> updateReq = new ServiceRequest<QoS>(
					new ServiceHeader(), qosToUpdate);
			ServiceResponse<QoS> updateQoSResp = qosServiceClient.updateQoS(updateReq);
			Assert.assertEquals(addedQoSResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedQoSResponse.getPayload());
			Assert.assertEquals(updateQoSResp.getPayload().getName(), updatedName);
			Assert.assertEquals(updateQoSResp.getPayload().getStatus(), StatusType.INACTIVE.toString());
			Assert.assertNotNull(updateQoSResp.getPayload().getCreatedAt());
			Assert.assertNotNull(updateQoSResp.getPayload().getCreatedBy());
			Assert.assertEquals(updateQoSResp.getPayload().getCreatedBy(), TEST_CREATED_BY_USER);
			//Assert.assertNotNull(updateQoSResp.getPayload().getModifiedAt());
			Assert.assertNotNull(updateQoSResp.getPayload().getModifiedBy());
			Assert.assertEquals(updateQoSResp.getPayload().getModifiedBy(), TEST_MODIFIED_BY_USER);
			
			ServiceResponse<QoS> resp = qosServiceClient.getQoS(updateQoSResp.getPayload().getId());
			Assert.assertNotNull(resp.getPayload().getModifiedBy());
			Assert.assertNotNull(resp.getPayload().getModifiedAt());
						
			qosToUpdate = updateQoSResp.getPayload();
			String modifiedBy = TEST_MODIFIED_BY_USER+"_2";
			now = System.currentTimeMillis();
			updatedName = TEST_QoS_NAME + now;
			qosToUpdate.setName(updatedName);
			qosToUpdate.setModifiedBy(modifiedBy);
			
			updateReq = new ServiceRequest<QoS>(
					new ServiceHeader(), qosToUpdate);
			updateQoSResp = qosServiceClient.updateQoS(updateReq);
			Assert.assertEquals(addedQoSResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedQoSResponse.getPayload());
			Assert.assertEquals(updateQoSResp.getPayload().getName(), updatedName);
			Assert.assertEquals(updateQoSResp.getPayload().getStatus(), StatusType.INACTIVE.toString());
			Assert.assertNotNull(updateQoSResp.getPayload().getCreatedAt());
			Assert.assertNotNull(updateQoSResp.getPayload().getCreatedBy());
			Assert.assertEquals(updateQoSResp.getPayload().getCreatedBy(), TEST_CREATED_BY_USER);
			Assert.assertNotNull(updateQoSResp.getPayload().getModifiedBy());
			Assert.assertEquals(updateQoSResp.getPayload().getModifiedBy(), modifiedBy);
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testUpdateQoSAddIfNotFound() throws Exception {
		try {
			QoS qos = newQoS();
			ServiceRequest<QoS> updateQoSReq = new ServiceRequest<QoS>(
					new ServiceHeader(), qos);
			ServiceResponse<QoS> updateQoSResp = qosServiceClient
					.updateQoS(updateQoSReq);
			Assert.assertEquals(updateQoSResp.getStatus(), Status.OK);
			Assert.assertNotNull(updateQoSResp.getPayload());

		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testUpdateQoSCheckDuplicate() throws Exception {
		try {
			QoS qos1 = newQoS();
			ServiceRequest<QoS> newQoSRequest1 = new ServiceRequest<QoS>(
					new ServiceHeader(), qos1);
			ServiceResponse<QoS> addedQoSResponse1 = qosServiceClient
					.addQoS(newQoSRequest1);
			Assert.assertEquals(addedQoSResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedQoSResponse1.getPayload());

			QoS qos2 = newQoS();
			ServiceRequest<QoS> newQoSRequest2 = new ServiceRequest<QoS>(
					new ServiceHeader(), qos2);
			ServiceResponse<QoS> addedQoSResponse2 = qosServiceClient
					.addQoS(newQoSRequest2);
			Assert.assertEquals(addedQoSResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedQoSResponse2.getPayload());

			QoS qosToUpdate = addedQoSResponse2.getPayload();
			qosToUpdate.setName(qos1.getName());

			ServiceRequest<QoS> updateReq = new ServiceRequest<QoS>(
					new ServiceHeader(), qosToUpdate);
			ServiceResponse<QoS> uopdateResp = qosServiceClient
					.updateQoS(updateReq);
			Assert.assertEquals(uopdateResp.getStatus(), Status.FAIL);
			Assert.assertNull(uopdateResp.getPayload());

		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.assertTrue(true);
		}
	}

	@Test(enabled = true)
	public void testAddQoSCheckDuplicate() throws Exception {
		try {
			QoS qos1 = newQoS();
			ServiceRequest<QoS> newQoSRequest1 = new ServiceRequest<QoS>(
					new ServiceHeader(), qos1);
			ServiceResponse<QoS> addedQoSResponse1 = qosServiceClient
					.addQoS(newQoSRequest1);
			Assert.assertEquals(addedQoSResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedQoSResponse1.getPayload());

			QoS qos2 = newQoS();
			qos2.setName(qos1.getName());
			ServiceRequest<QoS> newQoSRequest2 = new ServiceRequest<QoS>(
					new ServiceHeader(), qos2);
			ServiceResponse<QoS> addedQoSResponse2 = qosServiceClient
					.addQoS(newQoSRequest2);
			Assert.assertEquals(addedQoSResponse2.getStatus(), Status.FAIL);
			Assert.assertNull(addedQoSResponse2.getPayload());
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.assertTrue(true, "QOS name must be unique");
		}
	}

	@Test(enabled = true)
	public void testDeleteQoS() throws Exception {
		try {
			QoS qos = newQoS();
			ServiceRequest<QoS> newQoSRequest = new ServiceRequest<QoS>(
					new ServiceHeader(), qos);
			ServiceResponse<QoS> addedQoSResponse = qosServiceClient
					.addQoS(newQoSRequest);
			Assert.assertEquals(addedQoSResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedQoSResponse.getPayload());
			/*ServiceResponse<QOS> deleteQoSResponse = qosServiceClient
					.deleteQoS(addedQoSResponse.getPayload().getId());*/
			ServiceResponse<QoS> deleteQoSResponse = qosServiceClient
					.updateQoSStatus(addedQoSResponse.getPayload().getId(), "DELETE","test_user");
			Assert.assertEquals(deleteQoSResponse.getStatus(), Status.OK);
			Assert.assertNotNull(deleteQoSResponse.getPayload());
			
			ServiceResponse<QoS> getResp = qosServiceClient.getQoS(addedQoSResponse.getPayload().getId());
			Assert.assertEquals(getResp.getStatus(), Status.OK);
			Assert.assertNotNull(getResp.getPayload());
			Assert.assertEquals(getResp.getPayload().getStatus(), StatusType.DELETED.toString());
		
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testUpdateQoSStatus() throws Exception {
		try {
			QoS qos = newQoS();
			ServiceRequest<QoS> newQoSRequest = new ServiceRequest<QoS>(
					new ServiceHeader(), qos);
			ServiceResponse<QoS> addedQoSResponse = qosServiceClient
					.addQoS(newQoSRequest);
			Assert.assertEquals(addedQoSResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedQoSResponse.getPayload());
			Assert.assertEquals(addedQoSResponse.getPayload().getStatus(), StatusType.ACTIVE.toString());
			
			/*ServiceResponse<QOS> updateQoSStatusResp = qosServiceClient
					.updateQoSStatus(addedQoSResponse.getPayload().getId(), StatusType.INACTIVE.toString());*/
			ServiceResponse<QoS> updateQoSStatusResp = qosServiceClient
					.updateQoSStatus(addedQoSResponse.getPayload().getId(),"INACTIVATE","test_user");
			
			Assert.assertEquals(updateQoSStatusResp.getStatus(), Status.OK);
			Assert.assertNotNull(updateQoSStatusResp.getPayload());
			Assert.assertEquals(updateQoSStatusResp.getPayload().getStatus(), StatusType.INACTIVE.toString());
			
			ServiceResponse<QoS> getResp = qosServiceClient.getQoS(addedQoSResponse.getPayload().getId());
			Assert.assertEquals(getResp.getStatus(), Status.OK);
			Assert.assertNotNull(getResp.getPayload());
			Assert.assertEquals(getResp.getPayload().getStatus(), StatusType.INACTIVE.toString());
		
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testInActivateQoS() throws Exception {
		try {
			QoS qos = newQoS();
			ServiceRequest<QoS> newQoSRequest = new ServiceRequest<QoS>(
					new ServiceHeader(), qos);
			ServiceResponse<QoS> addedQoSResponse = qosServiceClient
					.addQoS(newQoSRequest);
			Assert.assertEquals(addedQoSResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedQoSResponse.getPayload());
			Assert.assertEquals(addedQoSResponse.getPayload().getStatus(), StatusType.ACTIVE.toString());
			
			ServiceResponse<QoS> updateQoSStatusResp = qosServiceClient
					.updateQoSStatus(addedQoSResponse.getPayload().getId(), "INACTIVATE","test_user");
			Assert.assertEquals(updateQoSStatusResp.getStatus(), Status.OK);
			Assert.assertNotNull(updateQoSStatusResp.getPayload());
			Assert.assertEquals(updateQoSStatusResp.getPayload().getStatus(), StatusType.INACTIVE.toString());
			
			ServiceResponse<QoS> getResp = qosServiceClient.getQoS(addedQoSResponse.getPayload().getId());
			Assert.assertEquals(getResp.getStatus(), Status.OK);
			Assert.assertNotNull(getResp.getPayload());
			Assert.assertEquals(getResp.getPayload().getStatus(), StatusType.INACTIVE.toString());
		
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testActivateQoS() throws Exception {
		try {
			QoS qos = newQoS();
			qos.setStatus(StatusType.INACTIVE.toString());
			ServiceRequest<QoS> newQoSRequest = new ServiceRequest<QoS>(
					new ServiceHeader(), qos);
			ServiceResponse<QoS> addedQoSResponse = qosServiceClient
					.addQoS(newQoSRequest);
			Assert.assertEquals(addedQoSResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedQoSResponse.getPayload());
			Assert.assertEquals(addedQoSResponse.getPayload().getStatus(), StatusType.INACTIVE.toString());
			
			ServiceResponse<QoS> updateQoSStatusResp = qosServiceClient
					.updateQoSStatus(addedQoSResponse.getPayload().getId(), "ACTIVATE","test_user");
			Assert.assertEquals(updateQoSStatusResp.getStatus(), Status.OK);
			Assert.assertNotNull(updateQoSStatusResp.getPayload());
			Assert.assertEquals(updateQoSStatusResp.getPayload().getStatus(), StatusType.ACTIVE.toString());
			
			ServiceResponse<QoS> getResp = qosServiceClient.getQoS(addedQoSResponse.getPayload().getId());
			Assert.assertEquals(getResp.getStatus(), Status.OK);
			Assert.assertNotNull(getResp.getPayload());
			Assert.assertEquals(getResp.getPayload().getStatus(), StatusType.ACTIVE.toString());
		
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testDeleteQoSQueryParam() throws Exception {
		try {
			QoS qos = newQoS();
			qos.setStatus(StatusType.INACTIVE.toString());
			ServiceRequest<QoS> newQoSRequest = new ServiceRequest<QoS>(
					new ServiceHeader(), qos);
			ServiceResponse<QoS> addedQoSResponse = qosServiceClient
					.addQoS(newQoSRequest);
			Assert.assertEquals(addedQoSResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedQoSResponse.getPayload());
			Assert.assertEquals(addedQoSResponse.getPayload().getStatus(), StatusType.INACTIVE.toString());
			
			ServiceResponse<QoS> updateQoSStatusResp = qosServiceClient
					.updateQoSStatus(addedQoSResponse.getPayload().getId(), "DELETE","test_user");
			Assert.assertEquals(updateQoSStatusResp.getStatus(), Status.OK);
			Assert.assertNotNull(updateQoSStatusResp.getPayload());
			Assert.assertEquals(updateQoSStatusResp.getPayload().getStatus(), StatusType.DELETED.toString());
			
			ServiceResponse<QoS> getResp = qosServiceClient.getQoS(addedQoSResponse.getPayload().getId());
			Assert.assertEquals(getResp.getStatus(), Status.OK);
			Assert.assertNotNull(getResp.getPayload());
			Assert.assertEquals(getResp.getPayload().getStatus(), StatusType.DELETED.toString());
		
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	private boolean contains(List<QoS> qosList, String id) {
		for(QoS qos : qosList) {
			if(qos.getId().equals(id)) {
				return true;
			}
		}
		return false;
	}

}
