package com.walmart.platform.soari.registry.client;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.walmart.platform.soa.common.service.wrappers.ServiceHeader;
import com.walmart.platform.soa.common.service.wrappers.ServiceRequest;
import com.walmart.platform.soa.common.service.wrappers.ServiceResponse;
import com.walmart.platform.soa.common.service.wrappers.Status;
import com.walmart.platform.soari.registry.client.util.AbstractClientTest;
import com.walmart.platform.soari.registry.client.util.PlatformJAXRSHttpServer;
import com.walmart.platform.soari.registry.common.dto.NotificationDestination;
import com.walmart.platform.soari.registry.common.dto.NotificationDestinationList;
import com.walmart.platform.soari.registry.common.enums.SearchFieldType;
import com.walmart.platform.soari.registry.common.enums.StatusType;

public class NotificationDestinationServiceClientTest extends AbstractClientTest {
	private static final Logger LOG = LoggerFactory
			.getLogger(NotificationDestinationServiceClientTest.class);

	@BeforeClass
	public void startServers() throws Exception {
		Assert.assertTrue(launchServer(PlatformJAXRSHttpServer.class, true),
				"server did not launch correctly");
		init();
	}

	@Test(enabled = true)
	public void testGetNotificationDestinations() throws Exception {
		try {
			NotificationDestination notificationDestination1 = newNotificationDestination();
			ServiceRequest<NotificationDestination> newNotificationDestinationRequest1 = new ServiceRequest<NotificationDestination>(
					new ServiceHeader(), notificationDestination1);
			ServiceResponse<NotificationDestination> addedNotificationDestinationResponse1 = notificationDestinationServiceClient
					.addNotificationDestination(newNotificationDestinationRequest1);
			Assert.assertEquals(addedNotificationDestinationResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedNotificationDestinationResponse1.getPayload());
			notificationDestination1 = addedNotificationDestinationResponse1.getPayload();
			
			NotificationDestination notificationDestination2 = newNotificationDestination();
			ServiceRequest<NotificationDestination> newNotificationDestinationRequest2 = new ServiceRequest<NotificationDestination>(
					new ServiceHeader(), notificationDestination2);
			ServiceResponse<NotificationDestination> addedNotificationDestinationResponse2 = notificationDestinationServiceClient
					.addNotificationDestination(newNotificationDestinationRequest2);
			Assert.assertEquals(addedNotificationDestinationResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedNotificationDestinationResponse2.getPayload());
			notificationDestination2 = addedNotificationDestinationResponse2.getPayload();
			
			ServiceResponse<NotificationDestinationList> getNotificationDestinationsResp = notificationDestinationServiceClient
					.getNotificationDestinations();
			Assert.assertEquals(getNotificationDestinationsResp.getStatus(), Status.OK);
			Assert.assertNotNull(getNotificationDestinationsResp.getPayload());
			Assert.assertTrue(!getNotificationDestinationsResp.getPayload().getNotificationDestinations()
					.isEmpty());
			Assert.assertTrue(contains(getNotificationDestinationsResp.getPayload().getNotificationDestinations(), notificationDestination1.getId()));
			Assert.assertTrue(contains(getNotificationDestinationsResp.getPayload().getNotificationDestinations(), notificationDestination2.getId()));
	
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testGetActiveNotificationDestinationsQueryParam() throws Exception {
		try {
			NotificationDestination notificationDestination1 = newNotificationDestination();
			ServiceRequest<NotificationDestination> newNotificationDestinationRequest1 = new ServiceRequest<NotificationDestination>(
					new ServiceHeader(), notificationDestination1);
			ServiceResponse<NotificationDestination> addedNotificationDestinationResponse1 = notificationDestinationServiceClient
					.addNotificationDestination(newNotificationDestinationRequest1);
			Assert.assertEquals(addedNotificationDestinationResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedNotificationDestinationResponse1.getPayload());
			notificationDestination1 = addedNotificationDestinationResponse1.getPayload();
			
			NotificationDestination notificationDestination2 = newNotificationDestination();
			notificationDestination2.setStatus(StatusType.INACTIVE.toString());
			ServiceRequest<NotificationDestination> newNotificationDestinationRequest2 = new ServiceRequest<NotificationDestination>(
					new ServiceHeader(), notificationDestination2);
			ServiceResponse<NotificationDestination> addedNotificationDestinationResponse2 = notificationDestinationServiceClient
					.addNotificationDestination(newNotificationDestinationRequest2);
			Assert.assertEquals(addedNotificationDestinationResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedNotificationDestinationResponse2.getPayload());
			notificationDestination2 = addedNotificationDestinationResponse2.getPayload();
			
			ServiceResponse<NotificationDestinationList> getNotificationDestinationsResp = notificationDestinationServiceClient.searchNotificationDestinations(SearchFieldType.STATUS.toString(), StatusType.ACTIVE.toString());
					Assert.assertEquals(getNotificationDestinationsResp.getStatus(), Status.OK);
			Assert.assertNotNull(getNotificationDestinationsResp.getPayload());
			Assert.assertTrue(!getNotificationDestinationsResp.getPayload().getNotificationDestinations()
					.isEmpty());

			Assert.assertTrue(contains(getNotificationDestinationsResp.getPayload().getNotificationDestinations(), notificationDestination1.getId()));
			Assert.assertFalse(contains(getNotificationDestinationsResp.getPayload().getNotificationDestinations(), notificationDestination2.getId()));
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testGetInActiveNotificationDestinationsQueryParam() throws Exception {
		try {
			NotificationDestination notificationDestination1 = newNotificationDestination();
			ServiceRequest<NotificationDestination> newNotificationDestinationRequest1 = new ServiceRequest<NotificationDestination>(
					new ServiceHeader(), notificationDestination1);
			ServiceResponse<NotificationDestination> addedNotificationDestinationResponse1 = notificationDestinationServiceClient
					.addNotificationDestination(newNotificationDestinationRequest1);
			Assert.assertEquals(addedNotificationDestinationResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedNotificationDestinationResponse1.getPayload());
			notificationDestination1 = addedNotificationDestinationResponse1.getPayload();
			
			NotificationDestination notificationDestination2 = newNotificationDestination();
			notificationDestination2.setStatus(StatusType.INACTIVE.toString());
			ServiceRequest<NotificationDestination> newNotificationDestinationRequest2 = new ServiceRequest<NotificationDestination>(
					new ServiceHeader(), notificationDestination2);
			ServiceResponse<NotificationDestination> addedNotificationDestinationResponse2 = notificationDestinationServiceClient
					.addNotificationDestination(newNotificationDestinationRequest2);
			Assert.assertEquals(addedNotificationDestinationResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedNotificationDestinationResponse2.getPayload());
			notificationDestination2 = addedNotificationDestinationResponse2.getPayload();
			
			ServiceResponse<NotificationDestinationList> getNotificationDestinationsResp = notificationDestinationServiceClient.searchNotificationDestinations(SearchFieldType.STATUS.toString(),StatusType.INACTIVE.toString());
			Assert.assertEquals(getNotificationDestinationsResp.getStatus(), Status.OK);
			Assert.assertNotNull(getNotificationDestinationsResp.getPayload());
			Assert.assertTrue(!getNotificationDestinationsResp.getPayload().getNotificationDestinations()
					.isEmpty());

			Assert.assertFalse(contains(getNotificationDestinationsResp.getPayload().getNotificationDestinations(), notificationDestination1.getId()));
			Assert.assertTrue(contains(getNotificationDestinationsResp.getPayload().getNotificationDestinations(), notificationDestination2.getId()));
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testGetDeletedNotificationDestinationsQueryParam() throws Exception {
		try {
			NotificationDestination notificationDestination1 = newNotificationDestination();
			ServiceRequest<NotificationDestination> newNotificationDestinationRequest1 = new ServiceRequest<NotificationDestination>(
					new ServiceHeader(), notificationDestination1);
			ServiceResponse<NotificationDestination> addedNotificationDestinationResponse1 = notificationDestinationServiceClient
					.addNotificationDestination(newNotificationDestinationRequest1);
			Assert.assertEquals(addedNotificationDestinationResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedNotificationDestinationResponse1.getPayload());
			notificationDestination1 = addedNotificationDestinationResponse1.getPayload();
			
			NotificationDestination notificationDestination2 = newNotificationDestination();
			notificationDestination2.setStatus(StatusType.INACTIVE.toString());
			ServiceRequest<NotificationDestination> newNotificationDestinationRequest2 = new ServiceRequest<NotificationDestination>(
					new ServiceHeader(), notificationDestination2);
			ServiceResponse<NotificationDestination> addedNotificationDestinationResponse2 = notificationDestinationServiceClient
					.addNotificationDestination(newNotificationDestinationRequest2);
			Assert.assertEquals(addedNotificationDestinationResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedNotificationDestinationResponse2.getPayload());
			notificationDestination2 = addedNotificationDestinationResponse2.getPayload();
			
			NotificationDestination notificationDestination3 = newNotificationDestination();
			notificationDestination3.setStatus(StatusType.DELETED.toString());
			ServiceRequest<NotificationDestination> newNotificationDestinationRequest3 = new ServiceRequest<NotificationDestination>(
					new ServiceHeader(), notificationDestination3);
			ServiceResponse<NotificationDestination> addedNotificationDestinationResponse3 = notificationDestinationServiceClient
					.addNotificationDestination(newNotificationDestinationRequest3);
			Assert.assertEquals(addedNotificationDestinationResponse3.getStatus(), Status.OK);
			Assert.assertNotNull(addedNotificationDestinationResponse3.getPayload());
			notificationDestination3 = addedNotificationDestinationResponse3.getPayload();
			
			ServiceResponse<NotificationDestinationList> getNotificationDestinationsResp = notificationDestinationServiceClient.searchNotificationDestinations(SearchFieldType.STATUS.toString(),StatusType.DELETED.toString());
						Assert.assertEquals(getNotificationDestinationsResp.getStatus(), Status.OK);
			Assert.assertNotNull(getNotificationDestinationsResp.getPayload());
			Assert.assertTrue(!getNotificationDestinationsResp.getPayload().getNotificationDestinations()
					.isEmpty());

			Assert.assertFalse(contains(getNotificationDestinationsResp.getPayload().getNotificationDestinations(), notificationDestination1.getId()));
			Assert.assertFalse(contains(getNotificationDestinationsResp.getPayload().getNotificationDestinations(), notificationDestination2.getId()));
			Assert.assertTrue(contains(getNotificationDestinationsResp.getPayload().getNotificationDestinations(), notificationDestination3.getId()));
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testGetAvailableNotificationDestinationsQueryParam() throws Exception {
		try {
			NotificationDestination notificationDestination1 = newNotificationDestination();
			ServiceRequest<NotificationDestination> newNotificationDestinationRequest1 = new ServiceRequest<NotificationDestination>(
					new ServiceHeader(), notificationDestination1);
			ServiceResponse<NotificationDestination> addedNotificationDestinationResponse1 = notificationDestinationServiceClient
					.addNotificationDestination(newNotificationDestinationRequest1);
			Assert.assertEquals(addedNotificationDestinationResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedNotificationDestinationResponse1.getPayload());
			notificationDestination1 = addedNotificationDestinationResponse1.getPayload();
			
			NotificationDestination notificationDestination2 = newNotificationDestination();
			notificationDestination2.setStatus(StatusType.INACTIVE.toString());
			ServiceRequest<NotificationDestination> newNotificationDestinationRequest2 = new ServiceRequest<NotificationDestination>(
					new ServiceHeader(), notificationDestination2);
			ServiceResponse<NotificationDestination> addedNotificationDestinationResponse2 = notificationDestinationServiceClient
					.addNotificationDestination(newNotificationDestinationRequest2);
			Assert.assertEquals(addedNotificationDestinationResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedNotificationDestinationResponse2.getPayload());
			notificationDestination2 = addedNotificationDestinationResponse2.getPayload();
			
			NotificationDestination notificationDestination3 = newNotificationDestination();
			notificationDestination3.setStatus(StatusType.DELETED.toString());
			ServiceRequest<NotificationDestination> newNotificationDestinationRequest3 = new ServiceRequest<NotificationDestination>(
					new ServiceHeader(), notificationDestination3);
			ServiceResponse<NotificationDestination> addedNotificationDestinationResponse3 = notificationDestinationServiceClient
					.addNotificationDestination(newNotificationDestinationRequest3);
			Assert.assertEquals(addedNotificationDestinationResponse3.getStatus(), Status.OK);
			Assert.assertNotNull(addedNotificationDestinationResponse3.getPayload());
			notificationDestination3 = addedNotificationDestinationResponse3.getPayload();
		
			ServiceResponse<NotificationDestinationList> getNotificationDestinationsResp = notificationDestinationServiceClient.searchNotificationDestinations(SearchFieldType.STATUS.toString(),StatusType.AVAILABLE.toString());
			
			
			Assert.assertEquals(getNotificationDestinationsResp.getStatus(), Status.OK);
			Assert.assertNotNull(getNotificationDestinationsResp.getPayload());
			Assert.assertTrue(!getNotificationDestinationsResp.getPayload().getNotificationDestinations()
					.isEmpty());

			Assert.assertTrue(contains(getNotificationDestinationsResp.getPayload().getNotificationDestinations(), notificationDestination1.getId()));
			Assert.assertTrue(contains(getNotificationDestinationsResp.getPayload().getNotificationDestinations(), notificationDestination2.getId()));
			Assert.assertFalse(contains(getNotificationDestinationsResp.getPayload().getNotificationDestinations(), notificationDestination3.getId()));
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testsearchByName() throws Exception {
		try {
			long now = System.currentTimeMillis();
			NotificationDestination notificationDestination1 = newNotificationDestination();
			notificationDestination1.setName("NotificationDestination1 "+now+" Test");
			ServiceRequest<NotificationDestination> newNotificationDestinationRequest1 = new ServiceRequest<NotificationDestination>(
					new ServiceHeader(), notificationDestination1);
			ServiceResponse<NotificationDestination> addedNotificationDestinationResponse1 = notificationDestinationServiceClient
					.addNotificationDestination(newNotificationDestinationRequest1);
			Assert.assertEquals(addedNotificationDestinationResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedNotificationDestinationResponse1.getPayload());

			NotificationDestination notificationDestination2 = newNotificationDestination();
			notificationDestination2.setName("NotificationDestination "+now+" Test");
			ServiceRequest<NotificationDestination> newNotificationDestinationRequest2 = new ServiceRequest<NotificationDestination>(
					new ServiceHeader(), notificationDestination2);
			ServiceResponse<NotificationDestination> addedNotificationDestinationResponse2 = notificationDestinationServiceClient
					.addNotificationDestination(newNotificationDestinationRequest2);
			Assert.assertEquals(addedNotificationDestinationResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedNotificationDestinationResponse2.getPayload());
			
			NotificationDestination notificationDestination3 = newNotificationDestination();
			long now2 = System.currentTimeMillis();
			notificationDestination3.setName("NotificationDestination3 "+now2+" Test");
			ServiceRequest<NotificationDestination> newNotificationDestinationRequest3 = new ServiceRequest<NotificationDestination>(
					new ServiceHeader(), notificationDestination3);
			ServiceResponse<NotificationDestination> addedNotificationDestinationResponse3 = notificationDestinationServiceClient
					.addNotificationDestination(newNotificationDestinationRequest3);
			Assert.assertEquals(addedNotificationDestinationResponse3.getStatus(), Status.OK);
			Assert.assertNotNull(addedNotificationDestinationResponse3.getPayload());

			ServiceResponse<NotificationDestinationList> getNotificationDestinationsResp = notificationDestinationServiceClient.searchNotificationDestinations(SearchFieldType.NAME.toString(),String.valueOf(now));
			Assert.assertEquals(getNotificationDestinationsResp.getStatus(), Status.OK);
			Assert.assertNotNull(getNotificationDestinationsResp.getPayload());
			Assert.assertTrue(contains(getNotificationDestinationsResp.getPayload().getNotificationDestinations(), addedNotificationDestinationResponse1.getPayload().getId()));
			Assert.assertTrue(contains(getNotificationDestinationsResp.getPayload().getNotificationDestinations(), addedNotificationDestinationResponse2.getPayload().getId()));
			Assert.assertFalse(contains(getNotificationDestinationsResp.getPayload().getNotificationDestinations(), addedNotificationDestinationResponse3.getPayload().getId()));

		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testsearchByStatus() throws Exception {
		try {
			NotificationDestination notificationDestination1 = newNotificationDestination();
			ServiceRequest<NotificationDestination> newNotificationDestinationRequest1 = new ServiceRequest<NotificationDestination>(
					new ServiceHeader(), notificationDestination1);
			ServiceResponse<NotificationDestination> addedNotificationDestinationResponse1 = notificationDestinationServiceClient
					.addNotificationDestination(newNotificationDestinationRequest1);
			Assert.assertEquals(addedNotificationDestinationResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedNotificationDestinationResponse1.getPayload());

			NotificationDestination notificationDestination2 = newNotificationDestination();
			ServiceRequest<NotificationDestination> newNotificationDestinationRequest2 = new ServiceRequest<NotificationDestination>(
					new ServiceHeader(), notificationDestination2);
			ServiceResponse<NotificationDestination> addedNotificationDestinationResponse2 = notificationDestinationServiceClient
					.addNotificationDestination(newNotificationDestinationRequest2);
			Assert.assertEquals(addedNotificationDestinationResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedNotificationDestinationResponse2.getPayload());
			
			NotificationDestination notificationDestination3 = newNotificationDestination();
			notificationDestination3.setStatus(StatusType.DELETED.toString());
			ServiceRequest<NotificationDestination> newNotificationDestinationRequest3 = new ServiceRequest<NotificationDestination>(
					new ServiceHeader(), notificationDestination3);
			ServiceResponse<NotificationDestination> addedNotificationDestinationResponse3 = notificationDestinationServiceClient
					.addNotificationDestination(newNotificationDestinationRequest3);
			Assert.assertEquals(addedNotificationDestinationResponse3.getStatus(), Status.OK);
			Assert.assertNotNull(addedNotificationDestinationResponse3.getPayload());

			ServiceResponse<NotificationDestinationList> getNotificationDestinationsResp = notificationDestinationServiceClient.searchNotificationDestinations(SearchFieldType.STATUS.toString(),StatusType.ACTIVE.toString());
			Assert.assertEquals(getNotificationDestinationsResp.getStatus(), Status.OK);
			Assert.assertNotNull(getNotificationDestinationsResp.getPayload());
			
			Assert.assertTrue(contains(getNotificationDestinationsResp.getPayload().getNotificationDestinations(), addedNotificationDestinationResponse1.getPayload().getId()));
			Assert.assertTrue(contains(getNotificationDestinationsResp.getPayload().getNotificationDestinations(), addedNotificationDestinationResponse2.getPayload().getId()));
			Assert.assertFalse(contains(getNotificationDestinationsResp.getPayload().getNotificationDestinations(), addedNotificationDestinationResponse3.getPayload().getId()));

		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testGetNotificationDestination() throws Exception {
		try {
			NotificationDestination notificationDestination1 = newNotificationDestination();
			ServiceRequest<NotificationDestination> newNotificationDestinationRequest1 = new ServiceRequest<NotificationDestination>(
					new ServiceHeader(), notificationDestination1);
			ServiceResponse<NotificationDestination> addedNotificationDestinationResponse1 = notificationDestinationServiceClient
					.addNotificationDestination(newNotificationDestinationRequest1);
			Assert.assertEquals(addedNotificationDestinationResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedNotificationDestinationResponse1.getPayload());

			ServiceResponse<NotificationDestination> getNotificationDestinationResp = notificationDestinationServiceClient
					.getNotificationDestination(addedNotificationDestinationResponse1.getPayload().getId());
			Assert.assertEquals(getNotificationDestinationResp.getStatus(), Status.OK);
			Assert.assertNotNull(getNotificationDestinationResp.getPayload());
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testAddNotificationDestination() throws Exception {
		try {
			NotificationDestination notificationDestination = newNotificationDestination();
			ServiceRequest<NotificationDestination> newNotificationDestinationRequest = new ServiceRequest<NotificationDestination>(
					new ServiceHeader(), notificationDestination);
			ServiceResponse<NotificationDestination> addedNotificationDestinationResponse = notificationDestinationServiceClient
					.addNotificationDestination(newNotificationDestinationRequest);
			Assert.assertEquals(addedNotificationDestinationResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedNotificationDestinationResponse.getPayload());
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testUpdateNotificationDestination() throws Exception {
		try {
			NotificationDestination notificationDestination = newNotificationDestination();
			ServiceRequest<NotificationDestination> newNotificationDestinationRequest = new ServiceRequest<NotificationDestination>(
					new ServiceHeader(), notificationDestination);
			ServiceResponse<NotificationDestination> addedNotificationDestinationResponse = notificationDestinationServiceClient
					.addNotificationDestination(newNotificationDestinationRequest);
			Assert.assertEquals(addedNotificationDestinationResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedNotificationDestinationResponse.getPayload());

			NotificationDestination notificationDestinationToUpdate = addedNotificationDestinationResponse.getPayload();
			long now = System.currentTimeMillis();
			String updatedName = TEST_NOTIFICATION_DESTINATION_NAME + now;
			notificationDestinationToUpdate.setName(updatedName);
			notificationDestinationToUpdate.setStatus(StatusType.INACTIVE.toString());
			
			ServiceRequest<NotificationDestination> updateReq = new ServiceRequest<NotificationDestination>(
					new ServiceHeader(), notificationDestinationToUpdate);
			ServiceResponse<NotificationDestination> updateNotificationDestinationResp = notificationDestinationServiceClient.updateNotificationDestination(updateReq);
			Assert.assertEquals(addedNotificationDestinationResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedNotificationDestinationResponse.getPayload());
			Assert.assertEquals(updateNotificationDestinationResp.getPayload().getName(), updatedName);
			Assert.assertEquals(updateNotificationDestinationResp.getPayload().getStatus(), StatusType.INACTIVE.toString());
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testUpdateNotificationDestinationAddIfNotFound() throws Exception {
		try {
			NotificationDestination notificationDestination = newNotificationDestination();
			ServiceRequest<NotificationDestination> updateNotificationDestinationReq = new ServiceRequest<NotificationDestination>(
					new ServiceHeader(), notificationDestination);
			ServiceResponse<NotificationDestination> updateNotificationDestinationResp = notificationDestinationServiceClient
					.updateNotificationDestination(updateNotificationDestinationReq);
			Assert.assertEquals(updateNotificationDestinationResp.getStatus(), Status.OK);
			Assert.assertNotNull(updateNotificationDestinationResp.getPayload());

		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testUpdateNotificationDestinationCheckDuplicate() throws Exception {
		try {
			NotificationDestination notificationDestination1 = newNotificationDestination();
			ServiceRequest<NotificationDestination> newNotificationDestinationRequest1 = new ServiceRequest<NotificationDestination>(
					new ServiceHeader(), notificationDestination1);
			ServiceResponse<NotificationDestination> addedNotificationDestinationResponse1 = notificationDestinationServiceClient
					.addNotificationDestination(newNotificationDestinationRequest1);
			Assert.assertEquals(addedNotificationDestinationResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedNotificationDestinationResponse1.getPayload());

			NotificationDestination notificationDestination2 = newNotificationDestination();
			ServiceRequest<NotificationDestination> newNotificationDestinationRequest2 = new ServiceRequest<NotificationDestination>(
					new ServiceHeader(), notificationDestination2);
			ServiceResponse<NotificationDestination> addedNotificationDestinationResponse2 = notificationDestinationServiceClient
					.addNotificationDestination(newNotificationDestinationRequest2);
			Assert.assertEquals(addedNotificationDestinationResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedNotificationDestinationResponse2.getPayload());

			NotificationDestination notificationDestinationToUpdate = addedNotificationDestinationResponse2.getPayload();
			notificationDestinationToUpdate.setName(notificationDestination1.getName());

			ServiceRequest<NotificationDestination> updateReq = new ServiceRequest<NotificationDestination>(
					new ServiceHeader(), notificationDestinationToUpdate);
			ServiceResponse<NotificationDestination> uopdateResp = notificationDestinationServiceClient
					.updateNotificationDestination(updateReq);
			Assert.assertEquals(uopdateResp.getStatus(), Status.FAIL);
			Assert.assertNull(uopdateResp.getPayload());

		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.assertTrue(true);
		}
	}

	@Test(enabled = true)
	public void testAddNotificationDestinationCheckDuplicate() throws Exception {
		try {
			NotificationDestination notificationDestination1 = newNotificationDestination();
			ServiceRequest<NotificationDestination> newNotificationDestinationRequest1 = new ServiceRequest<NotificationDestination>(
					new ServiceHeader(), notificationDestination1);
			ServiceResponse<NotificationDestination> addedNotificationDestinationResponse1 = notificationDestinationServiceClient
					.addNotificationDestination(newNotificationDestinationRequest1);
			Assert.assertEquals(addedNotificationDestinationResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedNotificationDestinationResponse1.getPayload());

			NotificationDestination notificationDestination2 = newNotificationDestination();
			notificationDestination2.setName(notificationDestination1.getName());
			ServiceRequest<NotificationDestination> newNotificationDestinationRequest2 = new ServiceRequest<NotificationDestination>(
					new ServiceHeader(), notificationDestination2);
			ServiceResponse<NotificationDestination> addedNotificationDestinationResponse2 = notificationDestinationServiceClient
					.addNotificationDestination(newNotificationDestinationRequest2);
			Assert.assertEquals(addedNotificationDestinationResponse2.getStatus(), Status.FAIL);
			Assert.assertNull(addedNotificationDestinationResponse2.getPayload());
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.assertTrue(true, "NotificationDestination name must be unique");
		}
	}

	@Test(enabled = true)
	public void testActionNotificationDestinationInactivate() throws Exception {
		try {
			NotificationDestination notificationDestination = newNotificationDestination();
			ServiceRequest<NotificationDestination> newNotificationDestinationRequest = new ServiceRequest<NotificationDestination>(
					new ServiceHeader(), notificationDestination);
			ServiceResponse<NotificationDestination> addedNotificationDestinationResponse = notificationDestinationServiceClient
					.addNotificationDestination(newNotificationDestinationRequest);
			Assert.assertEquals(addedNotificationDestinationResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedNotificationDestinationResponse.getPayload());
			Assert.assertEquals(addedNotificationDestinationResponse.getPayload().getStatus(), StatusType.ACTIVE.toString());
			
			ServiceResponse<NotificationDestination> updateNotificationDestinationStatusResp = notificationDestinationServiceClient
					.updateNotificationDestinationStatus(addedNotificationDestinationResponse.getPayload().getId(), "INACTIVATE","test_user");
			Assert.assertEquals(updateNotificationDestinationStatusResp.getStatus(), Status.OK);
			Assert.assertNotNull(updateNotificationDestinationStatusResp.getPayload());
			Assert.assertEquals(updateNotificationDestinationStatusResp.getPayload().getStatus(), StatusType.INACTIVE.toString());
			
			ServiceResponse<NotificationDestination> getResp = notificationDestinationServiceClient.getNotificationDestination(addedNotificationDestinationResponse.getPayload().getId());
			Assert.assertEquals(getResp.getStatus(), Status.OK);
			Assert.assertNotNull(getResp.getPayload());
			Assert.assertEquals(getResp.getPayload().getStatus(), StatusType.INACTIVE.toString());
		
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testActionNotificationDestinationActivate() throws Exception {
		try {
			NotificationDestination notificationDestination = newNotificationDestination();
			notificationDestination.setStatus(StatusType.INACTIVE.toString());
			ServiceRequest<NotificationDestination> newNotificationDestinationRequest = new ServiceRequest<NotificationDestination>(
					new ServiceHeader(), notificationDestination);
			ServiceResponse<NotificationDestination> addedNotificationDestinationResponse = notificationDestinationServiceClient
					.addNotificationDestination(newNotificationDestinationRequest);
			Assert.assertEquals(addedNotificationDestinationResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedNotificationDestinationResponse.getPayload());
			Assert.assertEquals(addedNotificationDestinationResponse.getPayload().getStatus(), StatusType.INACTIVE.toString());
			
			ServiceResponse<NotificationDestination> updateNotificationDestinationStatusResp = notificationDestinationServiceClient
					.updateNotificationDestinationStatus(addedNotificationDestinationResponse.getPayload().getId(), "ACTIVATE","test_user");
			Assert.assertEquals(updateNotificationDestinationStatusResp.getStatus(), Status.OK);
			Assert.assertNotNull(updateNotificationDestinationStatusResp.getPayload());
			Assert.assertEquals(updateNotificationDestinationStatusResp.getPayload().getStatus(), StatusType.ACTIVE.toString());
			
			ServiceResponse<NotificationDestination> getResp = notificationDestinationServiceClient.getNotificationDestination(addedNotificationDestinationResponse.getPayload().getId());
			Assert.assertEquals(getResp.getStatus(), Status.OK);
			Assert.assertNotNull(getResp.getPayload());
			Assert.assertEquals(getResp.getPayload().getStatus(), StatusType.ACTIVE.toString());
		
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testActionNotificationDestinationDelete() throws Exception {
		try {
			NotificationDestination notificationDestination = newNotificationDestination();
			notificationDestination.setStatus(StatusType.INACTIVE.toString());
			ServiceRequest<NotificationDestination> newNotificationDestinationRequest = new ServiceRequest<NotificationDestination>(
					new ServiceHeader(), notificationDestination);
			ServiceResponse<NotificationDestination> addedNotificationDestinationResponse = notificationDestinationServiceClient
					.addNotificationDestination(newNotificationDestinationRequest);
			Assert.assertEquals(addedNotificationDestinationResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedNotificationDestinationResponse.getPayload());
			Assert.assertEquals(addedNotificationDestinationResponse.getPayload().getStatus(), StatusType.INACTIVE.toString());
			
			ServiceResponse<NotificationDestination> updateNotificationDestinationStatusResp = notificationDestinationServiceClient
					.updateNotificationDestinationStatus(addedNotificationDestinationResponse.getPayload().getId(), "DELETE","test_user");
			Assert.assertEquals(updateNotificationDestinationStatusResp.getStatus(), Status.OK);
			Assert.assertNotNull(updateNotificationDestinationStatusResp.getPayload());
			Assert.assertEquals(updateNotificationDestinationStatusResp.getPayload().getStatus(), StatusType.DELETED.toString());
			
			ServiceResponse<NotificationDestination> getResp = notificationDestinationServiceClient.getNotificationDestination(addedNotificationDestinationResponse.getPayload().getId());
			Assert.assertEquals(getResp.getStatus(), Status.OK);
			Assert.assertNotNull(getResp.getPayload());
			Assert.assertEquals(getResp.getPayload().getStatus(), StatusType.DELETED.toString());
		
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	private boolean contains(List<NotificationDestination> notificationDestinations, String id) {
		for(NotificationDestination notificationDestination : notificationDestinations) {
			if(notificationDestination.getId().equals(id)) {
				return true;
			}
		}
		return false;
	}

}
