package com.walmart.platform.soari.registry.client;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.walmart.platform.soa.common.service.wrappers.ServiceHeader;
import com.walmart.platform.soa.common.service.wrappers.ServiceRequest;
import com.walmart.platform.soa.common.service.wrappers.ServiceResponse;
import com.walmart.platform.soa.common.service.wrappers.Status;
import com.walmart.platform.soa.policy.definition.model.ContextType;
import com.walmart.platform.soari.registry.client.util.AbstractClientTest;
import com.walmart.platform.soari.registry.client.util.PlatformJAXRSHttpServer;
import com.walmart.platform.soari.registry.common.dto.Policy;
import com.walmart.platform.soari.registry.common.dto.PolicyList;
import com.walmart.platform.soari.registry.common.enums.FlowType;
import com.walmart.platform.soari.registry.common.enums.SearchFieldType;
import com.walmart.platform.soari.registry.common.enums.StatusType;

public class PolicyServiceClientTest extends AbstractClientTest {
	private static final Logger LOG = LoggerFactory
			.getLogger(PolicyServiceClientTest.class);

	@BeforeClass
	public void startServers() throws Exception {
		Assert.assertTrue(launchServer(PlatformJAXRSHttpServer.class, true),
				"server did not launch correctly");
		init();
	}

	@Test(enabled = true)
	public void testGetPolicies() throws Exception {
		try {
			Policy policy1 = newPolicy();
			ServiceRequest<Policy> newPolicyRequest1 = new ServiceRequest<Policy>(
					new ServiceHeader(), policy1);
			ServiceResponse<Policy> addedPolicyResponse1 = policyServiceClient
					.addPolicy(newPolicyRequest1);
			Assert.assertEquals(addedPolicyResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedPolicyResponse1.getPayload());
			policy1 = addedPolicyResponse1.getPayload();
			
			Policy policy2 = newPolicy();
			ServiceRequest<Policy> newPolicyRequest2 = new ServiceRequest<Policy>(
					new ServiceHeader(), policy2);
			ServiceResponse<Policy> addedPolicyResponse2 = policyServiceClient
					.addPolicy(newPolicyRequest2);
			Assert.assertEquals(addedPolicyResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedPolicyResponse2.getPayload());
			policy2 = addedPolicyResponse2.getPayload();
			
			ServiceResponse<PolicyList> getPoliciesResp = policyServiceClient
					.getPolicies();
			Assert.assertEquals(getPoliciesResp.getStatus(), Status.OK);
			Assert.assertNotNull(getPoliciesResp.getPayload());
			Assert.assertTrue(!getPoliciesResp.getPayload().getPolicies()
					.isEmpty());
			Assert.assertTrue(contains(getPoliciesResp.getPayload().getPolicies(), policy1.getId()));
			Assert.assertTrue(contains(getPoliciesResp.getPayload().getPolicies(), policy2.getId()));
	
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testGetActivePoliciesQueryParam() throws Exception {
		try {
			Policy policy1 = newPolicy();
			ServiceRequest<Policy> newPolicyRequest1 = new ServiceRequest<Policy>(
					new ServiceHeader(), policy1);
			ServiceResponse<Policy> addedPolicyResponse1 = policyServiceClient
					.addPolicy(newPolicyRequest1);
			Assert.assertEquals(addedPolicyResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedPolicyResponse1.getPayload());
			policy1 = addedPolicyResponse1.getPayload();
			
			Policy policy2 = newPolicy();
			policy2.setStatus(StatusType.INACTIVE.toString());
			ServiceRequest<Policy> newPolicyRequest2 = new ServiceRequest<Policy>(
					new ServiceHeader(), policy2);
			ServiceResponse<Policy> addedPolicyResponse2 = policyServiceClient
					.addPolicy(newPolicyRequest2);
			Assert.assertEquals(addedPolicyResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedPolicyResponse2.getPayload());
			policy2 = addedPolicyResponse2.getPayload();
			
			ServiceResponse<PolicyList> getPoliciesResp = policyServiceClient.searchPolicies(SearchFieldType.STATUS.toString(), StatusType.ACTIVE.toString());
					Assert.assertEquals(getPoliciesResp.getStatus(), Status.OK);
			Assert.assertNotNull(getPoliciesResp.getPayload());
			Assert.assertTrue(!getPoliciesResp.getPayload().getPolicies()
					.isEmpty());

			Assert.assertTrue(contains(getPoliciesResp.getPayload().getPolicies(), policy1.getId()));
			Assert.assertFalse(contains(getPoliciesResp.getPayload().getPolicies(), policy2.getId()));
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testGetInActivePoliciesQueryParam() throws Exception {
		try {
			Policy policy1 = newPolicy();
			ServiceRequest<Policy> newPolicyRequest1 = new ServiceRequest<Policy>(
					new ServiceHeader(), policy1);
			ServiceResponse<Policy> addedPolicyResponse1 = policyServiceClient
					.addPolicy(newPolicyRequest1);
			Assert.assertEquals(addedPolicyResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedPolicyResponse1.getPayload());
			policy1 = addedPolicyResponse1.getPayload();
			
			Policy policy2 = newPolicy();
			policy2.setStatus(StatusType.INACTIVE.toString());
			ServiceRequest<Policy> newPolicyRequest2 = new ServiceRequest<Policy>(
					new ServiceHeader(), policy2);
			ServiceResponse<Policy> addedPolicyResponse2 = policyServiceClient
					.addPolicy(newPolicyRequest2);
			Assert.assertEquals(addedPolicyResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedPolicyResponse2.getPayload());
			policy2 = addedPolicyResponse2.getPayload();
			
			ServiceResponse<PolicyList> getPoliciesResp = policyServiceClient.searchPolicies(SearchFieldType.STATUS.toString(),StatusType.INACTIVE.toString());
			Assert.assertEquals(getPoliciesResp.getStatus(), Status.OK);
			Assert.assertNotNull(getPoliciesResp.getPayload());
			Assert.assertTrue(!getPoliciesResp.getPayload().getPolicies()
					.isEmpty());

			Assert.assertFalse(contains(getPoliciesResp.getPayload().getPolicies(), policy1.getId()));
			Assert.assertTrue(contains(getPoliciesResp.getPayload().getPolicies(), policy2.getId()));
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testGetDeletedPoliciesQueryParam() throws Exception {
		try {
			Policy policy1 = newPolicy();
			ServiceRequest<Policy> newPolicyRequest1 = new ServiceRequest<Policy>(
					new ServiceHeader(), policy1);
			ServiceResponse<Policy> addedPolicyResponse1 = policyServiceClient
					.addPolicy(newPolicyRequest1);
			Assert.assertEquals(addedPolicyResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedPolicyResponse1.getPayload());
			policy1 = addedPolicyResponse1.getPayload();
			
			Policy policy2 = newPolicy();
			policy2.setStatus(StatusType.INACTIVE.toString());
			ServiceRequest<Policy> newPolicyRequest2 = new ServiceRequest<Policy>(
					new ServiceHeader(), policy2);
			ServiceResponse<Policy> addedPolicyResponse2 = policyServiceClient
					.addPolicy(newPolicyRequest2);
			Assert.assertEquals(addedPolicyResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedPolicyResponse2.getPayload());
			policy2 = addedPolicyResponse2.getPayload();
			
			Policy policy3 = newPolicy();
			policy3.setStatus(StatusType.DELETED.toString());
			ServiceRequest<Policy> newPolicyRequest3 = new ServiceRequest<Policy>(
					new ServiceHeader(), policy3);
			ServiceResponse<Policy> addedPolicyResponse3 = policyServiceClient
					.addPolicy(newPolicyRequest3);
			Assert.assertEquals(addedPolicyResponse3.getStatus(), Status.OK);
			Assert.assertNotNull(addedPolicyResponse3.getPayload());
			policy3 = addedPolicyResponse3.getPayload();
			
			ServiceResponse<PolicyList> getPoliciesResp = policyServiceClient.searchPolicies(SearchFieldType.STATUS.toString(),StatusType.DELETED.toString());
						Assert.assertEquals(getPoliciesResp.getStatus(), Status.OK);
			Assert.assertNotNull(getPoliciesResp.getPayload());
			Assert.assertTrue(!getPoliciesResp.getPayload().getPolicies()
					.isEmpty());

			Assert.assertFalse(contains(getPoliciesResp.getPayload().getPolicies(), policy1.getId()));
			Assert.assertFalse(contains(getPoliciesResp.getPayload().getPolicies(), policy2.getId()));
			Assert.assertTrue(contains(getPoliciesResp.getPayload().getPolicies(), policy3.getId()));
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testGetAvailablePoliciesQueryParam() throws Exception {
		try {
			Policy policy1 = newPolicy();
			ServiceRequest<Policy> newPolicyRequest1 = new ServiceRequest<Policy>(
					new ServiceHeader(), policy1);
			ServiceResponse<Policy> addedPolicyResponse1 = policyServiceClient
					.addPolicy(newPolicyRequest1);
			Assert.assertEquals(addedPolicyResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedPolicyResponse1.getPayload());
			policy1 = addedPolicyResponse1.getPayload();
			
			Policy policy2 = newPolicy();
			policy2.setStatus(StatusType.INACTIVE.toString());
			ServiceRequest<Policy> newPolicyRequest2 = new ServiceRequest<Policy>(
					new ServiceHeader(), policy2);
			ServiceResponse<Policy> addedPolicyResponse2 = policyServiceClient
					.addPolicy(newPolicyRequest2);
			Assert.assertEquals(addedPolicyResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedPolicyResponse2.getPayload());
			policy2 = addedPolicyResponse2.getPayload();
			
			Policy policy3 = newPolicy();
			policy3.setStatus(StatusType.DELETED.toString());
			ServiceRequest<Policy> newPolicyRequest3 = new ServiceRequest<Policy>(
					new ServiceHeader(), policy3);
			ServiceResponse<Policy> addedPolicyResponse3 = policyServiceClient
					.addPolicy(newPolicyRequest3);
			Assert.assertEquals(addedPolicyResponse3.getStatus(), Status.OK);
			Assert.assertNotNull(addedPolicyResponse3.getPayload());
			policy3 = addedPolicyResponse3.getPayload();
		
			ServiceResponse<PolicyList> getPoliciesResp = policyServiceClient.searchPolicies(SearchFieldType.STATUS.toString(),StatusType.AVAILABLE.toString());
			
			
			Assert.assertEquals(getPoliciesResp.getStatus(), Status.OK);
			Assert.assertNotNull(getPoliciesResp.getPayload());
			Assert.assertTrue(!getPoliciesResp.getPayload().getPolicies()
					.isEmpty());

			Assert.assertTrue(contains(getPoliciesResp.getPayload().getPolicies(), policy1.getId()));
			Assert.assertTrue(contains(getPoliciesResp.getPayload().getPolicies(), policy2.getId()));
			Assert.assertFalse(contains(getPoliciesResp.getPayload().getPolicies(), policy3.getId()));
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testSearchPoliciesByName() throws Exception {
		try {
			long now = System.currentTimeMillis();
			Policy policy1 = newPolicy();
			policy1.setName("Policy1 "+now+" Test");
			ServiceRequest<Policy> newPolicyRequest1 = new ServiceRequest<Policy>(
					new ServiceHeader(), policy1);
			ServiceResponse<Policy> addedPolicyResponse1 = policyServiceClient
					.addPolicy(newPolicyRequest1);
			Assert.assertEquals(addedPolicyResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedPolicyResponse1.getPayload());

			Policy policy2 = newPolicy();
			policy2.setName("Policy "+now+" Test");
			ServiceRequest<Policy> newPolicyRequest2 = new ServiceRequest<Policy>(
					new ServiceHeader(), policy2);
			ServiceResponse<Policy> addedPolicyResponse2 = policyServiceClient
					.addPolicy(newPolicyRequest2);
			Assert.assertEquals(addedPolicyResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedPolicyResponse2.getPayload());
			
			Policy policy3 = newPolicy();
			long now2 = System.currentTimeMillis();
			policy3.setName("Policy3 "+now2+" Test");
			ServiceRequest<Policy> newPolicyRequest3 = new ServiceRequest<Policy>(
					new ServiceHeader(), policy3);
			ServiceResponse<Policy> addedPolicyResponse3 = policyServiceClient
					.addPolicy(newPolicyRequest3);
			Assert.assertEquals(addedPolicyResponse3.getStatus(), Status.OK);
			Assert.assertNotNull(addedPolicyResponse3.getPayload());

			ServiceResponse<PolicyList> getPoliciesResp = policyServiceClient.searchPolicies(SearchFieldType.NAME.toString(),String.valueOf(now));
			Assert.assertEquals(getPoliciesResp.getStatus(), Status.OK);
			Assert.assertNotNull(getPoliciesResp.getPayload());
			Assert.assertTrue(contains(getPoliciesResp.getPayload().getPolicies(), addedPolicyResponse1.getPayload().getId()));
			Assert.assertTrue(contains(getPoliciesResp.getPayload().getPolicies(), addedPolicyResponse2.getPayload().getId()));
			Assert.assertFalse(contains(getPoliciesResp.getPayload().getPolicies(), addedPolicyResponse3.getPayload().getId()));

		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testSearchPoliciesByStatus() throws Exception {
		try {
			Policy policy1 = newPolicy();
			ServiceRequest<Policy> newPolicyRequest1 = new ServiceRequest<Policy>(
					new ServiceHeader(), policy1);
			ServiceResponse<Policy> addedPolicyResponse1 = policyServiceClient
					.addPolicy(newPolicyRequest1);
			Assert.assertEquals(addedPolicyResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedPolicyResponse1.getPayload());

			Policy policy2 = newPolicy();
			ServiceRequest<Policy> newPolicyRequest2 = new ServiceRequest<Policy>(
					new ServiceHeader(), policy2);
			ServiceResponse<Policy> addedPolicyResponse2 = policyServiceClient
					.addPolicy(newPolicyRequest2);
			Assert.assertEquals(addedPolicyResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedPolicyResponse2.getPayload());
			
			Policy policy3 = newPolicy();
			policy3.setStatus(StatusType.DELETED.toString());
			ServiceRequest<Policy> newPolicyRequest3 = new ServiceRequest<Policy>(
					new ServiceHeader(), policy3);
			ServiceResponse<Policy> addedPolicyResponse3 = policyServiceClient
					.addPolicy(newPolicyRequest3);
			Assert.assertEquals(addedPolicyResponse3.getStatus(), Status.OK);
			Assert.assertNotNull(addedPolicyResponse3.getPayload());

			ServiceResponse<PolicyList> getPoliciesResp = policyServiceClient.searchPolicies(SearchFieldType.STATUS.toString(),StatusType.ACTIVE.toString());
			Assert.assertEquals(getPoliciesResp.getStatus(), Status.OK);
			Assert.assertNotNull(getPoliciesResp.getPayload());
			
			Assert.assertTrue(contains(getPoliciesResp.getPayload().getPolicies(), addedPolicyResponse1.getPayload().getId()));
			Assert.assertTrue(contains(getPoliciesResp.getPayload().getPolicies(), addedPolicyResponse2.getPayload().getId()));
			Assert.assertFalse(contains(getPoliciesResp.getPayload().getPolicies(), addedPolicyResponse3.getPayload().getId()));

		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testGetPolicy() throws Exception {
		try {
			Policy policy1 = newPolicy();
			ServiceRequest<Policy> newPolicyRequest1 = new ServiceRequest<Policy>(
					new ServiceHeader(), policy1);
			ServiceResponse<Policy> addedPolicyResponse1 = policyServiceClient
					.addPolicy(newPolicyRequest1);
			Assert.assertEquals(addedPolicyResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedPolicyResponse1.getPayload());

			ServiceResponse<Policy> getPolicyResp = policyServiceClient
					.getPolicy(addedPolicyResponse1.getPayload().getId());
			Assert.assertEquals(getPolicyResp.getStatus(), Status.OK);
			Assert.assertNotNull(getPolicyResp.getPayload());
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testAddPolicy() throws Exception {
		try {
			Policy policy = newPolicy();
			policy.setData(getSamplePolicyData());
			ServiceRequest<Policy> newPolicyRequest = new ServiceRequest<Policy>(
					new ServiceHeader(), policy);
			ServiceResponse<Policy> addedPolicyResponse = policyServiceClient
					.addPolicy(newPolicyRequest);
			Assert.assertEquals(addedPolicyResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedPolicyResponse.getPayload());
			Assert.assertEquals(addedPolicyResponse.getPayload().getData(), policy.getData());
			Assert.assertEquals(addedPolicyResponse.getPayload().getOrder(), policy.getOrder());
			Assert.assertEquals(addedPolicyResponse.getPayload().getFlow(), policy.getFlow());
			Assert.assertEquals(addedPolicyResponse.getPayload().getContext(), policy.getContext());
				} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testUpdatePolicy() throws Exception {
		try {
			Policy policy = newPolicy();
			ServiceRequest<Policy> newPolicyRequest = new ServiceRequest<Policy>(
					new ServiceHeader(), policy);
			ServiceResponse<Policy> addedPolicyResponse = policyServiceClient
					.addPolicy(newPolicyRequest);
			Assert.assertEquals(addedPolicyResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedPolicyResponse.getPayload());
			Assert.assertEquals(addedPolicyResponse.getPayload().getContext(), ContextType.SERVICE.toString());
			
			Policy policyToUpdate = addedPolicyResponse.getPayload();
			long now = System.currentTimeMillis();
			String updatedName = TEST_POLICY_NAME + now;
			policyToUpdate.setName(updatedName);
			policyToUpdate.setStatus(StatusType.INACTIVE.toString());
			policyToUpdate.setOrder(2);
			policyToUpdate.setFlow(FlowType.RESPONSE.toString());
			policyToUpdate.setModifiedBy("Test Modifier");
			policyToUpdate.setContext(ContextType.ESB.toString());
			ServiceRequest<Policy> updateReq = new ServiceRequest<Policy>(
					new ServiceHeader(), policyToUpdate);
			ServiceResponse<Policy> updatePolicyResp = policyServiceClient.updatePolicy(updateReq);
			Assert.assertEquals(updatePolicyResp.getStatus(), Status.OK);
			Assert.assertNotNull(updatePolicyResp.getPayload());
			Assert.assertEquals(updatePolicyResp.getPayload().getName(), updatedName);
			Assert.assertEquals(updatePolicyResp.getPayload().getStatus(), StatusType.INACTIVE.toString());
			Assert.assertEquals(updatePolicyResp.getPayload().getOrder(), Integer.valueOf(2));
			Assert.assertEquals(updatePolicyResp.getPayload().getFlow(), FlowType.RESPONSE.toString());
			Assert.assertEquals(updatePolicyResp.getPayload().getContext(), ContextType.ESB.toString());
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testUpdatePolicyAddIfNotFound() throws Exception {
		try {
			Policy policy = newPolicy();
			ServiceRequest<Policy> updatePolicyReq = new ServiceRequest<Policy>(
					new ServiceHeader(), policy);
			ServiceResponse<Policy> updatePolicyResp = policyServiceClient
					.updatePolicy(updatePolicyReq);
			Assert.assertEquals(updatePolicyResp.getStatus(), Status.OK);
			Assert.assertNotNull(updatePolicyResp.getPayload());

		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testUpdatePolicyCheckDuplicate() throws Exception {
		try {
			Policy policy1 = newPolicy();
			ServiceRequest<Policy> newPolicyRequest1 = new ServiceRequest<Policy>(
					new ServiceHeader(), policy1);
			ServiceResponse<Policy> addedPolicyResponse1 = policyServiceClient
					.addPolicy(newPolicyRequest1);
			Assert.assertEquals(addedPolicyResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedPolicyResponse1.getPayload());

			Policy policy2 = newPolicy();
			ServiceRequest<Policy> newPolicyRequest2 = new ServiceRequest<Policy>(
					new ServiceHeader(), policy2);
			ServiceResponse<Policy> addedPolicyResponse2 = policyServiceClient
					.addPolicy(newPolicyRequest2);
			Assert.assertEquals(addedPolicyResponse2.getStatus(), Status.OK);
			Assert.assertNotNull(addedPolicyResponse2.getPayload());

			Policy policyToUpdate = addedPolicyResponse2.getPayload();
			policyToUpdate.setName(policy1.getName());

			ServiceRequest<Policy> updateReq = new ServiceRequest<Policy>(
					new ServiceHeader(), policyToUpdate);
			ServiceResponse<Policy> uopdateResp = policyServiceClient
					.updatePolicy(updateReq);
			Assert.assertEquals(uopdateResp.getStatus(), Status.FAIL);
			Assert.assertNull(uopdateResp.getPayload());

		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.assertTrue(true);
		}
	}

	@Test(enabled = true)
	public void testAddPolicyCheckDuplicate() throws Exception {
		try {
			Policy policy1 = newPolicy();
			ServiceRequest<Policy> newPolicyRequest1 = new ServiceRequest<Policy>(
					new ServiceHeader(), policy1);
			ServiceResponse<Policy> addedPolicyResponse1 = policyServiceClient
					.addPolicy(newPolicyRequest1);
			Assert.assertEquals(addedPolicyResponse1.getStatus(), Status.OK);
			Assert.assertNotNull(addedPolicyResponse1.getPayload());

			Policy policy2 = newPolicy();
			policy2.setName(policy1.getName());
			ServiceRequest<Policy> newPolicyRequest2 = new ServiceRequest<Policy>(
					new ServiceHeader(), policy2);
			ServiceResponse<Policy> addedPolicyResponse2 = policyServiceClient
					.addPolicy(newPolicyRequest2);
			Assert.assertEquals(addedPolicyResponse2.getStatus(), Status.FAIL);
			Assert.assertNull(addedPolicyResponse2.getPayload());
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.assertTrue(true, "Policy name must be unique");
		}
	}

	@Test(enabled = true)
	public void testActionPolicyInactivate() throws Exception {
		try {
			Policy policy = newPolicy();
			ServiceRequest<Policy> newPolicyRequest = new ServiceRequest<Policy>(
					new ServiceHeader(), policy);
			ServiceResponse<Policy> addedPolicyResponse = policyServiceClient
					.addPolicy(newPolicyRequest);
			Assert.assertEquals(addedPolicyResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedPolicyResponse.getPayload());
			Assert.assertEquals(addedPolicyResponse.getPayload().getStatus(), StatusType.ACTIVE.toString());
			
			ServiceResponse<Policy> updatePolicyStatusResp = policyServiceClient
					.updatePolicyStatus(addedPolicyResponse.getPayload().getId(), "INACTIVATE","test_user");
			Assert.assertEquals(updatePolicyStatusResp.getStatus(), Status.OK);
			Assert.assertNotNull(updatePolicyStatusResp.getPayload());
			Assert.assertEquals(updatePolicyStatusResp.getPayload().getStatus(), StatusType.INACTIVE.toString());
			
			ServiceResponse<Policy> getResp = policyServiceClient.getPolicy(addedPolicyResponse.getPayload().getId());
			Assert.assertEquals(getResp.getStatus(), Status.OK);
			Assert.assertNotNull(getResp.getPayload());
			Assert.assertEquals(getResp.getPayload().getStatus(), StatusType.INACTIVE.toString());
		
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testActionPolicyActivate() throws Exception {
		try {
			Policy policy = newPolicy();
			policy.setStatus(StatusType.INACTIVE.toString());
			ServiceRequest<Policy> newPolicyRequest = new ServiceRequest<Policy>(
					new ServiceHeader(), policy);
			ServiceResponse<Policy> addedPolicyResponse = policyServiceClient
					.addPolicy(newPolicyRequest);
			Assert.assertEquals(addedPolicyResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedPolicyResponse.getPayload());
			Assert.assertEquals(addedPolicyResponse.getPayload().getStatus(), StatusType.INACTIVE.toString());
			
			ServiceResponse<Policy> updatePolicyStatusResp = policyServiceClient
					.updatePolicyStatus(addedPolicyResponse.getPayload().getId(), "ACTIVATE","test_user");
			Assert.assertEquals(updatePolicyStatusResp.getStatus(), Status.OK);
			Assert.assertNotNull(updatePolicyStatusResp.getPayload());
			Assert.assertEquals(updatePolicyStatusResp.getPayload().getStatus(), StatusType.ACTIVE.toString());
			
			ServiceResponse<Policy> getResp = policyServiceClient.getPolicy(addedPolicyResponse.getPayload().getId());
			Assert.assertEquals(getResp.getStatus(), Status.OK);
			Assert.assertNotNull(getResp.getPayload());
			Assert.assertEquals(getResp.getPayload().getStatus(), StatusType.ACTIVE.toString());
		
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test(enabled = true)
	public void testActionPolicyDelete() throws Exception {
		try {
			Policy policy = newPolicy();
			policy.setStatus(StatusType.INACTIVE.toString());
			ServiceRequest<Policy> newPolicyRequest = new ServiceRequest<Policy>(
					new ServiceHeader(), policy);
			ServiceResponse<Policy> addedPolicyResponse = policyServiceClient
					.addPolicy(newPolicyRequest);
			Assert.assertEquals(addedPolicyResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedPolicyResponse.getPayload());
			Assert.assertEquals(addedPolicyResponse.getPayload().getStatus(), StatusType.INACTIVE.toString());
			
			ServiceResponse<Policy> updatePolicyStatusResp = policyServiceClient
					.updatePolicyStatus(addedPolicyResponse.getPayload().getId(), "DELETE","test_user");
			Assert.assertEquals(updatePolicyStatusResp.getStatus(), Status.OK);
			Assert.assertNotNull(updatePolicyStatusResp.getPayload());
			Assert.assertEquals(updatePolicyStatusResp.getPayload().getStatus(), StatusType.DELETED.toString());
			
			ServiceResponse<Policy> getResp = policyServiceClient.getPolicy(addedPolicyResponse.getPayload().getId());
			Assert.assertEquals(getResp.getStatus(), Status.OK);
			Assert.assertNotNull(getResp.getPayload());
			Assert.assertEquals(getResp.getPayload().getStatus(), StatusType.DELETED.toString());
		
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	private boolean contains(List<Policy> policies, String id) {
		for(Policy policy : policies) {
			if(policy.getId().equals(id)) {
				return true;
			}
		}
		return false;
	}

}
