package com.walmart.platform.soari.registry.client;

import java.util.ArrayList;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.walmart.platform.soa.common.service.wrappers.ServiceHeader;
import com.walmart.platform.soa.common.service.wrappers.ServiceRequest;
import com.walmart.platform.soa.common.service.wrappers.ServiceResponse;
import com.walmart.platform.soa.common.service.wrappers.Status;
import com.walmart.platform.soari.registry.client.util.AbstractClientTest;
import com.walmart.platform.soari.registry.client.util.PlatformJAXRSHttpServer;
import com.walmart.platform.soari.registry.common.dto.Audit;
import com.walmart.platform.soari.registry.common.dto.AuditList;
import com.walmart.platform.soari.registry.common.dto.Policy;
import com.walmart.platform.soari.registry.common.dto.QoS;
import com.walmart.platform.soari.registry.common.dto.RegistryOptionList;
import com.walmart.platform.soari.registry.common.dto.Service;
import com.walmart.platform.soari.registry.common.dto.ServiceVersion;
import com.walmart.platform.soari.registry.common.enums.FlowType;
import com.walmart.platform.soari.registry.common.enums.RegistryPolicyCodeType;
import com.walmart.platform.soari.registry.common.enums.StatusType;

public class AuditServiceClientTest extends AbstractClientTest {

	private static final Logger LOG = LoggerFactory
			.getLogger(AuditServiceClientTest.class);

	int artifactIndex = 0;
	
	@BeforeClass
	public void startServers() throws Exception {
		Assert.assertTrue(launchServer(PlatformJAXRSHttpServer.class, true),
				"server did not launch correctly");
		init();
		ServiceResponse<RegistryOptionList> gerRegistryOptionResp = registryOptionServiceClient.getOptionsByType(RegistryPolicyCodeType.CMDB_ARTIFACT);
		Assert.assertEquals(gerRegistryOptionResp.getStatus(), Status.OK);
		Assert.assertNotNull(gerRegistryOptionResp.getPayload());
		Assert.assertNotNull(gerRegistryOptionResp.getPayload().getOptions());
		Assert.assertFalse(gerRegistryOptionResp.getPayload().getOptions().isEmpty());
		cmdbArtifacts.addAll(gerRegistryOptionResp.getPayload().getOptions());
	}

	@Test(enabled = true)
	public void testUpdatePolicyStatus() throws Exception {
		try {
			Policy policy = newPolicy();
			ServiceRequest<Policy> newPolicyRequest = new ServiceRequest<Policy>(
					new ServiceHeader(), policy);
			ServiceResponse<Policy> addedPolicyResponse = policyServiceClient
					.addPolicy(newPolicyRequest);
			Assert.assertEquals(addedPolicyResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedPolicyResponse.getPayload());

			policy = addedPolicyResponse.getPayload();

			ServiceResponse<Policy> updatePolicyResp = policyServiceClient
					.updatePolicyStatus(policy.getId(), "INACTIVATE",
							"Test_User");
			Assert.assertEquals(updatePolicyResp.getStatus(), Status.OK);
			policy = updatePolicyResp.getPayload();

			Assert.assertNotNull(policy);
			Assert.assertEquals(policy.getStatus(),
					StatusType.INACTIVE.toString());

			ServiceResponse<AuditList> auditResp = auditServiceClient
					.getAuditByEntityId(policy.getId(), 1);
			Assert.assertEquals(auditResp.getStatus(), Status.OK);
			Assert.assertNotNull(auditResp.getPayload());
			Assert.assertNotNull(auditResp.getPayload().getAuditList());
			Assert.assertFalse((auditResp.getPayload().getAuditList().isEmpty()));

			Audit audit = auditResp.getPayload().getAuditList().get(0);
			Assert.assertEquals(audit.getOldValue(),
					StatusType.ACTIVE.toString());
			Assert.assertEquals(audit.getNewValue(),
					StatusType.INACTIVE.toString());

		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testUpdateQoSStatus() throws Exception {
		try {
			QoS qos = newQoS();
			ServiceRequest<QoS> newQoSRequest = new ServiceRequest<QoS>(
					new ServiceHeader(), qos);
			ServiceResponse<QoS> addedQoSResponse = qosServiceClient
					.addQoS(newQoSRequest);
			Assert.assertEquals(addedQoSResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedQoSResponse.getPayload());

			qos = addedQoSResponse.getPayload();

			ServiceResponse<QoS> updateQoSResp = qosServiceClient
					.updateQoSStatus(qos.getId(), "INACTIVATE", "Test_User");
			Assert.assertEquals(updateQoSResp.getStatus(), Status.OK);
			qos = updateQoSResp.getPayload();

			Assert.assertNotNull(qos);
			Assert.assertEquals(qos.getStatus(), StatusType.INACTIVE.toString());

			ServiceResponse<AuditList> auditResp = auditServiceClient
					.getAuditByEntityId(qos.getId(), 1);
			Assert.assertEquals(auditResp.getStatus(), Status.OK);
			Assert.assertNotNull(auditResp.getPayload());
			Assert.assertNotNull(auditResp.getPayload().getAuditList());
			Assert.assertFalse((auditResp.getPayload().getAuditList().isEmpty()));

			Audit audit = auditResp.getPayload().getAuditList().get(0);
			Assert.assertEquals(audit.getOldValue(),
					StatusType.ACTIVE.toString());
			Assert.assertEquals(audit.getNewValue(),
					StatusType.INACTIVE.toString());

		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testUpdateServiceStatus() throws Exception {
		try {
			Service service = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceRequest<Service> newQoSRequest = new ServiceRequest<Service>(
					new ServiceHeader(), service);
			ServiceResponse<Service> addedServiceResponse = registryServiceClient
					.addService(newQoSRequest);
			Assert.assertEquals(addedServiceResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse.getPayload());

			service = addedServiceResponse.getPayload();

			ServiceResponse<Service> updateServiceResp = registryServiceClient
					.updateServiceStatus(service.getId(), "INACTIVATE",
							"Test_User");
			Assert.assertEquals(updateServiceResp.getStatus(), Status.OK);
			service = updateServiceResp.getPayload();

			Assert.assertNotNull(service);
			Assert.assertEquals(service.getStatus(),
					StatusType.INACTIVE.toString());

			ServiceResponse<AuditList> auditResp = auditServiceClient
					.getAuditByEntityId(service.getId(), 1);
			Assert.assertEquals(auditResp.getStatus(), Status.OK);
			Assert.assertNotNull(auditResp.getPayload());
			Assert.assertNotNull(auditResp.getPayload().getAuditList());
			Assert.assertFalse((auditResp.getPayload().getAuditList().isEmpty()));

			Audit audit = auditResp.getPayload().getAuditList().get(0);
			Assert.assertEquals(audit.getOldValue(),
					StatusType.ACTIVE.toString());
			Assert.assertEquals(audit.getNewValue(),
					StatusType.INACTIVE.toString());

		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testUpdateServiceVersionStatus() throws Exception {
		try {
			Service service = newService(cmdbArtifacts.get(artifactIndex++).getCode());
			ServiceRequest<Service> newQoSRequest = new ServiceRequest<Service>(
					new ServiceHeader(), service);
			ServiceResponse<Service> addedServiceResponse = registryServiceClient
					.addService(newQoSRequest);
			Assert.assertEquals(addedServiceResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse.getPayload());

			service = addedServiceResponse.getPayload();

			ServiceVersion serviceVersion = newServiceVersion();
			ServiceRequest<ServiceVersion> newServiceVersionRequest = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion);
			ServiceResponse<ServiceVersion> addServiceVersionResp = registryServiceClient
					.addServiceVersion(service.getId(),
							newServiceVersionRequest);
			Assert.assertEquals(addServiceVersionResp.getStatus(), Status.OK);
			Assert.assertNotNull(addServiceVersionResp.getPayload());

			serviceVersion = addServiceVersionResp.getPayload();

			ServiceResponse<ServiceVersion> updateServiceVersionResp = registryServiceClient
					.updateServiceVersionStatus(serviceVersion.getId(),
							"INACTIVATE", "Test_User");
			Assert.assertEquals(updateServiceVersionResp.getStatus(), Status.OK);
			serviceVersion = updateServiceVersionResp.getPayload();

			Assert.assertNotNull(service);
			Assert.assertEquals(serviceVersion.getStatus(),
					StatusType.INACTIVE.toString());

			ServiceResponse<AuditList> auditResp = auditServiceClient
					.getAuditByEntityId(serviceVersion.getId(), 1);
			Assert.assertEquals(auditResp.getStatus(), Status.OK);
			Assert.assertNotNull(auditResp.getPayload());
			Assert.assertNotNull(auditResp.getPayload().getAuditList());
			Assert.assertFalse((auditResp.getPayload().getAuditList().isEmpty()));

			Audit audit = auditResp.getPayload().getAuditList().get(0);
			Assert.assertEquals(audit.getOldValue(),
					StatusType.ACTIVE.toString());
			Assert.assertEquals(audit.getNewValue(),
					StatusType.INACTIVE.toString());

		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testUpdateQoS() throws Exception {
		try {
			Policy policy = newPolicy();
			ServiceRequest<Policy> newPolicyRequest = new ServiceRequest<Policy>(
					new ServiceHeader(), policy);
			ServiceResponse<Policy> addedPolicyResponse = policyServiceClient
					.addPolicy(newPolicyRequest);
			Assert.assertEquals(addedPolicyResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedPolicyResponse.getPayload());

			Policy policyToUpdate = addedPolicyResponse.getPayload();
			long now = System.currentTimeMillis();
			String updatedName = TEST_POLICY_NAME + now;
			policyToUpdate.setName(updatedName);
			policyToUpdate.setStatus(StatusType.INACTIVE.toString());
			policyToUpdate.setOrder(2);
			policyToUpdate.setFlow(FlowType.RESPONSE.toString());
			policyToUpdate.setModifiedBy("Test Modifier");
			ServiceRequest<Policy> updateReq = new ServiceRequest<Policy>(
					new ServiceHeader(), policyToUpdate);
			ServiceResponse<Policy> updatePolicyResp = policyServiceClient
					.updatePolicy(updateReq);
			Assert.assertEquals(addedPolicyResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedPolicyResponse.getPayload());
			Assert.assertEquals(updatePolicyResp.getPayload().getName(),
					updatedName);
			Assert.assertEquals(updatePolicyResp.getPayload().getStatus(),
					StatusType.INACTIVE.toString());
			Assert.assertEquals(addedPolicyResponse.getPayload().getOrder(),
					Integer.valueOf(2));
			Assert.assertEquals(addedPolicyResponse.getPayload().getFlow(),
					FlowType.RESPONSE.toString());

			ServiceResponse<AuditList> auditResp = auditServiceClient
					.getAuditByEntityId(updatePolicyResp.getPayload().getId(),
							2);
			Assert.assertEquals(auditResp.getStatus(), Status.OK);
			Assert.assertNotNull(auditResp.getPayload());
			Assert.assertNotNull(auditResp.getPayload().getAuditList());
			Assert.assertFalse((auditResp.getPayload().getAuditList().isEmpty()));
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}

	@Test(enabled = true)
	public void testUpdateServiceVersionWithAddDeleteQoSAndPolicy()
			throws Exception {
		try {

			Policy policy1 = newPolicy();
			policy1.setName(policy1.getName() + "_1");
			ServiceRequest<Policy> addPolicyReq1 = new ServiceRequest<Policy>(
					new ServiceHeader(), policy1);
			ServiceResponse<Policy> addPolicyResp1 = policyServiceClient
					.addPolicy(addPolicyReq1);
			Assert.assertEquals(addPolicyResp1.getStatus(), Status.OK);
			Assert.assertNotNull(addPolicyResp1.getPayload());
			policy1 = addPolicyResp1.getPayload();

			Policy policy2 = newPolicy();
			policy2.setName(policy2.getName() + "_2");
			ServiceRequest<Policy> addPolicyReq2 = new ServiceRequest<Policy>(
					new ServiceHeader(), policy2);
			ServiceResponse<Policy> addPolicyResp2 = policyServiceClient
					.addPolicy(addPolicyReq2);
			Assert.assertEquals(addPolicyResp2.getStatus(), Status.OK);
			Assert.assertNotNull(addPolicyResp2.getPayload());
			policy2 = addPolicyResp2.getPayload();

			Service service = newService(cmdbArtifacts.get(artifactIndex++).getCode());

			ServiceRequest<Service> newServiceRequest = new ServiceRequest<Service>(
					new ServiceHeader(), service);
			ServiceResponse<Service> addedServiceResponse = registryServiceClient
					.addService(newServiceRequest);
			Assert.assertEquals(addedServiceResponse.getStatus(), Status.OK);
			Assert.assertNotNull(addedServiceResponse.getPayload());

			service = addedServiceResponse.getPayload();
			ServiceVersion serviceVersion = newServiceVersion();

			QoS qos1 = addQoS();
			QoS qos2 = addQoS();

			serviceVersion.getQoSParameters().add(qos1);
			serviceVersion.getQoSParameters().add(qos2);

			serviceVersion.getPolicies().add(policy1);
			serviceVersion.getPolicies().add(policy2);

			ServiceRequest<ServiceVersion> addServiceVersionReq = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion);

			ServiceResponse<ServiceVersion> addServiceVersionRes = registryServiceClient
					.addServiceVersion(service.getId(), addServiceVersionReq);
			Assert.assertEquals(addServiceVersionRes.getStatus(), Status.OK);
			Assert.assertNotNull(addServiceVersionRes.getPayload());

			Assert.assertTrue(!addServiceVersionRes.getPayload()
					.getQoSParameters().isEmpty());
			Assert.assertEquals(addServiceVersionRes.getPayload()
					.getQoSParameters().size(), 2);
			Assert.assertEquals(addServiceVersionRes.getPayload().getPolicies()
					.size(), 2);

			ServiceResponse<ServiceVersion> getServiceVersionRes = registryServiceClient
					.getServiceVersion(service.getId(),
							serviceVersion.getSerVersion());
			Assert.assertEquals(getServiceVersionRes.getStatus(), Status.OK);
			Assert.assertNotNull(getServiceVersionRes.getPayload());

			Assert.assertEquals(getServiceVersionRes.getPayload()
					.getQoSParameters().size(), 2);
			Assert.assertEquals(addServiceVersionRes.getPayload().getPolicies()
					.size(), 2);

			Policy policy3 = newPolicy();
			policy3.setName(policy3.getName() + "_3");
			ServiceRequest<Policy> addPolicyReq3 = new ServiceRequest<Policy>(
					new ServiceHeader(), policy3);
			ServiceResponse<Policy> addPolicyResp3 = policyServiceClient
					.addPolicy(addPolicyReq3);
			Assert.assertEquals(addPolicyResp3.getStatus(), Status.OK);
			Assert.assertNotNull(addPolicyResp3.getPayload());
			policy3 = addPolicyResp3.getPayload();

			// Remove policy2 and Add policy3
			List<Policy> policies = new ArrayList<Policy>(0);
			policies.add(policy1);
			policies.add(policy3);
			serviceVersion = addServiceVersionRes.getPayload();
			serviceVersion.setPolicies(policies);

			QoS qos3 = addQoS();

			List<QoS> qosParams = new ArrayList<QoS>(0);
			QoS qosUpdate = serviceVersion.getQoSParameters().get(0);
			QoS qosDelete = serviceVersion.getQoSParameters().get(1);
			String newValue = qosUpdate.getValue() + "_UPDATED";
			qosUpdate.setValue(newValue);
			qosParams.add(qosUpdate);
			qosParams.add(qos3);
			serviceVersion.setQoSParameters(qosParams);

			serviceVersion.setSerVersion(TEST_SERVICE_VERSION_2);
			ServiceRequest<ServiceVersion> updateServiceVersionReq = new ServiceRequest<ServiceVersion>(
					new ServiceHeader(), serviceVersion);

			ServiceResponse<ServiceVersion> updateServiceVersionResp = registryServiceClient
					.updateServiceVersion(service.getId(),
							updateServiceVersionReq);

			Assert.assertEquals(updateServiceVersionResp.getStatus(), Status.OK);
			Assert.assertNotNull(updateServiceVersionResp.getPayload());
			Assert.assertEquals(updateServiceVersionResp.getPayload()
					.getSerVersion(), TEST_SERVICE_VERSION_2);

			Assert.assertTrue(!updateServiceVersionResp.getPayload()
					.getQoSParameters().isEmpty());
			Assert.assertEquals(updateServiceVersionResp.getPayload()
					.getQoSParameters().size(), 2);

			Assert.assertEquals(updateServiceVersionResp.getPayload()
					.getPolicies().size(), 2);

			qosUpdate = getQoS(updateServiceVersionResp.getPayload()
					.getQoSParameters(), qosUpdate.getId());
			Assert.assertNotNull(qosUpdate);
			Assert.assertEquals(qosUpdate.getValue(), newValue);

			qosDelete = getQoS(updateServiceVersionResp.getPayload()
					.getQoSParameters(), qosDelete.getId());
			Assert.assertNull(qosDelete);

			ServiceResponse<AuditList> auditResp = auditServiceClient
					.getAuditByEntityId(service.getId(), null);
			Assert.assertEquals(auditResp.getStatus(), Status.OK);
			Assert.assertNotNull(auditResp.getPayload());
			Assert.assertNotNull(auditResp.getPayload().getAuditList());
			Assert.assertFalse((auditResp.getPayload().getAuditList().isEmpty()));

		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}
	}
	
}
