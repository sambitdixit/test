package com.walmart.platform.soari.registry.client;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.walmart.platform.soa.common.HeaderElements;
import com.walmart.platform.soa.common.service.wrappers.ServiceResponse;
import com.walmart.platform.soa.common.service.wrappers.Status;
import com.walmart.platform.soa.http.client.PlatformHttpClient;
import com.walmart.platform.soari.registry.common.dto.Service;
import com.walmart.platform.soari.registry.common.dto.ServiceList;

public class ServiceDiscoveryTest {
	private static final Logger LOG = LoggerFactory
			.getLogger(ServiceDiscoveryTest.class);

	@SuppressWarnings({ "unchecked", "deprecation" })
	@Test(enabled = true)
	public void testServiceAccessByConsumerDicsoveryStrategy() throws Exception {
		try {
			PlatformHttpClient httpClient = PlatformHttpClient.getInstance();
			httpClient.setExtraClass(new Class[] { String.class, Service.class,
					ServiceList.class });

			Map<String, String> headers = new HashMap<String, String>();
			setMandatoryHeaders(headers);
			headers.put(HeaderElements.CONSUMER_ID,
					"841bfe07c3bb46dba6cee0ffdd5b4ffd");
			headers.put(HeaderElements.SERVICE_DISCOVERY_STRATEGY,
					HeaderElements.DiscoveryStrategy.CONSUMER.toString());
			ServiceResponse<ServiceList> response = httpClient.get("/registry/service", null, headers, ServiceResponse.class,ServiceList.class);
			Assert.assertEquals(response.getStatus(), Status.OK);
			Assert.assertNotNull(response.getPayload());
			Assert.assertNotNull(response.getPayload().getServices());
			Assert.assertFalse(response.getPayload().getServices().isEmpty());
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}

	}

	@SuppressWarnings({ "unchecked", "deprecation", "unused" })
	@Test(enabled = true)
	public void testServiceAccessByConsumerDicsoveryStrategyInvalidConsumerId()
			throws Exception {
		try {
			PlatformHttpClient httpClient = PlatformHttpClient.getInstance();
			httpClient.setExtraClass(new Class[] { String.class, Service.class,
					ServiceList.class });
			Map<String, String> headers = new HashMap<String, String>();
			setMandatoryHeaders(headers);
			headers.put(HeaderElements.CONSUMER_ID, "abc");
			headers.put(HeaderElements.SERVICE_DISCOVERY_STRATEGY,
					HeaderElements.DiscoveryStrategy.CONSUMER.toString());
			ServiceResponse<ServiceList> response = httpClient.get(
					"/registry/service",null,headers,ServiceResponse.class,ServiceList.class);
			Assert.fail("Invalid consumer id");
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.assertTrue(true, ex.getMessage());
		}

	}

	@SuppressWarnings({ "unchecked", "deprecation" })
	@Test(enabled = true)
	public void testServiceAccessByServiceDicsoveryStrategy() throws Exception {
		try {
			PlatformHttpClient httpClient = PlatformHttpClient.getInstance();
			httpClient.setExtraClass(new Class[] { String.class, Service.class,
					ServiceList.class });

			Map<String, String> headers = new HashMap<String, String>();
			setMandatoryHeaders(headers);
			headers.put(HeaderElements.CONSUMER_ID,
					"a3b799098c9e493a9b3a04ba4daedae0");
			headers.put(HeaderElements.SERVICE_DISCOVERY_STRATEGY,
					HeaderElements.DiscoveryStrategy.SERVICE.toString());
			ServiceResponse<ServiceList> response = httpClient.get(
					"/registry/service",null,headers,ServiceResponse.class,ServiceList.class);
			Assert.assertEquals(response.getStatus(), Status.OK);
			Assert.assertNotNull(response.getPayload());
			Assert.assertNotNull(response.getPayload().getServices());
			Assert.assertFalse(response.getPayload().getServices().isEmpty());
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.fail(ex.getMessage());
		}

	}

	@SuppressWarnings({ "unchecked", "deprecation", "unused" })
	@Test(enabled = true)
	public void testServiceAccessByServiceDicsoveryStrategyInvalidVersion()
			throws Exception {
		try {
			PlatformHttpClient httpClient = PlatformHttpClient.getInstance();
			httpClient.setExtraClass(new Class[] { String.class, Service.class,
					ServiceList.class });

			Map<String, String> headers = new HashMap<String, String>();
			setMandatoryHeaders(headers);
			headers.put(HeaderElements.CONSUMER_ID,
					"a3b799098c9e493a9b3a04ba4daedae0");
			headers.put(HeaderElements.SERVICE_VERSION, "3.0.20");
			headers.put(HeaderElements.SERVICE_DISCOVERY_STRATEGY,
					HeaderElements.DiscoveryStrategy.SERVICE.toString());
			ServiceResponse<ServiceList> response = httpClient.get(
					"/registry/service",null,headers,ServiceResponse.class,ServiceList.class);
			Assert.fail("Invalid consumer id");
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			Assert.assertTrue(true, ex.getMessage());
		}

	}

	private void setMandatoryHeaders(Map<String, String> headers) {

		headers.put(HeaderElements.CONSUMER_ID,
				"a3b799098c9e493a9b3a04ba4daedae0");
		headers.put(HeaderElements.SERVICE_VERSION, "3.0.16");
		headers.put(HeaderElements.SERVICE_ENV, "qa");
		headers.put(HeaderElements.SERVICE_NAME, "ServiceRegistry");
	}

}
