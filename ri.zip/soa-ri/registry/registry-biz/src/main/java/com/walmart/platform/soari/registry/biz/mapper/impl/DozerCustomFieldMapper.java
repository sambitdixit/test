package com.walmart.platform.soari.registry.biz.mapper.impl;

import org.dozer.CustomFieldMapper;
import org.dozer.classmap.ClassMap;
import org.dozer.fieldmap.FieldMap;
import org.hibernate.Hibernate;

/**
 * Custom Dozer Filed Mapper class to avoid copying the persistent objects
 * when their value is not initialized.
 * 
 * @author sbonde
 *
 */
public class DozerCustomFieldMapper implements CustomFieldMapper {

	/**
	 * Overridden method will avoid copying object to non initialized persistent
	 * objects. This is to avoid copying the objects with fetch = FetchType.LAZY
	 * 
	 * @see org.dozer.CustomFieldMapper#mapField(java.lang.Object,
	 * java.lang.Object, java.lang.Object, org.dozer.classmap.ClassMap,
	 * org.dozer.fieldmap.FieldMap)
	 * 
	 */
	@Override
	public boolean mapField(Object source, Object destination,
			Object sourceFieldValue, ClassMap classMap, FieldMap fieldMapping) {

		/*
		 * The method returns 'true' if the argument is already initialized, or
		 * is not a proxy or collection.
		 * 
		 * We return false under the above scenario.
		 */

		return !Hibernate.isInitialized(sourceFieldValue);
	}

}
