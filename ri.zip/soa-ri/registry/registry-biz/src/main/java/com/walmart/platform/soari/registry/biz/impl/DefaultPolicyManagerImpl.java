package com.walmart.platform.soari.registry.biz.impl;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.walmart.platform.kernel.exception.layers.business.BusinessException;
import com.walmart.platform.kernel.exception.layers.dao.DataAccessException;
import com.walmart.platform.soa.config.RegistryConfig;
import com.walmart.platform.soari.registry.biz.api.DefaultPolicyManager;
import com.walmart.platform.soari.registry.biz.mapper.api.DozerMapper;
import com.walmart.platform.soari.registry.biz.notification.api.EventHandler;
import com.walmart.platform.soari.registry.biz.util.BizUtil;
import com.walmart.platform.soari.registry.common.dto.DefaultPolicy;
import com.walmart.platform.soari.registry.common.enums.EntityType;
import com.walmart.platform.soari.registry.common.enums.RegistryPolicyCodeType;
import com.walmart.platform.soari.registry.common.enums.SearchFieldType;
import com.walmart.platform.soari.registry.domain.DefaultPolicyDO;
import com.walmart.platform.soari.registry.domain.RegistryPolicyCode;
import com.walmart.platform.soari.registry.domain.dao.api.AuditDAO;
import com.walmart.platform.soari.registry.domain.dao.api.DefaultPolicyDAO;
import com.walmart.platform.soari.registry.domain.dao.impl.RegistryPolicyCodeDAOImpl;
import com.walmart.platform.soari.registry.server.common.error.ErrorCode;
import com.walmart.platform.soari.registry.server.common.exception.ExceptionHandler;
import com.walmart.platform.soari.registry.server.common.exception.ServiceRegistryException;
import com.walmart.platform.soari.registry.domain.util.Timed;
import com.walmart.platform.soari.registry.server.common.util.CommonConstants;

/**
 * A class to perform business logic for mapping/transformation of DTO to Domain
 * objects and invoke Persistence APIs
 * 
 * @author smenon2
 * 
 */
@org.springframework.stereotype.Service("DefaultPolicyManager")
@Timed
public class DefaultPolicyManagerImpl implements DefaultPolicyManager {

	private static final Logger LOG = LoggerFactory
			.getLogger(DefaultPolicyManagerImpl.class);

	@Autowired
	private DefaultPolicyDAO policyDAO;

	@Autowired
	private DozerMapper mapper;

	@Autowired
	private ExceptionHandler exceptionHandler;

	@Autowired
	private AuditDAO auditDAO;

	@Autowired
	private EventHandler eventHandler;

	@Autowired
	private RegistryConfig registryConfig;

	@Override
	@Transactional(rollbackFor = { BusinessException.class })
	public List<DefaultPolicy> getPolicies() throws BusinessException {
		LOG.debug("Executing getPolicies ");
		List<DefaultPolicy> policies = new ArrayList<DefaultPolicy>(0);
		try {
			List<DefaultPolicyDO> policyDOs = policyDAO.findAll();
			policies = mapper.mapToList(policyDOs, DefaultPolicy.class);
		} catch (Exception ex) {
			LOG.error(MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE,
					ex.getMessage()));
			exceptionHandler.handleBusinessException(ex);
		}
		return policies;
	}

	/**
	 * Method to get a DefaultPolicy by Id
	 */
	@Override
	@Transactional(rollbackFor = { BusinessException.class })
	public DefaultPolicy getPolicyById(String id) throws BusinessException {
		LOG.debug("Executing getPolicyById for : " + id);
		DefaultPolicy result = null;
		try {
			if (StringUtils.isEmpty(id)) {
				throw new ServiceRegistryException(
						ErrorCode.BIZ_INVALID_POLICY_ID,
						CommonConstants.INVALID_POLICY_NAME);
			} else {
				DefaultPolicyDO policyDO = policyDAO.findOne(id);
				if (policyDO != null) {
					result = mapper.map(policyDO, DefaultPolicy.class);
				}
			}
		} catch (Exception ex) {
			LOG.error(MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE,
					ex.getMessage()));
			exceptionHandler.handleBusinessException(ex);
		}
		return result;
	}

	/**
	 * Method to create a new DefaultPolicy
	 */
	@Override
	@Transactional(rollbackFor = { BusinessException.class })
	@Timed
	public DefaultPolicy addPolicy(DefaultPolicy policy)
			throws BusinessException {
		LOG.debug("Executing addPolicy " + policy.getName());
		DefaultPolicy result = null;
		try {
			//BizUtil.validateCreatedBy(EntityType.POLICY, policy.getCreatedBy());
			validatePolicyName(policy.getName());
			if (isDuplicate(policy.getName(), null)) {
				throw new ServiceRegistryException(
						ErrorCode.BIZ_DUPLICATE_POLICY, MessageFormat.format(
								CommonConstants.DUPLICATE_POLICY_NAME,
								policy.getName()));
			} else {
				if (!BizUtil.isValidXml(policy.getData())) {
					throw new ServiceRegistryException(
							ErrorCode.BIZ_INVALID_POLICY_XML,
							CommonConstants.INVALID_POLICY_XML_STRING);
				}
				DefaultPolicyDO policyDO = mapper.map(policy,
						DefaultPolicyDO.class);
				policyDO = policyDAO.save(policyDO);
				//audit(policyDO);
				result = mapper.map(policyDO, DefaultPolicy.class);
			}
		} catch (Exception ex) {
			LOG.error(MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE,
					ex.getMessage()));
			exceptionHandler.handleBusinessException(ex);
		}
		return result;
	}

	/**
	 * Method to update an existing DefaultPolicy. This will first checks if
	 * DefaultPolicy exists. Also checks if other DefaultPolicy has the same
	 * name, If DefaultPolicy doesn't exists then create a new DefaultPolicy
	 */
	@Override
	@Transactional(rollbackFor = { BusinessException.class })
	public DefaultPolicy updatePolicy(DefaultPolicy policy)
			throws BusinessException {
		String policyId = policy.getId();
		LOG.debug("Executing updatePolicy [id, name] : [" + policyId + ","
				+ policy.getName() + "]");
		DefaultPolicy result = null;
		try {
			validatePolicyName(policy.getName());
			if (isDuplicate(policy.getName(), policyId)) {
				throw new ServiceRegistryException(
						ErrorCode.BIZ_DUPLICATE_POLICY, MessageFormat.format(
								CommonConstants.DUPLICATE_POLICY_NAME,
								policy.getName()));
			} else {
				if (!BizUtil.isValidXml(policy.getData())) {
					throw new ServiceRegistryException(
							ErrorCode.BIZ_INVALID_POLICY_XML,
							CommonConstants.INVALID_POLICY_XML_STRING);
				}
				DefaultPolicyDO policyDO = null;
				if (!StringUtils.isEmpty(policyId)) {
					policyDO = policyDAO.findOne(policyId);
				}
				// DefaultPolicy doesn't exists then create new DefaultPolicy
				if (policyDO == null) {
					// BizUtil.validateCreatedBy(EntityType.POLICY,
					// policy.getCreatedBy());
					policyDO = mapper.map(policy, DefaultPolicyDO.class);
					policyDO = policyDAO.save(policyDO);
					//audit(policyDO);
					result = mapper.map(policyDO, DefaultPolicy.class);
					return result;
				}
				// BizUtil.validateModifiedBy(EntityType.POLICY,
				// policy.getModifiedBy());
				// List<AuditDO> audits = BizUtil
				// .getAuditDetails(policy, policyDO);
				// if (!audits.isEmpty()) {
				mapper.map(policy, policyDO);
				policyDO = policyDAO.save(policyDO);
				// auditDAO.save(audits);
				result = mapper.map(policyDO, DefaultPolicy.class);

				// if(!policyDO.getServiceVersions().isEmpty()){
				// publishToEventBus(policyDO.getServiceVersions());
				// }
				// }
			}
		} catch (Exception ex) {
			LOG.error(MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE,
					ex.getMessage()));
			exceptionHandler.handleBusinessException(ex);
		}
		return result;
	}

	@Override
	@Transactional(rollbackFor = { BusinessException.class })
	public DefaultPolicy updatePolicyStatus(String id, String action,
			String actionBy) throws BusinessException {
		LOG.debug("Executing updatePolicyStatus for : " + id);
		DefaultPolicy policy = null;
		try {
			DefaultPolicyDO policyDO = policyDAO.findOne(id);
			if (policyDO == null) {
				throw new ServiceRegistryException(
						ErrorCode.BIZ_POLICY_NOT_FOUND, MessageFormat.format(
								CommonConstants.POLICY_NOT_FOUND,
								String.valueOf(id)));
			} else {
				String newStatus = BizUtil.toStatus(action);
				RegistryPolicyCode newStatusType = RegistryPolicyCodeDAOImpl
						.getCode(RegistryPolicyCodeType.STATUS,
								newStatus.toUpperCase());
				if (newStatusType == null) {
					throw new ServiceRegistryException(
							ErrorCode.BIZ_INVALID_STATUS_TYPE,
							MessageFormat.format(
									CommonConstants.INVALID_STATUS_TYPE,
									String.valueOf(id)));
				} else {
					String oldStatus = policyDO.getStatus();
					if (newStatusType.getCode().equalsIgnoreCase(oldStatus)) {
						throw new ServiceRegistryException(
								ErrorCode.BIZ_INVALID_ACTION_TYPE,
								MessageFormat.format(
										CommonConstants.INVALID_ACTION_TYPE,
										String.valueOf(id)));
					}
					BizUtil.validateModifiedBy(EntityType.POLICY, actionBy);
					policyDO.setStatus(newStatusType.getCode());
					//policyDO.setModifiedBy(actionBy);
					policyDO = policyDAO.save(policyDO);
					//auditStatus(policyDO, oldStatus);
					policy = mapper.map(policyDO, DefaultPolicy.class);

					//if (!policyDO.getServiceVersions().isEmpty()) {
						//publishToEventBus(policyDO.getServiceVersions());
					//}
				}
			}
		} catch (Exception ex) {
			LOG.error(MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE,
					ex.getMessage()));
			exceptionHandler.handleBusinessException(ex);
		}
		return policy;
	}

	/**
	 * Method to fetch DefaultPolicy by name
	 */
	@Override
	@Transactional(rollbackFor = { BusinessException.class })
	public DefaultPolicy getPolicyByName(String name) throws BusinessException {
		LOG.debug("Executing getPolicyByName for : " + name);
		DefaultPolicy result = null;
		try {
			List<DefaultPolicyDO> policyDOs = policyDAO.findByName(name);
			if (policyDOs != null && !policyDOs.isEmpty()) {
				result = mapper.map(policyDOs.get(0), DefaultPolicy.class);
			}
		} catch (Exception ex) {
			LOG.error(MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE,
					ex.getMessage()));
			exceptionHandler.handleBusinessException(ex);
		}
		return result;
	}

	/**
	 * Method to fetch Policies by matching name
	 */
	@Override
	@Transactional(rollbackFor = { BusinessException.class })
	public List<DefaultPolicy> searchPolicies(String searchName,
			String searchValue) throws BusinessException {
		LOG.debug("Executing searchPolicies for : " + searchName);
		List<DefaultPolicy> result = new ArrayList<DefaultPolicy>(0);
		List<DefaultPolicyDO> policyDOs = null;
		try {
			if (StringUtils.isEmpty(searchName)) {
				policyDOs = policyDAO.findAll();
			}

			else {
				if (!BizUtil.isValidPolicySearchOption(searchName)) {
					throw new ServiceRegistryException(
							ErrorCode.BIZ_INVALID_SEARCH_NAME,
							CommonConstants.INVALID_SEARCH_NAME);
				}

				if (SearchFieldType.STATUS.toString().equalsIgnoreCase(
						searchName)) {
					List<String> statusTypes = BizUtil
							.getStatusCriteria(searchValue);
					policyDOs = policyDAO.findByStatus(statusTypes);
				} else if (SearchFieldType.NAME.toString().equalsIgnoreCase(
						searchName)) {
					policyDOs = policyDAO.findByMatchingName(searchValue);
				}
			}
			if (policyDOs != null && !policyDOs.isEmpty()) {
				result = mapper.mapToList(policyDOs, DefaultPolicy.class);
			}
		} catch (Exception ex) {
			LOG.error(MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE,
					ex.getMessage()));
			exceptionHandler.handleBusinessException(ex);
		}
		return result;
	}

	/**
	 * NOTE: removed ServiceRegistryException from throws since it is unchecked
	 * exception
	 * 
	 * @param name
	 * @throws ServiceRegistryException
	 */
	private void validatePolicyName(String name) {
		if (StringUtils.isEmpty(name)) {
			throw new ServiceRegistryException(
					ErrorCode.BIZ_INVALID_POLICY_NAME, MessageFormat.format(
							CommonConstants.INVALID_POLICY_NAME, name));
		}
	}

	/**
	 * This method checks if other DefaultPolicy already exists with the same
	 * name
	 * 
	 * @param policyName
	 * @param id
	 *            (to be pass null in case of ADD use case)
	 * @return
	 * @throws Exception
	 */
	private boolean isDuplicate(String policyName, String id)
			throws DataAccessException {
		List<DefaultPolicyDO> existingPolicies = policyDAO
				.findByName(policyName);
		if (existingPolicies != null && !existingPolicies.isEmpty()) {
			// If id == null means it is update else it is add DefaultPolicy use
			// case
			if (id != null) {
				for (DefaultPolicyDO policyDO : existingPolicies) {
					if (!policyDO.getId().equals(id)) {
						return true;
					}
				}
			} else {
				return true;
			}
		}
		return false;
	}

	/*private void audit(DefaultPolicyDO policy) throws DataAccessException {
		AuditDO audit = BizUtil.getAddAudit(policy);
		auditDAO.save(audit);
	}

	private void auditStatus(DefaultPolicyDO policy, String oldValue)
			throws DataAccessException {
		AuditDO audit = BizUtil.getStatusAudit(policy, oldValue);
		auditDAO.save(audit);
	}

	private void publishToEventBus(Set<ServiceVersionDO> serviceVersionDOSet) {
		LOG.info("Registry Notifcation enabled-->"
				+ registryConfig.isNotificationEnabled());
		if (Boolean
				.valueOf(registryConfig.isNotificationEnabled() != null ? registryConfig
						.isNotificationEnabled().trim() : "false")) {

			for (ServiceVersionDO serviceVersionDO : serviceVersionDOSet) {
				eventHandler.post(serviceVersionDO.getService());
			}

		}
	}*/

}
