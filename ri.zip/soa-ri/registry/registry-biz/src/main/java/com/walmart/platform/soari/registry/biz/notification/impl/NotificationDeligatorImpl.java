package com.walmart.platform.soari.registry.biz.notification.impl;

import java.sql.Timestamp;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.mail.internet.MimeMessage;

import org.apache.velocity.app.VelocityEngine;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.ui.velocity.VelocityEngineUtils;

import com.walmart.platform.kernel.exception.layers.business.BusinessException;
import com.walmart.platform.soari.registry.biz.notification.api.JIRATaskHandler;
import com.walmart.platform.soari.registry.biz.notification.api.NotificationDeligator;
import com.walmart.platform.soari.registry.common.dto.Subscription;
import com.walmart.platform.soari.registry.common.enums.AuditType;
import com.walmart.platform.soari.registry.common.enums.NotificationDestinationType;
import com.walmart.platform.soari.registry.domain.AuditDO;
import com.walmart.platform.soari.registry.domain.ServiceDO;
import com.walmart.platform.soari.registry.server.common.error.ErrorCode;
import com.walmart.platform.soari.registry.server.common.exception.ServiceRegistryException;

@org.springframework.stereotype.Service("notificationDeligator")
public class NotificationDeligatorImpl implements NotificationDeligator {

	@Autowired
	private JavaMailSenderImpl emailSender;

	@Autowired
	private VelocityEngine velocityEngine;

	@Autowired
	private JIRATaskHandler jiraTaskHandler;

	@Value("${emailNotificationEnabled}")
	private String emailNotificationEnabled;

	@Value("${jiraTaskCreateEnabled}")
	private String jiraTaskCreateEnabled;

	@Override
	public void notifyServiceUpdate(final ServiceDO service,
			final AuditDO audit, final AuditType auditType)
			throws BusinessException {
		List<AuditDO> audits = new ArrayList<AuditDO>(0);
		audits.add(audit);
		notifyServiceUpdate(service, audits, auditType);
	}

	@Override
	public void notifyServiceUpdate(final ServiceDO service,
			final List<AuditDO> audits, final AuditType auditType)
			throws BusinessException {

		if (!service.getNotificationRequested()) {
			return;
		}

		/*for (NotificationDestinationDO notification : service
				.getNotificationTypes()) {
			if (notification.getType().equals(
					NotificationDestinationType.EMAIL.toString())) {
				emailServiceUpdateNotification(service, audits, auditType);
			}
		}*/
		for (String notificationType : service
				.getNotificationTypes()) {
			if (notificationType.equals(
					NotificationDestinationType.EMAIL.toString())) {
				emailServiceUpdateNotification(service, audits, auditType);
			}
		}
	}

	@Override
	public void notifySubscriptionCreated(final String recipient, final Subscription subscription) throws BusinessException {
		MimeMessagePreparator preparator = new MimeMessagePreparator() {

			@Override
			public void prepare(MimeMessage mimeMessage) throws Exception {

				MimeMessageHelper message = new MimeMessageHelper(mimeMessage,
						true);
				message.setTo(recipient);
				message.setFrom("service-registry@walmartlabs.com");
				message.setSubject("Subscription Notification");
				String body = VelocityEngineUtils.mergeTemplateIntoString(
						velocityEngine, "templates/add_subscription.vm",
						"UTF-8", null);

				StringBuilder sb = new StringBuilder();
				sb.append("<TABLE border=\"1\">");
				sb.append("<TR>");
				sb.append("<TD>Service Name</TD><TD>"
						+ subscription.getServiceName() + "</TD>");
				sb.append("</TR>");
				sb.append("<TR>");
				sb.append("<TD>Service Version</TD><TD>"
						+ subscription.getVersionNumber() + "</TD>");
				sb.append("</TR>");
				sb.append("<TR>");
				sb.append("<TD>Environment</TD><TD>"
						+ subscription.getEnvironment() + "</TD>");
				sb.append("</TR>");
				sb.append("<TR>");
				sb.append("<TD>Consumer Id</TD><TD>"
						+ subscription.getConsumerId() + "</TD>");
				sb.append("</TR>");
				sb.append("</TABLE>");
				sb.append("<br/>");

				message.setText(MessageFormat.format(body, sb), true);
			}
		};
		sendEmail(preparator);
	}

	private void emailServiceUpdateNotification(final ServiceDO service,
			final List<AuditDO> audits, final AuditType auditType)
			throws BusinessException {

		boolean notificationRequired = false;

		Set<String> auditTypes = new HashSet<String>(0);
		auditTypes.add(auditType.toString());
		if (AuditType.UPDATE_SERVICE_VERSION == auditType) {
			auditTypes.add(AuditType.ADD_SERVICE_VERSION_POLICY.toString());
			auditTypes.add(AuditType.DELETE_SERVICE_VERSION_POLICY.toString());
			auditTypes.add(AuditType.ADD_SERVICE_VERSION_QOS.toString());
			auditTypes.add(AuditType.UPDATE_SERVICE_VERSION_QOS.toString());
			auditTypes.add(AuditType.DELETE_SERVICE_VERSION_QOS.toString());
		}

		for (String changeType : service.getNotificationFor()) {
			if (auditTypes.contains(changeType)) {
				notificationRequired = true;
				break;
			}
		}
		if (!notificationRequired) {
			return;
		}

		MimeMessagePreparator preparator = new MimeMessagePreparator() {

			@Override
			public void prepare(MimeMessage mimeMessage) throws Exception {

				String updatedBy = audits.get(0).getModifiedBy();
				Timestamp time = audits.get(0).getModifiedAt();

				MimeMessageHelper message = new MimeMessageHelper(mimeMessage,
						true);
				message.setTo(service.getOwner());
				message.setFrom("service-registry@walmartlabs.com");
				message.setSubject("Service Update Notification");
				StringBuilder sb = new StringBuilder();
				sb.append("<TABLE border=\"1\">");
				sb.append("<TR>");
				sb.append("<TD>Operation</TD><TD>Update By</TD><TD>Date & Time</TD>");
				sb.append("</TR>");
				sb.append("<TR>");
				sb.append("<TD>" + auditType.toString() + "</TD><TD>"
						+ updatedBy + "</TD><TD>" + time + "</TD>");
				sb.append("</TR>");
				sb.append("</TABLE>");
				sb.append("<br/>");

				sb.append("<TABLE border=\"1\">");
				sb.append("<TR>");
				sb.append("<TD>Field</TD><TD>Old Value</TD><TD>New Value</TD>");
				sb.append("</TR>");
				for (AuditDO audit : audits) {
					String oldValue = audit.getOldValue() != null ? audit
							.getOldValue() : "";
					String newValue = audit.getNewValue() != null ? audit
							.getNewValue() : "";
					sb.append("<TR>");
					sb.append("<TD>" + audit.getField() + "</TD><TD>"
							+ oldValue + "</TD><TD>" + newValue + "</TD>");
					sb.append("</TR>");
				}
				sb.append("</TABLE>");

				String body = VelocityEngineUtils.mergeTemplateIntoString(
						velocityEngine, "templates/service_update.vm", "UTF-8",
						null);
				message.setText(MessageFormat.format(body, sb.toString()), true);
			}
		};
		sendEmail(preparator);
	}

	private void sendEmail(MimeMessagePreparator preparator) {
		// String emailNotificationEnabled =
		// System.get.getProperty("emailNotificationEnabled");
		if (emailNotificationEnabled != null
				&& Boolean.valueOf(emailNotificationEnabled)) {
			this.emailSender.send(preparator);
		}
	}

	@Override
	public String createJiraTicket(String projectKey, Subscription subscription) throws BusinessException{
		try {
			if (jiraTaskCreateEnabled == null
					|| !Boolean.valueOf(jiraTaskCreateEnabled)) {
				return "";
			}
			return jiraTaskHandler.createActivateSubscriptionTicket(projectKey, subscription);
		} catch (Exception ex) {
			throw new ServiceRegistryException(ErrorCode.BIZ_JIRA_CREATE_FAILED, "Failed to create JIRA project : "+projectKey);
		}
	}

}
