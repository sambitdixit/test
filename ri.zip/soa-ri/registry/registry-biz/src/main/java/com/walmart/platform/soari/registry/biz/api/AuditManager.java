package com.walmart.platform.soari.registry.biz.api;

import java.util.List;

import com.walmart.platform.kernel.exception.layers.business.BusinessException;
import com.walmart.platform.soari.registry.common.dto.Audit;

public interface AuditManager {
	
	/**
	 * Fetches list of audits with matching 'entityId'
	 * 
	 * @param entityId Identifier for Entity
	 * @param fetchCount Audits per page
	 * @return List of Audits
	 * @throws BusinessException
	 */
	List<Audit> getAuditsByEntityId(String entityId, Integer fetchCount) throws BusinessException;
}
