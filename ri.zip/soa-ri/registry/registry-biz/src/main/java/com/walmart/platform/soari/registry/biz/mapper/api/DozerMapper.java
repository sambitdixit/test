package com.walmart.platform.soari.registry.biz.mapper.api;

import java.util.List;
import java.util.Set;

import org.dozer.Mapper;

import com.walmart.platform.soari.registry.common.dto.Service;
import com.walmart.platform.soari.registry.common.dto.ServiceSearchBean;
import com.walmart.platform.soari.registry.domain.ServiceDO;

public interface DozerMapper extends Mapper {
	
	/**
	 * Method to map List to List
	 * 
	 * @param source
	 * @param destinationClass
	 * @return
	 */
	<S, D> List<D> mapToList(final List<S> source, final Class<D> destinationClass);
	
	/**
	 * Method to map Set to List
	 * 
	 * @param source
	 * @param destinationClass
	 * @return
	 */
	<S, D> List<D> mapToList(final Set<S> source, final Class<D> destinationClass);
	
	public List<Service> mapFilterVersions(List<ServiceDO> services, ServiceSearchBean search);
	
	public Service mapFilterVersions(ServiceDO serviceDO, ServiceSearchBean search);
}
