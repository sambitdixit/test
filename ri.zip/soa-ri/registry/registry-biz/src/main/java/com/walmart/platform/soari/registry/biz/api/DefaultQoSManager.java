package com.walmart.platform.soari.registry.biz.api;

import java.util.List;

import com.walmart.platform.kernel.exception.layers.business.BusinessException;
import com.walmart.platform.soari.registry.common.dto.DefaultQoS;

public interface DefaultQoSManager {
	
	/**
	 * Fetches all existing qos
	 * 
	 * @return list of all existing QoS
	 * @throws BusinessException
	 */
	List<DefaultQoS> getDefaultQoS() throws BusinessException;
	
	/**
	 * Fetches a SefaultQos by Id
	 * 
	 * @param id Identifier of the SefaultQos being searched
	 * @return QoS matched by id or null
	 * @throws BusinessException
	 */
	DefaultQoS getDefaultQoSById(String id) throws BusinessException;
	
	/**
	 * Fetches a DefaultQoS by Name
	 * @param name Name of the DefaultQoS being searched
	 * @return DefaultQoS matched by name or null
	 * @throws BusinessException
	 */
	DefaultQoS getDefaultQoSByName(String name) throws BusinessException;
	
	/**
	 * Fetches list of DefaultQoS by matching name
	 *
	 * @param searchName Name of the DefaultQoS being searched
	 * @param searchValue Matching criteria
	 * @return list of DefaultQoS containing matching DefaultQoS
	 * @throws BusinessException
	 */
	List<DefaultQoS> searchDefaultQoS(String searchName, String searchValue) throws BusinessException;
	
	/**
	 * Creates a new DefaultQoS
	 * 
	 * @param qos DefaultQoS to be created
	 * @return newly created DefaultQoS
	 * @throws BusinessException
	 */
	DefaultQoS addDefaultQoS(DefaultQoS qos) throws BusinessException;
	
	/**
	 * Method to update an existing DefaultQoS. This will first checks if DefaultQoS exists.
	 * Also checks if other DefaultQoS has the same name, If DefaultQoS doesn't exists then
	 * create a new DefaultQoS
	 * 
	 * @param qos DefaultQoS to be updated
	 * @return updated/newly-created DefaultQoS
	 * @throws BusinessException
	 */
	DefaultQoS updateDefaultQoS(DefaultQoS qos) throws BusinessException;
	
	/**
	 * updates the status of DefaultQoS
	 * 
	 * @param id unique identifier for the DefaultQoS
	 * @param action [activate, deactivate, delete]
	 * @param actionBy 'modifiedBy' in Entity Table
	 * @return updated/newly-created DefaultQoS or null
	 * @throws BusinessException
	 */
	DefaultQoS updateDefaultQoSStatus(String id, String action, String actionBy) throws BusinessException;
}
