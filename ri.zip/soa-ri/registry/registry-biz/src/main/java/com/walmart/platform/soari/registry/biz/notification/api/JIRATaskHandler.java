package com.walmart.platform.soari.registry.biz.notification.api;

import com.walmart.platform.soari.registry.common.dto.Subscription;

public interface JIRATaskHandler {
	public String createActivateSubscriptionTicket(String projectKey, Subscription subscription);
}
