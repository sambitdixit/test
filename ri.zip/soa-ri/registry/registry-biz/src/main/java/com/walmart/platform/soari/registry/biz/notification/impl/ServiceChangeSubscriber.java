package com.walmart.platform.soari.registry.biz.notification.impl;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.google.common.eventbus.AllowConcurrentEvents;
import com.google.common.eventbus.Subscribe;
import com.walmart.platform.soa.common.util.SOAStringUtil;
import com.walmart.platform.soari.registry.common.dto.Service;
import com.walmart.platform.soari.registry.common.dto.ServiceVersion;
import com.walmart.platform.soari.registry.notification.NotificationRequest;
import com.walmart.platform.soari.registry.notification.publisher.MessagePublisher;

public class ServiceChangeSubscriber {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(ServiceChangeSubscriber.class);

	@Autowired
	private MessagePublisher messagePublisher;

	@Subscribe
	@AllowConcurrentEvents
	public void handleServiceChangeEvent(Service service) {

		LOGGER.debug("Service Change Event triggered for Service = {}",""+service.getName());

		for (ServiceVersion svcVersion : service.getServiceVersions()) {

			if (StringUtils.isNotBlank(svcVersion.getEsbReference())) {
				NotificationRequest req = new NotificationRequest();
				req.setServiceName(service.getName());
				req.setServiceEnv(service.getEnvironment());
				req.setStatus(service.getStatus());
				req.setApplicationId(service.getApplicationId());
				req.setDomain(service.getDomain());
				req.setServiceCategory(service.getCategory());
				req.setServiceDescription(service.getDescription());
				req.setId(service.getName());
				req.setUsage(service.getUsage());
				req.setServiceOwner(service.getOwner());
				if (SOAStringUtil.isNotBlank(svcVersion.getAvailabilityTier())) {
					req.setAvailaibilityTier(svcVersion.getAvailabilityTier());
				} else {
					req.setAvailaibilityTier("TIER1");
				}
				req.setEsbReference(svcVersion.getEsbReference());
				req.setData(svcVersion);
				messagePublisher.publishRequest(req);
			}
		}
	}

	/**
	 * setter for the message publisher
	 */

	public void setMessagePublisher(MessagePublisher msgPblshr) {
		this.messagePublisher = msgPblshr;
	}

	/**
	 * Getter for MessagePublisher
	 * 
	 * @return MessagePublisher
	 */
	public MessagePublisher getMessagePublisher() {
		return this.messagePublisher;
	}

}