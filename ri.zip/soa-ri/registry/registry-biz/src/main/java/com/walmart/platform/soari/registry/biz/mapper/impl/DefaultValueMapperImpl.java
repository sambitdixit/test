package com.walmart.platform.soari.registry.biz.mapper.impl;

import org.apache.commons.lang.StringUtils;
import org.dozer.DozerConverter;
import org.springframework.stereotype.Service;

import com.walmart.platform.soari.registry.common.enums.RegistryPolicyCodeType;
import com.walmart.platform.soari.registry.server.common.util.CommonConstants;

@Service("defaultValueMapper")
public class DefaultValueMapperImpl extends
		DozerConverter<String, String> {
	
	/**
	 * no-arg constructor
	 */
	public DefaultValueMapperImpl() {
		super(String.class, String.class);
	}

	/**
	 * Returns source as a string
	 * 
	 * @param source
	 * @param destination
	 */
	@Override
	public String convertTo(String source, String destination) {
		return source;
	}

	/**
	 * Returns source as a string 
	 * NOTE: need to add more comment to make it more clear
	 * 
	 * @param source
	 * @param destination
	 */
	@Override
	public String convertFrom(String source,
			String destination) {
		String fieldName = getParameter();
		if(!RegistryPolicyCodeType.ENVIRONMENT.toString().equals(fieldName)) {
			return source;
		}
		if(StringUtils.isEmpty(source)) {
			return CommonConstants.getRunOnEnv();
		} else {
			return source;
		}
	}
}
