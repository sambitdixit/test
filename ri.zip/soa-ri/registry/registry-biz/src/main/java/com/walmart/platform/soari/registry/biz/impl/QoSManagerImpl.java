package com.walmart.platform.soari.registry.biz.impl;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.walmart.platform.kernel.exception.layers.business.BusinessException;
import com.walmart.platform.kernel.exception.layers.dao.DataAccessException;
import com.walmart.platform.soa.config.RegistryConfig;
import com.walmart.platform.soari.registry.biz.api.QoSManager;
import com.walmart.platform.soari.registry.biz.mapper.api.DozerMapper;
import com.walmart.platform.soari.registry.biz.notification.api.EventHandler;
import com.walmart.platform.soari.registry.biz.util.BizUtil;
import com.walmart.platform.soari.registry.common.dto.QoS;
import com.walmart.platform.soari.registry.common.dto.Service;
import com.walmart.platform.soari.registry.common.enums.EntityType;
import com.walmart.platform.soari.registry.common.enums.RegistryPolicyCodeType;
import com.walmart.platform.soari.registry.common.enums.SearchFieldType;
import com.walmart.platform.soari.registry.domain.AuditDO;
import com.walmart.platform.soari.registry.domain.QoSDO;
import com.walmart.platform.soari.registry.domain.RegistryPolicyCode;
import com.walmart.platform.soari.registry.domain.ServiceDO;
import com.walmart.platform.soari.registry.domain.dao.api.AuditDAO;
import com.walmart.platform.soari.registry.domain.dao.api.QoSDAO;
import com.walmart.platform.soari.registry.domain.dao.api.ServiceDAO;
import com.walmart.platform.soari.registry.domain.dao.impl.RegistryPolicyCodeDAOImpl;
import com.walmart.platform.soari.registry.domain.util.Timed;
import com.walmart.platform.soari.registry.server.common.error.ErrorCode;
import com.walmart.platform.soari.registry.server.common.exception.ExceptionHandler;
import com.walmart.platform.soari.registry.server.common.exception.ServiceRegistryException;
import com.walmart.platform.soari.registry.server.common.util.CommonConstants;

/**
 * A class to perform business logic for mapping/transformation of DTO to Domain
 * objects and invoke Persistence APIs
 * 
 * @author sbonde
 * 
 */
@org.springframework.stereotype.Service("qosManager")
@Timed
public class QoSManagerImpl implements QoSManager {

	private static final Logger LOG = LoggerFactory
			.getLogger(QoSManagerImpl.class);

	@Autowired
	private QoSDAO qosDAO;
	
	@Autowired
	private ServiceDAO serviceDAO;

	@Autowired
	private DozerMapper mapper;

	@Autowired
	private ExceptionHandler exceptionHandler;

	@Autowired
	private AuditDAO auditDAO;

	@Autowired
	private EventHandler eventHandler;
	
	@Autowired
	private RegistryConfig registryConfig;

	@Override
	@Transactional(rollbackFor={BusinessException.class})
	public List<QoS> getQoS() throws BusinessException {
		LOG.debug("Executing getAllQoS ");
		List<QoS> qos = new ArrayList<QoS>(0);
		try {
			List<QoSDO> qosDOs = qosDAO.findAll();
			qos = mapper.mapToList(qosDOs, QoS.class);
		} catch (Exception ex) {
			LOG.error(MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE,
					ex.getMessage()));
			exceptionHandler.handleBusinessException(ex);
		}
		return qos;
	}

	@Override
	@Transactional(rollbackFor={BusinessException.class})
	public QoS getQoSById(String id) throws BusinessException {
		LOG.debug("Executing getQoSById for : " + id);
		QoS result = null;
		try {
			if (StringUtils.isEmpty(id)) {
				throw new ServiceRegistryException(
						ErrorCode.BIZ_INVALID_QAS_ID,
						CommonConstants.INVALID_QAS_NAME);
			} else {
				QoSDO qosDO = qosDAO.findOne(id);
				if(qosDO != null) {
					result = mapper.map(qosDO, QoS.class);
				}
			}
		} catch (Exception ex) {
			LOG.error(MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE,
					ex.getMessage()));
			exceptionHandler.handleBusinessException(ex);
		}
		return result;
	}

	@Override
	@Transactional(rollbackFor={BusinessException.class})
	public QoS addQoS(QoS qos) throws BusinessException {
		LOG.debug("Executing addQoS " + qos.getName());
		QoS result = null;
		try {
			BizUtil.validateCreatedBy(EntityType.QoS, qos.getCreatedBy());
			validateQoSName(qos.getName());
			if (isDuplicate(qos.getName(), null)) {
				throw new ServiceRegistryException(
						ErrorCode.BIZ_DUPLICATE_SERVICE_PARAMETER,
						MessageFormat
								.format(CommonConstants.DUPLICATE_SERVICE_PARAMETER_NAME,
										qos.getName()));
			} else {
				QoSDO qosDO = mapper.map(qos, QoSDO.class);
				qosDO = qosDAO.save(qosDO);
				audit(qosDO);
				result = mapper.map(qosDO, QoS.class);
			}
		} catch (Exception ex) {
			LOG.error(MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE,
					ex.getMessage()));
			exceptionHandler.handleBusinessException(ex);
		}
		return result;
	}

	@Override
	@Transactional(rollbackFor={BusinessException.class})
	public QoS updateQoS(QoS qos) throws BusinessException {
		String qosId = qos.getId();
		LOG.debug("Executing updateQoS [id, name] : [" + qosId + ","
				+ qos.getName() + "]");
		QoS result = null;
		try {
			validateQoSName(qos.getName());
			if (isDuplicate(qos.getName(), qosId)) {
				throw new ServiceRegistryException(
						ErrorCode.BIZ_DUPLICATE_SERVICE_PARAMETER,
						MessageFormat
								.format(CommonConstants.DUPLICATE_SERVICE_PARAMETER_NAME,
										qos.getName()));
			} else {
				QoSDO qosDO = null;
				if (!StringUtils.isEmpty(qosId)) {
					qosDO = qosDAO.findOne(qosId);
				}
				// QoS doesn't exists then create new QoS
				if (qosDO == null) {
					BizUtil.validateCreatedBy(EntityType.QoS, qos.getCreatedBy());
					qosDO = mapper.map(qos, QoSDO.class);
					qosDO = qosDAO.save(qosDO);
					audit(qosDO);
					result = mapper.map(qosDO, QoS.class);
					return result;
				}
				BizUtil.validateModifiedBy(EntityType.QoS, qos.getModifiedBy());
				List<AuditDO> audits = BizUtil.getAuditDetails(qos, qosDO);
				if (!audits.isEmpty()) {
					mapper.map(qos, qosDO);
					//qosDO.setModifiedAt(new Timestamp(System.currentTimeMillis()));
					qosDO = qosDAO.save(qosDO);
					auditDAO.save(audits);
					result = mapper.map(qosDO, QoS.class);
					publishToEventBus(qosId);
				}
			}
		} catch (Exception ex) {
			LOG.error(MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE,
					ex.getMessage()));
			exceptionHandler.handleBusinessException(ex);
		}
		return result;
	}
	
	@Override
	@Transactional(rollbackFor={BusinessException.class})
	public QoS updateQoSStatus(String id, String action, String actionBy) throws BusinessException {
		LOG.debug("Executing updateQoSStatus for : " + id);
		QoS qos = null;
		try {
			QoSDO qosDO = qosDAO.findOne(id);
			if (qosDO == null) {
				throw new ServiceRegistryException(
						ErrorCode.BIZ_QOS_NOT_FOUND,
						MessageFormat.format(
								CommonConstants.QOS_NOT_FOUND,
								String.valueOf(id)));
			} else {
				if (StringUtils.isEmpty(action)) {
					throw new ServiceRegistryException(
							ErrorCode.BIZ_INVALID_STATUS_TYPE,
							MessageFormat.format(
									CommonConstants.INVALID_STATUS_TYPE,
									String.valueOf(id)));
				} else {
					String newStatusValue = BizUtil.toStatus(action);
					RegistryPolicyCode newStatusType = RegistryPolicyCodeDAOImpl.getCode(RegistryPolicyCodeType.STATUS, newStatusValue.toUpperCase());
					if (newStatusType == null) {
						throw new ServiceRegistryException(
								ErrorCode.BIZ_INVALID_STATUS_TYPE,
								MessageFormat.format(
										CommonConstants.INVALID_STATUS_TYPE,
										String.valueOf(id)));
					} else {
						String oldStatusValue = qosDO.getStatus();
						if (newStatusType.getCode().equals(oldStatusValue)) {
							throw new ServiceRegistryException(
									ErrorCode.BIZ_INVALID_ACTION_TYPE,
									MessageFormat
											.format(CommonConstants.INVALID_ACTION_TYPE,
													String.valueOf(id)));
						} else {
							BizUtil.validateModifiedBy(EntityType.QoS, actionBy);
							qosDO.setStatus(newStatusType.getCode());
							qosDO.setModifiedBy(actionBy);
							qosDO = qosDAO.save(qosDO);
							auditStatus(qosDO, oldStatusValue);
							qos = mapper.map(qosDO, QoS.class);
							publishToEventBus(qosDO.getId());
						}
					}
				}
			}
		} catch (Exception ex) {
			LOG.error(MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE,
					ex.getMessage()));
			exceptionHandler.handleBusinessException(ex);
		}
		return qos;
	}

	@Override
	@Transactional(rollbackFor={BusinessException.class})
	public QoS getQoSByName(String name) throws BusinessException {
		LOG.debug("Executing getQoSByName for : " + name);
		QoS result = null;
		try {
			List<QoSDO> qosDOs = qosDAO.findByName(name);
			if (qosDOs != null && !qosDOs.isEmpty()) {
				result = mapper.map(qosDOs.get(0), QoS.class);
			}
		} catch (Exception ex) {
			LOG.error(MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE,
					ex.getMessage()));
			exceptionHandler.handleBusinessException(ex);
		}
		return result;
	}

	@Override
	@Transactional(rollbackFor={BusinessException.class})
	public List<QoS> searchQoS(String searchName, String searchValue)
			throws BusinessException {
		LOG.debug("Executing searchQoS for : " + searchName);
		List<QoS> result = new ArrayList<QoS>(0);
		List<QoSDO> qosDOs = null;
		try {
			if (StringUtils.isEmpty(searchName)) {
				qosDOs = qosDAO.findAll();
			}

			else {
				if (!BizUtil.isValidQoSSearchOption(searchName)) {
					throw new ServiceRegistryException(
							ErrorCode.BIZ_INVALID_SEARCH_NAME,
							CommonConstants.INVALID_SEARCH_NAME);
				}
				else if (SearchFieldType.STATUS.toString().equalsIgnoreCase(
						searchName)) {
					List<String> statusTypes = BizUtil
							.getStatusCriteria(searchValue);
					qosDOs = qosDAO.findByStatus(statusTypes);
				} else if (SearchFieldType.NAME.toString().equalsIgnoreCase(
						searchName)) {
					qosDOs = qosDAO.findByMatchingName(searchValue);
				}
			}
			if (qosDOs != null && !qosDOs.isEmpty()) {
				result = mapper.mapToList(qosDOs, QoS.class);
			}
		} catch (Exception ex) {
			LOG.error(MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE,
					ex.getMessage()));
			exceptionHandler.handleBusinessException(ex);
		}
		return result;
	}

	/**
	 * This method checks if other QoS already exists with the same name
	 * 
	 * @param qosName
	 * @param id 
	 *            (to be pass null in case of ADD use case)
	 * @return true if duplicate
	 * @throws Exception
	 */
	private boolean isDuplicate(String qosName, String id)
			throws DataAccessException {
		List<QoSDO> existingQoS = qosDAO.findByName(qosName);
		if (existingQoS != null && !existingQoS.isEmpty()) {
			// If id == null means it is update else it is add QoS use case
			if (id != null) {
				for (QoSDO qosDO : existingQoS) {
					if (!qosDO.getId().equals(id)) {
						return true;
					}
				}
			} else {
				return true;
			}
		}
		return false;
	}

	/**
	 * NOTE: removed ServiceRegistryException from throws since it is unchecked exception
	 * @param name
	 */
	private void validateQoSName(String name) {
		if(StringUtils.isEmpty(name)) {
			throw new ServiceRegistryException(ErrorCode.BIZ_INVALID_QAS_NAME,
					MessageFormat.format(CommonConstants.INVALID_QAS_NAME,
							name));
		}
	}

	private void audit(QoSDO qos)
			throws DataAccessException {
		AuditDO audit = BizUtil.getAddAudit(qos);
		auditDAO.save(audit);
	}
	private void auditStatus(QoSDO qos, String oldValue)
			throws DataAccessException {
		AuditDO audit = BizUtil.getStatusAudit(qos, oldValue);
		auditDAO.save(audit);
	}

	/**
	 * Publish the notification to the event bus if notification is enabled
	 * 
	 * @param serviceDO
	 * @param type
	 */
	private void publishToEventBus(String qosId) {
		LOG.info("Registry Notifcation enabled-->"
				+ registryConfig.isNotificationEnabled());
		if (Boolean
				.valueOf(registryConfig.isNotificationEnabled() != null ? registryConfig
						.isNotificationEnabled().trim() : "false")) {
			List<Service> serviceList = new ArrayList<Service>();
			
			try {
				serviceList = mapToServices(serviceDAO.findByQoSId(qosId));
			} catch (DataAccessException dae) {
				LOG.error("Error in fetching services for qos with id==>+qosId",dae);
			}
			
			for(Service service:serviceList){
				eventHandler.post(service);
			}
		}
	}
	
	private List<Service> mapToServices(List<ServiceDO> serviceDOs) {
		List<Service> services = mapper.mapToList(serviceDOs, Service.class);
		for(Service service : services) {
			BizUtil.mapQoSToQoSParameter(service, serviceDOs);
		}
		return services;
	}
	
}
