package com.walmart.platform.soari.registry.biz.impl;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.walmart.platform.kernel.exception.layers.business.BusinessException;
import com.walmart.platform.soari.registry.biz.api.RegistryOptionManager;
import com.walmart.platform.soari.registry.biz.mapper.api.DozerMapper;
import com.walmart.platform.soari.registry.common.dto.RegistryOption;
import com.walmart.platform.soari.registry.common.enums.RegistryPolicyCodeType;
import com.walmart.platform.soari.registry.common.enums.ReportType;
import com.walmart.platform.soari.registry.domain.RegistryPolicyCode;
import com.walmart.platform.soari.registry.domain.dao.impl.RegistryPolicyCodeDAOImpl;
import com.walmart.platform.soari.registry.server.common.error.ErrorCode;
import com.walmart.platform.soari.registry.server.common.exception.ExceptionHandler;
import com.walmart.platform.soari.registry.server.common.exception.ServiceRegistryException;
import com.walmart.platform.soari.registry.server.common.util.CommonConstants;

@Service("registryOptionManager")
public class RegistryOptionManagerImpl implements RegistryOptionManager {

	private static final Logger LOG = LoggerFactory
			.getLogger(RegistryOptionManagerImpl.class);

	@Autowired
	private ExceptionHandler exceptionHandler;
	
	@Autowired
	private RegistryPolicyCodeDAOImpl registryPolicyCodeDAO;
	
	@Autowired
	private DozerMapper mapper;

	@Override
	public List<RegistryOption> getOptionsByType(RegistryPolicyCodeType type)
			throws BusinessException {
		List<RegistryOption> options = null;
		List<RegistryPolicyCode> list = new ArrayList<RegistryPolicyCode>(0);
		List<RegistryPolicyCode> registryPolicyCodes = null;
		try {
			if (type == null) {
				throw new ServiceRegistryException(
						ErrorCode.BIZ_INVALID_OPTION_NOT_NULL,
						CommonConstants.INVALID_OPTION_NOT_NULL);
			} else if(type == RegistryPolicyCodeType.SERVICE_OPTION) {
				registryPolicyCodes = RegistryPolicyCodeDAOImpl.getCodesByType(RegistryPolicyCodeType.STATUS);
				if(registryPolicyCodes != null) {
					list.addAll(registryPolicyCodes);
				}
				registryPolicyCodes = RegistryPolicyCodeDAOImpl.getCodesByType(RegistryPolicyCodeType.SERVICE_CATEGORY);
				if(registryPolicyCodes != null) {
					list.addAll(registryPolicyCodes);
				}
				registryPolicyCodes = RegistryPolicyCodeDAOImpl.getCodesByType(RegistryPolicyCodeType.SERVICE_DOMAIN);
				if(registryPolicyCodes != null) {
					list.addAll(registryPolicyCodes);
				}
				registryPolicyCodes = RegistryPolicyCodeDAOImpl.getCodesByType(RegistryPolicyCodeType.SERVICE_USAGE);
				if(registryPolicyCodes != null) {
					list.addAll(registryPolicyCodes);
				}
				registryPolicyCodes = RegistryPolicyCodeDAOImpl.getCodesByType(RegistryPolicyCodeType.NOTIFICATION_TYPE);
				if(registryPolicyCodes != null) {
					list.addAll(registryPolicyCodes);
				}
				registryPolicyCodes = RegistryPolicyCodeDAOImpl.getCodesByType(RegistryPolicyCodeType.CHANGE_TYPE);
				if(registryPolicyCodes != null) {
					list.addAll(registryPolicyCodes);
				}
				registryPolicyCodes = RegistryPolicyCodeDAOImpl.getCodesByType(RegistryPolicyCodeType.JIRA_PROJECT);
				if(registryPolicyCodes != null) {
					list.addAll(registryPolicyCodes);
				}
			} else if(type == RegistryPolicyCodeType.SERVICE_VERSION_OPTION) {
				registryPolicyCodes = RegistryPolicyCodeDAOImpl.getCodesByType(RegistryPolicyCodeType.STATUS);
				if(registryPolicyCodes != null) {
					list.addAll(registryPolicyCodes);
				}
				registryPolicyCodes = RegistryPolicyCodeDAOImpl.getCodesByType(RegistryPolicyCodeType.URL);
				if(registryPolicyCodes != null) {
					list.addAll(registryPolicyCodes);
				}
			} else if(type == RegistryPolicyCodeType.QOS_OPTION) {
				registryPolicyCodes = RegistryPolicyCodeDAOImpl.getCodesByType(RegistryPolicyCodeType.STATUS);
				if(registryPolicyCodes != null) {
					list.addAll(registryPolicyCodes);
				}
				registryPolicyCodes = RegistryPolicyCodeDAOImpl.getCodesByType(RegistryPolicyCodeType.QoS_TYPE);
				if(registryPolicyCodes != null) {
					list.addAll(registryPolicyCodes);
				}
			} else if(type == RegistryPolicyCodeType.POLICY_OPTION) {
				registryPolicyCodes = RegistryPolicyCodeDAOImpl.getCodesByType(RegistryPolicyCodeType.STATUS);
				if(registryPolicyCodes != null) {
					list.addAll(registryPolicyCodes);
				}
				registryPolicyCodes = RegistryPolicyCodeDAOImpl.getCodesByType(RegistryPolicyCodeType.POLICY_TYPE);
				if(registryPolicyCodes != null) {
					list.addAll(registryPolicyCodes);
				}
				registryPolicyCodes = RegistryPolicyCodeDAOImpl.getCodesByType(RegistryPolicyCodeType.CONTEXT);
				if(registryPolicyCodes != null) {
					list.addAll(registryPolicyCodes);
				}
				registryPolicyCodes = RegistryPolicyCodeDAOImpl.getCodesByType(RegistryPolicyCodeType.FLOW);
				if(registryPolicyCodes != null) {
					list.addAll(registryPolicyCodes);
				}
			} else if(type == RegistryPolicyCodeType.SUBSCRIPTION_OPTION) {
				registryPolicyCodes = RegistryPolicyCodeDAOImpl.getCodesByType(RegistryPolicyCodeType.STATUS);
				if(registryPolicyCodes != null) {
					list.addAll(registryPolicyCodes);
				}
				registryPolicyCodes = RegistryPolicyCodeDAOImpl.getCodesByType(RegistryPolicyCodeType.COMMUNICATION_TYPE);
				if(registryPolicyCodes != null) {
					list.addAll(registryPolicyCodes);
				}
			} else if(type == RegistryPolicyCodeType.DASHBOARD_REPORT) {
				for(ReportType reportType : ReportType.values()) {
					RegistryPolicyCode registryPolicyCode = new RegistryPolicyCode();
					registryPolicyCode.setCode(reportType.toString());
					registryPolicyCode.setDescription(reportType.getDescription());
					registryPolicyCode.setType(RegistryPolicyCodeType.DASHBOARD_REPORT);
					list.add(registryPolicyCode);
				}
			} else {
				registryPolicyCodes = RegistryPolicyCodeDAOImpl.getCodesByType(type);	
				if(registryPolicyCodes != null) {
					list.addAll(registryPolicyCodes);
				}
			}
			if(list != null) {
				options = mapper.mapToList(list, RegistryOption.class);
			}
		} catch (Exception ex) {
			LOG.error(MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE,
					ex.getMessage()));
			exceptionHandler.handleBusinessException(ex);
		}
		return options;
	}
	
	@Override
	public Long getOptionCount() throws BusinessException {
		Long count = null;
		try {
			count = registryPolicyCodeDAO.findCount();
		} catch (Exception ex) {
			LOG.error(MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE,
					ex.getMessage()));
			exceptionHandler.handleBusinessException(ex);
		}
		return count;
	}
}
