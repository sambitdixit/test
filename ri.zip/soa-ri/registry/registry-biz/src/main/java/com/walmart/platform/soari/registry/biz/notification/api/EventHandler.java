package com.walmart.platform.soari.registry.biz.notification.api;

import java.util.List;

import com.google.common.eventbus.EventBus;

public interface EventHandler {

	/**
	 * @return the eventBus
	 */
	EventBus getEventBus();

	/**
	 * @param eventBus
	 *            the eventBus to set
	 */
	void setEventBus(EventBus eventBus);

	/**
	 * @param subscribers
	 */
	void setSubscribers(List<Object> subscribers);

	void post(Object event);

}