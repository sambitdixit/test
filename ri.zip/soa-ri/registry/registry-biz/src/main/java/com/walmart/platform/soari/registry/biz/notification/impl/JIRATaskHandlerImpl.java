package com.walmart.platform.soari.registry.biz.notification.impl;

import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.core.MediaType;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;

import com.walmart.platform.soa.http.client.PlatformHttpClient;
import com.walmart.platform.soa.http.client.enums.TransportMethod;
import com.walmart.platform.soari.registry.biz.notification.api.JIRATaskHandler;
import com.walmart.platform.soari.registry.biz.util.BizUtil;
import com.walmart.platform.soari.registry.common.dto.Subscription;

@org.springframework.stereotype.Service("jiraTaskHandler")
public class JIRATaskHandlerImpl implements JIRATaskHandler {

	@Value("${jira.url}")
	private String jiraUrl;
	@Value("${jira.authorization}")
	private String jiraAuthorization;

	private static final Logger logger = LoggerFactory
			.getLogger(JIRATaskHandlerImpl.class);

	@Override
	public String createActivateSubscriptionTicket(String projectKey, Subscription subscription){
		logger.debug("Creating JIRA task for project : "+projectKey);
		if(StringUtils.isEmpty(projectKey)) {
			return "";
		}
		StringBuilder sb = new StringBuilder();
		sb.append("This is to notify you that recently a consumer has subscribed for one of your service version. Below are the details of the subscription. ");
		sb.append("\\nService Name    : " + subscription.getServiceName());
		sb.append("\\nService Version : " + subscription.getVersionNumber());
		sb.append("\\nEnvironment     : " + subscription.getEnvironment());
		sb.append("\\nConsumer Id     : " + subscription.getConsumerId());

		sb.append("\\nThis subscription will be inactive unless you activate the same. You can activate the subscription by following the below steps on Service Regsitry Portal @Platform");
		sb.append("\\nThank you for using Service Registry @Platform.");

		sb.append("\\nRegards,");
		sb.append("\\nService Registry @Platform.");
		
		return BizUtil.createJiraTask(jiraUrl, jiraAuthorization, projectKey, "Activate Service Subscription Notification",sb.toString());
		//return createJiraTask(jiraUrl, jiraAuthorization, projectKey, "Activate Service Subscription Notification",sb.toString());
	}
	
	public String createJiraTask(String baseUrl, String authorization, String projectKey, String summary, String description) {
		String response = new String();
		try {
		
			String request = "{\"fields\": {\"project\":{ \"key\": \""+projectKey+"\"},\"summary\": \""+summary+"\",\"description\": \""+description+"\",\"issuetype\": {\"name\": \"Story\"}}}";
			Map<String, String> customHeaders = new HashMap<String, String>(0);
			customHeaders.put("Authorization", authorization);
			PlatformHttpClient httpClient = PlatformHttpClient
					.getInstance();
					httpClient.setAcceptType(MediaType.APPLICATION_JSON);
					httpClient.setContentType(MediaType.APPLICATION_JSON);
					response = httpClient.invoke(TransportMethod.POST, baseUrl, "", request, null, customHeaders, String.class, null);
					//response = httpClient.post(baseUrl, null, request, String.class, String.class, null, customHeaders);
					//invoke(TransportMethod.POST, "https://jira.walmart.com/rest/api/2/issue", "", t, null, customeHeaders, String.class, String.class);
					System.out.println("resp = "+response);
		
		  } catch (Exception e) {
			e.printStackTrace();
		 }
		return response!=null?response.toString():"";
	}
}
