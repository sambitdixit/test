package com.walmart.platform.soari.registry.biz.api;

import java.util.List;

import com.walmart.platform.kernel.exception.layers.business.BusinessException;
import com.walmart.platform.soari.registry.common.dto.Policy;
import com.walmart.platform.soari.registry.common.dto.QoS;
import com.walmart.platform.soari.registry.common.dto.Service;
import com.walmart.platform.soari.registry.common.dto.ServiceSearchBean;
import com.walmart.platform.soari.registry.common.dto.ServiceVersion;

public interface RegistryManager {
	
	/**
	 * Fetches all the services
	 * 
	 * @return list of all services
	 * @throws BusinessException
	 */
	List<Service> getServices() throws BusinessException;
	
	/**
	 * Fetches a service by id
	 * 
	 * @param id Identifier for service
	 * @return matching service or null
	 * @throws BusinessException
	 */
	Service getService(String id) throws BusinessException;
	
	/**
	 * Creates a new service 
	 * 
	 * @param service
	 * @return newly-created service or null
	 * @throws BusinessException
	 */
	Service addService(Service service) throws BusinessException;
	
	/**
	 * Updates an existing service or creates a new service if non-existent 
	 * 
	 * @param service Service to be updated
	 * @return update/newly-created service or null
	 * @throws BusinessException
	 */
	Service updateService(Service service) throws BusinessException;
	
	/**
	 * Updates service status
	 * 
	 * @param id Identifier for the service
	 * @param action [activate, deactivate, delete]
	 * @param actionBy 'modifiedBy' in Entity Table
	 * @return updated service or null
	 * @throws BusinessException
	 */
	Service updateServiceStatus(String id, String action, String actionBy) throws BusinessException;
	
	/**
	 * Updates the service version status
	 * 
	 * @param id Identifier for service version
	 * @param action [activate, deactivate, delete]
	 * @param actionBy 'modifiedBy' in Entity Table
	 * @return Updated service version or null
	 * @throws BusinessException
	 */
	ServiceVersion updateServiceVersionStatus(String id, String action, String actionBy) throws BusinessException;
	
	/** 
	 * Fetches list of service with name matching with 'name' 
	 * Uses '%name%' pattern for matching
	 * 
	 * @param name Name of service to being searched
	 * @return list of matching services
	 * @throws BusinessException
	 */
	List<Service> findServices(String name) throws BusinessException;
	
	/**
	 * Fetches list of service with matching name and criteria
	 * 
	 * @param searchName Name of service to being searched
	 * @param searchValue Matching criteria
	 * @return list of matching services
	 * @throws BusinessException
	 */
	List<Service> searchServices(String searchName, String searchValue) throws BusinessException;
	
	/**
	 * Fetches list of services with matching description
	 * 
	 * @param search
	 * @return list of matching services
	 * @throws BusinessException
	 */
	List<Service> searchServices(ServiceSearchBean search) throws BusinessException;
	
	/**
	 * Fetches service by name
	 * 
	 * @param name  Name of the service to be searched for
	 * @return Matching service or null
	 * @throws BusinessException
	 */
	List<Service> getServiceByName(String name) throws BusinessException;
	
	/**
	 * Fetch the service version of service identified by 'serviceId'
	 * 
	 * @param serviceId Identifier for the service
	 * @param serVersion  Service Version to be searched for
	 * @return Matching service version or null
	 * @throws BusinessException
	 */
	ServiceVersion getServiceVersion(String serviceId, String serVersion) throws BusinessException;
	
	/**
	 * Creates a new Service Version
	 * 
	 * @param serviceId Identifier for the service
	 * @param serviceVersion New service version to be created
	 * @return newly-created service version or null
	 * @throws BusinessException
	 */
	ServiceVersion addServiceVersion(String serviceId, ServiceVersion serviceVersion) throws BusinessException;
	
	/**
	 * Updates service version
	 * Checks for duplicates as well
	 * 
	 * @param serviceId Identifier for the service
	 * @param serviceVersion New service version for the service
	 * @return updated service version or null
	 * @throws BusinessException
	 */
	ServiceVersion updateServiceVersion(String serviceId, ServiceVersion serviceVersion) throws BusinessException;
	
	List<Policy> getServiceVersionPolicies(String serviceVersionId) throws BusinessException;
	ServiceVersion addServiceVersionPolicy(String serviceVersionId, String policyId) throws BusinessException;
	ServiceVersion deleteServiceVersionPolicy(String serviceVersionId, String policyId) throws BusinessException;
	List<QoS> getServiceVersionParameters(String serviceVersionId) throws BusinessException;
	QoS addServiceVersionParameter(String serviceVersionId, QoS qosParameter) throws BusinessException;
	QoS updateServiceVersionParameter(String serviceVersionId, QoS qosParameter) throws BusinessException;
	void deleteServiceVersionParameter(String serviceVersionId, String qosId) throws BusinessException;
}
