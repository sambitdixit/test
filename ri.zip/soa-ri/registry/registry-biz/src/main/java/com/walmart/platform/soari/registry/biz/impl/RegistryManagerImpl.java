package com.walmart.platform.soari.registry.biz.impl;

import java.sql.Timestamp;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.walmart.platform.kernel.exception.layers.base.PlatformException;
import com.walmart.platform.kernel.exception.layers.business.BusinessException;
import com.walmart.platform.kernel.exception.layers.dao.DataAccessException;
import com.walmart.platform.soa.config.RegistryConfig;
import com.walmart.platform.soari.registry.biz.api.RegistryManager;
import com.walmart.platform.soari.registry.biz.mapper.api.DozerMapper;
import com.walmart.platform.soari.registry.biz.notification.api.EventHandler;
import com.walmart.platform.soari.registry.biz.notification.impl.NotificationDeligatorImpl;
import com.walmart.platform.soari.registry.biz.util.BizUtil;
import com.walmart.platform.soari.registry.common.dto.ConsumerSubscription;
import com.walmart.platform.soari.registry.common.dto.Policy;
import com.walmart.platform.soari.registry.common.dto.QoS;
import com.walmart.platform.soari.registry.common.dto.Service;
import com.walmart.platform.soari.registry.common.dto.ServiceSearchBean;
import com.walmart.platform.soari.registry.common.dto.ServiceVersion;
import com.walmart.platform.soari.registry.common.dto.Url;
import com.walmart.platform.soari.registry.common.enums.AuditType;
import com.walmart.platform.soari.registry.common.enums.EntityType;
import com.walmart.platform.soari.registry.common.enums.RegistryPolicyCodeType;
import com.walmart.platform.soari.registry.common.enums.SearchFieldType;
import com.walmart.platform.soari.registry.domain.AttributeDO;
import com.walmart.platform.soari.registry.domain.AuditDO;
import com.walmart.platform.soari.registry.domain.EntityDO;
import com.walmart.platform.soari.registry.domain.PolicyDO;
import com.walmart.platform.soari.registry.domain.QoSDO;
import com.walmart.platform.soari.registry.domain.RegistryPolicyCode;
import com.walmart.platform.soari.registry.domain.ServiceDO;
import com.walmart.platform.soari.registry.domain.ServiceVersionDO;
import com.walmart.platform.soari.registry.domain.ServiceVersionQoS;
import com.walmart.platform.soari.registry.domain.SubscriptionDO;
import com.walmart.platform.soari.registry.domain.UrlDO;
import com.walmart.platform.soari.registry.domain.dao.api.AuditDAO;
import com.walmart.platform.soari.registry.domain.dao.api.PolicyDAO;
import com.walmart.platform.soari.registry.domain.dao.api.QoSDAO;
import com.walmart.platform.soari.registry.domain.dao.api.ServiceDAO;
import com.walmart.platform.soari.registry.domain.dao.api.ServiceVersionDAO;
import com.walmart.platform.soari.registry.domain.dao.api.SubscriptionDAO;
import com.walmart.platform.soari.registry.domain.dao.impl.RegistryPolicyCodeDAOImpl;
import com.walmart.platform.soari.registry.server.common.error.ErrorCode;
import com.walmart.platform.soari.registry.server.common.exception.ExceptionHandler;
import com.walmart.platform.soari.registry.server.common.exception.ServiceRegistryException;
import com.walmart.platform.soari.registry.server.common.util.CommonConstants;

@org.springframework.stereotype.Service("registryManager")
public class RegistryManagerImpl implements RegistryManager {

	private static final Logger LOG = LoggerFactory
			.getLogger(RegistryManagerImpl.class);

	@Autowired
	private EventHandler eventHandler;

	@Autowired
	private ServiceDAO serviceDAO;

	@Autowired
	private ServiceVersionDAO serviceVersionDAO;

	@Autowired
	private SubscriptionDAO subscriptionDAO;

	@Autowired
	private AuditDAO auditDAO;

	@Autowired
	private QoSDAO qosDAO;

	@Autowired
	private PolicyDAO policyDAO;

	@Autowired
	private DozerMapper mapper;

	@Autowired
	private ExceptionHandler exceptionHandler;

	@Autowired
	private RegistryConfig registryConfig;

	@Autowired
	private NotificationDeligatorImpl notificationDeligator;

	/* Service operations */
	@Override
	@Transactional(rollbackFor = { BusinessException.class })
	public Service addService(Service service) throws BusinessException {
		LOG.debug("Executing addService : " + service.getName());
		Service result = null;
		try {
			result = createService(service);
		} catch (Exception ex) {
			LOG.error(MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE,
					ex.getMessage()));
			exceptionHandler.handleBusinessException(ex);
		}
		return result;
	}

	@Override
	@Transactional(rollbackFor = { BusinessException.class })
	public Service updateService(Service service) throws BusinessException {
		String serviceId = service.getId();
		LOG.debug("Executing updateService [id] : " + serviceId);
		try {
			ServiceDO serviceDO = null;
			if (!StringUtils.isEmpty(serviceId)) {
				serviceDO = serviceDAO.findOne(serviceId);
			}
			// If Service doesn't exists, then create a new Service
			if (serviceDO == null) {
				if (StringUtils.isEmpty(service.getCreatedBy())) {
					service.setCreatedBy(service.getModifiedBy());
				}
				return createService(service);
			}
			validateService(service);
			if (isServiceDuplicate(service, false)) {
				throw new ServiceRegistryException(
						ErrorCode.BIZ_DUPLICATE_SERVICE_NAME,
						MessageFormat.format(
								CommonConstants.DUPLICATE_SERVICE_NAME,
								service.getName()));
			}
			BizUtil.validateModifiedBy(EntityType.SERVICE, service.getModifiedBy());
			List<AuditDO> audits = BizUtil.getAuditDetails(service, serviceDO);
			List<ServiceVersion> serviceVersions = new ArrayList<ServiceVersion>(
					0);
			serviceVersions.addAll(service.getServiceVersions());
			if (!audits.isEmpty()) {
				mapper.map(service, serviceDO);
				serviceDO = serviceDAO.save(serviceDO);
				auditDAO.save(audits);
				service = mapper.map(serviceDO, Service.class);
				notificationDeligator.notifyServiceUpdate(serviceDO, audits,
						AuditType.UPDATE_SERVICE);
				publishToEventBus(service);
			}
			service.getServiceVersions().clear();
			for (ServiceVersion serviceVersion : serviceVersions) {
				serviceVersion.setModifiedBy(service.getModifiedBy());
				service.getServiceVersions().add(
						updateSrcVersion(serviceDO, serviceVersion));
			}
		} catch (Exception ex) {
			LOG.error(MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE,
					ex.getMessage()));
			exceptionHandler.handleBusinessException(ex);
		}
		return service;
	}

	@Override
	@Transactional(rollbackFor = { BusinessException.class })
	public Service updateServiceStatus(String serviceId, String action,
			String actionBy) throws BusinessException {
		LOG.debug("Executing actionService : " + serviceId);
		Service service = null;
		try {
			if (StringUtils.isEmpty(serviceId)) {
				throw new ServiceRegistryException(
						ErrorCode.BIZ_INVALID_SERVICE_ID,
						CommonConstants.INVALID_SERVICE_ID);
			} else {
				String newStatusValue = BizUtil.toStatus(action);
				ServiceDO serviceDO = serviceDAO.findOne(serviceId);
				if (serviceDO == null) {
					throw new ServiceRegistryException(
							ErrorCode.BIZ_SERVICE_NOT_FOUND,
							MessageFormat.format(
									CommonConstants.SERVICE_NOT_FOUND,
									String.valueOf(serviceId)));
				} else {
					// No physical delete, Change status to 'DELETED'
					RegistryPolicyCode newStatusType = RegistryPolicyCodeDAOImpl
							.getCode(RegistryPolicyCodeType.STATUS,
									newStatusValue.toUpperCase());
					if (newStatusType == null) {
						throw new ServiceRegistryException(
								ErrorCode.BIZ_INVALID_STATUS_TYPE,
								CommonConstants.INVALID_STATUS_TYPE);
					} else {
						String oldStatusValue = serviceDO.getStatus();
						if (newStatusType.getCode().equalsIgnoreCase(
								oldStatusValue)) {
							throw new ServiceRegistryException(
									ErrorCode.BIZ_INVALID_ACTION_TYPE,
									CommonConstants.INVALID_ACTION_TYPE);
						} else {
							BizUtil.validateModifiedBy(EntityType.SERVICE, actionBy);
							serviceDO.setStatus(newStatusType.getCode());
							serviceDO.setModifiedBy(actionBy);
							serviceDO = serviceDAO.save(serviceDO);
							AuditDO audit = auditStatus(serviceDO,
									oldStatusValue);
							service = mapper.map(serviceDO, Service.class);
							notificationDeligator
									.notifyServiceUpdate(
											serviceDO,
											audit,
											AuditType
													.getServiceAuditTypeByStatus(newStatusValue));
							publishToEventBus(service);
						}
					}
				}
			}
		} catch (Exception ex) {
			LOG.error(MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE,
					ex.getMessage()));
			exceptionHandler.handleBusinessException(ex);
		}
		return service;
	}

	@Override
	@Transactional(rollbackFor = { BusinessException.class })
	public List<Service> getServices() throws BusinessException {
		LOG.debug("Executing getServices()");
		List<Service> services = new ArrayList<Service>(0);
		try {
			List<ServiceDO> serviceDOs = serviceDAO.findAll();
			if (serviceDOs != null) {
				services = mapToServices(serviceDOs);
				populateServiceVersionWithConsumerSubscription(services);
			}
		} catch (Exception ex) {
			LOG.error(MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE,
					ex.getMessage()));
			exceptionHandler.handleBusinessException(ex);
		}
		return services;
	}

	@Override
	@Transactional(rollbackFor = { BusinessException.class })
	public Service getService(String id) throws BusinessException {
		LOG.debug("Executing getApplicationServices()");
		Service service = null;
		try {
			if (StringUtils.isEmpty(id)) {
				throw new ServiceRegistryException(
						ErrorCode.BIZ_INVALID_SERVICE_ID,
						CommonConstants.INVALID_SERVICE_ID);
			} else {
				ServiceDO serviceDO = serviceDAO.findOne(id);
				if (serviceDO != null) {
					service = mapper.map(serviceDO, Service.class);
					List<Service> services = new ArrayList<Service>();
					services.add(service);
					populateServiceVersionWithConsumerSubscription(services);
				} else {
					throw new ServiceRegistryException(
							ErrorCode.BIZ_SERVICE_NOT_FOUND,
							CommonConstants.SERVICE_NOT_FOUND);
				}
			}
		} catch (Exception ex) {
			LOG.error(MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE,
					ex.getMessage()));
			exceptionHandler.handleBusinessException(ex);
		}
		return service;
	}

	@Override
	@Transactional(rollbackFor = { BusinessException.class })
	public List<Service> findServices(String name) throws BusinessException {
		LOG.debug("Executing findServices : " + name);
		List<Service> services = null;
		try {
			if (StringUtils.isEmpty(name)) {
				throw new ServiceRegistryException(
						ErrorCode.BIZ_INVALID_SERVICE_NAME,
						CommonConstants.INVALID_SERVICE_NAME);
			} else {
				List<ServiceDO> serviceDOs = serviceDAO
						.findByMatchingName(name);
				if (serviceDOs != null) {
					services = mapper.mapToList(serviceDOs, Service.class);
					populateServiceVersionWithConsumerSubscription(services);
				}
			}
		} catch (Exception ex) {
			LOG.error(MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE,
					ex.getMessage()));
			exceptionHandler.handleBusinessException(ex);
		}
		return services;
	}

	@SuppressWarnings("unchecked")
	@Override
	@Transactional(rollbackFor = { BusinessException.class })
	public List<Service> searchServices(ServiceSearchBean search)
			throws BusinessException {
		LOG.debug("Executing searchServices : ");
		List<Service> services = null;
		try {
			Map<String, String> map = BeanUtils.describe(search);
			if (BizUtil.isConsumerSubscriptionFilterRequested(search)) {
				List<SubscriptionDO> subscriptions = subscriptionDAO.search(map);
				if(subscriptions!=null&&subscriptions.size()>0) {
					services = mapFilterServices(subscriptions, search);
				} else {
					List<ServiceDO> serviceDOs = serviceDAO.search(map);
					if (serviceDOs != null) {
						if (!BizUtil.isServiceVersionFilterRequested(search)) {
							services = mapper.mapToList(serviceDOs, Service.class);
						} else {
							services = mapper.mapFilterVersions(serviceDOs, search);
						}
					}
				}
				
			} else {
				List<ServiceDO> serviceDOs = serviceDAO.search(map);
				if (serviceDOs != null) {
					if (!BizUtil.isServiceVersionFilterRequested(search)) {
						services = mapper.mapToList(serviceDOs, Service.class);
					} else {
						services = mapper.mapFilterVersions(serviceDOs, search);
					}
				}
			}
			
			populateServiceVersionWithConsumerSubscription(services);
			
		} catch (Exception ex) {
			LOG.error(MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE,
					ex.getMessage()));
			exceptionHandler.handleBusinessException(ex);
		}
		return services;
	}

	@Override
	@Transactional(rollbackFor = { BusinessException.class })
	public List<Service> searchServices(String searchName, String searchValue)
			throws BusinessException {
		LOG.debug("Executing searchServices[name,value] : [" + searchName + ","
				+ searchValue + "]");
		List<Service> services = null;
		List<ServiceDO> serviceDOs = new ArrayList<ServiceDO>(0);
		try {

			if (StringUtils.isEmpty(searchName)) {
				serviceDOs = serviceDAO.findAll();
			}

			else {
				if (!BizUtil.isValidServiceSearchOption(searchName)) {
					throw new ServiceRegistryException(
							ErrorCode.BIZ_INVALID_SEARCH_NAME,
							CommonConstants.INVALID_SEARCH_NAME);
				}
				
				if (SearchFieldType.CATEGORY.toString().equalsIgnoreCase(searchName)) {
					serviceDOs = serviceDAO.findByCategory(searchValue);
				} else if (SearchFieldType.DESCRIPTION.toString().equalsIgnoreCase(searchName)) {
					serviceDOs = serviceDAO.findByMatchingDescription(searchValue);
				} else if (SearchFieldType.OWNER.toString().equalsIgnoreCase(searchName)) {
					serviceDOs = serviceDAO.findByMatchingOwner(searchValue);
				} else if (SearchFieldType.DOMAIN.toString().equalsIgnoreCase(searchName)) {
					serviceDOs = serviceDAO.findByDomain(searchValue);
				} else if (SearchFieldType.USAGE.toString().equalsIgnoreCase(searchName)) {
					serviceDOs = serviceDAO.findByUsage(searchValue);
				} else if (SearchFieldType.NAME.toString().equalsIgnoreCase(searchName)) {
					serviceDOs = serviceDAO.findByMatchingName(searchValue);
				} else if (SearchFieldType.STATUS.toString().equalsIgnoreCase(searchName)) {
					List<String> statusTypes = BizUtil.getStatusCriteria(searchValue);
					serviceDOs = serviceDAO.findByStatus(statusTypes);
				} else if (SearchFieldType.APPLICATION.toString().equalsIgnoreCase(searchName)) {
					serviceDOs = serviceDAO.findByApplicationId(searchValue);
				} else if (SearchFieldType.ENVIRONMENT.toString().equalsIgnoreCase(searchName)) {
					serviceDOs = serviceDAO.findByEnvironment(searchValue);
				} else if (SearchFieldType.AVAILABILITY_TIER.toString().equalsIgnoreCase(searchName)) {
					List<ServiceVersionDO> serviceVersionDOs = serviceVersionDAO.findByAvailabilityTier(searchValue);
					services = populateServiceWithVersions(serviceVersionDOs);
					populateServiceVersionWithConsumerSubscription(services);
					return services;
				} else if (SearchFieldType.ESB_REFERENCE.toString().equalsIgnoreCase(searchName)) {
					
					List<ServiceVersionDO> serviceVersionDOs = serviceVersionDAO.findByESBReference(searchValue);
					
					services = populateServiceWithVersions(serviceVersionDOs);
					
					populateServiceVersionWithConsumerSubscription(services);
					return services;
				}
			}
			if (serviceDOs != null) {
				services = mapToServices(serviceDOs);
				populateServiceVersionWithConsumerSubscription(services);
			}
		} catch (Exception ex) {
			LOG.error(MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE,
					ex.getMessage()));
			exceptionHandler.handleBusinessException(ex);
		}
		return services;
	}

	@Override
	@Transactional(rollbackFor = { BusinessException.class })
	public List<Service> getServiceByName(String name) throws BusinessException {
		LOG.debug("Executing getServiceByName : " + name);
		List<Service> services = null;
		try {
			List<ServiceDO> serviceDOs = serviceDAO.findByName(name);
			if (serviceDOs != null) {
				services = mapper.mapToList(serviceDOs, Service.class);
				populateServiceVersionWithConsumerSubscription(services);
			}
		} catch (Exception ex) {
			LOG.error(MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE,
					ex.getMessage()));
			exceptionHandler.handleBusinessException(ex);
		}
		return services;
	}

	/* Service Version operations */
	@Override
	@Transactional(rollbackFor = { BusinessException.class })
	public ServiceVersion addServiceVersion(String serviceId,
			ServiceVersion serviceVersion) throws BusinessException {
		LOG.debug("Executing addServiceVersion [serviceId, version] : ["
				+ serviceId + " : " + serviceVersion.getSerVersion() + "]");
		ServiceVersion result = null;
		try {
			ServiceDO service = validateIfServiceExists(serviceId);
			result = addServiceVersion(service, serviceVersion);
		} catch (Exception ex) {
			LOG.error(MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE,
					ex.getMessage()));
			exceptionHandler.handleBusinessException(ex);
		}
		return result;
	}

	@Override
	@Transactional(rollbackFor = { BusinessException.class })
	public ServiceVersion updateServiceVersion(String serviceId,
			ServiceVersion serviceVersion) throws BusinessException {
		LOG.debug("Executing updateServiceVersion [id, version] : ["
				+ serviceId + "," + serviceVersion.getSerVersion() + "]");
		ServiceVersion result = null;
		try {
			if (StringUtils.isEmpty(serviceVersion.getSerVersion())) {
				throw new ServiceRegistryException(
						ErrorCode.BIZ_INVALID_SERVICE_VERSION_NUMBER,
						CommonConstants.INVALID_SERVICE_VERSION_NUMBER);
			} else {
				result = updateSrcVersion(serviceId, serviceVersion);
			}
		} catch (Exception ex) {
			LOG.error(MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE,
					ex.getMessage()));
			exceptionHandler.handleBusinessException(ex);
		}
		return result;
	}

	@Override
	@Transactional(rollbackFor = { BusinessException.class })
	public ServiceVersion updateServiceVersionStatus(String serviceVersionId,
			String action, String actionBy) throws BusinessException {
		LOG.debug("Executing updateServiceVersionStatus : " + serviceVersionId);
		ServiceVersion serviceVersion = null;
		try {
			if (StringUtils.isEmpty(serviceVersionId)) {
				throw new ServiceRegistryException(
						ErrorCode.BIZ_INVALID_SERVICE_VERSION_ID,
						CommonConstants.INVALID_SERVICE_VERSION_ID);
			} else {
				String newStatusValue = BizUtil.toStatus(action);
				ServiceVersionDO serviceVersionDO = serviceVersionDAO
						.findOne(serviceVersionId);
				if (serviceVersionDO == null) {
					throw new ServiceRegistryException(
							ErrorCode.BIZ_SERVICE_VERSION_NOT_FOUND,
							MessageFormat.format(
									CommonConstants.SERVICE_VERSION_NOT_FOUND,
									String.valueOf(serviceVersionId)));
				} else {
					// No physical delete, Change status to 'DELETED'
					RegistryPolicyCode newStatusType = RegistryPolicyCodeDAOImpl
							.getCode(RegistryPolicyCodeType.STATUS,
									newStatusValue.toUpperCase());
					String oldStatusValue = serviceVersionDO.getStatus();
					if (newStatusType == null) {
						throw new ServiceRegistryException(
								ErrorCode.BIZ_INVALID_STATUS_TYPE,
								CommonConstants.INVALID_STATUS_TYPE);
					}
					if (newStatusType.getCode()
							.equalsIgnoreCase(oldStatusValue)) {
						throw new ServiceRegistryException(
								ErrorCode.BIZ_INVALID_ACTION_TYPE,
								CommonConstants.INVALID_ACTION_TYPE);
					} else {
						BizUtil.validateModifiedBy(EntityType.SRVC_VERSION, actionBy);
						serviceVersionDO.setStatus(newStatusType.getCode());
						serviceVersionDO.setModifiedBy(actionBy);
						serviceVersionDO = serviceVersionDAO
								.save(serviceVersionDO);
						AuditDO audit = auditStatus(serviceVersionDO,
								oldStatusValue);

						// Publish event to event-bus
						publishToEventBus(mapTo(serviceVersionDO.getService()));
						notificationDeligator
								.notifyServiceUpdate(
										serviceVersionDO.getService(),
										audit,
										AuditType
												.getServiceVersionAuditTypeByStatus(newStatusValue));
						serviceVersion = mapTo(serviceVersionDO);
					}
				}
			}
		} catch (Exception ex) {
			LOG.error(MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE,
					ex.getMessage()));
			exceptionHandler.handleBusinessException(ex);
		}
		return serviceVersion;
	}

	@Override
	@Transactional(rollbackFor = { BusinessException.class })
	public ServiceVersion getServiceVersion(String serviceId,
			String serviceVersion) throws BusinessException {
		LOG.debug("Executing getServiceVersion [serviceId, version] : ["
				+ serviceId + " : " + serviceVersion + "]");
		ServiceVersion result = null;
		try {
			if (StringUtils.isEmpty(serviceId)) {
				throw new ServiceRegistryException(
						ErrorCode.BIZ_INVALID_SERVICE_ID,
						CommonConstants.INVALID_SERVICE_ID);
			}
			if (StringUtils.isEmpty(serviceVersion)) {
				throw new ServiceRegistryException(
						ErrorCode.BIZ_INVALID_SERVICE_VERSION_NUMBER,
						CommonConstants.INVALID_SERVICE_VERSION_NUMBER);
			}
			List<ServiceVersionDO> serviceVersionDOs = serviceVersionDAO
					.findServiceVersion(serviceId, serviceVersion);
			if (serviceVersionDOs != null && !serviceVersionDOs.isEmpty()) {
				ServiceVersionDO serviceVersionDO = serviceVersionDOs.get(0);
				result = mapTo(serviceVersionDO);
			}
		} catch (Exception ex) {
			LOG.error(MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE,
					ex.getMessage()));
			exceptionHandler.handleBusinessException(ex);
		}
		return result;
	}

	/* Service Version QoS Operations */
	@Override
	@Transactional(rollbackFor = { BusinessException.class })
	public QoS addServiceVersionParameter(String serviceVersionId,
			QoS qosParameter) throws BusinessException {
		LOG.debug("Executing addServiceVersionParameter [serviceVersionId, param] : ["
				+ serviceVersionId + " , " + qosParameter.getName() + "]");
		QoS result = null;
		try {
			BizUtil.validateCreatedBy(EntityType.QoS, qosParameter.getCreatedBy());
			validateServiceVersionParameter(qosParameter);
			result = addServiceVersionQoS(serviceVersionId, qosParameter);
		} catch (Exception ex) {
			LOG.error(MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE,
					ex.getMessage()));
			exceptionHandler.handleBusinessException(ex);
		}
		return result;
	}

	@Override
	@Transactional(rollbackFor = { BusinessException.class })
	public QoS updateServiceVersionParameter(String serviceVersionId,
			QoS qosParameter) throws BusinessException {
		LOG.debug("Executing updateServiceVersionParameter [serviceVersionId,qos] : ["
				+ serviceVersionId + "," + qosParameter.getName() + "]");
		QoS result = null;
		try {
			validateServiceVersionParameter(qosParameter);
			ServiceVersionDO serviceVersionDO = validateServiceVersionIfNotExists(serviceVersionId);
			QoS qos = BizUtil.getQoSParameter(serviceVersionDO,
					qosParameter.getId());
			if (qos == null) {
				if (StringUtils.isEmpty(qosParameter.getCreatedBy())) {
					qosParameter.setCreatedBy(qosParameter.getModifiedBy());
				}
				BizUtil.validateCreatedBy(EntityType.QoS, qosParameter.getCreatedBy());
				addServiceVersionQoS1(serviceVersionDO, qosParameter);
			} else {
				BizUtil.validateModifiedBy(EntityType.QoS, qosParameter.getModifiedBy());
				for (ServiceVersionQoS serviceVersionQoS : serviceVersionDO
						.getServiceVersionQos()) {
					if (serviceVersionQoS.getQos().getId()
							.equals(qosParameter.getId())) {
						serviceVersionQoS.setQosValue(qosParameter.getValue());
						serviceVersionQoS.setModifiedBy(qosParameter
								.getModifiedBy());
						break;
					}
				}
			}
			serviceVersionDO = serviceVersionDAO.save(serviceVersionDO);

			// Publish event to event-bus
			publishToEventBus(mapTo(serviceVersionDO.getService()));

			result = BizUtil.getQoSParameter(serviceVersionDO,
					qosParameter.getId());
		} catch (Exception ex) {
			LOG.error(MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE,
					ex.getMessage()));
			exceptionHandler.handleBusinessException(ex);
		}
		return result;
	}

	@Override
	@Transactional(rollbackFor = { BusinessException.class })
	public void deleteServiceVersionParameter(String serviceVersionId,
			String qosId) throws BusinessException {
		LOG.debug("Executing deleteServiceVersionParameter [serviceVersionId,qosId] : ["
				+ serviceVersionId + "," + qosId + "]");
		try {
			ServiceVersionDO serviceVersionDO = validateServiceVersionIfNotExists(serviceVersionId);
			ServiceVersionQoS existingQoS = validateServiceVersionQoSIfNotExists(
					serviceVersionDO, qosId);
			serviceVersionDO.removeServiceVersionQoS(existingQoS);
			serviceVersionDO = serviceVersionDAO.save(serviceVersionDO);

			// Publish event to event-bus
			publishToEventBus(mapTo(serviceVersionDO.getService()));

		} catch (Exception ex) {
			LOG.error(MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE,
					ex.getMessage()));
			exceptionHandler.handleBusinessException(ex);
		}
	}

	@Override
	@Transactional(rollbackFor = { BusinessException.class })
	public List<QoS> getServiceVersionParameters(String serviceVersionId)
			throws BusinessException {
		LOG.debug("Executing getServiceVersionParameters [serviceVersionId] : ["
				+ serviceVersionId + "]");
		List<QoS> result = null;
		try {
			if (StringUtils.isEmpty(serviceVersionId)) {
				throw new ServiceRegistryException(
						ErrorCode.BIZ_INVALID_SERVICE_VERSION_ID,
						CommonConstants.INVALID_SERVICE_VERSION_ID);
			}
			ServiceVersionDO serviceVersionDO = serviceVersionDAO
					.findOne(serviceVersionId);
			if (serviceVersionDO == null) {
				throw new ServiceRegistryException(
						ErrorCode.BIZ_SERVICE_VERSION_NOT_FOUND,
						MessageFormat.format(
								CommonConstants.SERVICE_VERSION_NOT_FOUND,
								String.valueOf(serviceVersionId)));
			}
			result = new ArrayList<QoS>(0);
			for (ServiceVersionQoS serviceVersionQoS : serviceVersionDO
					.getServiceVersionQos()) {
				QoS qosParameter = new QoS();
				BizUtil.map(serviceVersionQoS, qosParameter);
				result.add(qosParameter);
			}
		} catch (Exception ex) {
			LOG.error(MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE,
					ex.getMessage()));
			exceptionHandler.handleBusinessException(ex);
		}
		return result;
	}

	/* Service Version Policy Operations */
	@Override
	@Transactional(rollbackFor = { BusinessException.class })
	public ServiceVersion addServiceVersionPolicy(String serviceVersionId,
			String policyId) throws BusinessException {
		LOG.debug("Executing addServiceVersionPolicy [serviceVersionId, policyId] : ["
				+ serviceVersionId + " , " + policyId + "]");
		ServiceVersion result = null;
		try {
			if (StringUtils.isEmpty(serviceVersionId)) {
				throw new ServiceRegistryException(
						ErrorCode.BIZ_INVALID_SERVICE_VERSION_ID,
						CommonConstants.INVALID_SERVICE_VERSION_ID);
			}
			if (StringUtils.isEmpty(policyId)) {
				throw new ServiceRegistryException(
						ErrorCode.BIZ_INVALID_POLICY_ID,
						CommonConstants.INVALID_POLICY_ID);
			}
			ServiceVersionDO serviceVersionDO = serviceVersionDAO
					.findOne(serviceVersionId);
			if (serviceVersionDO == null) {
				throw new ServiceRegistryException(
						ErrorCode.BIZ_SERVICE_VERSION_NOT_FOUND,
						MessageFormat.format(
								CommonConstants.SERVICE_VERSION_NOT_FOUND,
								String.valueOf(serviceVersionId)));
			}
			PolicyDO policyDO = addServiceVersionPolicy(serviceVersionDO,
					policyId);
			serviceVersionDO = serviceVersionDAO.save(serviceVersionDO);
			auditDAO.save(BizUtil.getAddVersionPolicyAudit(serviceVersionDO,
					policyDO.getName()));
			// Publish event to event-bus
			publishToEventBus(mapTo(serviceVersionDO.getService()));

			result = mapTo(serviceVersionDO);
		} catch (Exception ex) {
			LOG.error(MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE,
					ex.getMessage()));
			exceptionHandler.handleBusinessException(ex);
		}
		return result;
	}

	@Override
	@Transactional(rollbackFor = { BusinessException.class })
	public ServiceVersion deleteServiceVersionPolicy(String serviceVersionId,
			String policyId) throws BusinessException {
		LOG.debug("Executing deleteServiceVersionPolicy [serviceVersionId, policyId] : ["
				+ serviceVersionId + " ," + policyId + "]");
		ServiceVersion result = null;
		try {
			if (StringUtils.isEmpty(serviceVersionId)) {
				throw new ServiceRegistryException(
						ErrorCode.BIZ_INVALID_SERVICE_VERSION_ID,
						CommonConstants.INVALID_SERVICE_VERSION_ID);
			}
			if (StringUtils.isEmpty(policyId)) {
				throw new ServiceRegistryException(
						ErrorCode.BIZ_INVALID_POLICY_ID,
						CommonConstants.INVALID_POLICY_ID);
			}
			ServiceVersionDO serviceVersionDO = serviceVersionDAO
					.findOne(serviceVersionId);

			if (serviceVersionDO == null) {
				throw new ServiceRegistryException(
						ErrorCode.BIZ_SERVICE_VERSION_NOT_FOUND,
						MessageFormat.format(
								CommonConstants.SERVICE_VERSION_NOT_FOUND,
								String.valueOf(serviceVersionId)));
			}

			PolicyDO policyDO = getExitingPolicy(serviceVersionDO, policyId);
			if (policyDO == null) {
				throw new ServiceRegistryException(
						ErrorCode.BIZ_POLICY_NOT_FOUND, MessageFormat.format(
								CommonConstants.POLICY_NOT_FOUND,
								String.valueOf(policyId)));
			}
			serviceVersionDO.removePolicy(policyDO);
			serviceVersionDO = serviceVersionDAO.save(serviceVersionDO);
			auditDAO.save(BizUtil.getDeleteVersionPolicyAudit(serviceVersionDO,
					policyDO.getName()));

			// Publish event to event-bus
			publishToEventBus(mapTo(serviceVersionDO.getService()));

			result = mapTo(serviceVersionDO);
		} catch (Exception ex) {
			LOG.error(MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE,
					ex.getMessage()));
			exceptionHandler.handleBusinessException(ex);
		}
		return result;
	}

	@Override
	@Transactional(rollbackFor = { BusinessException.class })
	public List<Policy> getServiceVersionPolicies(String serviceVersionId)
			throws BusinessException {
		LOG.debug("Executing getServiceVersionPolicies [serviceVersionId] : ["
				+ serviceVersionId + "]");
		List<Policy> result = null;
		try {
			if (StringUtils.isEmpty(serviceVersionId)) {
				throw new ServiceRegistryException(
						ErrorCode.BIZ_INVALID_SERVICE_VERSION_ID,
						CommonConstants.INVALID_SERVICE_VERSION_ID);
			}
			ServiceVersionDO serviceVersionDO = serviceVersionDAO
					.findOne(serviceVersionId);
			if (serviceVersionDO == null) {
				throw new ServiceRegistryException(
						ErrorCode.BIZ_SERVICE_VERSION_NOT_FOUND,
						MessageFormat.format(
								CommonConstants.SERVICE_VERSION_NOT_FOUND,
								String.valueOf(serviceVersionId)));
			}
			result = mapper.mapToList(serviceVersionDO.getPolicies(),
					Policy.class);
		} catch (Exception ex) {
			LOG.error(MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE,
					ex.getMessage()));
			exceptionHandler.handleBusinessException(ex);
		}
		return result;
	}

/* Service Operation helper methods */
	/**
	 * NOTE: removed ServiceRegistryException & MappingException from throws
	 * since it is unchecked exception
	 * 
	 * @param service
	 * @return Service
	 * @throws DataAccessException
	 * @throws BusinessException
	 */
	private Service createService(Service service) throws DataAccessException,
			BusinessException, PlatformException {
		BizUtil.validateCreatedBy(EntityType.SERVICE, service.getCreatedBy());
		validateService(service);
		if (isServiceDuplicate(service, true)) {
			throw new ServiceRegistryException(
					ErrorCode.BIZ_DUPLICATE_SERVICE_NAME, MessageFormat.format(
							CommonConstants.DUPLICATE_SERVICE_NAME,
							service.getName()));
		} else {
			List<ServiceVersion> serviceVersions = new ArrayList<ServiceVersion>(
					0);
			serviceVersions.addAll(service.getServiceVersions());
			service.getServiceVersions().clear();

			ServiceDO serviceDO = mapper.map(service, ServiceDO.class);
			serviceDO = serviceDAO.save(serviceDO);
			AuditDO audit = audit(serviceDO);
			Service result = mapper.map(serviceDO, Service.class);
			for (ServiceVersion serviceVersion : serviceVersions) {
				serviceVersion.setCreatedBy(service.getCreatedBy());
				ServiceVersion version = addServiceVersion(serviceDO,
						serviceVersion);
				result.getServiceVersions().add(version);
			}

			notificationDeligator.notifyServiceUpdate(serviceDO, audit,
					AuditType.ADD_SERVICE);
			publishToEventBus(result);

			return result;
		}

	}

	/* Service Version operation helper methods */
	private ServiceVersion addServiceVersion(ServiceDO service,
			ServiceVersion serviceVersion) throws PlatformException {
		ServiceVersion result = null;
		BizUtil.validateCreatedBy(EntityType.SRVC_VERSION, serviceVersion.getCreatedBy());
		result = createServiceVersion(service, serviceVersion);
		return result;
	}

	private ServiceVersion createServiceVersion(ServiceDO service,
			ServiceVersion serviceVersion) throws PlatformException {
		if (StringUtils.isEmpty(serviceVersion.getSerVersion())) {
			throw new ServiceRegistryException(
					ErrorCode.BIZ_INVALID_SERVICE_VERSION_NUMBER,
					CommonConstants.INVALID_SERVICE_VERSION_NUMBER);
		}
		validateActivationDate(serviceVersion);
		ServiceVersionDO serviceVersionDO = getServiceVersionByVersionNumber(
				service, serviceVersion.getSerVersion());
		if (serviceVersionDO != null) {
			throw new ServiceRegistryException(
					ErrorCode.BIZ_DUPLICATE_SERVICE_VERSION,
					MessageFormat.format(
							CommonConstants.DUPLICATE_SERVICE_VERSION_NUMBER,
							String.valueOf(serviceVersion.getSerVersion())));
		}
		serviceVersionDO = mapper.map(serviceVersion, ServiceVersionDO.class);
		serviceVersionDO.setService(service);

		// Add QoS
		for (QoS qosParameter : serviceVersion.getQoSParameters()) {
			addServiceVersionQoS1(serviceVersionDO, qosParameter);
		}

		serviceVersionDO.getPolicies().clear();
		addServiceVersionPolicies(serviceVersionDO, serviceVersion);
		serviceVersionDO = serviceVersionDAO.save(serviceVersionDO);
		AuditDO audit = audit(serviceVersionDO);
		notificationDeligator.notifyServiceUpdate(service, audit,
				AuditType.ADD_SERVICE_VERSION);
		// Publish to event bus
		publishToEventBus(mapTo(serviceVersionDO.getService()));
		serviceVersion = mapTo(serviceVersionDO);
		return serviceVersion;
	}

	private List<Policy> addServiceVersionPolicies(
			ServiceVersionDO serviceVersionDO, ServiceVersion serviceVersion)
			throws PlatformException {
		List<Policy> policies = new ArrayList<Policy>(0);
		policies.addAll(serviceVersion.getPolicies());
		serviceVersion.getPolicies().clear();

		List<Policy> added = new ArrayList<Policy>(0);
		for (Policy policy : policies) {
			if (StringUtils.isEmpty(policy.getId())) {
				throw new ServiceRegistryException(
						ErrorCode.BIZ_INVALID_POLICY_ID,
						CommonConstants.INVALID_POLICY_ID);
			}
			PolicyDO policyDO = addServiceVersionPolicy(serviceVersionDO,
					policy.getId());
			added.add(mapper.map(policyDO, Policy.class));
		}
		return added;
	}

	private ServiceVersion updateSrcVersion(String serviceId,
			ServiceVersion serviceVersion) throws PlatformException {
		ServiceDO serviceDO = serviceDAO.findOne(serviceId);
		if (serviceDO == null) {
			throw new ServiceRegistryException(ErrorCode.BIZ_SERVICE_NOT_FOUND,
					MessageFormat.format(CommonConstants.SERVICE_NOT_FOUND,
							String.valueOf(serviceId)));
		}
		return updateSrcVersion(serviceDO, serviceVersion);
	}

	private ServiceVersion updateSrcVersion(ServiceDO service,
			ServiceVersion serviceVersion) throws PlatformException {
		String serviceVersionId = serviceVersion.getId();
		ServiceVersionDO serviceVersionDO = null;
		if (!StringUtils.isEmpty(serviceVersionId)) {
			serviceVersionDO = getServiceVersionById(service, serviceVersionId);
		}
		if (serviceVersionDO == null) {
			if (StringUtils.isEmpty(serviceVersion.getCreatedBy())) {
				serviceVersion.setCreatedBy(serviceVersion.getModifiedBy());
			}
			return addServiceVersion(service, serviceVersion);
		}
		if (isDuplicate(service, serviceVersion.getSerVersion(),
				serviceVersionId)) {
			throw new ServiceRegistryException(
					ErrorCode.BIZ_DUPLICATE_SERVICE_VERSION,
					MessageFormat.format(
							CommonConstants.DUPLICATE_SERVICE_VERSION_NUMBER,
							String.valueOf(serviceVersion.getSerVersion())));
		}
		BizUtil.validateModifiedBy(EntityType.SRVC_VERSION, serviceVersion.getModifiedBy());
		validateActivationDate(serviceVersion);
		List<AuditDO> audits = BizUtil.getAuditDetails(serviceVersion,
				serviceVersionDO);
		if (!audits.isEmpty()) {
			updatePrimaryFields(serviceVersionDO, serviceVersion);
		}
		audits.addAll(updateServiceVersionPolicies(serviceVersionDO,
				serviceVersion.getPolicies()));

		/**
		 * Reset the QoS Parameters with the input details
		 */
		audits.addAll(auditServiceVersionQoS(serviceVersionDO,
				serviceVersion.getQoSParameters()));
		resetServiceVersionQoS(serviceVersionDO,
				serviceVersion.getQoSParameters());
		serviceVersionDO = serviceVersionDAO.save(serviceVersionDO);
		auditDAO.save(audits);
		ServiceVersion result = mapTo(serviceVersionDO);

		publishToEventBus(mapTo(serviceVersionDO.getService()));
		notificationDeligator.notifyServiceUpdate(service, audits,
				AuditType.UPDATE_SERVICE_VERSION);
		return result;
	}

	private ServiceVersionDO updatePrimaryFields(
			ServiceVersionDO serviceVersionDO, ServiceVersion serviceVersion)
			throws DataAccessException {
		serviceVersionDO.setActivationEndDate(serviceVersion
				.getActivationEndDate());
		serviceVersionDO.setActivationStartDate(serviceVersion
				.getActivationStartDate());
		serviceVersionDO.setAvailabilityTier(serviceVersion
				.getAvailabilityTier());
		serviceVersionDO.setEnvironment(serviceVersion.getEnvironment());
		serviceVersionDO.setEsbReference(serviceVersion.getEsbReference());
		serviceVersionDO
				.setPublicationDate(serviceVersion.getPublicationDate());
		serviceVersionDO.setSerVersion(serviceVersion.getSerVersion());
		serviceVersionDO.setModifiedBy(serviceVersion.getModifiedBy());
		if (!serviceVersionDO.getStatus().equalsIgnoreCase(
				serviceVersion.getStatus())) {
			RegistryPolicyCode status = RegistryPolicyCodeDAOImpl.getCode(
					RegistryPolicyCodeType.STATUS, serviceVersion.getStatus());
			serviceVersionDO.setStatus(status.getCode());
		}
		updateVersionUrls(serviceVersion, serviceVersionDO);
		serviceVersionDO.setSerVersion(serviceVersion.getSerVersion());
		updateServiceVersionAttrbutes(serviceVersion, serviceVersionDO);
		return serviceVersionDO;
	}

	private void updateVersionUrls(ServiceVersion serviceVersion,
			ServiceVersionDO serviceVersionDO) throws DataAccessException {
		Set<UrlDO> exitingUrls = new HashSet<UrlDO>(0);
		exitingUrls.addAll(serviceVersionDO.getUrls());
		for (UrlDO urlDO : exitingUrls) {
			Url url = getUrl(serviceVersion.getUrls(), urlDO.getId());
			if (url == null) {
				serviceVersionDO.getUrls().remove(urlDO);
			}
		}
		for (Url url : serviceVersion.getUrls()) {
			UrlDO urlDO = getUrlDO(serviceVersionDO.getUrls(), url.getId());
			if (urlDO == null) {
				urlDO = new UrlDO();
				mapper.map(url, urlDO);
				serviceVersionDO.getUrls().add(urlDO);
			} else {
				mapper.map(url, urlDO);
			}
		}
	}

	private void updateServiceVersionAttrbutes(ServiceVersion serviceVersion,
			ServiceVersionDO serviceVersionDO) {
		Set<AttributeDO> target = new HashSet<AttributeDO>();
		target.addAll(mapper.mapToList(serviceVersion.getAttributes(),
				AttributeDO.class));
		serviceVersionDO.setAttributes(target);
	}

	private QoS addServiceVersionQoS(String serviceVersionId, QoS qosParameter)
			throws PlatformException {
		ServiceVersionDO serviceVersionDO = validateServiceVersionIfNotExists(serviceVersionId);
		addServiceVersionQoS1(serviceVersionDO, qosParameter);
		serviceVersionDO = serviceVersionDAO.save(serviceVersionDO);
		// Publish event to event-bus
		publishToEventBus(mapTo(serviceVersionDO.getService()));

		return BizUtil.getQoSParameter(serviceVersionDO, qosParameter.getId());
	}

	private PolicyDO addServiceVersionPolicy(ServiceVersionDO serviceVersionDO,
			String policyId) throws PlatformException {
		PolicyDO policyDO = policyDAO.findOne(policyId);
		if (policyDO == null) {
			throw new ServiceRegistryException(ErrorCode.BIZ_POLICY_NOT_FOUND,
					MessageFormat.format(CommonConstants.POLICY_NOT_FOUND,
							String.valueOf(policyId)));
		}
		serviceVersionDO.addPolicy(policyDO);
		return policyDO;
	}

	/* Validation Helper methods */
	/**
	 * This method return true if Service is already exists with name &
	 * environment or applicationId & environment
	 * 
	 * @param service
	 * @param isNew
	 * @return
	 * @throws DataAccessException
	 */
	private boolean isServiceDuplicate(Service service, boolean isNew)
			throws DataAccessException {
		List<ServiceDO> exitingServices = serviceDAO.findDuplicate(
				service.getName(), service.getEnvironment(),
				service.getApplicationId());
		if (exitingServices != null && !exitingServices.isEmpty()) {
			if (isNew) {
				return true;
			}
			for (ServiceDO exitingService : exitingServices) {
				if (!exitingService.getId().equals(service.getId())) {
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * This method returns true if Service with given id already exists.
	 * 
	 * @param serviceId
	 * @return
	 * @throws DataAccessException
	 */
	private ServiceDO validateIfServiceExists(String serviceId)
			throws DataAccessException {
		if (StringUtils.isEmpty(serviceId)) {
			throw new ServiceRegistryException(
					ErrorCode.BIZ_INVALID_SERVICE_ID,
					CommonConstants.INVALID_SERVICE_ID);
		}
		ServiceDO serviceDO = serviceDAO.findOne(serviceId);
		if (serviceDO == null) {
			throw new ServiceRegistryException(ErrorCode.BIZ_SERVICE_NOT_FOUND,
					MessageFormat.format(CommonConstants.SERVICE_NOT_FOUND,
							String.valueOf(serviceId)));
		}
		return serviceDO;
	}

	private void validateDuplicateServiceVersionQoS(
			ServiceVersionDO serviceVersionDO, QoS qosParameter)
			throws PlatformException {
		for (ServiceVersionQoS serviceVersionQoS : serviceVersionDO
				.getServiceVersionQos()) {
			if (serviceVersionQoS.getQos().getName()
					.equalsIgnoreCase(qosParameter.getName())
					&& (!serviceVersionQoS.getQos().getId()
							.equals(qosParameter.getId()))) {
				throw new ServiceRegistryException(
						ErrorCode.BIZ_DUPLICATE_SERVICE_PARAMETER,
						MessageFormat
								.format(CommonConstants.DUPLICATE_SERVICE_PARAMETER_NAME,
										qosParameter.getName()));

			}
		}
	}

	private QoSDO validateQoSIfNotExists(String qosId) throws PlatformException {
		if (StringUtils.isEmpty(qosId)) {
			throw new ServiceRegistryException(ErrorCode.BIZ_INVALID_QAS_ID,
					CommonConstants.INVALID_QAS_ID);
		}
		QoSDO qos = qosDAO.findOne(qosId);
		if (qos == null) {
			throw new ServiceRegistryException(ErrorCode.BIZ_QOS_NOT_FOUND,
					CommonConstants.QOS_NOT_FOUND);
		}
		return qos;
	}

	private void validateServiceVersionParameter(QoS qos)
			throws PlatformException {
		if (StringUtils.isEmpty(qos.getId())) {
			throw new ServiceRegistryException(ErrorCode.BIZ_INVALID_QAS_ID,
					CommonConstants.INVALID_QAS_ID);
		}
		if (StringUtils.isEmpty(qos.getValue())) {
			throw new ServiceRegistryException(ErrorCode.BIZ_INVALID_QAS_VALUE,
					CommonConstants.INVALID_QAS_VALUE);
		}
	}

	private ServiceVersionQoS validateServiceVersionQoSIfNotExists(
			ServiceVersionDO serviceVersionDO, String qosId)
			throws PlatformException {
		if (StringUtils.isEmpty(qosId)) {
			throw new ServiceRegistryException(ErrorCode.BIZ_INVALID_QAS_ID,
					CommonConstants.INVALID_QAS_ID);
		}
		ServiceVersionQoS serviceVersionQoS = BizUtil.getServiceVersionQoS(
				serviceVersionDO, qosId);
		if (serviceVersionQoS == null) {
			throw new ServiceRegistryException(ErrorCode.BIZ_QOS_NOT_FOUND,
					CommonConstants.QOS_NOT_FOUND);
		}
		return serviceVersionQoS;
	}

	private ServiceVersionDO validateServiceVersionIfNotExists(
			String serviceVersionId) throws PlatformException {
		if (StringUtils.isEmpty(serviceVersionId)) {
			throw new ServiceRegistryException(
					ErrorCode.BIZ_INVALID_SERVICE_VERSION_ID,
					CommonConstants.INVALID_SERVICE_VERSION_ID);
		}
		ServiceVersionDO serviceVersionDO = serviceVersionDAO
				.findOne(serviceVersionId);
		if (serviceVersionDO == null) {
			throw new ServiceRegistryException(
					ErrorCode.BIZ_SERVICE_VERSION_NOT_FOUND,
					CommonConstants.SERVICE_VERSION_NOT_FOUND);
		}
		return serviceVersionDO;
	}

	private void validateService(Service service) {
		if (StringUtils.isEmpty(service.getName())) {
			throw new ServiceRegistryException(
					ErrorCode.BIZ_INVALID_SERVICE_NAME, MessageFormat.format(
							CommonConstants.INVALID_SERVICE_NAME,
							service.getName()));
		}
		if (StringUtils.isEmpty(service.getApplicationId())) {
			throw new ServiceRegistryException(
					ErrorCode.BIZ_INVALID_APPLICATION_ID, MessageFormat.format(
							CommonConstants.INVALID_APPLICATION_ID,
							service.getApplicationId()));
		}
	}

	private AuditDO audit(EntityDO entity) throws DataAccessException {
		AuditDO audit = BizUtil.getAddAudit(entity);
		return auditDAO.save(audit);
	}

	private AuditDO auditStatus(EntityDO entity, String oldValue)
			throws DataAccessException {
		AuditDO audit = BizUtil.getStatusAudit(entity, oldValue);
		return auditDAO.save(audit);
	}

	/**
	 * Publish the notification to the event bus if notification is enabled
	 * 
	 * @param serviceDO
	 * @param type
	 */
	private void publishToEventBus(Service serviceDTO) {
		LOG.info("Registry Notifcation enabled-->"
				+ registryConfig.isNotificationEnabled());
		if (Boolean
				.valueOf(registryConfig.isNotificationEnabled() != null ? registryConfig
						.isNotificationEnabled().trim() : "false")) {
			eventHandler.post(serviceDTO);
		}
	}

	/**
	 * This method clears the existing QoS parameters and set the QoS with the
	 * new details
	 * 
	 * @param serviceVersionDO
	 * @param qosParameters
	 * @throws PlatformException
	 */
	private void resetServiceVersionQoS(ServiceVersionDO serviceVersionDO,
			List<QoS> qosParameters) throws PlatformException {
		Set<ServiceVersionQoS> versionQoS = new HashSet<ServiceVersionQoS>(0);
		serviceVersionDO.getServiceVersionQos().clear();
		for (QoS qosParameter : qosParameters) {
			versionQoS.add(map(serviceVersionDO, qosParameter));
		}
		serviceVersionDO.getServiceVersionQos().addAll(versionQoS);
	}

	/**
	 * Populates available consumer subscription for the specific service and version combination. 
	 * @param services
	 */
	private void populateServiceVersionWithConsumerSubscription(List<Service> services) throws DataAccessException {
	  if(services!=null&&services.size()>0){
		Map<String,String> search = new HashMap<String,String>();
		 for(Service service:services){
			 search.put("name",service.getName());
			 search.put("environment",service.getEnvironment());
			 List<SubscriptionDO> subscriptions = subscriptionDAO.search(search);
		     if(subscriptions!=null && subscriptions.size() > 0) {
			  for(ServiceVersion serviceVersion:service.getServiceVersions()){
				 //search.put("serVersion",serviceVersion.getSerVersion());
			  	 	 for(SubscriptionDO subscription:subscriptions) {
			  	 		 String serVersionFromDO = subscription.getServiceVersion().getSerVersion();
			  	 		 String serVersionFromDTO = serviceVersion.getSerVersion();
			  	 		 if(serVersionFromDO!=null && serVersionFromDTO!=null && serVersionFromDTO.equals(serVersionFromDO)){
			  	 		  String communicationType = subscription.getCommunicationType();
			  			  String consumerId = subscription.getConsumer().getConsumerId();
			  			  ConsumerSubscription cs = new ConsumerSubscription();
			  			  cs.setCommunicationType(communicationType);
			  			  cs.setConsumerId(consumerId);
			  			  serviceVersion.getConsumerSubscriptions().add(cs);
			  	 		 }
			  		 }
			  	 }
			 }
		  }
		}
	}
	
	
	private ServiceVersionQoS map(ServiceVersionDO serviceVersionDO,
			QoS qosParameter) throws PlatformException {
		validateQoSIfNotExists(qosParameter.getId());
		validateDuplicateServiceVersionQoS(serviceVersionDO, qosParameter);
		QoSDO qos = qosDAO.findOne(qosParameter.getId());
		ServiceVersionQoS serviceVersionQoS = new ServiceVersionQoS();
		serviceVersionQoS.setQos(qos);
		serviceVersionQoS.setServiceVersion(serviceVersionDO);
		serviceVersionQoS.setQosValue(qosParameter.getValue());
		serviceVersionQoS.setCreatedAt(qosParameter.getCreatedAt());
		serviceVersionQoS.setCreatedBy(qosParameter.getCreatedBy());
		serviceVersionQoS.setModifiedAt(qosParameter.getModifiedAt());
		serviceVersionQoS.setModifiedBy(qosParameter.getModifiedBy());
		return serviceVersionQoS;
	}

	/**
	 * NOTE: removed ServiceRegistryException from throws since it is unchecked
	 * exception
	 * 
	 * @param serviceVersion
	 */
	private void validateActivationDate(ServiceVersion serviceVersion) {
		Timestamp activationStartDate = serviceVersion.getActivationStartDate();
		Timestamp activationEndDate = serviceVersion.getActivationEndDate();
		if (activationStartDate != null && activationEndDate != null
				&& activationStartDate.after(activationEndDate)) {
			throw new ServiceRegistryException(
					ErrorCode.BIZ_INVALID_SERVICE_VERSION_ACTIVATION_END_DATE_BEFORE_START_DATE,
					CommonConstants.INVALID_SERVICE_VERSION_ACTIVATION_END_DATE_BEFORE_START_DATE);
		}
	}

	private List<Service> mapToServices(List<ServiceDO> serviceDOs) {
		List<Service> services = mapper.mapToList(serviceDOs, Service.class);
		for (Service service : services) {
			BizUtil.mapQoSToQoSParameter(service, serviceDOs);
		}
		return services;
	}

	private Service mapTo(ServiceDO serviceDO) {
		if (serviceDO == null) {
			return null;
		}
		Service service = mapper.map(serviceDO, Service.class);
		BizUtil.mapQoSToQoSParameter(service,
				Arrays.asList(new ServiceDO[] { serviceDO }));
		return service;
	}

	private ServiceVersion mapTo(ServiceVersionDO serviceVersionDO) {
		if (serviceVersionDO == null) {
			return null;
		}
		ServiceVersion serviceVersion = mapper.map(serviceVersionDO,
				ServiceVersion.class);
		serviceVersion.setQoSParameters(BizUtil.mapTo(serviceVersionDO
				.getServiceVersionQos()));
		serviceVersion.setAttributes(BizUtil.mapAttributes(serviceVersionDO.getAttributes()));
		return serviceVersion;
	}

	private void addServiceVersionQoS1(ServiceVersionDO serviceVersionDO,QoS qosParameter) throws PlatformException {
		ServiceVersionQoS serviceVersionQoS = map(serviceVersionDO,qosParameter);
		serviceVersionDO.addServiceVersionQoS(serviceVersionQoS);
	}

	private List<Service> populateServiceWithVersions(List<ServiceVersionDO> serviceVersionDOs) {
		List<Service> services = new ArrayList<Service>(0);
		if (serviceVersionDOs != null && !serviceVersionDOs.isEmpty()) {
			Map<String, Service> serviceMap = new HashMap<String, Service>(0);
			for (ServiceVersionDO serviceVersionDO : serviceVersionDOs) {
				Service service = serviceMap.get(serviceVersionDO.getService().getId());
				if (service == null) {
					service = mapper.map(serviceVersionDO.getService(),Service.class);
					service.getServiceVersions().clear();
					serviceMap.put(service.getId(), service);
				}
				ServiceVersion serviceVersion = mapTo(serviceVersionDO);
				service.getServiceVersions().add(serviceVersion);
			}
			services.addAll(serviceMap.values());
		}
		return services;
	}

	private UrlDO getUrlDO(Set<UrlDO> urlDOs, String id) {
		if (StringUtils.isEmpty(id)) {
			return null;
		}
		for (UrlDO urlDO : urlDOs) {
			if (id.equals(urlDO.getId())) {
				return urlDO;
			}
		}
		return null;
	}

	private Url getUrl(List<Url> urls, String id) {
		for (Url url : urls) {
			if (id.equals(url.getId())) {
				return url;
			}
		}
		return null;
	}

	private ServiceVersionDO getServiceVersionByVersionNumber(
			ServiceDO service, String versionNumber) {
		for (ServiceVersionDO serviceVersion : service.getServiceVersions()) {
			if (serviceVersion.getSerVersion().equals(versionNumber)) {
				return serviceVersion;
			}
		}
		return null;
	}

	private ServiceVersionDO getServiceVersionById(ServiceDO service, String id) {
		for (ServiceVersionDO serviceVersion : service.getServiceVersions()) {
			if (serviceVersion.getId().equals(id)) {
				return serviceVersion;
			}
		}
		return null;
	}

	private boolean isDuplicate(ServiceDO service, String srcVersion, String id) {
		for (ServiceVersionDO existingVersion : service.getServiceVersions()) {
			if (existingVersion.getSerVersion().equals(srcVersion)
					&& !existingVersion.getId().equals(id)) {
				return true;
			}
		}
		return false;
	}

	private List<AuditDO> updateServiceVersionPolicies(
			ServiceVersionDO serviceVersionDO, List<Policy> policies)
			throws PlatformException {
		// Add new policies
		List<AuditDO> audits = new ArrayList<AuditDO>(0);
		for (Policy policy : policies) {
			PolicyDO exitingPolicy = getExitingPolicy(serviceVersionDO,
					policy.getId());
			if (exitingPolicy == null) {
				PolicyDO addedPolicy = addServiceVersionPolicy(
						serviceVersionDO, policy.getId());
				audits.add(BizUtil.getAddVersionPolicyAudit(serviceVersionDO,
						addedPolicy.getName()));
			}
		}
		// Remove policies
		Set<PolicyDO> existingPolicies = new HashSet<PolicyDO>(0);
		existingPolicies.addAll(serviceVersionDO.getPolicies());
		for (PolicyDO policy : existingPolicies) {
			Policy newPolicy = getNewPolicy(policies, policy.getId());
			if (newPolicy == null) {
				PolicyDO policyToRemove = getExitingPolicy(serviceVersionDO,
						policy.getId());
				if (policyToRemove != null) {
					serviceVersionDO.removePolicy(policyToRemove);
				}
				audits.add(BizUtil.getDeleteVersionPolicyAudit(
						serviceVersionDO, policy.getName()));
			}
		}
		return audits;
	}

	private List<AuditDO> auditServiceVersionQoS(
			ServiceVersionDO serviceVersionDO, List<QoS> qosList)
			throws PlatformException {
		// Add new qos
		List<AuditDO> audits = new ArrayList<AuditDO>(0);
		for (QoS qos : qosList) {
			QoSDO qosDO = validateQoSIfNotExists(qos.getId());
			ServiceVersionQoS exitingQoS = getExitingQoS(serviceVersionDO,
					qos.getId());
			if (exitingQoS == null) {
				audits.add(BizUtil.getAddVersionQoSAudit(serviceVersionDO,
						qosDO.getName()));
			} else {
				String newValue = qos.getValue() != null ? qos.getValue() : "";
				String oldValue = exitingQoS.getQosValue() != null ? exitingQoS
						.getQosValue() : "";
				if (!newValue.equals(oldValue)) {
					audits.add(BizUtil.getUpdateVersionQoSAudit(
							serviceVersionDO, qosDO.getName(), oldValue,
							newValue));
				}

			}
		}
		// Remove qos
		for (ServiceVersionQoS qos : serviceVersionDO.getServiceVersionQos()) {
			QoS newQoS = getNewQoS(qosList, qos.getQos().getId());
			if (newQoS == null) {
				audits.add(BizUtil
						.getDeleteVersionQoSAudit(serviceVersionDO, qos
								.getQos().getName()
								+ " ["
								+ qos.getQosValue()
								+ "]"));
			}
		}
		return audits;
	}

	private PolicyDO getExitingPolicy(ServiceVersionDO serviceVersionDO,
			String policyId) {
		for (PolicyDO policyDO : serviceVersionDO.getPolicies()) {
			if (policyDO.getId().equals(policyId)) {
				return policyDO;
			}
		}
		return null;
	}

	private Policy getNewPolicy(List<Policy> policies, String policyId) {
		for (Policy policy : policies) {
			if (policy.getId().equals(policyId)) {
				return policy;
			}
		}
		return null;
	}

	private ServiceVersionQoS getExitingQoS(ServiceVersionDO serviceVersionDO,
			String qosId) {
		for (ServiceVersionQoS serviceVersionQoS : serviceVersionDO
				.getServiceVersionQos()) {
			if (serviceVersionQoS.getQos().getId().equals(qosId)) {
				return serviceVersionQoS;
			}
		}
		return null;
	}

	private QoS getNewQoS(List<QoS> qosList, String qosId) {
		for (QoS qos : qosList) {
			if (qos.getId().equals(qosId)) {
				return qos;
			}
		}
		return null;
	}

	public List<Service> mapFilterServices(List<SubscriptionDO> subscriptions,ServiceSearchBean search) {
		boolean versionFilter = BizUtil.isServiceVersionFilterRequested(search);
		List<ServiceVersionDO> filteredVersions = new ArrayList<ServiceVersionDO>(0);
		for (SubscriptionDO subscription : subscriptions) {
			ServiceVersionDO serviceVersionDO = subscription.getServiceVersion();
			if (versionFilter) {
				serviceVersionDO = BizUtil.filter(subscription.getServiceVersion(), search);
			}
			if (serviceVersionDO != null) {
				filteredVersions.add(serviceVersionDO);
			}
		}
		return populateServiceWithVersions(filteredVersions, search);
	}

	private List<Service> populateServiceWithVersions(List<ServiceVersionDO> serviceVersionDOs, ServiceSearchBean search) {
		List<Service> services = new ArrayList<Service>(0);
		if (serviceVersionDOs != null && !serviceVersionDOs.isEmpty()) {
			Map<String, Service> serviceMap = new HashMap<String, Service>(0);
			for (ServiceVersionDO serviceVersionDO : serviceVersionDOs) {
				ServiceDO serviceFromVersion = serviceVersionDO.getService();
				if (BizUtil.isServiceFilterRequested(search)) {
					serviceFromVersion = BizUtil.filter(serviceFromVersion,search);
				}
				if (serviceFromVersion == null) {
					continue;
				}
				Service service = serviceMap.get(serviceFromVersion.getId());
				if (service == null) {
					ServiceDO serviceDO = serviceVersionDO.getService();
					service = mapper.map(serviceDO, Service.class);
					service.getServiceVersions().clear();
					serviceMap.put(service.getId(), service);
				}
				ServiceVersion serviceVersion = mapTo(serviceVersionDO);
				service.getServiceVersions().add(serviceVersion);
			}
			services.addAll(serviceMap.values());
		}
		return services;
	}

}