package com.walmart.platform.soari.registry.biz.api;

import java.util.List;

import com.walmart.platform.kernel.exception.layers.business.BusinessException;
import com.walmart.platform.soari.registry.common.dto.Policy;

public interface PolicyManager {
	
	/**
	 * Fetches all the policies
	 * 
	 * @return list of all policies
	 * @throws BusinessException
	 */
	List<Policy> getPolicies() throws BusinessException;
	
	/**
	 * Fetches policy by id
	 * 
	 * @param id Identifier for Policy being searched
	 * @return Matched policy or null
	 * @throws BusinessException
	 */
	Policy getPolicyById(String id) throws BusinessException;
	
	/**
	 * Fetches policy by name
	 * 
	 * @param name Name for Policy being searched
	 * @return Matched policy or null
	 * @throws BusinessException
	 */
	Policy getPolicyByName(String name) throws BusinessException;
	
	/**
	 * Fetches list of policies by matching name 
	 * 
	 * @param searchName Name of the policy being searched for
	 * @param searchValue Matching criteria
	 * @return list of policies matching criteria
	 * @throws BusinessException
	 */
	List<Policy> searchPolicies(String searchName, String searchValue) throws BusinessException;
	
	/**
	 * Creates a new policy, checks for duplicates
	 * 
	 * @param policy Policy to be added
	 * @return Newly-added policy or null
	 * @throws BusinessException
	 */
	Policy addPolicy(Policy policy) throws BusinessException;
	
	/**
	 * Updates a policy 
	 * 
	 * @param policy Policy to be updated
	 * @return updated/newly-created policy or null
	 * @throws BusinessException
	 */
	Policy updatePolicy(Policy policy) throws BusinessException;
	
	/**
	 * Updates policy status 
	 * 
	 * @param id Identifier for Policy
	 * @param action [activate, deactivate, delete]
	 * @param actionBy 'modifiedBy' in Entity Table
	 * @return updated Policy
	 * @throws BusinessException
	 */
	Policy updatePolicyStatus(String id, String action, String actionBy)throws BusinessException;
}
