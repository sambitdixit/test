package com.walmart.platform.soari.registry.biz.impl;

import java.text.MessageFormat;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.walmart.platform.kernel.exception.layers.business.BusinessException;
import com.walmart.platform.soari.registry.biz.api.DashboardManager;
import com.walmart.platform.soari.registry.common.enums.ReportType;
import com.walmart.platform.soari.registry.domain.dao.api.ServiceDAO;
import com.walmart.platform.soari.registry.domain.dao.api.SubscriptionDAO;
import com.walmart.platform.soari.registry.server.common.error.ErrorCode;
import com.walmart.platform.soari.registry.server.common.exception.ExceptionHandler;
import com.walmart.platform.soari.registry.server.common.exception.ServiceRegistryException;
import com.walmart.platform.soari.registry.server.common.util.CommonConstants;

@Service("dashboardManager")
public class DashboardManagerImpl implements DashboardManager{

	@Autowired
	private ServiceDAO serviceDAO;

	@Autowired
	private SubscriptionDAO subscriptionDAO;

	@Autowired
	private ExceptionHandler exceptionHandler;
	
	private static final Logger LOG = LoggerFactory
			.getLogger(DashboardManagerImpl.class);

	/**
	 * Total no of unique services registered per environment. Like qa – 10, pqa – 10, dev –10 etc.
	 * @return
	 * @throws ServiceException
	 */
	private String getServiceCountPerEnvironment() throws BusinessException {
		LOG.debug("Executing getServiceCountPerEnvironment");
		String result = null;
		try {
			result = serviceDAO.findServiceCountPerEnvironment();

		} catch (Exception ex) {
			LOG.error(MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE,
					ex.getMessage()));
			exceptionHandler.handleBusinessException(ex);
		}
		return result;
	}
	
	/**
	 * Total no of data services/business/infra etc type of services per environment.
	 * @return
	 * @throws ServiceException
	 */
	private String getServiceCategoryCountPerEnvironment() throws BusinessException {
		LOG.debug("Executing getServiceCategoryCountPerEnvironment");
		String result = null;
		try {
			result = serviceDAO.findCategoryCountPerEnvironment();

		} catch (Exception ex) {
			LOG.error(MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE,
					ex.getMessage()));
			exceptionHandler.handleBusinessException(ex);
		}
		return result;
	}
	
	/**
	 * Which service has been registered in maximum no of environments
	 * @return
	 * @throws ServiceException
	 */
	private String getEnvironmentCountPerService() throws BusinessException {
		LOG.debug("Executing getEnvironmentCountPerService");
		String result = null;
		try {
			result = serviceDAO.findEnvironmentCountForService();

		} catch (Exception ex) {
			LOG.error(MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE,
					ex.getMessage()));
			exceptionHandler.handleBusinessException(ex);
		}
		return result;
	}

	/**
	 * How many consumers have been on boarded so far in each environment
	 * @return
	 * @throws ServiceException
	 */
	private String getSubscriptionCountPerEnvironment() throws BusinessException {
		LOG.debug("Executing getSubscriptionCountPerEnvironment");
		String result = null;
		try {
			result = subscriptionDAO.findSubscriptionCountPerEnvironment();

		} catch (Exception ex) {
			LOG.error(MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE,
					ex.getMessage()));
			exceptionHandler.handleBusinessException(ex);
		}
		return result;
	}
	
	/**
	 * How many consumers have been on boarded so far in each environment
	 * @return
	 * @throws ServiceException
	 */
	private String getConsumerCountPerEnvironment() throws BusinessException {
		LOG.debug("Executing getConsumerCountPerEnvironment");
		String result = null;
		try {
			result = subscriptionDAO.findConsumerCountPerEnvironment();

		} catch (Exception ex) {
			LOG.error(MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE,
					ex.getMessage()));
			exceptionHandler.handleBusinessException(ex);
		}
		return result;
	}

	/**
	 * Which consumer has how many subscriptions in each environment
	 * @return
	 * @throws ServiceException
	 */
	private String getConsumerSubscriptionCountPerEnvironment()
			throws BusinessException {
		LOG.debug("Executing getConsumerSubscriptionCountPerEnvironment");
		String result = null;
		try {
			result = subscriptionDAO.findConsumerSubscriptionCountPerEnvironment();

		} catch (Exception ex) {
			LOG.error(MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE,
					ex.getMessage()));
			exceptionHandler.handleBusinessException(ex);
		}
		return result;
	}

	/**
	 * No of services getting on-boarded in each month
	 * @return
	 * @throws ServiceException
	 */
	private String getServiceCountPerMonth() throws BusinessException {
		LOG.debug("Executing getServiceCountPerMonth");
		String result = null;
		try {
			result = serviceDAO.findServiceCountPerMonth();

		} catch (Exception ex) {
			LOG.error(MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE,
					ex.getMessage()));
			exceptionHandler.handleBusinessException(ex);
		}
		return result;
	}
	
	/**
	 * Which service has max consumer subscriptions?
	 * @return
	 * @throws ServiceException
	 */
	private String findSubscriptionCountPerService() throws BusinessException {
		LOG.debug("Executing findSubscriptionCountPerService");
		String result = null;
		try {
			result = subscriptionDAO.findSubscriptionCountPerService();

		} catch (Exception ex) {
			LOG.error(MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE,
					ex.getMessage()));
			exceptionHandler.handleBusinessException(ex);
		}
		return result;
	}
	
	/**
	 * Which many consumer has subscribed max number of services
	 * @return
	 * @throws ServiceException
	 */
	private String findServiceCountPerConsumer() throws BusinessException {
		LOG.debug("Executing findServiceCountPerConsumer");
		String result = null;
		try {
			result = subscriptionDAO.findServiceCountPerConsumer();

		} catch (Exception ex) {
			LOG.error(MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE,
					ex.getMessage()));
			exceptionHandler.handleBusinessException(ex);
		}
		return result;
	}

	@Override
	@Transactional(readOnly=true)
	public String getReport(ReportType reportType) throws BusinessException {
		LOG.debug("Executing service api : getReport ");
		String result = null;
		try {
			if(ReportType.CONSUMERS_PER_ENVIRONMENT == reportType) {
				result = getConsumerCountPerEnvironment();
			}else if(ReportType.CUNSUMER_SUBSCRIPTIONS_PER_ENVIRONMENT == reportType) {
				result = getConsumerSubscriptionCountPerEnvironment();
			}else if(ReportType.ENVIRONMENTS_PER_SERVICE == reportType) {
				result = getEnvironmentCountPerService();
			}else if(ReportType.SERVICE_CATEGORIES_PER_ENVIRONMENT == reportType) {
				result = getServiceCategoryCountPerEnvironment();
			}else if(ReportType.SERVICES_PER_ENVIRONMENT == reportType) {
				result = getServiceCountPerEnvironment();
			}else if(ReportType.SERVICES_PER_MONTH == reportType) {
				result = getServiceCountPerMonth();
			}else if(ReportType.CONSUMER_SUBSCRIPTIONS_PER_SERVICE == reportType) {
				result = findSubscriptionCountPerService();
			}else if(ReportType.SERVICES_PER_CONSUMER == reportType) {
				result = findServiceCountPerConsumer();
			}else if(ReportType.SUBSCRIPTIONS_PER_ENVIRONMENT == reportType) {
				result = getSubscriptionCountPerEnvironment();
			}else {
				throw new ServiceRegistryException(
						ErrorCode.BIZ_INVALID_REPORT_TYPE, CommonConstants.INVALID_REPORT_TYPE + ": "+reportType);
			}
		}catch(Exception ex) {
			String message = MessageFormat.format(CommonConstants.INVALID_REPORT_TYPE, ex.getMessage());
			LOG.error(message);
			exceptionHandler.handleBusinessException(ex);
		}
		return result;	
	}
	
}
