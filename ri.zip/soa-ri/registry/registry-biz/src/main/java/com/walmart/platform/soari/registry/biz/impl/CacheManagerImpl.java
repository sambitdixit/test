package com.walmart.platform.soari.registry.biz.impl;

import java.text.MessageFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.core.MediaType;

import org.apache.commons.lang.StringUtils;
import org.codehaus.jackson.map.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.walmart.platform.kernel.exception.layers.business.BusinessException;
import com.walmart.platform.soa.http.client.PlatformHttpClient;
import com.walmart.platform.soari.registry.biz.api.CacheManager;
import com.walmart.platform.soari.registry.biz.util.BizUtil;
import com.walmart.platform.soari.registry.domain.RegistryPolicyCode;
import com.walmart.platform.soari.registry.domain.dao.impl.RegistryPolicyCodeDAOImpl;
import com.walmart.platform.soari.registry.server.common.error.ErrorCode;
import com.walmart.platform.soari.registry.server.common.exception.ExceptionHandler;
import com.walmart.platform.soari.registry.server.common.util.CommonConstants;

@Service("cacheManager")
public class CacheManagerImpl implements CacheManager {

	@Autowired
	private ExceptionHandler exceptionHandler;

	@Autowired
	private RegistryPolicyCodeDAOImpl registryPolicyCodeDAO;

	@Value("${cmdb.env.url}")
	private String cmdbEnvironmentUrl;

	@Value("${cmdb.artifact.url}")
	private String cmdbArtifactUrl;

	@Value("${jira.url}")
	private String jiraUrl;

	private static final Logger LOG = LoggerFactory
			.getLogger(PolicyManagerImpl.class);

	@SuppressWarnings("rawtypes")
	public void refreshEnvCache(String value, boolean defaultEnvRequired) throws Exception {
		if (StringUtils.isEmpty(value)) {
			return;
		}
		Map<String, RegistryPolicyCode> codes = new HashMap<String, RegistryPolicyCode>(
				0);
		if (value != null) {
			ObjectMapper mapper = new ObjectMapper();
			Map<?, ?> rootAsMap = mapper.readValue(value.getBytes(), Map.class);
			List parents = (List) rootAsMap.get("payload");
			if (parents == null || parents.isEmpty()) {
				return;
			}
			for (Object parentObject : parents) {
				Map parent = (Map) parentObject;
				RegistryPolicyCode registryPolicyCode = new RegistryPolicyCode();
				registryPolicyCode.setCode((String) parent.get("name"));
				registryPolicyCode.setDescription((String) parent.get("desc"));
				codes.put(registryPolicyCode.getCode(), registryPolicyCode);
			}
			if(defaultEnvRequired) {
				RegistryPolicyCode registryPolicyCode = new RegistryPolicyCode();
				registryPolicyCode.setCode("dev");
				registryPolicyCode.setDescription("dev");
				codes.put(registryPolicyCode.getCode(), registryPolicyCode);
			}
			RegistryPolicyCodeDAOImpl.refreshEnvCache(codes);
		}
	}

	@SuppressWarnings("rawtypes")
	public void refreshArtifactCache(String value) throws Exception {
		if (StringUtils.isEmpty(value)) {
			return;
		}
		Map<String, RegistryPolicyCode> codes = new HashMap<String, RegistryPolicyCode>(
				0);
		if (value != null) {
			ObjectMapper mapper = new ObjectMapper();
			Map<?, ?> rootAsMap = mapper.readValue(value.getBytes(), Map.class);
			List parents = (List) rootAsMap.get("payload");
			if (parents == null || parents.isEmpty()) {
				return;
			}
			for (Object parentObject : parents) {
				Map parent = (Map) parentObject;
				RegistryPolicyCode registryPolicyCode = new RegistryPolicyCode();
				registryPolicyCode.setCode((String) parent.get("appName"));
				registryPolicyCode.setDescription((String) parent
						.get("appName"));
				codes.put(registryPolicyCode.getCode(), registryPolicyCode);
			}
			RegistryPolicyCodeDAOImpl.refreshArtifactCache(codes);
		}
	}

	@SuppressWarnings("rawtypes")
	public void refreshJIRACache(String value) throws Exception {
		if (StringUtils.isEmpty(value)) {
			return;
		}
		Map<String, RegistryPolicyCode> jiraProjects = new HashMap<String, RegistryPolicyCode>(
				0);
		if (value != null) {
			ObjectMapper mapper = new ObjectMapper();
			Map<?, ?> rootAsMap = mapper.readValue(value.getBytes(), Map.class);
			List parents = (List) rootAsMap.get("projects");
			if (parents == null || parents.isEmpty()) {
				return;
			}
			for (Object parentObject : parents) {
				Map parent = (Map) parentObject;
				RegistryPolicyCode registryPolicyCode = new RegistryPolicyCode();
				registryPolicyCode.setCode((String) parent.get("key"));
				registryPolicyCode.setDescription((String) parent.get("name"));
				jiraProjects.put(registryPolicyCode.getCode(),
						registryPolicyCode);
			}
			RegistryPolicyCodeDAOImpl.refreshJIRACache(jiraProjects);
		}
	}

	@SuppressWarnings("deprecation")
	@Override
	public void refreshEnvCache() throws BusinessException {
		LOG.debug("Executing manager api : refreshEnvCache ");
		try {
			String host = CommonConstants.getRunOnEnv();
			boolean defaultEnvRequired = false;
			String response = "";
			if (CommonConstants.RUN_ON_ENV_DEFAULT.equals(host)) {
				response = BizUtil.getJsonDefaultEnv();
			} else {
				if (host.startsWith("dev") || host.startsWith("DEV") ) {
					defaultEnvRequired = true;
				}
				PlatformHttpClient httpClient = PlatformHttpClient
						.getInstance();
				httpClient.setAcceptType(MediaType.APPLICATION_JSON);
				response = httpClient.get(cmdbEnvironmentUrl, null,
						String.class, null, null, null);
			}
			refreshEnvCache(response, defaultEnvRequired);
		} catch (Exception ex) {
			String message = MessageFormat.format(
					CommonConstants.CMDB_ENVIRONMENTS_ACCESS_FAILED,
					ex.getMessage());
			LOG.error(message);
			exceptionHandler.handleBusinessException(
					ErrorCode.BIZ_CMDB_ENVIRONMENTS_ACCESS_FAILED.toString(),
					message);
		}
	}

	@SuppressWarnings("deprecation")
	@Override
	public void refreshArtifactCache() throws BusinessException {
		LOG.debug("Executing manager api : refreshEnvCache ");
		try {
			String host = CommonConstants.getRunOnEnv();
			String response = "";
			if (CommonConstants.RUN_ON_ENV_DEFAULT.equals(host)) {
				response = BizUtil.getJsonDefaultArtifacts();
			} else {
				PlatformHttpClient httpClient = PlatformHttpClient
						.getInstance();
				httpClient.setAcceptType(MediaType.APPLICATION_JSON);
				response = httpClient.get(cmdbArtifactUrl, null, String.class,
						null, null, null);
			}
			refreshArtifactCache(response);
		} catch (Exception ex) {
			String message = MessageFormat.format(
					CommonConstants.CMDB_ARTIFACTS_ACCESS_FAILED,
					ex.getMessage());
			LOG.error(message);
			exceptionHandler.handleBusinessException(
					ErrorCode.BIZ_CMDB_ARTIFACTS_ACCESS_FAILED.toString(),
					message);
		}
	}

	@SuppressWarnings("deprecation")
	@Override
	public void refreshJIRACache() throws BusinessException {
		LOG.debug("Executing manager api : refreshJIRACache ");
		try {
			String host = CommonConstants.getRunOnEnv();
			String response = "";
			if (CommonConstants.RUN_ON_ENV_DEFAULT.equals(host)) {
				response = BizUtil.getJsonDefaultJIRAProjects();
			} else {
				PlatformHttpClient httpClient = PlatformHttpClient
						.getInstance();
				httpClient.setAcceptType(MediaType.APPLICATION_JSON);
				response = httpClient.get(jiraUrl + "/createmeta", null,
						String.class, null, null, null);
			}
			refreshJIRACache(response);
		} catch (Exception ex) {
			String message = MessageFormat.format(
					CommonConstants.CMDB_ARTIFACTS_ACCESS_FAILED,
					ex.getMessage());
			LOG.error(message);
			exceptionHandler.handleBusinessException(
					ErrorCode.BIZ_CMDB_ARTIFACTS_ACCESS_FAILED.toString(),
					message);
		}
	}

	@Override
	public void refreshCodeCache() throws BusinessException {
		LOG.debug("Executing manager api : refreshCodeCache ");
		try {
			registryPolicyCodeDAO.rebuildCodeCache();
		} catch (Exception ex) {
			String message = MessageFormat.format(
					CommonConstants.CACHE_BUILD_CODES_FALIED, ex.getMessage());
			LOG.error(message);
			exceptionHandler.handleBusinessException(
					ErrorCode.CACHE_BUILD_CODES_FALIED.toString(), message);
		}
	}
}
