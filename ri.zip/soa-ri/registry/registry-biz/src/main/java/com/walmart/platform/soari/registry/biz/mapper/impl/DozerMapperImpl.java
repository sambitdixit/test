package com.walmart.platform.soari.registry.biz.mapper.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
 
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.apache.commons.lang.StringUtils;
import org.dozer.DozerBeanMapper;
import org.dozer.MappingException;
import org.springframework.beans.factory.annotation.Autowired;
import com.walmart.platform.kernel.exception.layers.base.PlatformException;
import com.walmart.platform.kernel.exception.layers.dao.DataAccessException;
import com.walmart.platform.soari.registry.biz.mapper.api.DozerMapper;
import com.walmart.platform.soari.registry.biz.util.BizUtil;
import com.walmart.platform.soari.registry.common.dto.Consumer;
import com.walmart.platform.soari.registry.common.dto.Policy;
import com.walmart.platform.soari.registry.common.dto.Service;
import com.walmart.platform.soari.registry.common.dto.ServiceSearchBean;
import com.walmart.platform.soari.registry.common.dto.ServiceVersion;
import com.walmart.platform.soari.registry.common.dto.Subscription;
import com.walmart.platform.soari.registry.domain.ConsumerDO;
import com.walmart.platform.soari.registry.domain.ServiceDO;
import com.walmart.platform.soari.registry.domain.ServiceVersionDO;
import com.walmart.platform.soari.registry.domain.SubscriptionDO;
import com.walmart.platform.soari.registry.domain.dao.api.ConsumerDAO;
import com.walmart.platform.soari.registry.domain.dao.api.QoSDAO;
import com.walmart.platform.soari.registry.domain.dao.api.ServiceVersionDAO;

/**
 * Custom DozerBeanMapper class to have additional mapping methods
 * 
 * @author sbonde
 * 
 */
public class DozerMapperImpl extends DozerBeanMapper implements DozerMapper {

	private static final Logger LOG = LoggerFactory.getLogger(DozerMapperImpl.class);
	
	@Autowired
	private ServiceVersionDAO serviceVersionDAO;

	@Autowired
	private ConsumerDAO consumerDAO;
	
	@Autowired
	private QoSDAO qosDAO;

	@Override
	public <S, D> List<D> mapToList(final List<S> source,
			final Class<D> destinationClass) {
		final List<D> result = new ArrayList<D>();
		for (S element : source) {
			result.add(this.map(element, destinationClass));
		}
		return result;
	}

	@Override
	public <S, D> List<D> mapToList(final Set<S> source,
			final Class<D> destinationClass) {
		final List<D> result = new ArrayList<D>();
		for (S element : source) {
			result.add(this.map(element, destinationClass));
		}
		return result;
	}

	/**
	 * NOTE : removed MappingException from throws since it is unchecked exception
	 */
	@Override
	public <T> T map(Object source, Class<T> destinationClass) {
		Object dest = getMappingProcessor().map(source, destinationClass);
		try {
			if (source instanceof ServiceDO
					&& destinationClass != null
					&& destinationClass.getSimpleName().equals(
							Service.class.getSimpleName())) {
				BizUtil.reset((Service) dest, (ServiceDO) source);
			}
			return mapSubscription(source, dest);
		}catch (PlatformException ex) {
			LOG.error("Exception in DozerMapperImpl with stack trace", ex);
			throw new MappingException(ex.getMessage());
		}
	}
	
	/**
	 * NOTE: res1...res6 have been added to avoid 'too much complex boolean expression' of return statement
	 * @param source
	 * @param dest
	 * @return
	 */
	private <T> boolean isSubscriptionMapping(Object source, Object dest) {
		
		boolean res1 = (source instanceof Subscription && dest instanceof SubscriptionDO);
		boolean res2 = (source instanceof SubscriptionDO && dest instanceof Subscription);
		boolean res3 = (source instanceof Consumer && dest instanceof ConsumerDO);
		boolean res4 = (source instanceof ConsumerDO && dest instanceof Consumer);
		
		boolean res5 = res1 || res2;
		boolean res6 = res3 || res4;
		
		return source != null && (res5 || res6);
	}

	/**
	 * NOTE: removed MappingException from throws since it is unchecked exception
	 * @param source
	 * @param dest
	 * @return
	 * @throws DataAccessException
	 */
	@SuppressWarnings("unchecked")
	public <T> T mapSubscription(Object source, Object dest) throws PlatformException {
		if (!isSubscriptionMapping(source, dest)) {
			return (T) dest;
		}
		if (source instanceof ConsumerDO && dest instanceof Consumer) {
			ConsumerDO consumerDO = (ConsumerDO)source;
			Consumer consumer = (Consumer)dest;
			consumer.getSubscriptions().clear();
			List<Subscription> subscriptions = this.mapToList(consumerDO.getSubscriptions(), Subscription.class);
			consumer.getSubscriptions().addAll(subscriptions);
		} else {
			if (source instanceof SubscriptionDO
					&& dest instanceof Subscription) {
				Subscription subscription = (Subscription) dest;
				SubscriptionDO subscriptionDO = (SubscriptionDO) source;
				subscription.setConsumerId(subscriptionDO.getConsumer()
						.getConsumerId());
				ServiceVersionDO serviceVersion = subscriptionDO
						.getServiceVersion();
				if (serviceVersion != null) {
					subscription.setServiceVersionStatus(serviceVersion.getStatus());
					ServiceDO service = serviceVersion.getService();
					if (service != null) {
						subscription.setEnvironment(service.getEnvironment());
						subscription.setServiceName(service.getName());
						subscription.setServiceId(service.getId());
						subscription.setApplicationId(service.getApplicationId());
						subscription.setServiceStatus(service.getStatus());
						subscription.setServiceCategory(service.getCategory());
						subscription.setServiceUsage(service.getUsage());
						subscription.setServiceDomain(service.getDomain());
						subscription.setServiceOwner(service.getOwner());
					}
					subscription.setRequestUrl(BizUtil.getRequestUrl(subscriptionDO));
					subscription.setAlternateUrls(BizUtil.getAlternateUrls(subscriptionDO));
					subscription.setServiceVersionId(serviceVersion.getId());
					subscription.setVersionNumber(serviceVersion
							.getSerVersion());
					subscription.getQosParameters().addAll(BizUtil.mapTo(serviceVersion.getServiceVersionQos()));
					subscription.setPolicies(this.mapToList(serviceVersion.getPolicies(), Policy.class));
				}
			} else if (source instanceof Subscription
					&& dest instanceof SubscriptionDO) {
				SubscriptionDO subscriptionDO = (SubscriptionDO) dest;
				Subscription subscription = (Subscription) source;
				if (!StringUtils.isEmpty(subscription.getServiceVersionId())) {
					ServiceVersionDO serviceVersion = serviceVersionDAO
							.findOne(subscription.getServiceVersionId());
					subscriptionDO.setServiceVersion(serviceVersion);
				}
				if (!StringUtils.isEmpty(subscription.getConsumerId())) {
					List<ConsumerDO> consumers = consumerDAO
							.findByConsumerId(subscription.getConsumerId());
					if (consumers != null && !consumers.isEmpty()) {
						subscriptionDO.setConsumer(consumers.get(0));
					}
				}
			}
		}
		return (T) dest;
	}
	
	@Override
	public List<Service> mapFilterVersions(List<ServiceDO> services, ServiceSearchBean search) {
		List<Service> result = new ArrayList<Service>(0);
		for(ServiceDO serviceDO : services) {
			Service service = mapFilterVersions(serviceDO, search);
			if(service != null) {
				result.add(service);
			}
		}
		return result;
	}
	
	@Override
	public Service mapFilterVersions(ServiceDO serviceDO, ServiceSearchBean search) {
		Service service = this.map(serviceDO, Service.class);
		service.getServiceVersions().clear();
		for(ServiceVersionDO serviceVersionDO : serviceDO.getServiceVersions()) {
			serviceVersionDO = BizUtil.filter(serviceVersionDO, search);
			if(serviceVersionDO != null) {
				ServiceVersion serviceVersion = this.map(serviceVersionDO, ServiceVersion.class);
				serviceVersion.setQoSParameters(BizUtil.mapTo(serviceVersionDO
						.getServiceVersionQos()));
				service.getServiceVersions().add(serviceVersion);
			}
		}
		return service.getServiceVersions().isEmpty()?null:service;
	}

}
