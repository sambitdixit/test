package com.walmart.platform.soari.registry.biz.notification.impl;

import java.util.List;

import com.google.common.eventbus.EventBus;
import com.walmart.platform.soari.registry.biz.notification.api.EventHandler;

/**
 * @author sambitdikshit
 *
 */
public class EventHandlerImpl implements EventHandler {

	private EventBus eventBus;

	@Override
	public EventBus getEventBus() {
		return eventBus;
	}

	@Override
	public void setEventBus(EventBus eventBus) {
		this.eventBus = eventBus;
	}

	@Override
	public void setSubscribers(List<Object> subscribers) {
		if (subscribers != null && !subscribers.isEmpty()) {
			for (Object s : subscribers) {
				eventBus.register(s);
			}
		}
	}
	
	@Override
	public void post(Object event){
		eventBus.post(event);
	}

}
