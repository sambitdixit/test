package com.walmart.platform.soari.registry.biz.api;

import java.util.List;

import com.walmart.platform.kernel.exception.layers.business.BusinessException;
import com.walmart.platform.soari.registry.common.dto.NotificationDestination;

public interface NotificationDestinationManager {
	
	/**
	 * Fetches list of all NotificationDestination
	 * 
	 * @return list of all NotificationDestination
	 * @throws BusinessException
	 */
	List<NotificationDestination> getNotificationDestinations() throws BusinessException;
	
	/**
	 * Fetches NotificationDestination by Id  
	 * @param id Identifier of NotificationDestination being searched
	 * @return Matching NotificationDestination
	 * @throws BusinessException
	 */
	NotificationDestination getNotificationDestinationById(String id) throws BusinessException;
	
	/**
	 * Fetches NotificationDestination by name 
	 * 
	 * @param name Name of NotificationDestination being searched
	 * @return Matching NotificationDestination
	 * @throws BusinessException
	 */
	NotificationDestination getNotificationDestinationByName(String name) throws BusinessException;
	
	/**
	 *  Fetches list of NotificationDestination with matching criteria
	 * 
	 * @param searchName Name for NotificationDestination
	 * @param searchValue matching criteria
	 * @return list of all matching NotificationDestination
	 * @throws BusinessException
	 */
	List<NotificationDestination> searchNotificationDestinations(String searchName, String searchValue) throws BusinessException;
	
	/**
	 * Creates a new NotificationDestination, checks for duplicates too 
	 * 
	 * @param notificationDestination new NotificationDestination to be created
	 * @return newly-created NotificationDestination
	 * @throws BusinessException
	 */
	NotificationDestination addNotificationDestination(NotificationDestination notificationDestination) throws BusinessException;
	
	/**
	 * Updates NotificationDestination
	 * 
	 * @param notificationDestination NotificationDestination to be updated
	 * @return updated NotificationDestination
	 * @throws BusinessException
	 */
	NotificationDestination updateNotificationDestination(NotificationDestination notificationDestination) throws BusinessException;
	
	/**
	 * Updates status of NotificationDestination
	 * 
	 * @param id Identifier for NotificationDestination
	 * @param action [activate, deactivate, delete]
	 * @param actionBy 'modifiedBy' in Entity Table
	 * @return updated NotificationDestination
	 * @throws BusinessException
	 */
	NotificationDestination updateNotificationDestinationStatus(String id, String action, String actionBy)throws BusinessException;
}
