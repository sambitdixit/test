package com.walmart.platform.soari.registry.biz.impl;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.walmart.platform.kernel.exception.layers.base.PlatformException;
import com.walmart.platform.kernel.exception.layers.business.BusinessException;
import com.walmart.platform.kernel.exception.layers.dao.DataAccessException;
import com.walmart.platform.soari.registry.biz.api.ConsumerManager;
import com.walmart.platform.soari.registry.biz.mapper.api.DozerMapper;
import com.walmart.platform.soari.registry.biz.notification.impl.NotificationDeligatorImpl;
import com.walmart.platform.soari.registry.biz.util.BizUtil;
import com.walmart.platform.soari.registry.common.dto.Consumer;
import com.walmart.platform.soari.registry.common.dto.ServiceSearchBean;
import com.walmart.platform.soari.registry.common.dto.Subscription;
import com.walmart.platform.soari.registry.common.dto.SubscriptionRequest;
import com.walmart.platform.soari.registry.common.enums.EntityType;
import com.walmart.platform.soari.registry.common.enums.NotificationDestinationType;
import com.walmart.platform.soari.registry.common.enums.RegistryPolicyCodeType;
import com.walmart.platform.soari.registry.common.enums.StatusType;
import com.walmart.platform.soari.registry.domain.AuditDO;
import com.walmart.platform.soari.registry.domain.ConsumerDO;
import com.walmart.platform.soari.registry.domain.RegistryPolicyCode;
import com.walmart.platform.soari.registry.domain.ServiceDO;
import com.walmart.platform.soari.registry.domain.ServiceVersionDO;
import com.walmart.platform.soari.registry.domain.SubscriptionDO;
import com.walmart.platform.soari.registry.domain.dao.api.AuditDAO;
import com.walmart.platform.soari.registry.domain.dao.api.ConsumerDAO;
import com.walmart.platform.soari.registry.domain.dao.api.PolicyDAO;
import com.walmart.platform.soari.registry.domain.dao.api.QoSDAO;
import com.walmart.platform.soari.registry.domain.dao.api.ServiceVersionDAO;
import com.walmart.platform.soari.registry.domain.dao.api.SubscriptionDAO;
import com.walmart.platform.soari.registry.domain.dao.impl.RegistryPolicyCodeDAOImpl;
import com.walmart.platform.soari.registry.server.common.error.ErrorCode;
import com.walmart.platform.soari.registry.server.common.exception.ExceptionHandler;
import com.walmart.platform.soari.registry.server.common.exception.ServiceRegistryException;
import com.walmart.platform.soari.registry.server.common.util.CommonConstants;

/**
 * A class to perform business logic for mapping/transformation of DTO to Domain
 * objects and invoke Persistence APIs
 * 
 * @author sbonde
 * 
 */
@org.springframework.stereotype.Service("consumerManager")
public class ConsumerManagerImpl implements ConsumerManager {

	private static final Logger LOG = LoggerFactory
			.getLogger(ConsumerManagerImpl.class);

	@Autowired
	private ConsumerDAO consumerDAO;

	@Autowired
	private DozerMapper mapper;

	@Autowired
	private ExceptionHandler exceptionHandler;

	@Autowired
	private AuditDAO auditDAO;

	@Autowired
	private ServiceVersionDAO serviceVersionDAO;

	@Autowired
	private SubscriptionDAO subscriptionDAO;
	
	@Autowired
	private QoSDAO qosDAO;
	
	@Autowired
	private PolicyDAO policyDAO;

	@Autowired
	private NotificationDeligatorImpl notificationDeligator;
	
	@Override
	@Transactional(rollbackFor={BusinessException.class})
	public List<Consumer> getConsumers() throws BusinessException {
		LOG.debug("Executing getConsumers ");
		List<Consumer> consumers = new ArrayList<Consumer>(0);
		try {
			List<ConsumerDO> consumerDOs = consumerDAO.findAll();
			consumers = mapper.mapToList(consumerDOs, Consumer.class);
		} catch (Exception ex) {
			LOG.error(MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE,
					ex.getMessage()));
			exceptionHandler.handleBusinessException(ex);
		}
		return consumers;
	}

	@Override
	@Transactional(rollbackFor={BusinessException.class})
	public Consumer getById(String id) throws BusinessException {
		LOG.debug("Executing getById for : " + id);
		Consumer result = null;
		try {
			if (StringUtils.isEmpty(id)) {
				throw new ServiceRegistryException(
						ErrorCode.BIZ_INVALID_CONSUMER_ID,
						CommonConstants.INVALID_CONSUMER_ID);
			} else {
				ConsumerDO consumerDO = consumerDAO.findOne(id);
				if (consumerDO != null) {
					result = mapper.map(consumerDO, Consumer.class);
				}
			}
		} catch (Exception ex) {
			LOG.error(MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE,
					ex.getMessage()));
			exceptionHandler.handleBusinessException(ex);
		}
		return result;
	}

	/**
	 * Method to create a new Consumer
	 */
	@Override
	@Transactional(rollbackFor={BusinessException.class})
	public Consumer addConsumer(Consumer consumer) throws BusinessException {
		LOG.debug("Executing addConsumer " + consumer.getConsumerId());
		Consumer result = null;
		try {
			BizUtil.validateCreatedBy(EntityType.CONSUMER, consumer.getCreatedBy());
			validateConsumer(consumer.getConsumerId());
			if (isDuplicate(consumer.getConsumerId(), null)) {
				throw new ServiceRegistryException(
						ErrorCode.BIZ_DUPLICATE_CONSUMER, MessageFormat.format(
								CommonConstants.DUPLICATE_CONSUMER_ID,
								consumer.getConsumerId()));
			} else {
				ConsumerDO consumerDO = mapper.map(consumer, ConsumerDO.class);
				consumerDO = consumerDAO.save(consumerDO);
				audit(consumerDO);
				result = mapper.map(consumerDO, Consumer.class);
			}
		} catch (Exception ex) {
			LOG.error(MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE,
					ex.getMessage()));
			exceptionHandler.handleBusinessException(ex);
		}
		return result;
	}

	@Override
	@Transactional(rollbackFor={BusinessException.class})
	public Consumer updateConsumer(Consumer consumer) throws BusinessException {
		String id = consumer.getId();
		LOG.debug("Executing updateConsumer [id, consumerId] : [" + id + ","
				+ consumer.getConsumerId() + "]");
		Consumer result = null;
		try {
			validateConsumer(consumer.getConsumerId());
			if (isDuplicate(consumer.getConsumerId(), id)) {
				throw new ServiceRegistryException(
						ErrorCode.BIZ_DUPLICATE_CONSUMER, MessageFormat.format(
								CommonConstants.DUPLICATE_CONSUMER_ID,
								consumer.getConsumerId()));
			} else {
				ConsumerDO consumerDO = null;
				if (!StringUtils.isEmpty(id)) {
					consumerDO = consumerDAO.findOne(id);
				}
				// Consumer doesn't exists then create new Consumer
				if (consumerDO == null) {
					BizUtil.validateCreatedBy(EntityType.CONSUMER, consumer.getCreatedBy());
					consumerDO = mapper.map(consumer, ConsumerDO.class);
					consumerDO = consumerDAO.save(consumerDO);
					audit(consumerDO);
					result = mapper.map(consumerDO, Consumer.class);
					return result;
				}
				BizUtil.validateModifiedBy(EntityType.CONSUMER, consumer.getModifiedBy());
				List<AuditDO> audits = BizUtil
						.getAuditDetails(consumer, consumerDO);
				if (!audits.isEmpty()) {
					mapper.map(consumer, consumerDO);
					consumerDO = consumerDAO.save(consumerDO);
					auditDAO.save(audits);
					result = mapper.map(consumerDO, Consumer.class);
				}
			}
		} catch (Exception ex) {
			LOG.error(MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE,
					ex.getMessage()));
			exceptionHandler.handleBusinessException(ex);
		}
		return result;
	}

	@Override
	@Transactional(rollbackFor={BusinessException.class})
	public Consumer updateConsumerStatus(String id, String action, String actionBy)
			throws BusinessException {
		LOG.debug("Executing updateConsumerStatus for : " + id);
		Consumer consumer = null;
		try {
			ConsumerDO consumerDO = consumerDAO.findOne(id);
			if (consumerDO == null) {
				throw new ServiceRegistryException(
						ErrorCode.BIZ_CONSUMER_NOT_FOUND, MessageFormat.format(
								CommonConstants.CONSUMER_NOT_FOUND,
								String.valueOf(id)));
			} else {
				String newStatusValue = BizUtil.toStatus(action);
				RegistryPolicyCode newStatusType = RegistryPolicyCodeDAOImpl.getCode(RegistryPolicyCodeType.STATUS, newStatusValue.toUpperCase());
				if (newStatusType == null) {
					throw new ServiceRegistryException(
							ErrorCode.BIZ_INVALID_STATUS_TYPE,
							MessageFormat.format(
									CommonConstants.INVALID_STATUS_TYPE,
									String.valueOf(id)));
				} else {
					String oldStatusValue = consumerDO.getStatus();
					if (newStatusType.getCode().equalsIgnoreCase(oldStatusValue)) {
						throw new ServiceRegistryException(
								ErrorCode.BIZ_INVALID_ACTION_TYPE,
								MessageFormat
										.format(CommonConstants.INVALID_ACTION_TYPE,
												String.valueOf(id)));
					}
					BizUtil.validateModifiedBy(EntityType.CONSUMER, actionBy);
					consumerDO.setStatus(newStatusType.getCode());
					consumerDO.setModifiedBy(actionBy);
					consumerDO = consumerDAO.save(consumerDO);
					auditStatus(consumerDO, oldStatusValue);
					consumer = mapper.map(consumerDO, Consumer.class);
				}
			}
		} catch (Exception ex) {
			LOG.error(MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE,
					ex.getMessage()));
			exceptionHandler.handleBusinessException(ex);
		}
		return consumer;
	}

	@SuppressWarnings("unchecked")
	@Override
	@Transactional(rollbackFor={BusinessException.class})
	public List<Subscription> searchConsumerSubscriptions(ServiceSearchBean search) throws BusinessException {
		LOG.debug("Executing searchConsumerSubscriptions : ");
		List<Subscription> result = null;
		try {
			Map<String, String> map = BeanUtils.describe(search);
			List<SubscriptionDO> subscriptions = subscriptionDAO.search(map);
			result = populateSubscriptions(subscriptions, search.getStatus());
		} 
		catch (Exception ex) {
			LOG.error(MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE,
					ex.getMessage()));
			exceptionHandler.handleBusinessException(ex);
		}
		return result;
	}

	private List<Subscription> populateSubscriptions(
			List<SubscriptionDO> subscriptions, String serviceStatus) {
		List<Subscription> result = new ArrayList<Subscription>(0);
		if(StringUtils.isEmpty(serviceStatus)) {
			result = populateSubscriptions(subscriptions);
		} else {
			for(SubscriptionDO subscription : subscriptions) {
				if(subscription.getServiceVersion().getService().getStatus().equals(serviceStatus)) {
					result.add(mapper.map(subscription, Subscription.class));
				}
			}
		}
		return result;
	}

	private List<Subscription> populateSubscriptions(
			List<SubscriptionDO> subscriptions) {
		List<Subscription> result = new ArrayList<Subscription>(0);
		if (subscriptions != null && !subscriptions.isEmpty()) {
			result = mapper.mapToList(subscriptions, Subscription.class);
		}
		return result;
	}
	
	/**
	 * NOTE : removed throws ServiceRegistryException since it is unchecked exception
	 * @param consumerId
	 */
	private void validateConsumer(String consumerId) {
		if(StringUtils.isEmpty(consumerId)) {
			throw new ServiceRegistryException(ErrorCode.BIZ_INVALID_CONSUMER_ID,
					MessageFormat.format(CommonConstants.INVALID_CONSUMER_ID,
							consumerId));
		}
	}

	/**
	 * This method checks if other Consumer already exists with the same name
	 * 
	 * @param consumerName
	 * @param id
	 *            (to be pass null in case of ADD use case)
	 * @return
	 * @throws Exception
	 */
	private boolean isDuplicate(String consumerId, String id)
			throws DataAccessException {
		List<ConsumerDO> existingConsumers = consumerDAO.findByConsumerId(consumerId);
		if (existingConsumers != null && !existingConsumers.isEmpty()) {
			// If id == null means it is update else it is add Consumer use case
			if (id != null) {
				for (ConsumerDO consumerDO : existingConsumers) {
					if (!consumerDO.getId().equals(id)) {
						return true;
					}
				}
			} else {
				return true;
			}
		}
		return false;
	}

	private void audit(ConsumerDO consumer)
			throws DataAccessException {
		AuditDO audit = BizUtil.getAddAudit(consumer);
		auditDAO.save(audit);
	}
	private void auditStatus(ConsumerDO consumer, String oldValue)
			throws DataAccessException {
		AuditDO audit = BizUtil.getStatusAudit(consumer, oldValue);
		auditDAO.save(audit);
	}
	private void auditSubscriptionStatus(SubscriptionDO subscription)
			throws DataAccessException {
		List<AuditDO> audits = BizUtil.getSubscriptionUpdateStatusAudits(subscription);
		auditDAO.save(audits);
	}
	private void auditSubscriptionAdd(SubscriptionDO subscription)
			throws DataAccessException {
		List<AuditDO> audits = BizUtil.getSubscriptionAddAudits(subscription);
		auditDAO.save(audits);
	}

	@Override
	@Transactional(rollbackFor={BusinessException.class})
	public Subscription addSubscription(String consumerId,
			SubscriptionRequest subscription) throws BusinessException {
		Subscription result = null;
		try {
			if (StringUtils.isEmpty(consumerId)) {
				throw new ServiceRegistryException(
						ErrorCode.BIZ_INVALID_CONSUMER_ID,
						CommonConstants.INVALID_CONSUMER_ID);
			}
			subscription.setStatus(StatusType.INACTIVE.toString());
			Subscription sub = mapper.map(subscription, Subscription.class);
			result = add(consumerId, sub);
		} catch (Exception ex) {
			LOG.error(MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE,
					ex.getMessage()));
			exceptionHandler.handleBusinessException(ex);
		}
		return result;
	}
	
	private Subscription add(String consumerId, Subscription subscription) throws PlatformException{
		ConsumerDO consumer = null;
		List<ConsumerDO> consumers = consumerDAO.findByConsumerId(consumerId);
		if(consumers !=null && !consumers.isEmpty()) {
			consumer = consumers.get(0);
		}
		if(consumer == null) {
			consumer = new ConsumerDO();
			RegistryPolicyCode status = RegistryPolicyCodeDAOImpl.getCode(RegistryPolicyCodeType.STATUS, StatusType.ACTIVE.toString());
			consumer.setStatus(status.getCode());
			consumer.setConsumerId(consumerId);
			consumer.setCreatedBy(subscription.getCreatedBy());
			consumer = consumerDAO.save(consumer);
		}
		SubscriptionDO subscriptionDO = addConsumerSubscription(consumer, subscription);
		subscriptionDO = subscriptionDAO.save(subscriptionDO);
		auditSubscriptionAdd(subscriptionDO);
		subscription = mapper.map(subscriptionDO, Subscription.class);
		notifyServiceOwner(subscriptionDO, subscription);
		return subscription;
	}
	
	private void notifyServiceOwner(SubscriptionDO subscriptionDO, Subscription subscription) throws BusinessException{
		try {
			ServiceDO service = subscriptionDO.getServiceVersion().getService();
			notificationDeligator.notifySubscriptionCreated(service.getOwner(), subscription);
			if(jiraNotificationRequested(service)) {
				notificationDeligator.createJiraTicket(service.getJiraProject(), subscription);
			}
		}catch(Exception ex) {
			LOG.error("Failed to notify service owner : "+ex.getMessage());
		}
	}
	
	/*private boolean jiraNotificationRequested(ServiceDO service) {
		for(NotificationDestinationDO notification : service.getNotificationTypes()) {
			if(NotificationDestinationType.JIRA.toString().equals(notification.getType())) {
				return true;
			}
		}
		return false;
	}*/
	private boolean jiraNotificationRequested(ServiceDO service) {
		for(String notificationType : service.getNotificationTypes()) {
			if(NotificationDestinationType.JIRA.toString().equals(notificationType)) {
				return true;
			}
		}
		return false;
	}

	private void validateSubscription(Subscription subscription, boolean isNew) {
		if(subscription == null) {
			throw new ServiceRegistryException(
					ErrorCode.BIZ_INVALID_SUBSCRIPTION,
					CommonConstants.INVALID_SUBSCRIPTION);
		}
		if(!isNew && StringUtils.isEmpty(subscription.getId())) {
			throw new ServiceRegistryException(
					ErrorCode.BIZ_INVALID_SUBSCRIPTION_ID,
					CommonConstants.INVALID_SUBSCRIPTION_ID);
		}
		if (StringUtils.isEmpty(subscription.getConsumerId())) {
			throw new ServiceRegistryException(
					ErrorCode.BIZ_INVALID_CONSUMER_ID,
					CommonConstants.INVALID_CONSUMER_ID);
		}
		if (StringUtils.isEmpty(subscription.getServiceVersionId())) {
			throw new ServiceRegistryException(
					ErrorCode.BIZ_INVALID_SERVICE_VERSION_ID,
					CommonConstants.INVALID_SERVICE_VERSION_ID);
		}
	}
	
	private void validateNonUpdatableFields(Subscription source, SubscriptionDO target) {
		if(!source.getConsumerId().equals(target.getConsumer().getConsumerId())) {
			throw new ServiceRegistryException(
				ErrorCode.BIZ_INVALID_UPDATE_SUBSCRIPTION_CONSUMER,
				CommonConstants.INVALID_UPDATE_SUBSCRIPTION_CONSUMER);
		}
		if(!source.getServiceVersionId().equals(target.getServiceVersion().getId())) {
			throw new ServiceRegistryException(
					ErrorCode.BIZ_INVALID_UPDATE_SUBSCRIPTION_SERVICE_VERSION,
					CommonConstants.INVALID_UPDATE_SUBSCRIPTION_SERVICE_VERSION);
		}
	}
	
	@Override
	@Transactional(rollbackFor={BusinessException.class})
	public Subscription updateSubscription(SubscriptionRequest subscriptionRequest) throws BusinessException {
		Subscription result = null;
		try {
			Subscription subscription = mapper.map(subscriptionRequest, Subscription.class);
			validateSubscription(subscription, true);
			SubscriptionDO subscriptionDO = subscriptionDAO.findOne(subscription.getId());
			if(subscriptionDO == null) {
				result = add(subscription.getConsumerId(), subscription);
			} else {
				validateNonUpdatableFields(subscription, subscriptionDO);
				Map<String, String> search = new HashMap<String, String>(0);
				search.put("consumerId", subscription.getConsumerId());
				List<SubscriptionDO> existingConsumerSubscription = subscriptionDAO.search(search);
				if(isDuplicate(existingConsumerSubscription, subscription, false)) {
					throw new ServiceRegistryException(
							ErrorCode.BIZ_DUPLICATE_SUBSCRIPTION,
							CommonConstants.BIZ_DUPLICATE_SUBSCRIPTION);
				}
				ServiceVersionDO serviceVersion = serviceVersionDAO.findOne(subscription.getServiceVersionId());
				List<ConsumerDO> consumers = consumerDAO.findByConsumerId(subscription.getConsumerId());
				String newName = "";
				if(serviceVersion != null && consumers != null && !consumers.isEmpty()) {
					newName = BizUtil.getSubscriptionName(serviceVersion, consumers.get(0));
				}
				List<AuditDO> audits = BizUtil.getAuditDetails(subscription, subscriptionDO, newName);
				if(audits != null && !audits.isEmpty()) {
					mapper.map(subscription, subscriptionDO);
					subscriptionDO = subscriptionDAO.save(subscriptionDO);
					auditDAO.save(audits);
					result = mapper.map(subscriptionDO, Subscription.class);
				}else {
					result = subscription;
				}
			}
		} catch (Exception ex) {
			LOG.error(MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE,
					ex.getMessage()));
			exceptionHandler.handleBusinessException(ex);
		}
		return result;
	}
	
	@Override
	@Transactional
	public List<Subscription> getSubscriptions(String consumerId) throws BusinessException {
		List<Subscription> result = null;
		try {
			if (StringUtils.isEmpty(consumerId)) {
				throw new ServiceRegistryException(
						ErrorCode.BIZ_INVALID_CONSUMER_ID,
						CommonConstants.INVALID_CONSUMER_ID);
			}
			ConsumerDO consumer = null;
			List<ConsumerDO> consumers = consumerDAO.findByConsumerId(consumerId);
			if(consumers !=null && !consumers.isEmpty()) {
				consumer = consumers.get(0);
			}
			
			if(consumer == null) {
				throw new ServiceRegistryException(
						ErrorCode.BIZ_CONSUMER_NOT_FOUND,
						CommonConstants.CONSUMER_NOT_FOUND);
			}
			result = mapper.mapToList(consumer.getSubscriptions(), Subscription.class);
		} catch (Exception ex) {
			LOG.error(MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE,
					ex.getMessage()));
			exceptionHandler.handleBusinessException(ex);
		}
		return result;
	}
	
	@Override
	//@Transactional(rollbackFor={BusinessException.class})
	@Transactional
	public void deleteSubscription(String id, String actionBy)
			throws BusinessException {
		LOG.debug("Executing deleteSubscription for : " + id);
		try {
			updateSubscriptionStatusOrDelete(id, "DELETE", actionBy);
		} catch (Exception ex) {
			LOG.error(MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE,
					ex.getMessage()));
			exceptionHandler.handleBusinessException(ex);
		}
	}
	
	
	@Override
	@Transactional(rollbackFor={BusinessException.class})
	public Subscription updateSubscriptionStatus(String id, String action, String actionBy)
			throws BusinessException {
		LOG.debug("Executing updateSubscriptionStatus for : " + id);
		Subscription subscription = null;
		try {
			String statusValue = BizUtil.toStatus(action);
			if (StatusType.DELETED.toString().equals(statusValue)) {
				throw new ServiceRegistryException(
						ErrorCode.BIZ_INVALID_ACTION_TYPE,
						MessageFormat
								.format(CommonConstants.INVALID_ACTION_TYPE,
										String.valueOf(id)));
			} 
			subscription = updateSubscriptionStatusOrDelete(id, action, actionBy);
		} catch (Exception ex) {
			LOG.error(MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE,
					ex.getMessage()));
			exceptionHandler.handleBusinessException(ex);
		}
		return subscription;
	}
	
	private Subscription updateSubscriptionStatusOrDelete(String id, String action, String actionBy) throws DataAccessException {
		Subscription subscription = null;
		if(StringUtils.isEmpty(id)) {
			throw new ServiceRegistryException(
					ErrorCode.BIZ_INVALID_SUBSCRIPTION_ID, CommonConstants.INVALID_SUBSCRIPTION_ID);
		}
		SubscriptionDO subscriptionDO = subscriptionDAO.findOne(id);
		if (subscriptionDO == null) {
			throw new ServiceRegistryException(
					ErrorCode.BIZ_SUBSCRIPTION_NOT_FOUND,CommonConstants.SUBSCRIPTION_NOT_FOUND);
		} else {
			if (StringUtils.isEmpty(action)) {
				throw new ServiceRegistryException(
						ErrorCode.BIZ_INVALID_STATUS_TYPE,
						MessageFormat.format(
								CommonConstants.INVALID_STATUS_TYPE,
								String.valueOf(id)));
			} else {
				String newStatusValue = BizUtil.toStatus(action);
				RegistryPolicyCode newStatustype = RegistryPolicyCodeDAOImpl.getCode(RegistryPolicyCodeType.STATUS, newStatusValue.toUpperCase());
				if (newStatustype == null) {
					throw new ServiceRegistryException(
							ErrorCode.BIZ_INVALID_STATUS_TYPE,
							MessageFormat.format(
									CommonConstants.INVALID_STATUS_TYPE,
									String.valueOf(id)));
				} else {
					String oldStatusValue = subscriptionDO.getStatus();
					if (newStatustype.getCode().equalsIgnoreCase(oldStatusValue)) {
						throw new ServiceRegistryException(
								ErrorCode.BIZ_INVALID_ACTION_TYPE,
								MessageFormat
										.format(CommonConstants.INVALID_ACTION_TYPE,
												String.valueOf(id)));
					} else {
						BizUtil.validateModifiedBy(EntityType.SUBSCRIPTION, actionBy);
						subscriptionDO.setStatus(newStatustype.getCode());
						subscriptionDO.setModifiedBy(actionBy);
						Set<SubscriptionDO> temp = new HashSet<SubscriptionDO>(0);
						
						if(StatusType.DELETED.toString().equals(newStatustype.getCode())) {
							ConsumerDO consumer = subscriptionDO.getConsumer();
							for(SubscriptionDO sub : consumer.getSubscriptions()) {
								if(!sub.getId().equals(id)) {
									temp.add(sub);
								}
							}
							consumer.getSubscriptions().clear();
							consumer.getSubscriptions().addAll(temp);
							consumer = consumerDAO.save(consumer);
						} else {
							subscriptionDO = subscriptionDAO.save(subscriptionDO);
							subscription = mapper.map(subscriptionDO, Subscription.class);
						}
						auditSubscriptionStatus(subscriptionDO);
					}
				}
			}
		}
		return subscription;
	}

	private SubscriptionDO addConsumerSubscription(ConsumerDO consumer,Subscription subscription) {
		BizUtil.validateCreatedBy(EntityType.SUBSCRIPTION, subscription.getCreatedBy());
		if(isDuplicate(consumer.getSubscriptions(), subscription, true)) {
			throw new ServiceRegistryException(
					ErrorCode.BIZ_DUPLICATE_SUBSCRIPTION,
					CommonConstants.BIZ_DUPLICATE_SUBSCRIPTION);
		}
		SubscriptionDO subscriptionDO = mapper.map(subscription, SubscriptionDO.class);
		consumer.addSubscription(subscriptionDO);
		return subscriptionDO;
	}
	
	private boolean isConsumerSame(SubscriptionDO subscription, String consumerId) {
		return subscription.getConsumer().getConsumerId().equals(consumerId);
	}
	private boolean isServiceVersionSame(SubscriptionDO subscription, String serviceVersionId) {
		return subscription.getServiceVersion().getId().equals(serviceVersionId);
	}
	private boolean isSubscriptionSame(SubscriptionDO subscription, String id) {
		return subscription.getId().equals(id);
	}
	
	private boolean isDuplicate(Collection<SubscriptionDO> subscriptions, Subscription newSubscription, boolean isNew) {
		for(SubscriptionDO existing : subscriptions) {
			if(((isConsumerSame(existing, newSubscription.getConsumerId())) && isServiceVersionSame(existing, newSubscription.getServiceVersionId()))) {
				if(isNew) {
					return true;
				}else if(!isSubscriptionSame(existing, newSubscription.getId())){
					return true;
				} 
			}
		}
		return false;
	}
	
}
