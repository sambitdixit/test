package com.walmart.platform.soari.registry.biz.impl;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.walmart.platform.kernel.exception.layers.business.BusinessException;
import com.walmart.platform.soari.registry.biz.api.AuditManager;
import com.walmart.platform.soari.registry.biz.mapper.api.DozerMapper;
import com.walmart.platform.soari.registry.common.dto.Audit;
import com.walmart.platform.soari.registry.domain.AuditDO;
import com.walmart.platform.soari.registry.domain.ServiceDO;
import com.walmart.platform.soari.registry.domain.ServiceVersionDO;
import com.walmart.platform.soari.registry.domain.dao.api.AuditDAO;
import com.walmart.platform.soari.registry.domain.dao.api.ServiceDAO;
import com.walmart.platform.soari.registry.server.common.error.ErrorCode;
import com.walmart.platform.soari.registry.server.common.exception.ExceptionHandler;
import com.walmart.platform.soari.registry.server.common.exception.ServiceRegistryException;
import com.walmart.platform.soari.registry.server.common.util.CommonConstants;

@Service("auditManager")
public class AuditManagerImpl implements AuditManager {

	private static final Logger LOG = LoggerFactory
			.getLogger(AuditManagerImpl.class);

	@Autowired
	private ExceptionHandler exceptionHandler;
	
	@Autowired
	private AuditDAO auditDAO;
	
	@Autowired
	private ServiceDAO serviceDAO;
	
	@Autowired
	private DozerMapper mapper;

	@Override
	public List<Audit> getAuditsByEntityId(String entityId, Integer fetchCount) throws BusinessException {
		List<Audit> audits = new ArrayList<Audit>(0);
		try {
			if(fetchCount == null) {
				fetchCount = 100;
			}
			if (StringUtils.isEmpty(entityId)) {
				throw new ServiceRegistryException(
						ErrorCode.BIZ_INVALID_ENTITY_ID,
						CommonConstants.INVALID_ENTITY_ID);
			} else {
				List<AuditDO> auditDOs = auditDAO.findByEntity(entityId, fetchCount);
				if(auditDOs != null) {
					audits.addAll(mapper.mapToList(auditDOs, Audit.class));
				}
				ServiceDO service = serviceDAO.findOne(entityId);
				if(service != null) {
					for(ServiceVersionDO serviceVersion : service.getServiceVersions()) {
						Integer nextMax = fetchCount-audits.size();
						if(nextMax<=0) {
							return audits;
						}
						List<AuditDO> versionAuditDOs = auditDAO.findByEntity(serviceVersion.getId(), nextMax);
						if(versionAuditDOs != null) {
							audits.addAll(mapper.mapToList(versionAuditDOs, Audit.class));
						}
					}
				}
				
			}
		} catch (Exception ex) {
			LOG.error(MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE,
					ex.getMessage()));
			exceptionHandler.handleBusinessException(ex);
		}
		return audits;
	}
	
}
