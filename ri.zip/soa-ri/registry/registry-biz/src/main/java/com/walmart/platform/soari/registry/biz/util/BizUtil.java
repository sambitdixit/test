package com.walmart.platform.soari.registry.biz.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.cert.X509Certificate;
import java.sql.Timestamp;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.commons.lang.StringUtils;
import org.dozer.MappingException;

import com.walmart.platform.kernel.exception.layers.base.PlatformException;
import com.walmart.platform.kernel.exception.layers.dao.DataAccessException;
import com.walmart.platform.soa.policy.common.impl.PolicyProvider;
import com.walmart.platform.soa.policy.definition.model.PolicyDefinition;
import com.walmart.platform.soari.registry.common.dto.Attribute;
import com.walmart.platform.soari.registry.common.dto.Consumer;
import com.walmart.platform.soari.registry.common.dto.NotificationDestination;
import com.walmart.platform.soari.registry.common.dto.Policy;
import com.walmart.platform.soari.registry.common.dto.QoS;
import com.walmart.platform.soari.registry.common.dto.Service;
import com.walmart.platform.soari.registry.common.dto.ServiceSearchBean;
import com.walmart.platform.soari.registry.common.dto.ServiceVersion;
import com.walmart.platform.soari.registry.common.dto.Subscription;
import com.walmart.platform.soari.registry.common.dto.SubscriptionRequest;
import com.walmart.platform.soari.registry.common.dto.Url;
import com.walmart.platform.soari.registry.common.enums.AuditType;
import com.walmart.platform.soari.registry.common.enums.EntityType;
import com.walmart.platform.soari.registry.common.enums.RegistryPolicyCodeType;
import com.walmart.platform.soari.registry.common.enums.SearchFieldType;
import com.walmart.platform.soari.registry.common.enums.ServiceCommunicationType;
import com.walmart.platform.soari.registry.common.enums.StatusType;
import com.walmart.platform.soari.registry.common.enums.UrlType;
import com.walmart.platform.soari.registry.domain.AuditDO;
import com.walmart.platform.soari.registry.domain.ConsumerDO;
import com.walmart.platform.soari.registry.domain.EntityDO;
import com.walmart.platform.soari.registry.domain.NotificationDestinationDO;
import com.walmart.platform.soari.registry.domain.PolicyDO;
import com.walmart.platform.soari.registry.domain.QoSDO;
import com.walmart.platform.soari.registry.domain.RegistryPolicyCode;
import com.walmart.platform.soari.registry.domain.ServiceDO;
import com.walmart.platform.soari.registry.domain.AttributeDO;
import com.walmart.platform.soari.registry.domain.ServiceVersionDO;
import com.walmart.platform.soari.registry.domain.ServiceVersionQoS;
import com.walmart.platform.soari.registry.domain.SubscriptionDO;
import com.walmart.platform.soari.registry.domain.UrlDO;
import com.walmart.platform.soari.registry.domain.dao.impl.RegistryPolicyCodeDAOImpl;
import com.walmart.platform.soari.registry.server.common.error.ErrorCode;
import com.walmart.platform.soari.registry.server.common.exception.ServiceRegistryException;
import com.walmart.platform.soari.registry.server.common.util.CommonConstants;

public final class BizUtil {

	public static final String FIELD_STATUS = "STATUS";
	public static final String FIELD_NAME = "NAME";
	public static final String FIELD_CONSUMER_ID = "CONSUMER_ID";
	public static final String FIELD_URL = "URL";
	public static final String FIELD_DATA = "DATA";
	public static final String FIELD_URL_TYPE = "URL_TYPE";
	public static final String FIELD_VERSION = "VERSION";
	public static final String FIELD_VERSION_ATTRIBUTE = "VERSION_ATTRUBUTE";
	public static final String FIELD_APPLICATION_ID = "APPLICATION_ID";
	public static final String FIELD_NOTIFICATION_REQUESTED = "NOTIFICATION_REQUESTED";
	public static final String FIELD_CATEGORY = "CATEGORY";
	public static final String FIELD_DESCRIPTION = "DESCRIPTION";
	public static final String FIELD_TYPE = "TYPE";
	public static final String FIELD_COMMUNICATION_TYPE = "COMMUNICATION_TYPE";
	public static final String FIELD_CONSUMER = "CONSUMER";
	public static final String FIELD_SERVICE_VERSION = "SERVICE_VERSION";
	public static final String FIELD_FLOW = "FLOW";
	public static final String FIELD_CONTEXT = "CONTEXT";
	public static final String FIELD_ORDER = "ORDER";
	public static final String FIELD_DOMAIN = "DOMAIN";
	public static final String FIELD_NOTIFICATION_FOR = "NOTIFICATION_FOR";
	public static final String FIELD_NOTIFICATION_DESTINATION = "NOTIFICATION_DESTINATION";
	public static final String FIELD_OWNER = "OWNER";
	public static final String FIELD_USAGE = "USAGE";
	public static final String FIELD_AVAILABILITY_TIER = "AVAILABILITY_TIER";
	public static final String FIELD_ENVIRONMENT = "ENVIRONMENT";
	public static final String FIELD_ESB_REFERENCE = "ESB_REFERENCE";
	public static final String FIELD_SERVICE_VERSION_NUMBER = "SERVICE_VERSION_NUMBER";
	public static final String FIELD_ACTIVATION_START_DATE = "ACTIVATION_START_DATE";
	public static final String FIELD_ACTIVATION_END_DATE = "ACTIVATION_END_DATE";
	public static final String FIELD_PUBLICATION_DATE = "PUBLICATION_DATE";
	public static final String FIELD_QoS_NAME = "QoS_NAME";
	public static final String FIELD_QoS_VALUE = "QoS_VALUE";
	public static final String FIELD_QoS_PARENT_ID = "QoS_PARENT_ID";
	public static final String FIELD_URLS = "URLS";

	private BizUtil() {

	}

	public static AuditDO getAddVersionPolicyAudit(ServiceVersionDO entity,
			String policyName) {
		AuditDO audit = new AuditDO(entity);
		audit.setNewValue(policyName);
		audit.setType(AuditType.ADD_SERVICE_VERSION_POLICY);
		audit.setModifiedBy(entity.getModifiedBy());
		audit.setField(EntityType.SRVC_VERSION.toString());
		return audit;
	}

	public static AuditDO getDeleteVersionPolicyAudit(ServiceVersionDO entity,
			String policyName) {
		AuditDO audit = new AuditDO(entity);
		audit.setNewValue(policyName);
		audit.setType(AuditType.DELETE_SERVICE_VERSION_POLICY);
		audit.setModifiedBy(entity.getModifiedBy());
		audit.setField(EntityType.SRVC_VERSION.toString());
		return audit;
	}

	public static AuditDO getAddSubscriptionPolicyAudit(SubscriptionDO entity,
			String policyName) {
		AuditDO audit = new AuditDO(entity);
		audit.setNewValue(policyName);
		audit.setType(AuditType.ADD_SERVICE_VERSION_POLICY);
		audit.setModifiedBy(entity.getModifiedBy());
		audit.setField(EntityType.SRVC_VERSION.toString());
		return audit;
	}

	public static AuditDO getDeleteSubscriptionPolicyAudit(
			SubscriptionDO entity, String policyName) {
		AuditDO audit = new AuditDO(entity);
		audit.setNewValue(policyName);
		audit.setType(AuditType.DELETE_SERVICE_VERSION_POLICY);
		audit.setModifiedBy(entity.getModifiedBy());
		audit.setField(EntityType.SRVC_VERSION.toString());
		return audit;
	}

	public static AuditDO getAddVersionQoSAudit(ServiceVersionDO entity,
			String qosName) {
		AuditDO audit = new AuditDO(entity);
		audit.setNewValue(qosName);
		audit.setType(AuditType.ADD_SERVICE_VERSION_QOS);
		audit.setModifiedBy(entity.getModifiedBy());
		audit.setField(EntityType.SRVC_VERSION.toString());
		return audit;
	}

	public static AuditDO getUpdateVersionQoSAudit(ServiceVersionDO entity,
			String qosName, String oldValue, String newValue) {
		AuditDO audit = new AuditDO(entity);
		audit.setOldValue(qosName + " : " + oldValue);
		audit.setNewValue(qosName + " : " + newValue);
		audit.setType(AuditType.UPDATE_SERVICE_VERSION_QOS);
		audit.setModifiedBy(entity.getModifiedBy());
		audit.setField(EntityType.SRVC_VERSION.toString());
		return audit;
	}

	public static AuditDO getDeleteVersionQoSAudit(ServiceVersionDO entity,
			String qosName) {
		AuditDO audit = new AuditDO(entity);
		audit.setOldValue(qosName);
		audit.setType(AuditType.DELETE_SERVICE_VERSION_QOS);
		audit.setModifiedBy(entity.getModifiedBy());
		audit.setField(EntityType.SRVC_VERSION.toString());
		return audit;
	}

	public static AuditDO getAddSubscriptionQoSAudit(SubscriptionDO entity,
			String qosName) {
		AuditDO audit = new AuditDO(entity);
		audit.setNewValue(qosName);
		audit.setType(AuditType.ADD_SUBSCRIPTION_QOS);
		audit.setModifiedBy(entity.getModifiedBy());
		audit.setField(EntityType.SUBSCRIPTION.toString());
		return audit;
	}

	public static AuditDO getUpdateSubscriptionQoSAudit(SubscriptionDO entity,
			String qosName, String oldValue, String newValue) {
		AuditDO audit = new AuditDO(entity);
		audit.setOldValue(qosName + " : " + oldValue);
		audit.setNewValue(qosName + " : " + newValue);
		audit.setType(AuditType.UPDATE_SUBSCRIPTION_QOS);
		audit.setModifiedBy(entity.getModifiedBy());
		audit.setField(EntityType.SUBSCRIPTION.toString());
		return audit;
	}

	public static AuditDO getDeleteSubscriptionQoSAudit(SubscriptionDO entity,
			String qosName) {
		AuditDO audit = new AuditDO(entity);
		audit.setOldValue(qosName);
		audit.setType(AuditType.DELETE_SERVICE_VERSION_QOS);
		audit.setModifiedBy(entity.getModifiedBy());
		audit.setField(EntityType.SUBSCRIPTION.toString());
		return audit;
	}

	public static AuditDO getStatusAudit(EntityDO entity, String oldValue) {
		AuditDO audit = new AuditDO(entity);
		audit.setOldValue(oldValue);
		audit.setNewValue(entity.getStatus() != null ? entity.getStatus() : "");
		audit.setType(getStatusAuditType(entity));
		audit.setModifiedBy(entity.getModifiedBy());
		if (entity instanceof ServiceDO) {
			audit.setField(EntityType.SERVICE.toString());
		} else if (entity instanceof ServiceVersionDO) {
			audit.setField(EntityType.SRVC_VERSION.toString());
		} else if (entity instanceof PolicyDO) {
			audit.setField(EntityType.POLICY.toString());
		} else if (entity instanceof QoSDO) {
			audit.setField(EntityType.QoS.toString());
		} else if (entity instanceof NotificationDestinationDO) {
			audit.setField(EntityType.NOTIFICATION_DESTINATION.toString());
		} else if (entity instanceof ConsumerDO) {
			audit.setField(EntityType.CONSUMER.toString());
		} else {
			audit.setField("UNKNOWN_ENTITY");
		}
		return audit;
	}

	public static List<AuditDO> getSubscriptionUpdateStatusAudits(
			SubscriptionDO subscription) {
		List<AuditDO> audits = new ArrayList<AuditDO>(0);
		AuditType auditType = getStatusAuditType(subscription);
		audits.add(getSubscriptionAuditForServiceVersion(subscription,
				auditType));
		audits.add(getSubscriptionAuditForConsumer(subscription, auditType));
		return audits;
	}

	public static List<AuditDO> getSubscriptionAddAudits(
			SubscriptionDO subscription) {
		List<AuditDO> audits = new ArrayList<AuditDO>(0);
		AuditType auditType = AuditType.ADD_SUBSCRIPTION;
		audits.add(getSubscriptionAuditForServiceVersion(subscription,
				auditType));
		audits.add(getSubscriptionAuditForConsumer(subscription, auditType));
		return audits;
	}

	public static AuditDO getSubscriptionAuditForServiceVersion(
			SubscriptionDO subscription, AuditType auditType) {
		AuditDO audit = new AuditDO(subscription.getServiceVersion());
		audit = getSubscriptionAudit(audit, subscription, auditType);
		return audit;
	}

	private static AuditDO getSubscriptionAudit(AuditDO audit,
			SubscriptionDO subscription, AuditType auditType) {
		audit.setField(EntityType.SUBSCRIPTION.toString());
		audit.setModifiedBy(subscription.getModifiedBy());
		if (AuditType.ADD_SUBSCRIPTION == auditType) {
			audit.setNewValue(getSubscriptionName(subscription));
			audit.setModifiedBy(subscription.getCreatedBy());
		} else if (AuditType.DELETE_SUBSCRIPTION == auditType) {
			audit.setOldValue(getSubscriptionName(subscription));
		} else {
			audit.setNewValue(getSubscriptionName(subscription));
			audit.setOldValue(getSubscriptionName(subscription));
		}
		audit.setType(auditType);
		return audit;
	}

	public static String getSubscriptionName(SubscriptionDO subscription) {
		return getSubscriptionName(subscription.getServiceVersion(),
				subscription.getConsumer());
	}

	public static String getSubscriptionName(ServiceVersionDO serviceVersion,
			ConsumerDO consumer) {
		return MessageFormat.format("[{0}:{1}:{2}:{3}]", serviceVersion
				.getService().getName(), serviceVersion.getSerVersion(),
				serviceVersion.getService().getEnvironment(), consumer
						.getConsumerId());
	}

	public static AuditDO getSubscriptionAuditForConsumer(
			SubscriptionDO subscription, AuditType auditType) {
		AuditDO audit = new AuditDO(subscription.getConsumer());
		audit = getSubscriptionAudit(audit, subscription, auditType);
		return audit;
	}

	public static AuditDO getAddAudit(EntityDO entity) {
		AuditDO audit = new AuditDO(entity);
		if (entity instanceof ServiceDO) {
			ServiceDO service = (ServiceDO) entity;
			audit.setField(EntityType.SERVICE.toString());
			audit.setType(AuditType.ADD_SERVICE);
			audit.setNewValue(service.getName());
		} else if (entity instanceof ServiceVersionDO) {
			ServiceVersionDO serviceVersion = (ServiceVersionDO) entity;
			audit.setField(EntityType.SRVC_VERSION.toString());
			audit.setType(AuditType.ADD_SERVICE_VERSION);
			audit.setNewValue(serviceVersion.getSerVersion());
		} else if (entity instanceof PolicyDO) {
			PolicyDO policy = (PolicyDO) entity;
			audit.setField(EntityType.POLICY.toString());
			audit.setType(AuditType.ADD_POLICY);
			audit.setNewValue(policy.getName());
		} else if (entity instanceof QoSDO) {
			QoSDO qos = (QoSDO) entity;
			audit.setField(EntityType.QoS.toString());
			audit.setType(AuditType.ADD_QOS);
			audit.setNewValue(qos.getName());
		} else if (entity instanceof NotificationDestinationDO) {
			NotificationDestinationDO notification = (NotificationDestinationDO) entity;
			audit.setField(EntityType.NOTIFICATION_DESTINATION.toString());
			audit.setType(AuditType.ADD_NOTIFICATION);
			audit.setNewValue(notification.getName());
		} else if (entity instanceof ConsumerDO) {
			ConsumerDO consumer = (ConsumerDO) entity;
			audit.setField(EntityType.CONSUMER.toString());
			audit.setType(AuditType.ADD_CONSUMER);
			audit.setNewValue(consumer.getConsumerId());
		}
		audit.setModifiedBy(entity.getCreatedBy());
		return audit;
	}

	public static AuditType getStatusAuditType(EntityDO entity) {
		String status = entity.getStatus();
		AuditType auditType;
		if (entity instanceof ServiceDO) {
			if (StatusType.ACTIVE.toString().equals(status)) {
				auditType = AuditType.ACTIVATE_SERVICE;
			} else if (StatusType.INACTIVE.toString().equals(status)) {
				auditType = AuditType.DEACTIVATE_SERVICE;
			} else if (StatusType.DELETED.toString().equals(status)) {
				auditType = AuditType.DELETE_SERVICE;
			} else {
				auditType = AuditType.UPDATE_SERVICE;
			}
		} else if (entity instanceof ServiceVersionDO) {
			if (StatusType.ACTIVE.toString().equals(status)) {
				auditType = AuditType.ACTIVATE_SERVICE_VERSION;
			} else if (StatusType.INACTIVE.toString().equals(status)) {
				auditType = AuditType.DEACTIVATE_SERVICE_VERSION;
			} else if (StatusType.DELETED.toString().equals(status)) {
				auditType = AuditType.DELETE_SERVICE_VERSION;
			} else {
				auditType = AuditType.UPDATE_SERVICE_VERSION;
			}
		} else if (entity instanceof QoSDO) {
			if (StatusType.ACTIVE.toString().equals(status)) {
				auditType = AuditType.ACTIVATE_QOS;
			} else if (StatusType.INACTIVE.toString().equals(status)) {
				auditType = AuditType.DEACTIVATE_QOS;
			} else if (StatusType.DELETED.toString().equals(status)) {
				auditType = AuditType.DELETE_QOS;
			} else {
				auditType = AuditType.UPDATE_QOS;
			}
		} else if (entity instanceof PolicyDO) {
			if (StatusType.ACTIVE.toString().equals(status)) {
				auditType = AuditType.ACTIVATE_POLICY;
			} else if (StatusType.INACTIVE.toString().equals(status)) {
				auditType = AuditType.DEACTIVATE_POLICY;
			} else if (StatusType.DELETED.toString().equals(status)) {
				auditType = AuditType.DELETE_POLICY;
			} else {
				auditType = AuditType.UPDATE_POLICY;
			}
		} else if (entity instanceof NotificationDestinationDO) {
			if (StatusType.ACTIVE.toString().equals(status)) {
				auditType = AuditType.ACTIVATE_NOTIFICATION;
			} else if (StatusType.INACTIVE.toString().equals(status)) {
				auditType = AuditType.DEACTIVATE_NOTIFICATION;
			} else if (StatusType.DELETED.toString().equals(status)) {
				auditType = AuditType.DELETE_NOTIFICATION;
			} else {
				auditType = AuditType.UPDATE_NOTIFICATION;
			}
		} else if (entity instanceof SubscriptionDO) {
			if (StatusType.ACTIVE.toString().equals(status)) {
				auditType = AuditType.ACTIVATE_SUBSCRIPTION;
			} else if (StatusType.INACTIVE.toString().equals(status)) {
				auditType = AuditType.DEACTIVATE_SUBSCRIPTION;
			} else if (StatusType.DELETED.toString().equals(status)) {
				auditType = AuditType.DELETE_SUBSCRIPTION;
			} else {
				auditType = AuditType.UPDATE_SUBSCRIPTION;
			}
		} else {
			auditType = AuditType.UNKNOWN;
		}
		return auditType;
	}

	public static List<AuditDO> getAuditDetails(Policy source, PolicyDO target)
			throws DataAccessException {
		List<AuditDO> policyAudits = new ArrayList<AuditDO>(0);
		AuditType auditType = AuditType.UPDATE_POLICY;
		String modifiedBy = source.getModifiedBy();
		audit(policyAudits, source.getName(), target.getName(), FIELD_NAME,
				target, auditType, modifiedBy);
		audit(policyAudits, source.getDescription(), target.getDescription(),
				FIELD_DESCRIPTION, target, auditType, modifiedBy);
		audit(policyAudits, source.getType(), target.getType(), FIELD_TYPE,
				target, auditType, modifiedBy);
		audit(policyAudits, source.getFlow(), target.getFlow(), FIELD_FLOW,
				target, auditType, modifiedBy);
		audit(policyAudits, String.valueOf(source.getOrder()),
				String.valueOf(target.getOrder()), FIELD_ORDER, target,
				auditType, modifiedBy);
		auditPolicyData(policyAudits, source.getData(), target.getData(),
				FIELD_DATA, target, auditType, modifiedBy);
		audit(policyAudits, source.getStatus(), target.getStatus(),
				FIELD_STATUS, target, auditType, modifiedBy);
		audit(policyAudits, source.getContext(), target.getContext(),
				FIELD_CONTEXT, target, auditType, modifiedBy);
		return policyAudits;
	}

	public static List<AuditDO> getAuditDetails(SubscriptionRequest source,
			SubscriptionDO target, String newName) throws DataAccessException {
		List<AuditDO> subscriptionAudits = new ArrayList<AuditDO>(0);
		AuditType auditType = AuditType.UPDATE_SUBSCRIPTION;
		String modifiedBy = source.getModifiedBy();
		auditSubscription(subscriptionAudits, source.getCommunicationType(),
				target.getCommunicationType(), FIELD_COMMUNICATION_TYPE,
				target, auditType, modifiedBy, newName);
		auditSubscription(subscriptionAudits, source.getStatus(),
				target.getStatus(), FIELD_STATUS, target, auditType,
				modifiedBy, newName);
		return subscriptionAudits;
	}

	public static List<AuditDO> getAuditDetails(Consumer source,
			ConsumerDO target) throws DataAccessException {
		List<AuditDO> policyAudits = new ArrayList<AuditDO>(0);
		AuditType auditType = AuditType.UPDATE_SUBSCRIPTION;
		String modifiedBy = source.getModifiedBy();
		audit(policyAudits, source.getConsumerId(), target.getConsumerId(),
				FIELD_CONSUMER_ID, target, auditType, modifiedBy);
		audit(policyAudits, source.getStatus(), target.getStatus(),
				FIELD_STATUS, target, auditType, modifiedBy);
		return policyAudits;
	}

	public static List<AuditDO> getAuditDetails(NotificationDestination source,
			NotificationDestinationDO target) throws DataAccessException {
		List<AuditDO> audits = new ArrayList<AuditDO>(0);
		String modifiedBy = source.getModifiedBy();
		AuditType auditType = AuditType.UPDATE_NOTIFICATION;
		audit(audits, source.getName(), target.getName(), FIELD_NAME, target,
				auditType, modifiedBy);
		audit(audits, source.getEnvironment(), target.getEnvironment(),
				FIELD_ENVIRONMENT, target, auditType, modifiedBy);
		audit(audits, source.getType(), target.getType(), FIELD_TYPE, target,
				auditType, modifiedBy);
		audit(audits, source.getAvailabilityTier(),
				target.getAvailabilityTier(), FIELD_AVAILABILITY_TIER, target,
				auditType, modifiedBy);
		audit(audits, source.getUrl(), target.getUrl(), FIELD_URL, target,
				auditType, modifiedBy);
		audit(audits, source.getStatus(), target.getStatus(), FIELD_STATUS,
				target, auditType, modifiedBy);
		return audits;
	}

	public static List<AuditDO> getAuditDetails(QoS source, QoSDO target)
			throws DataAccessException {
		List<AuditDO> audits = new ArrayList<AuditDO>(0);
		AuditType auditType = AuditType.UPDATE_QOS;
		String modifiedBy = source.getModifiedBy();
		audit(audits, source.getName(), target.getName(), FIELD_NAME, target,
				auditType, modifiedBy);
		audit(audits, source.getDescription(), target.getDescription(),
				FIELD_DESCRIPTION, target, auditType, modifiedBy);
		audit(audits, source.getType(), target.getType(), FIELD_TYPE, target,
				auditType, modifiedBy);
		audit(audits, source.getStatus(), target.getStatus(), FIELD_STATUS,
				target, auditType, modifiedBy);
		return audits;
	}

	public static boolean hasUpdate(Subscription source, SubscriptionDO target)
			throws DataAccessException {
		if (!source.getCommunicationType()
				.equals(target.getCommunicationType())) {
			return true;
		}
		if (!source.getStatus().equals(target.getStatus())) {
			return true;
		}
		return false;
	}

	public static List<AuditDO> getAuditDetails(Service source, ServiceDO target)
			throws DataAccessException {
		List<AuditDO> audits = new ArrayList<AuditDO>(0);
		AuditType auditType = AuditType.UPDATE_SERVICE;
		String modifiedBy = source.getModifiedBy();
		audit(audits, source.getApplicationId(), target.getApplicationId(),
				FIELD_APPLICATION_ID, target, auditType, modifiedBy);
		audit(audits, source.getNotificationRequested(),
				target.getNotificationRequested(),
				FIELD_NOTIFICATION_REQUESTED, target, auditType, modifiedBy);
		auditNotificationFor(audits, source.getNotificationFor(),
				target.getNotificationFor(), target, modifiedBy);
		auditNotificationTypes(audits, source.getNotificationTypes(),
				target.getNotificationTypes(), target, modifiedBy);
		audit(audits, source.getCategory(), target.getCategory(),
				FIELD_CATEGORY, target, auditType, modifiedBy);
		audit(audits, source.getDescription(), target.getDescription(),
				FIELD_DESCRIPTION, target, auditType, modifiedBy);
		audit(audits, source.getDomain(), target.getDomain(), FIELD_DOMAIN,
				target, auditType, modifiedBy);
		audit(audits, source.getName(), target.getName(), FIELD_NAME, target,
				auditType, modifiedBy);
		audit(audits, source.getOwner(), target.getOwner(), FIELD_OWNER,
				target, auditType, modifiedBy);
		String env = source.getEnvironment() == null ? source.getEnvironment()
				: source.getEnvironment().toLowerCase();
		audit(audits, env, target.getEnvironment(), FIELD_ENVIRONMENT, target,
				auditType, modifiedBy);
		audit(audits, source.getStatus(), target.getStatus(), FIELD_STATUS,
				target, auditType, modifiedBy);
		audit(audits, source.getUsage(), target.getUsage(), FIELD_USAGE,
				target, auditType, modifiedBy);
		return audits;
	}

	public static List<AuditDO> getAuditDetails(ServiceVersion source,
			ServiceVersionDO target) throws DataAccessException {
		List<AuditDO> audits = new ArrayList<AuditDO>(0);
		AuditType auditType = AuditType.UPDATE_SERVICE_VERSION;
		String modifiedBy = source.getModifiedBy();
		audit(audits, source.getAvailabilityTier(),
				target.getAvailabilityTier(), FIELD_AVAILABILITY_TIER, target,
				auditType, modifiedBy);
		audit(audits, source.getEnvironment(), target.getEnvironment(),
				FIELD_ENVIRONMENT, target, auditType, modifiedBy);
		audit(audits, source.getEsbReference(), target.getEsbReference(),
				FIELD_ESB_REFERENCE, target, auditType, modifiedBy);
		audit(audits, source.getSerVersion(), target.getSerVersion(),
				FIELD_SERVICE_VERSION_NUMBER, target, auditType, modifiedBy);
		audit(audits, source.getStatus(), target.getStatus(), FIELD_STATUS,
				target, auditType, modifiedBy);
		audit(audits, source.getActivationEndDate(),
				target.getActivationEndDate(), FIELD_ACTIVATION_END_DATE,
				target, auditType, modifiedBy);
		audit(audits, source.getActivationStartDate(),
				target.getActivationStartDate(), FIELD_ACTIVATION_START_DATE,
				target, auditType, modifiedBy);
		audit(audits, source.getPublicationDate(), target.getPublicationDate(),
				FIELD_PUBLICATION_DATE, target, auditType, modifiedBy);
		auditUrls(audits, source.getUrls(), target.getUrls(), target,
				modifiedBy);
		auditAttributes(audits, target, FIELD_VERSION_ATTRIBUTE, modifiedBy,
				auditType, target.getAttributes(), source.getAttributes());
		return audits;
	}

	public static void auditSubsctionCode(List<AuditDO> audits,
			String newValue, RegistryPolicyCode oldValue, String fieldName,
			SubscriptionDO target, AuditType auditType, String modifiedBy,
			String newName) {
		String str = oldValue != null ? oldValue.getCode() : "";
		auditSubscription(audits, newValue, str, fieldName, target, auditType,
				modifiedBy, newName);
	}

	public static void auditUrlType(List<AuditDO> audits, String newValue,
			UrlType oldValue, String fieldName, EntityDO target,
			AuditType auditType, String modifiedBy) {
		String str = oldValue != null ? oldValue.toString() : "";
		audit(audits, newValue, str, fieldName, target, auditType, modifiedBy);
	}

	public static void audit(List<AuditDO> audits, Url source, UrlDO target,
			EntityDO entity, String modifiedBy) throws DataAccessException {
		AuditType auditType = AuditType.UPDATE_SERVICE_VERSION_URL;
		audit(audits, source.getUrl(), target.getUrl(), FIELD_URL, entity,
				auditType, modifiedBy);
		audit(audits, source.getType(), target.getType(), FIELD_URL_TYPE,
				entity, auditType, modifiedBy);
	}

	private static Map<String, List<String>> getNewUrls(List<Url> newUrls) {
		Map<String, List<String>> urls = new HashMap<String, List<String>>(0);
		if (newUrls == null) {
			return urls;
		}
		for (Url url : newUrls) {
			List<String> urlList = urls.get(url.getType());
			if (urlList == null) {
				urlList = new ArrayList<String>(0);
				urls.put(url.getType(), urlList);
			}
			urlList.add(url.getUrl());
		}
		return urls;
	}

	private static Map<String, List<String>> getOldUrls(Set<UrlDO> oldUrls) {
		Map<String, List<String>> urls = new HashMap<String, List<String>>(0);
		if (oldUrls == null) {
			return urls;
		}
		for (UrlDO url : oldUrls) {
			List<String> urlList = urls.get(url.getType());
			if (urlList == null) {
				urlList = new ArrayList<String>(0);
				urls.put(url.getType(), urlList);
			}
			urlList.add(url.getUrl());
		}
		return urls;
	}

	public static void auditUrls(List<AuditDO> audits, List<Url> newValues,
			Set<UrlDO> oldValues, ServiceVersionDO serviceVersion,
			String modifiedBy) {
		Map<String, List<String>> oldUrlMap = getOldUrls(oldValues);
		Map<String, List<String>> newUrlMap = getNewUrls(newValues);
		Set<String> urlTypes = getUrlTypes(newValues, oldValues);
		for (String urlType : urlTypes) {
			List<String> newUrlList = newUrlMap.get(urlType);
			if (newUrlList == null) {
				newUrlList = new ArrayList<String>(0);
			}
			List<String> oldUrlList = oldUrlMap.get(urlType);
			if (oldUrlList == null) {
				oldUrlList = new ArrayList<String>(0);
			}
			auditCollection(audits, serviceVersion, FIELD_URL + "_" + urlType,
					modifiedBy, AuditType.UPDATE_SERVICE_VERSION_URL,
					oldUrlList, newUrlList);
		}
	}

	public static void auditNotificationFor(List<AuditDO> audits,
			Collection<String> newValues, Collection<String> oldValues,
			ServiceDO service, String modifiedBy) {
		List<String> oldValueList = new ArrayList<String>(0);
		for (String changeType : oldValues) {
			oldValueList.add(changeType);
		}
		auditCollection(audits, service, FIELD_NOTIFICATION_FOR, modifiedBy,
				AuditType.UPDATE_SERVICE, oldValueList, newValues);
	}

	/*public static void auditNotificationTypes(List<AuditDO> audits,
			Collection<String> newValues,
			Collection<NotificationDestinationDO> oldValues, ServiceDO service,
			String modifiedBy) {
		List<String> oldValueList = new ArrayList<String>(0);
		for (NotificationDestinationDO botificationType : oldValues) {
			oldValueList.add(botificationType.getName());
		}
		auditCollection(audits, service, FIELD_NOTIFICATION_DESTINATION,
				modifiedBy, AuditType.UPDATE_SERVICE_VERSION, oldValueList,
				newValues);
	}*/
	
	public static void auditNotificationTypes(List<AuditDO> audits,
			Collection<String> newValues,
			Collection<String> oldValues, ServiceDO service,
			String modifiedBy) {
		List<String> oldValueList = new ArrayList<String>(0);
		for (String notificationType : oldValues) {
			oldValueList.add(notificationType);
		}
		auditCollection(audits, service, FIELD_NOTIFICATION_DESTINATION,
				modifiedBy, AuditType.UPDATE_SERVICE_VERSION, oldValueList,
				newValues);
	}

	private static Set<String> getUrlTypes(List<Url> newUrls, Set<UrlDO> oldUrls) {
		Set<String> urlTypes = new HashSet<String>(0);
		if (newUrls != null) {
			for (Url url : newUrls) {
				urlTypes.add(url.getType());
			}
		}
		if (oldUrls != null)
			for (UrlDO url : oldUrls) {
				urlTypes.add(url.getType());
			}
		return urlTypes;
	}

	public static void auditCollection(List<AuditDO> audits, EntityDO entity,
			String field, String modifiedBy, AuditType auditType,
			Collection<String> oldValues, Collection<String> newValues) {
		Collection<String> similar = new HashSet<String>(0);
		similar.addAll(oldValues);
		Collection<String> different = new HashSet<String>();
		different.addAll(oldValues);
		different.addAll(newValues);
		similar.retainAll(newValues);
		different.removeAll(similar);
		if (!different.isEmpty()) {
			
			for(String removed : getRemovedItems(oldValues, newValues)) {
				AuditDO audit = new AuditDO(entity);
				audit.setField(field);
				audit.setModifiedBy(modifiedBy);
				audit.setOldValue("REMOVED : "+removed);
				audit.setType(auditType);
				audits.add(audit);
			}
			for(String added : getAddedItems(oldValues, newValues)) {
				AuditDO audit = new AuditDO(entity);
				audit.setField(field);
				audit.setModifiedBy(modifiedBy);
				audit.setNewValue("ADDED : "+added);
				audit.setType(auditType);
				audits.add(audit);
			}
			/*AuditDO audit = new AuditDO(entity);
			audit.setField(field);
			audit.setModifiedBy(modifiedBy);
			audit.setOldValue(oldValues.toString());
			audit.setNewValue(newValues.toString());
			audit.setType(auditType);
			audits.add(audit);*/
		}
	}

	public static void auditAttributes(List<AuditDO> audits, EntityDO entity,
			String field, String modifiedBy, AuditType auditType,
			Collection<AttributeDO> oldValues, Collection<Attribute> newValues) {

		for (Attribute newAttribute : newValues) {
			AttributeDO oldAttr = getExistingAttribute(oldValues,
					newAttribute.getName());
			if (oldAttr == null) {
				AuditDO audit = new AuditDO(entity);
				audit.setField(field);
				audit.setModifiedBy(modifiedBy);
				audit.setNewValue(newAttribute.getName() + ":"
						+ newAttribute.getValue());
				audit.setType(auditType);
				audits.add(audit);
			} else {
				audit(audits,
						newAttribute.getName() + ":" + newAttribute.getValue(),
						oldAttr.getName() + ":" + oldAttr.getValue(), field,
						entity, auditType, modifiedBy);
			}
		}
		for (AttributeDO oldAttribute : oldValues) {
			Attribute newAttr = getNewAttribute(newValues,
					oldAttribute.getName());
			if (newAttr == null) {
				AuditDO audit = new AuditDO(entity);
				audit.setField(field);
				audit.setModifiedBy(modifiedBy);
				audit.setOldValue(oldAttribute.getName());
				audit.setType(auditType);
				audits.add(audit);
			}
		}

	}

	private static AttributeDO getExistingAttribute(
			Collection<AttributeDO> attributes, String name) {
		for (AttributeDO attr : attributes) {
			if (attr.getName().equals(name)) {
				return attr;
			}
		}
		return null;
	}

	private static Attribute getNewAttribute(Collection<Attribute> attributes,
			String name) {
		for (Attribute attr : attributes) {
			if (attr.getName().equals(name)) {
				return attr;
			}
		}
		return null;
	}

	public static void auditServiceNotificationDestinations(
			List<AuditDO> audits, Set<String> newNotificationDestinations,
			Set<NotificationDestinationDO> oldNotificationDestinations,
			String field, ServiceDO service, String modifiedBy)
			throws DataAccessException {
		AuditDO audit = null;
		// Added Urls
		for (String newNotificationDestination : newNotificationDestinations) {
			NotificationDestinationDO oldNotificationDestination = getOldNotificationDestination(
					oldNotificationDestinations, newNotificationDestination);
			if (oldNotificationDestination == null) {
				audit = new AuditDO(service);
				audit.setField(field);
				audit.setNewValue(newNotificationDestination);
				audit.setType(AuditType.ADD_NOTIFICATION);
				audit.setModifiedBy(modifiedBy);
				audits.add(audit);
			}
		}

		// Deleted Urls
		for (NotificationDestinationDO oldNotificationDestination : oldNotificationDestinations) {
			String newNotificationDestination = getNewNotificationDestination(
					newNotificationDestinations,
					oldNotificationDestination.getName());
			if (newNotificationDestination == null) {
				audit = new AuditDO(service);
				audit.setField(field);
				audit.setOldValue(oldNotificationDestination.getName());
				audit.setType(AuditType.DELETE_NOTIFICATION);
				audit.setModifiedBy(modifiedBy);
				audits.add(audit);
			}
		}
	}

	public static void auditServiceAuditTypes(List<AuditDO> audits,
			Set<String> newAuditTypes, Set<String> oldAuditTypes, String field,
			ServiceDO service, String modifiedBy) throws DataAccessException {
		AuditDO audit = null;
		// Added AuditType
		for (String newAuditType : newAuditTypes) {
			String oldAuditType = getOldAuditType(oldAuditTypes, newAuditType);
			if (oldAuditType == null) {
				audit = new AuditDO(service);
				audit.setField(field);
				audit.setNewValue(newAuditType);
				audit.setType(AuditType.ADD_AUDIT_TYPE);
				audit.setModifiedBy(modifiedBy);
				audits.add(audit);
			}
		}

		// Deleted AuditType
		for (String oldAuditType : oldAuditTypes) {
			String newAuditType = getNewAuditType(newAuditTypes, oldAuditType);
			if (newAuditType == null) {
				audit = new AuditDO(service);
				audit.setField(field);
				audit.setOldValue(oldAuditType);
				audit.setType(AuditType.DELETE_AUDIT_TYPE);
				audit.setModifiedBy(modifiedBy);
				audits.add(audit);
			}
		}
	}

	public static UrlDO getOldUrl(Set<UrlDO> urls, String id) {
		for (UrlDO url : urls) {
			if (StringUtils.equals(url.getId(), id)) {
				return url;
			}
		}
		return null;
	}

	public static Url getNewUrl(List<Url> urls, String id) {
		for (Url url : urls) {
			if (StringUtils.equals(url.getId(), id)) {
				return url;
			}
		}
		return null;
	}

	public static NotificationDestinationDO getOldNotificationDestination(
			Set<NotificationDestinationDO> notificationDestinations, String name) {
		for (NotificationDestinationDO notificationDestination : notificationDestinations) {
			if (StringUtils.endsWithIgnoreCase(
					notificationDestination.getName(), name)) {
				return notificationDestination;
			}
		}
		return null;
	}

	public static String getNewNotificationDestination(
			Set<String> notificationDestinations, String name) {
		for (String notificationDestination : notificationDestinations) {
			if (StringUtils.endsWithIgnoreCase(notificationDestination, name)) {
				return notificationDestination;
			}
		}
		return null;
	}

	public static String getOldAuditType(Set<String> auditTypes,
			String findAuditType) {
		for (String auditType : auditTypes) {
			if (StringUtils.equals(auditType, findAuditType)) {
				return auditType;
			}
		}
		return null;
	}

	public static String getNewAuditType(Set<String> auditTypes,
			String findAuditType) {
		for (String auditType : auditTypes) {
			if (StringUtils.equals(auditType, findAuditType)) {
				return auditType;
			}
		}
		return null;
	}

	public static void audit(List<AuditDO> audits, Timestamp newValue,
			Timestamp oldValue, String field, EntityDO entity,
			AuditType auditType, String modifiedBy) {
		AuditDO audit = null;
		String newTime = newValue != null ? newValue.toString() : "";
		String oldTime = oldValue != null ? oldValue.toString() : "";
		if (!newTime.equals(oldTime)) {
			audit = new AuditDO(entity);
			audit.setField(field);
			audit.setOldValue(oldTime);
			audit.setNewValue(newTime);
			audit.setType(auditType);
			audit.setModifiedBy(modifiedBy);
			audits.add(audit);
		}
	}

	public static void audit(List<AuditDO> audits, String newValue,
			String oldValue, String field, EntityDO entity,
			AuditType auditType, String modifiedBy) {
		AuditDO audit = null;
		if (!isEquals(newValue, oldValue)) {
			audit = new AuditDO(entity);
			audit.setField(field);
			audit.setOldValue(oldValue);
			audit.setNewValue(newValue);
			audit.setType(auditType);
			audit.setModifiedBy(modifiedBy);
			audits.add(audit);
		}
	}

	public static void auditSubscription(List<AuditDO> audits, String newValue,
			String oldValue, String field, SubscriptionDO subscription,
			AuditType auditType, String modifiedBy, String newName) {
		AuditDO audit = null;
		String oldName = getSubscriptionName(subscription);
		if (!isEquals(newValue, oldValue)) {
			audit = new AuditDO(subscription.getServiceVersion());
			audit.setField(field);
			audit.setOldValue(oldName);
			audit.setNewValue(newName);
			audit.setType(auditType);
			audit.setModifiedBy(modifiedBy);
			audits.add(audit);

			audit = new AuditDO(subscription.getConsumer());
			audit.setField(field);
			audit.setOldValue(oldName);
			audit.setNewValue(newName);
			audit.setType(auditType);
			audit.setModifiedBy(modifiedBy);
			audits.add(audit);
		}
	}

	public static void audit(List<AuditDO> audits, Boolean newValue,
			Boolean oldValue, String field, EntityDO entity,
			AuditType auditType, String modifiedBy) {
		AuditDO audit = null;
		if (!newValue.equals(oldValue)) {
			audit = new AuditDO(entity);
			audit.setField(field);
			audit.setOldValue(String.valueOf(oldValue));
			audit.setNewValue(String.valueOf(newValue));
			audit.setType(auditType);
			audit.setModifiedBy(modifiedBy);
			audits.add(audit);
		}
	}

	public static void auditPolicyData(List<AuditDO> audits, String newValue,
			String oldValue, String field, EntityDO entity,
			AuditType auditType, String modifiedBy) {
		AuditDO audit = null;
		if (!isEquals(newValue, oldValue)) {
			audit = new AuditDO(entity);
			audit.setField(field);
			audit.setOldValue("Policy definition changed");
			audit.setNewValue("Policy definition changed");
			audit.setType(auditType);
			audit.setModifiedBy(modifiedBy);
			audits.add(audit);
		}
	}

	public static void audit(List<AuditDO> audits, byte[] newValue,
			byte[] oldValue, String field, EntityDO entity,
			AuditType auditType, String modifiedBy) {
		AuditDO audit = null;
		if (!Arrays.equals(newValue, oldValue)) {
			audit = new AuditDO(entity);
			audit.setField(field);
			audit.setOldValue(null);
			audit.setNewValue(null);
			audit.setType(auditType);
			audit.setModifiedBy(modifiedBy);
			audits.add(audit);
		}
	}

	public static boolean isEquals(String source, String target) {
		String value1 = source == null ? "" : source;
		String value2 = target == null ? "" : target;
		return value1.equals(value2);
	}

	public static Object getEnum(Class<?> destinationClass, Object source) {
		Object enumeration = null;
		Method[] ms = destinationClass.getMethods();
		for (Method m : ms) {
			if (m.getName().equalsIgnoreCase("valueOf")) {
				try {
					enumeration = m.invoke(destinationClass.getClass(),
							(String) source);
				} catch (Exception e) {
					throw new MappingException(
							"Exception while convert to enum", e);
				}
				break;
			}
		}
		return enumeration;
	}

	public static String getStatus(String action) {
		String status = null;
		if (StringUtils.isEmpty(action)) {
			return status;
		} else if (action.equalsIgnoreCase("ACTIVATE")) {
			return StatusType.ACTIVE.toString();
		} else if (action.equalsIgnoreCase("INACTIVATE")) {
			return StatusType.INACTIVE.toString();
		} else if (action.equalsIgnoreCase("DELETE")) {
			return StatusType.DELETED.toString();
		}
		return status;
	}

	public static String toStatus(String action) {
		String status = getStatus(action);
		if (StringUtils.isEmpty(status)) {
			throw new ServiceRegistryException(
					ErrorCode.BIZ_INVALID_STATUS_TYPE,
					CommonConstants.INVALID_STATUS_TYPE);
		}
		return status;
	}

	public static List<String> getStatusCriteria(String status) {
		String statusString = status != null ? status : "";
		List<String> statusTypes = new ArrayList<String>(0);
		if (StatusType.ACTIVE.toString().equalsIgnoreCase(statusString)) {
			statusTypes.add(StatusType.ACTIVE.toString());
		} else if (StatusType.INACTIVE.toString()
				.equalsIgnoreCase(statusString)) {
			statusTypes.add(StatusType.INACTIVE.toString());
		} else if (StatusType.DELETED.toString().equalsIgnoreCase(statusString)) {
			statusTypes.add(StatusType.DELETED.toString());
		} else if (StatusType.AVAILABLE.toString().equalsIgnoreCase(
				statusString)) {
			statusTypes.add(StatusType.ACTIVE.toString());
			statusTypes.add(StatusType.INACTIVE.toString());
		} else {
			statusTypes.add(statusString.toUpperCase());
		}
		return statusTypes;
	}

	public static boolean isValidQoSSearchOption(String searchName) {
		List<String> options = new ArrayList<String>(0);
		options.add(SearchFieldType.NAME.toString());
		options.add(SearchFieldType.STATUS.toString());
		return options.contains(searchName);
	}

	public static boolean isValidDefaultQoSSearchOption(String searchName) {
		List<String> options = new ArrayList<String>(0);
		options.add(SearchFieldType.NAME.toString());
		options.add(SearchFieldType.STATUS.toString());
		options.add(SearchFieldType.ENVIRONMENT.toString());
		options.add(SearchFieldType.CATEGORY.toString());
		return options.contains(searchName);
	}
	
	
	public static boolean isValidPolicySearchOption(String searchName) {
		List<String> options = new ArrayList<String>(0);
		options.add(SearchFieldType.NAME.toString());
		options.add(SearchFieldType.STATUS.toString());
		return options.contains(searchName);
	}

	public static boolean isValidNotificationDestinationSearchOption(
			String searchName) {
		List<String> options = new ArrayList<String>(0);
		options.add(SearchFieldType.NAME.toString());
		options.add(SearchFieldType.STATUS.toString());
		return options.contains(searchName);
	}

	public static boolean isValidServiceSearchOption(String searchName) {
		List<String> options = new ArrayList<String>(0);
		options.add(SearchFieldType.NAME.toString());
		options.add(SearchFieldType.STATUS.toString());
		options.add(SearchFieldType.CATEGORY.toString());
		options.add(SearchFieldType.DESCRIPTION.toString());
		options.add(SearchFieldType.OWNER.toString());
		options.add(SearchFieldType.DOMAIN.toString());
		options.add(SearchFieldType.USAGE.toString());
		options.add(SearchFieldType.APPLICATION.toString());
		options.add(SearchFieldType.AVAILABILITY_TIER.toString());
		options.add(SearchFieldType.ESB_REFERENCE.toString());
		options.add(SearchFieldType.ENVIRONMENT.toString());
		return options.contains(searchName);
	}

	public static boolean isValidXml(String xml) {
		return isValidPolicy(xml);
	}

	/**
	 * This method populates the QoS dto with ServiceVersionQoS details
	 * 
	 * @param serviceVersionQoS
	 * @param qosParameter
	 */
	public static void map(ServiceVersionQoS serviceVersionQoS, QoS qosParameter) {
		QoSDO qos = serviceVersionQoS.getQos();
		qosParameter.setId(qos.getId());
		qosParameter.setCreatedAt(serviceVersionQoS.getCreatedAt());
		qosParameter.setCreatedBy(serviceVersionQoS.getCreatedBy());
		qosParameter.setModifiedBy(serviceVersionQoS.getModifiedBy());
		qosParameter.setId(qos.getId());
		qosParameter.setName(qos.getName());
		qosParameter.setValue(serviceVersionQoS.getQosValue());
		qosParameter.setStatus(qos.getStatus());
		qosParameter.setType(qos.getType());
		qosParameter.setDescription(qos.getDescription());
	}

	/**
	 * This methods populates QoS DTOs from ServiceversionQoS
	 * 
	 * @param service
	 * @param serviceDOs
	 */
	public static void mapQoSToQoSParameter(Service service,
			List<ServiceDO> serviceDOs) {
		for (ServiceVersion serviceVersion : service.getServiceVersions()) {
			ServiceVersionDO serviceVersionDO = getServiceVersionDO(serviceDOs,serviceVersion.getId());
			if (serviceVersionDO != null) {
				serviceVersion.setQoSParameters(mapTo(serviceVersionDO.getServiceVersionQos()));
			}
		}
	}

	/**
	 * This method creates list of QoS DTOs from set of ServiceversionQoS
	 * 
	 * @param srvVersionQoS
	 * @return
	 */
	public static List<QoS> mapTo(Set<ServiceVersionQoS> srvVersionQoS) {
		List<QoS> result = new ArrayList<QoS>(0);
		for (ServiceVersionQoS srvQos : srvVersionQoS) {
			QoS qosParameter = new QoS();
			BizUtil.map(srvQos, qosParameter);
			result.add(qosParameter);
		}
		return result;
	}
	
	public static List<Attribute> mapAttributes(Set<AttributeDO> attributes) {
		List<Attribute> result = new ArrayList<Attribute>(0);
		for (AttributeDO attributeDO : attributes) {
			Attribute att = new Attribute(attributeDO.getName(), attributeDO.getValue());
			result.add(att);
		}
		return result;
	}

	/**
	 * This method returns ServiceVersionDO for given id
	 * 
	 * @param serviceDOs
	 * @param serviceVersionId
	 * @return
	 */
	public static ServiceVersionDO getServiceVersionDO(
			List<ServiceDO> serviceDOs, String serviceVersionId) {
		for (ServiceDO serviceDO : serviceDOs) {
			for (ServiceVersionDO serviceVersionDO : serviceDO
					.getServiceVersions()) {
				if (serviceVersionDO.getId().equals(serviceVersionId)) {
					return serviceVersionDO;
				}
			}
		}
		return null;
	}

	/**
	 * This method return ServiceVersionQoS by given id
	 * 
	 * @param serviceVersionDO
	 * @param id
	 * @return
	 * @throws PlatformException
	 */
	public static ServiceVersionQoS getServiceVersionQoS(
			ServiceVersionDO serviceVersionDO, String id)
			throws PlatformException {
		for (ServiceVersionQoS serviceVersionQoS : serviceVersionDO
				.getServiceVersionQos()) {
			QoSDO qos = serviceVersionQoS.getQos();
			if (qos.getId().equals(id)) {
				return serviceVersionQoS;
			}
		}
		return null;
	}

	/**
	 * Create QoS DTO from ServiceVersionQoS for given id
	 * 
	 * @param serviceVersionDO
	 * @param id
	 * @return
	 * @throws PlatformException
	 */
	public static QoS getQoSParameter(ServiceVersionDO serviceVersionDO,
			String id) throws PlatformException {
		for (ServiceVersionQoS serviceVersionQoS : serviceVersionDO
				.getServiceVersionQos()) {
			QoSDO qos = serviceVersionQoS.getQos();
			if (qos.getId().equals(id)) {
				QoS qosParameter = new QoS();
				BizUtil.map(serviceVersionQoS, qosParameter);
				return qosParameter;
			}
		}
		return null;
	}

	public static void validateCreatedBy(EntityType entityType, String createdBy) {
		if (StringUtils.isEmpty(createdBy)) {
			ErrorCode errorCode = getCreatedByErrorCode(entityType);
			throw new ServiceRegistryException(errorCode, CommonConstants.INVALID_CREATED_BY);
		}
	}
	
	public static ErrorCode getCreatedByErrorCode(EntityType entityType) {
		if(EntityType.SERVICE == entityType) {
			return ErrorCode.BIZ_INVALID_SERVICE_CREATED_BY;
		} else if(EntityType.SRVC_VERSION == entityType) {
			return ErrorCode.BIZ_INVALID_SERVICE_VERSION_CREATED_BY;
		} else if(EntityType.POLICY == entityType) {
			return ErrorCode.BIZ_INVALID_POLICY_CREATED_BY;
		} else if(EntityType.QoS == entityType) {
			return ErrorCode.BIZ_INVALID_QOS_CREATED_BY;
		} else if(EntityType.NOTIFICATION_DESTINATION == entityType) {
			return ErrorCode.BIZ_INVALID_NOTIFICATION_CREATED_BY;
		} else if(EntityType.CONSUMER == entityType) {
			return ErrorCode.BIZ_INVALID_CONSUMER_CREATED_BY;
		} else if(EntityType.SUBSCRIPTION == entityType) {
			return ErrorCode.BIZ_INVALID_SUBSCRIPTION_CREATED_BY;
		}
		return 	 ErrorCode.BIZ_INVALID_CREATED_BY;
	}

	public static ErrorCode getUpdatedByErrorCode(EntityType entityType) {
		if(EntityType.SERVICE == entityType) {
			return ErrorCode.BIZ_INVALID_SERVICE_UPDATED_BY;
		} else if(EntityType.SRVC_VERSION == entityType) {
			return ErrorCode.BIZ_INVALID_SERVICE_VERSION_UPDATED_BY;
		} else if(EntityType.POLICY == entityType) {
			return ErrorCode.BIZ_INVALID_POLICY_UPDATED_BY;
		} else if(EntityType.QoS == entityType) {
			return ErrorCode.BIZ_INVALID_QOS_UPDATED_BY;
		} else if(EntityType.NOTIFICATION_DESTINATION == entityType) {
			return ErrorCode.BIZ_INVALID_NOTIFICATION_UPDATED_BY;
		} else if(EntityType.CONSUMER == entityType) {
			return ErrorCode.BIZ_INVALID_CONSUMER_UPDATED_BY;
		} else if(EntityType.SUBSCRIPTION == entityType) {
			return ErrorCode.BIZ_INVALID_SUBSCRIPTION_UPDATED_BY;
		}
		return 	 ErrorCode.BIZ_INVALID_UPDATED_BY;
	}

	public static void validateModifiedBy(EntityType entityType, String modifiedBy) {
		if (StringUtils.isEmpty(modifiedBy)) {
			ErrorCode errorCode = getUpdatedByErrorCode(entityType);
			throw new ServiceRegistryException(errorCode, CommonConstants.INVALID_UPDATED_BY);
		}
	}

	public static boolean isValidPolicy(String policyDefinition) {
		if (StringUtils.isEmpty(policyDefinition)) {
			return false;
		}
		PolicyProvider resp = PolicyProvider.instance();
		PolicyDefinition policy = resp.getPolicyDefinition(policyDefinition);
		return policy != null;
	}

	public static String getCleanVersionNumber(String version) {
		if (version == null || "".equals("")) {
			return "";
		}

		String[] n = version.split("\\.");
		String result = "";
		for (int i = 0; i < n.length; i++) {
			String s = n[i].replaceFirst("^0+(?!$)", "");
			result = result + (s.equals("") ? "0" : s);
			if (i < n.length - 1) {
				result = result + ".";
			}
		}
		return result;
	}

	public static boolean isValid(String s) {
		String pattern = "^((([1-9]{0,1})\\d).(([1-9]{0,1})\\d).(([1-9]{0,1})\\d))";
		return s.matches(pattern);
	}

	public static boolean isServiceVersionFilterRequested(
			ServiceSearchBean search) {
		return !StringUtils.isEmpty(search.getSerVersion())
				|| !StringUtils.isEmpty(search.getEsbReference())
				|| !StringUtils.isEmpty(search.getAvailabilityTier())
				|| !StringUtils.isEmpty(search.getVersionStatus());
	}

	public static boolean isServiceFilterRequested(ServiceSearchBean search) {
		return !StringUtils.isEmpty(search.getApplicationId())
				|| !StringUtils.isEmpty(search.getCategory())
				|| !StringUtils.isEmpty(search.getDescription())
				|| !StringUtils.isEmpty(search.getEnvironment())
				|| !StringUtils.isEmpty(search.getName())
				|| !StringUtils.isEmpty(search.getOwner())
				|| !StringUtils.isEmpty(search.getStatus())
				|| !StringUtils.isEmpty(search.getDomain())
				|| !StringUtils.isEmpty(search.getUsage());
	}

	public static boolean isConsumerSubscriptionFilterRequested(
			ServiceSearchBean search) {
		return !StringUtils.isEmpty(search.getConsumerId())
				|| !StringUtils.isEmpty(search.getCommunicationType()) || !StringUtils.isEmpty(search.getSubscriptonStatus());
	}

	/*public static void reset(Service service, ServiceDO serviceDO) {
		service.getNotificationTypes().clear();
		service.getNotificationFor().clear();
		for (NotificationDestinationDO notification : serviceDO
				.getNotificationTypes()) {
			service.getNotificationTypes().add(notification.getName());
		}
		for (String changeType : serviceDO.getNotificationFor()) {
			service.getNotificationFor().add(changeType);
		}
	}*/
	
	public static void reset(Service service, ServiceDO serviceDO) {
		service.getNotificationTypes().clear();
		service.getNotificationFor().clear();
		for (String notificationType : serviceDO
				.getNotificationTypes()) {
			service.getNotificationTypes().add(notificationType);
		}
		for (String changeType : serviceDO.getNotificationFor()) {
			service.getNotificationFor().add(changeType);
		}
	}

	public static boolean isFiltered(String s, String search) {
		if (StringUtils.isEmpty(search)) {
			return false;
		}
		s = s != null ? s.trim() : "";
		return !s.equalsIgnoreCase(search.trim());
	}

	public static boolean isFiltereLike(String s, String search) {
		if (StringUtils.isEmpty(search)) {
			return false;
		}
		s = s != null ? s.trim().toLowerCase() : "";
		return !s.contains(search.toLowerCase());
	}

	public static ServiceVersionDO filter(ServiceVersionDO serviceVersion,
			ServiceSearchBean search) {
		if (isFiltered(serviceVersion.getAvailabilityTier(),
				search.getAvailabilityTier())) {
			return null;
		}
		if (isFiltered(serviceVersion.getEsbReference(),
				search.getEsbReference())) {
			return null;
		}
		if (isFiltered(serviceVersion.getSerVersion(), search.getSerVersion())) {
			return null;
		}
		if (isFiltered(serviceVersion.getStatus(), search.getVersionStatus())) {
			return null;
		}
		return serviceVersion;
	}

	public static ServiceDO filter(ServiceDO service, ServiceSearchBean search) {
		if (isFiltered(service.getApplicationId(), search.getApplicationId())) {
			return null;
		}
		if (isFiltereLike(service.getDescription(), search.getDescription())) {
			return null;
		}
		if (isFiltered(service.getEnvironment(), search.getEnvironment())) {
			return null;
		}
		if (isFiltered(service.getApplicationId(), search.getApplicationId())) {
			return null;
		}
		if (isFiltereLike(service.getName(), search.getName())) {
			return null;
		}
		if (isFiltered(service.getOwner(), search.getOwner())) {
			return null;
		}
		if (isFiltered(service.getCategory(), search.getCategory())) {
			return null;
		}
		if (isFiltered(service.getDomain(), search.getDomain())) {
			return null;
		}
		if (isFiltered(service.getStatus(), search.getStatus())) {
			return null;
		}
		if (isFiltered(service.getUsage(), search.getUsage())) {
			return null;
		}
		return service;
	}

	public static String getRequestUrl(SubscriptionDO subscription) {
		List<String> result = null;
		if (ServiceCommunicationType.ESB_PROXY.toString().equals(
				subscription.getCommunicationType())) {
			result = getUrls(subscription.getServiceVersion().getUrls(),
					UrlType.ESB_PROXY);
		} else if (ServiceCommunicationType.DIRECT.toString().equals(
				subscription.getCommunicationType())) {
			result = getUrls(subscription.getServiceVersion().getUrls(),
					UrlType.ENDPOINT);
		} else if (ServiceCommunicationType.LOCAL.toString().equals(
				subscription.getCommunicationType())) {
			result = getUrls(subscription.getServiceVersion().getUrls(),
					UrlType.LOCAL_ENDPOINT);
		}
		return result != null && !result.isEmpty() ? result.get(0) : null;
	}

	public static List<Attribute> getAlternateUrlAttributes(SubscriptionDO subscription) {
		if (ServiceCommunicationType.DIRECT.toString().equals(
				subscription.getCommunicationType())) {
			return getUrlAttributes(subscription.getServiceVersion().getUrls(),
					UrlType.ENDPOINT_ALTERNATE);
		} else if (ServiceCommunicationType.LOCAL.toString().equals(
				subscription.getCommunicationType())) {
			return getUrlAttributes(subscription.getServiceVersion().getUrls(),
					UrlType.LOCAL_ENDPOINT);
		} else if (ServiceCommunicationType.ESB_PROXY.toString().equals(
				subscription.getCommunicationType())) {
			return getUrlAttributes(subscription.getServiceVersion().getUrls(),
					UrlType.ESB_ALTERNATE);
		}
		return null;
	}
	
	public static List<String> getAlternateUrls(SubscriptionDO subscription) {
		if (ServiceCommunicationType.DIRECT.toString().equals(
				subscription.getCommunicationType())) {
			return getUrls(subscription.getServiceVersion().getUrls(),
					UrlType.ENDPOINT_ALTERNATE);
		} else if (ServiceCommunicationType.LOCAL.toString().equals(
				subscription.getCommunicationType())) {
			return getUrls(subscription.getServiceVersion().getUrls(),
					UrlType.LOCAL_ENDPOINT);
		} else if (ServiceCommunicationType.ESB_PROXY.toString().equals(
				subscription.getCommunicationType())) {
			return getUrls(subscription.getServiceVersion().getUrls(),
					UrlType.ESB_ALTERNATE);
		}
		return null;
	}

	public static List<Attribute> getOtherServiceUrls(Set<UrlDO> urls) {
		List<Attribute> result = new ArrayList<Attribute>(0);
		for (UrlDO url : urls) {
			if (!isAlternateUrl(url.getType()) && isServiceUrl(url.getType())) {
				result.add(new Attribute(url.getType(), url.getUrl()));
			}
		}
		return result;
	}

	public static List<Attribute> getUrlAttributes(
			ServiceVersionDO serviceVersion, String communicationType) {
		List<Attribute> attributes = new ArrayList<Attribute>(0);
		for (UrlDO url : serviceVersion.getUrls()) {
			if (UrlType.ENDPOINT_ALTERNATE.toString().equals(url.getType())
					&& ServiceCommunicationType.DIRECT.toString().equals(
							communicationType)) {
				attributes.add(new Attribute(url.getType(), url.getUrl()));
			} else if (isServiceUrl(url.getType())) {
				attributes.add(new Attribute(url.getType(), url.getUrl()));
			}
		}
		return attributes;
	}

	public static boolean isServiceUrl(String type) {
		if (UrlType.API_DOC.toString().equals(type)
				|| UrlType.API_SAMPLE_CLIENT_CODE.toString().equals(type)) {
			return false;
		}
		return true;
	}

	public static boolean isAlternateUrl(String type) {
		if (UrlType.ENDPOINT_ALTERNATE.toString().equals(type)
				|| UrlType.LOCAL_ENDPOINT.toString().equals(type)
				|| UrlType.ESB_ALTERNATE.toString().equals(type)) {
			return true;
		}
		return false;
	}

	public static List<String> getUrls(Set<UrlDO> urls, UrlType urlType) {
		List<String> result = new ArrayList<String>(0);
		for (UrlDO url : urls) {
			if (url.getType().equals(urlType.toString())) {
				result.add(url.getUrl());
			}
		}
		return result;
	}

	public static List<Attribute> getUrlAttributes(Set<UrlDO> urls,
			UrlType urlType) {
		List<Attribute> result = new ArrayList<Attribute>(0);
		for (UrlDO url : urls) {
			if (url.getType().equals(urlType.toString())) {
				result.add(new Attribute(url.getType(), url.getUrl()));
			}
		}
		return result;
	}

	/**
	 * @param fieldName
	 * @param source
	 * @param destination
	 * @return
	 * @throws DataAccessException
	 */
	public static synchronized String convertFrom(String fieldName,
			String source, String destination) throws DataAccessException {
		RegistryPolicyCode result = null;
		if (RegistryPolicyCodeType.SERVICE_CATEGORY.toString()
				.equalsIgnoreCase(fieldName)) {
			result = RegistryPolicyCodeDAOImpl.getCode(
					RegistryPolicyCodeType.SERVICE_CATEGORY,
					source.toUpperCase());
			if (result == null) {
				throw new ServiceRegistryException(
						ErrorCode.BIZ_INVALID_SERVICE_CATEGORY,
						"Invalid service category : " + source);
			}
		} else if (RegistryPolicyCodeType.SERVICE_DOMAIN.toString()
				.equalsIgnoreCase(fieldName)) {
			result = RegistryPolicyCodeDAOImpl
					.getCode(RegistryPolicyCodeType.SERVICE_DOMAIN,
							source.toUpperCase());
			if (result == null) {
				throw new ServiceRegistryException(
						ErrorCode.BIZ_INVALID_SERVICE_DOMAIN,
						"Invalid service domain : " + source);
			}
		} else if (RegistryPolicyCodeType.SERVICE_USAGE.toString()
				.equalsIgnoreCase(fieldName)) {
			result = RegistryPolicyCodeDAOImpl.getCode(
					RegistryPolicyCodeType.SERVICE_USAGE, source.toUpperCase());
			if (result == null) {
				throw new ServiceRegistryException(
						ErrorCode.BIZ_INVALID_SERVICE_DOMAIN,
						"Invalid service usage : " + source);
			}
		} else if (RegistryPolicyCodeType.STATUS.toString().equalsIgnoreCase(
				fieldName)) {
			result = RegistryPolicyCodeDAOImpl.getCode(
					RegistryPolicyCodeType.STATUS, source.toUpperCase());
			if (result == null) {
				throw new ServiceRegistryException(
						ErrorCode.BIZ_INVALID_STATUS_TYPE, "Invalid status : "
								+ source);
			}
		} else if (RegistryPolicyCodeType.QoS_TYPE.toString().equalsIgnoreCase(
				fieldName)) {
			result = RegistryPolicyCodeDAOImpl.getCode(
					RegistryPolicyCodeType.QoS_TYPE, source.toUpperCase());
			if (result == null) {
				throw new ServiceRegistryException(
						ErrorCode.BIZ_INVALID_QoS_TYPE, "Invalid QOS type : "
								+ source);
			}
		} else if (RegistryPolicyCodeType.POLICY_TYPE.toString()
				.equalsIgnoreCase(fieldName)) {
			result = RegistryPolicyCodeDAOImpl.getCode(
					RegistryPolicyCodeType.POLICY_TYPE, source.toUpperCase());
			if (result == null) {
				throw new ServiceRegistryException(
						ErrorCode.BIZ_INVALID_POLICY_TYPE,
						"Invalid policy type : " + source);
			}
		} else if (RegistryPolicyCodeType.NOTIFICATION_TYPE.toString()
				.equalsIgnoreCase(fieldName)) {
			result = RegistryPolicyCodeDAOImpl.getCode(
					RegistryPolicyCodeType.NOTIFICATION_TYPE,
					source.toUpperCase());
			if (result == null) {
				throw new ServiceRegistryException(
						ErrorCode.BIZ_INVALID_NOTIFICATION_TYPE,
						"Invalid notification type : " + source);
			}
		} else if (RegistryPolicyCodeType.URL.toString().equalsIgnoreCase(
				fieldName)) {
			result = RegistryPolicyCodeDAOImpl.getCode(
					RegistryPolicyCodeType.URL, source.toUpperCase());
			if (result == null) {
				throw new ServiceRegistryException(ErrorCode.BIZ_INVALID_URL,
						"Invalid url type : " + source);
			}
		} else if (RegistryPolicyCodeType.FLOW.toString().equalsIgnoreCase(
				fieldName)) {
			result = RegistryPolicyCodeDAOImpl.getCode(
					RegistryPolicyCodeType.FLOW, source.toUpperCase());
			if (result == null) {
				throw new ServiceRegistryException(ErrorCode.BIZ_INVALID_FLOW,
						"Invalid flow type : " + source);
			}
		} else if (RegistryPolicyCodeType.CHANGE_TYPE.toString()
				.equalsIgnoreCase(fieldName)) {
			result = RegistryPolicyCodeDAOImpl.getCode(
					RegistryPolicyCodeType.CHANGE_TYPE, source.toUpperCase());
			if (result == null) {
				throw new ServiceRegistryException(ErrorCode.BIZ_INVALID_FLOW,
						"Invalid Change type : " + source);
			}
		} else if (RegistryPolicyCodeType.COMMUNICATION_TYPE.toString()
				.equalsIgnoreCase(fieldName)) {
			result = RegistryPolicyCodeDAOImpl.getCode(
					RegistryPolicyCodeType.COMMUNICATION_TYPE,
					source.toUpperCase());
			if (result == null) {
				throw new ServiceRegistryException(ErrorCode.BIZ_INVALID_FLOW,
						"Invalid Access type : " + source);
			}
		} else if (RegistryPolicyCodeType.CONTEXT.toString().equalsIgnoreCase(
				fieldName)) {
			result = RegistryPolicyCodeDAOImpl.getCode(
					RegistryPolicyCodeType.CONTEXT, source.toUpperCase());
			if (result == null) {
				throw new ServiceRegistryException(
						ErrorCode.BIZ_INVALID_CONTEXT,
						"Invalid Context type : " + source);
			}
		} else if (RegistryPolicyCodeType.CMDB_ENVIRONMENT.toString()
				.equalsIgnoreCase(fieldName)) {
			/*result = RegistryPolicyCodeDAOImpl.getCode(
					RegistryPolicyCodeType.CMDB_ENVIRONMENT,
					source.toLowerCase());
			if (result == null) {*/
			if(StringUtils.isEmpty(source)){
				throw new ServiceRegistryException(
						ErrorCode.BIZ_INVALID_CMDB_ENVIRONMENT,
						"Invalid environment type : " + source);
			}
			return source.toLowerCase();
		} else if (RegistryPolicyCodeType.CMDB_ARTIFACT.toString()
				.equalsIgnoreCase(fieldName)) {
			result = RegistryPolicyCodeDAOImpl.getCode(
					RegistryPolicyCodeType.CMDB_ARTIFACT, source.toLowerCase());
			if (result == null) {
				throw new ServiceRegistryException(
						ErrorCode.BIZ_INVALID_CMDB_ARTIFACT,
						"Invalid artifact id : " + source);
			}
		} else if (RegistryPolicyCodeType.JIRA_PROJECT.toString()
				.equalsIgnoreCase(fieldName)) {
			result = RegistryPolicyCodeDAOImpl.getCode(
					RegistryPolicyCodeType.JIRA_PROJECT, source.toUpperCase());
			if (result == null) {
				throw new ServiceRegistryException(
						ErrorCode.BIZ_INVALID_JIRA_PROJECT,
						"Invalid JIRA Project Key : " + source);
			}
		}
		return result != null ? result.getCode() : null;
	}

	public static Policy getNewPolicy(List<Policy> policies, String policyId) {
		for (Policy policy : policies) {
			if (policy.getId().equals(policyId)) {
				return policy;
			}
		}
		return null;
	}

	public static String getJsonDefaultEnv() {
		return "{\"status\":\"OK\",\"header\":{\"headerAttributes\":{}},\"errors\":[],\"payload\":[{\"name\":\"default\",\"desc\":null,\"created_date\":null},{\"name\":\"dev\",\"desc\":null,\"created_date\":null},{\"name\":\"build\",\"desc\":null,\"created_date\":null},{\"name\":\"pqa\",\"desc\":null,\"created_date\":null},{\"name\":\"qa\",\"desc\":null,\"created_date\":null},{\"name\":\"qa-stg\",\"desc\":null,\"created_date\":null},{\"name\":\"qa2\",\"desc\":null,\"created_date\":null},{\"name\":\"qa3\",\"desc\":null,\"created_date\":null},{\"name\":\"dev2\",\"desc\":null,\"created_date\":null},{\"name\":\"pqae2e1\",\"desc\":null,\"created_date\":null},{\"name\":\"pqae2e2\",\"desc\":null,\"created_date\":null},{\"name\":\"pqas1\",\"desc\":null,\"created_date\":null},{\"name\":\"pqas2\",\"desc\":null,\"created_date\":null},{\"name\":\"pqac1\",\"desc\":null,\"created_date\":null},{\"name\":\"pqac2\",\"desc\":null,\"created_date\":null},{\"name\":\"stg\",\"desc\":null,\"created_date\":null},{\"name\":\"ebf\",\"desc\":null,\"created_date\":null},{\"name\":\"qa4\",\"desc\":null,\"created_date\":null},{\"name\":\"qa5\",\"desc\":null,\"created_date\":null},{\"name\":\"a1\",\"desc\":null,\"created_date\":null},{\"name\":\"ptr\",\"desc\":null,\"created_date\":null},{\"name\":\"qa-int\",\"desc\":null,\"created_date\":null},{\"name\":\"a2\",\"desc\":null,\"created_date\":null},{\"name\":\"stg2\",\"desc\":null,\"created_date\":null}]}";
	}

	public static String getJsonDefaultArtifacts() {
		return "{\"status\":\"OK\",\"header\":{\"headerAttributes\":{}},\"errors\":[],\"payload\":[{\"appName\":\"soari-registry-app\",\"envName\":\"qa\",\"appVersion\":\"3.0.15\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"mp-portal-app\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"order-services-lookup-app\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"samsimsq4-oracle\",\"envName\":\"qa\",\"appVersion\":\"11.2.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"mp-portal-app\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"order-services-lookup-app\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"uscmdbq1-oracle\",\"envName\":\"qa\",\"appVersion\":\"11.2.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"mpp-reporting\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"customer-account-service\",\"envName\":\"qa\",\"appVersion\":\"0.1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"uiaas-serving\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"ukims-hfinstall\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"ems-ats\",\"envName\":\"qa\",\"appVersion\":\"1.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"ems-ois\",\"envName\":\"qa\",\"appVersion\":\"1.2\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"logcollector\",\"envName\":\"qa\",\"appVersion\":\"1.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"paas\",\"envName\":\"qa\",\"appVersion\":\"1.18\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"itemasset-read-app\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"samsimsq3-oracle\",\"envName\":\"qa\",\"appVersion\":\"11.2.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"ukoms-agent-qa\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"usims-manifest\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"sterlinghfinstall\",\"envName\":\"qa\",\"appVersion\":\"1.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"samsimsq8-oracle\",\"envName\":\"qa\",\"appVersion\":\"11.2.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"cart-ois-service\",\"envName\":\"qa\",\"appVersion\":\"1.18\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"log-search-api\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"ems-ss\",\"envName\":\"qa\",\"appVersion\":\"1.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"promisedate-app\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"paas-tar-demo-v2\",\"envName\":\"qa\",\"appVersion\":\"1.18\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"samsimsq2_it-oracle\",\"envName\":\"qa\",\"appVersion\":\"11.2.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"sterling-misc-qa\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"usbrmsq1-oracle\",\"envName\":\"qa\",\"appVersion\":\"11.2.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"sdcukomsq2.gecwalmart.com-oracle\",\"envName\":\"qa\",\"appVersion\":\"11.2.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"ship-methods-read-service\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"brims-agent-qa\",\"envName\":\"qa\",\"appVersion\":\"1.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"r2d2\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"photo-p2r\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"tax-app\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"ship-pricing-ggo\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"iam-oracle\",\"envName\":\"qa\",\"appVersion\":\"11.2.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"cuid-service\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"ggo-ship-methods-app\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"goms-agent-qa\",\"envName\":\"qa\",\"appVersion\":\"1.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"platform-iam-server\",\"envName\":\"qa\",\"appVersion\":\"1.1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"sams-invup\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"cart-xo-test-utils\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"pricing-catalog-adapter\",\"envName\":\"qa\",\"appVersion\":\"1.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"item-cat-adapter-response-app\",\"envName\":\"qa\",\"appVersion\":\"1.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"jboss-patch\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"ems-ds-qa\",\"envName\":\"qa\",\"appVersion\":\"1.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"seller-app\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"usims\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"log-stream\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"usims-sterling-jdk\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"limelight-icaas\",\"envName\":\"qa\",\"appVersion\":\"1.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"pronto-app\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"customer-overrides-qa\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"auth-server\",\"envName\":\"qa\",\"appVersion\":\"1.1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"ems-ts\",\"envName\":\"qa\",\"appVersion\":\"1.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"ems-pagebuilder\",\"envName\":\"qa\",\"appVersion\":\"1.2\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"logstream_tar\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"ultraesb-uconsole\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"goms\",\"envName\":\"qa\",\"appVersion\":\"1.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"mpoms-cdt-qa\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"address-service\",\"envName\":\"qa\",\"appVersion\":\"1.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"ems-store\",\"envName\":\"qa\",\"appVersion\":\"1.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"ukoms-hfinstall\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"sterlinginstall\",\"envName\":\"qa\",\"appVersion\":\"1.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"validation\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"order-services-admin\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"ultraesb-distribution\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"dbaas-services-mysql\",\"envName\":\"qa\",\"appVersion\":\"11.2.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"ems\",\"envName\":\"qa\",\"appVersion\":\"1.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"item-rollups\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"samsimsq6-oracle\",\"envName\":\"qa\",\"appVersion\":\"11.2.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"uspricq1-oracle\",\"envName\":\"qa\",\"appVersion\":\"11.2.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"ems-da-qa\",\"envName\":\"qa\",\"appVersion\":\"1.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"cart-service\",\"envName\":\"qa\",\"appVersion\":\"1.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"usgomsq4-oracle\",\"envName\":\"qa\",\"appVersion\":\"11.2.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"ukims\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"paas-mysql\",\"envName\":\"qa\",\"appVersion\":\"11.2.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"sdcukimsq2.gecwalmart.com-oracle\",\"envName\":\"qa\",\"appVersion\":\"11.2.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"cart-ref-app\",\"envName\":\"qa\",\"appVersion\":\"1.18\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"pricing\",\"envName\":\"qa\",\"appVersion\":\"11.2.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"b2b-marketplace\",\"envName\":\"qa\",\"appVersion\":\"1.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"noncore-adapter-service\",\"envName\":\"qa\",\"appVersion\":\"1.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"ppo-app\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"taxservice\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"snap-demo\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"tibco-ems\",\"envName\":\"qa\",\"appVersion\":\"6.1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"idt-services\",\"envName\":\"qa\",\"appVersion\":\"1.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"irs-webmgmt\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"sdcussmsq1.gecwalmart.com-oracle\",\"envName\":\"qa\",\"appVersion\":\"11.2.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"shorten_deploy\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"payment-app\",\"envName\":\"qa\",\"appVersion\":\"12.5\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"dbaas-services\",\"envName\":\"qa\",\"appVersion\":\"1.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"inventory-availability-admin\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"usims-misc-qa\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"platform-portal\",\"envName\":\"qa\",\"appVersion\":\"1.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"sterling-agent-qa\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"usbrmsq2-oracle\",\"envName\":\"qa\",\"appVersion\":\"11.2.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"samsimsq2-oracle\",\"envName\":\"qa\",\"appVersion\":\"11.2.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"fraud-uso\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"sdcusiprq1.gecwalmart.com-oracle\",\"envName\":\"qa\",\"appVersion\":\"11.2.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"limelight-das-ingestion\",\"envName\":\"qa\",\"appVersion\":\"1.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"paas-demo-service\",\"envName\":\"qa\",\"appVersion\":\"1.18\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"paas-zookeeper\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"ggo-inventory-ingestion-app\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"list-service\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"mpoms-agent-qa\",\"envName\":\"qa\",\"appVersion\":\"1.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"limelight-icaas-job\",\"envName\":\"qa\",\"appVersion\":\"1.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"sdcuslista1.gecwalmart.com-oracle\",\"envName\":\"qa\",\"appVersion\":\"11.2.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"cache-cart-service\",\"envName\":\"qa\",\"appVersion\":\"1.18\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"pangaea-dal-refimpl\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"ggois-item\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"item-cat-adapter-injestion-app\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"ems-cms\",\"envName\":\"qa\",\"appVersion\":\"1.2\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"paas-perf-test\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"item-setup-brms-app\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"cpf\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"oracle-ds-qa\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"item-pricing\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"cdaas\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"ukoms-cdt-qa\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"usims-sterling-factorysetup\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"irs-ws\",\"envName\":\"qa\",\"appVersion\":\"1.18\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"soa.gecwalmart.com\",\"envName\":\"qa\",\"appVersion\":\"11.2.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"adsaver-services\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"limelight-b2ba\",\"envName\":\"qa\",\"appVersion\":\"1.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"settlement\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"ship-methods-setup-service\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"asdagmoms-oracle\",\"envName\":\"qa\",\"appVersion\":\"11.2.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"itemstore-item-read-app\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"soari-registry-app\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"usgomsq2-oracle\",\"envName\":\"qa\",\"appVersion\":\"11.2.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"tempo\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"previewems\",\"envName\":\"qa\",\"appVersion\":\"11.2.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"scm-app\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"limelight-ca\",\"envName\":\"qa\",\"appVersion\":\"1.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"ggo-order-ingestion-app\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"ukims-cdt-qa\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"samsims-agent-qa\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"limelight-icaas-ingestion\",\"envName\":\"qa\",\"appVersion\":\"1.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"snap-sandbox\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"brims-sterlinginstallfiles-qa\",\"envName\":\"qa\",\"appVersion\":\"1.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"sdcuscartq1.gecwalmart.com-oracle\",\"envName\":\"qa\",\"appVersion\":\"11.2.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"usims-sterling-ibm-im\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"ukims-oracle\",\"envName\":\"qa\",\"appVersion\":\"11.2.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"usims-sterling-hf-install\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"samsimsq5-oracle\",\"envName\":\"qa\",\"appVersion\":\"11.2.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"ucid-seg\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"pricing-oracle\",\"envName\":\"qa\",\"appVersion\":\"11.2.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"tempo-service-app\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"samsims-hfinstall\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"mpoms\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"usgomsq3-oracle\",\"envName\":\"qa\",\"appVersion\":\"11.2.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"usims-sterling-sf-install-qa\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"sdcbromsq1.gecwalmart.com-oracle\",\"envName\":\"qa\",\"appVersion\":\"11.2.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"samsims-cdt-qa\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"checkoutservice\",\"envName\":\"qa\",\"appVersion\":\"12.5\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"usims-sterling-cdt-qa\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"node\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"item-pricing-ca\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"previewems-oracle\",\"envName\":\"qa\",\"appVersion\":\"11.2.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"samsimsq7-oracle\",\"envName\":\"qa\",\"appVersion\":\"11.2.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"analytics\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"ship-pricing-rules\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"ukesba1_ops-oracle\",\"envName\":\"qa\",\"appVersion\":\"11.2.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"item-read-service\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"brims\",\"envName\":\"qa\",\"appVersion\":\"1.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"sampleapp\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"cmdb-server\",\"envName\":\"qa\",\"appVersion\":\"1.9\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"cacheserver\",\"envName\":\"qa\",\"appVersion\":\"1.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"brims-cdt-qa\",\"envName\":\"qa\",\"appVersion\":\"1.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"sdcuscusaq1.gecwalmart.com-oracle\",\"envName\":\"qa\",\"appVersion\":\"11.2.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"settlement-cron\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"ucid-scs\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"ukoms\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"iso-app\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"itemasset-setup-app\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"ship-pricing\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"inventory-availability-ingestion\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"broms-sterlinginstallfiles-qa\",\"envName\":\"qa\",\"appVersion\":\"1.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"sdcukimsq1.gecwalmart.com-oracle\",\"envName\":\"qa\",\"appVersion\":\"11.2.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"brms-oracle\",\"envName\":\"qa\",\"appVersion\":\"11.2.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"itemstore-item-setup-app\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"baas-activiti-app\",\"envName\":\"qa\",\"appVersion\":\"1.18\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"gomsext\",\"envName\":\"qa\",\"appVersion\":\"1.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"samsims\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"log-stream-agent\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"baas-app\",\"envName\":\"qa\",\"appVersion\":\"1.18\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"mpoms-oracle\",\"envName\":\"qa\",\"appVersion\":\"11.2.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"usims-sterling-installable\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"sdcbrimsq1.gecwalmart.com-oracle\",\"envName\":\"qa\",\"appVersion\":\"11.2.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"usgomsq1-oracle\",\"envName\":\"qa\",\"appVersion\":\"11.2.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"usims-sterling-agent-qa\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"checkoutbatch\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"scm.gecwalmart.com\",\"envName\":\"qa\",\"appVersion\":\"11.2.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"pangaea-logging-web\",\"envName\":\"qa\",\"appVersion\":\"1.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"ukims-agent-qa\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"samsimsq9-oracle\",\"envName\":\"qa\",\"appVersion\":\"11.2.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"ca-app\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"pricing-ingestion-impl\",\"envName\":\"qa\",\"appVersion\":\"1.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"checkoutapi_2.10\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"emsmonservice\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"order-services-ingestion-app\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"pharmacy-app\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"limelight-das-processing\",\"envName\":\"qa\",\"appVersion\":\"1\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"inventory-availability-service\",\"envName\":\"qa\",\"appVersion\":\"1.0\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null},{\"appName\":\"fraudengine-app\",\"envName\":\"qa\",\"appVersion\":\"12.5\",\"minInstances\":\"1\",\"maxInstances\":\"500\",\"availabilityZone\":null,\"faultZone\":null}]}";
	}

	public static String getJsonDefaultJIRAProjects() {
		StringBuilder sb = new StringBuilder();
		sb.append("{");
		sb.append("   \"expand\":\"projects\",");
		sb.append("   \"projects\":[");
		sb.append("      {");
		sb.append("         \"self\":\"https://jira.walmart.com/rest/api/2/project/PGPSOA\",");
		sb.append("         \"id\":\"10137\",");
		sb.append("         \"key\":\"PGPSOA\",");
		sb.append("         \"name\":\"PG Foundation - SOA\",");
		sb.append("         \"avatarUrls\":{");
		sb.append("            \"16x16\":\"https://jira.walmart.com/secure/projectavatar?size=small&pid=10137&avatarId=10011\",");
		sb.append("            \"48x48\":\"https://jira.walmart.com/secure/projectavatar?pid=10137&avatarId=10011\"");
		sb.append("         },");
		sb.append("         \"issuetypes\":[");
		sb.append("            {");
		sb.append("               \"self\":\"https://jira.walmart.com/rest/api/2/issuetype/6\",");
		sb.append("               \"id\":\"6\",");
		sb.append("               \"description\":\"A big user story that needs to be broken down.\",");
		sb.append("               \"iconUrl\":\"https://jira.walmart.com/images/icons/ico_epic.png\",");
		sb.append("               \"name\":\"Epic\",");
		sb.append("               \"subtask\":false");
		sb.append("            },");
		sb.append("            {");
		sb.append("               \"self\":\"https://jira.walmart.com/rest/api/2/issuetype/7\",");
		sb.append("               \"id\":\"7\",");
		sb.append("               \"description\":\"A user story\",");
		sb.append("               \"iconUrl\":\"https://jira.walmart.com/images/icons/ico_story.png\",");
		sb.append("               \"name\":\"Story\",");
		sb.append("               \"subtask\":false");
		sb.append("            },");
		sb.append("            {");
		sb.append("               \"self\":\"https://jira.walmart.com/rest/api/2/issuetype/1\",");
		sb.append("               \"id\":\"1\",");
		sb.append("               \"description\":\"A problem which impairs or prevents the functions of the product.\",");
		sb.append("               \"iconUrl\":\"https://jira.walmart.com/images/icons/bug.gif\",");
		sb.append("               \"name\":\"Bug\",");
		sb.append("               \"subtask\":false");
		sb.append("            },");
		sb.append("            {");
		sb.append("               \"self\":\"https://jira.walmart.com/rest/api/2/issuetype/15\",");
		sb.append("               \"id\":\"15\",");
		sb.append("               \"description\":\"\",");
		sb.append("               \"iconUrl\":\"https://jira.walmart.com/images/icons/genericissue.gif\",");
		sb.append("               \"name\":\"Support Incident\",");
		sb.append("               \"subtask\":false");
		sb.append("            },");
		sb.append("            {");
		sb.append("               \"self\":\"https://jira.walmart.com/rest/api/2/issuetype/10\",");
		sb.append("               \"id\":\"10\",");
		sb.append("               \"description\":\"Only for the JIRA Team\",");
		sb.append("               \"iconUrl\":\"https://jira.walmart.com/images/icons/genericissue.gif\",");
		sb.append("               \"name\":\"Support Ticket\",");
		sb.append("               \"subtask\":false");
		sb.append("            },");
		sb.append("            {");
		sb.append("               \"self\":\"https://jira.walmart.com/rest/api/2/issuetype/9\",");
		sb.append("               \"id\":\"9\",");
		sb.append("               \"description\":\"A test case is a created by a QA Person and meant to test case all the features developed in JIRA.\",");
		sb.append("               \"iconUrl\":\"https://jira.walmart.com/images/icons/genericissue.gif\",");
		sb.append("               \"name\":\"Test Case\",");
		sb.append("               \"subtask\":false");
		sb.append("            },");
		sb.append("            {");
		sb.append("               \"self\":\"https://jira.walmart.com/rest/api/2/issuetype/5\",");
		sb.append("               \"id\":\"5\",");
		sb.append("               \"description\":\"The sub-task of the issue\",");
		sb.append("               \"iconUrl\":\"https://jira.walmart.com/images/icons/issue_subtask.gif\",");
		sb.append("               \"name\":\"Sub-task\",");
		sb.append("               \"subtask\":true");
		sb.append("            },");
		sb.append("            {");
		sb.append("               \"self\":\"https://jira.walmart.com/rest/api/2/issuetype/12\",");
		sb.append("               \"id\":\"12\",");
		sb.append("               \"description\":\"WebOps Sub-task Issue Type\",");
		sb.append("               \"iconUrl\":\"https://jira.walmart.com/images/icons/task.gif\",");
		sb.append("               \"name\":\"WebOps Sub-task\",");
		sb.append("               \"subtask\":true");
		sb.append("            },");
		sb.append("            {");
		sb.append("               \"self\":\"https://jira.walmart.com/rest/api/2/issuetype/14\",");
		sb.append("               \"id\":\"14\",");
		sb.append("               \"description\":\"\",");
		sb.append("               \"iconUrl\":\"https://jira.walmart.com/images/icons/genericissue.gif\",");
		sb.append("               \"name\":\"Deployment\",");
		sb.append("               \"subtask\":false");
		sb.append("            }");
		sb.append("         ]");
		sb.append("      }");
		sb.append("   ]");
		sb.append("}");
		return sb.toString();
	}

	public static String createJiraTask(String baseUrl, String authorization,
			String projectKey, String summary, String description) {
		StringBuilder response = new StringBuilder();
		try {
			URL url = new URL(baseUrl);

			// Create a trust manager that does not validate certificate chains
			final TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
				@Override
				public void checkClientTrusted(final X509Certificate[] chain,
						final String authType) {
				}

				@Override
				public void checkServerTrusted(final X509Certificate[] chain,
						final String authType) {
				}

				@Override
				public X509Certificate[] getAcceptedIssuers() {
					return null;
				}
			} };
			// Install the all-trusting trust manager
			final SSLContext sslContext = SSLContext.getInstance("SSL");
			sslContext.init(null, trustAllCerts,
					new java.security.SecureRandom());
			// Create an ssl socket factory with our all-trusting manager
			final SSLSocketFactory sslSocketFactory = sslContext
					.getSocketFactory();

			HttpsURLConnection conn = (HttpsURLConnection) url.openConnection();
			conn.setSSLSocketFactory(sslSocketFactory);
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "application/json");
			conn.setRequestProperty("Authorization", authorization);
			String input = "{\"fields\": {\"project\":{ \"key\": \""
					+ projectKey + "\"},\"summary\": \"" + summary
					+ "\",\"description\": \"" + description
					+ "\",\"issuetype\": {\"name\": \"Story\"}}}";
			OutputStream os = conn.getOutputStream();
			os.write(input.getBytes());
			os.flush();
			if (conn.getResponseCode() != HttpURLConnection.HTTP_CREATED) {
				throw new RuntimeException("Failed : HTTP error code : "
						+ conn.getResponseCode());
			}
			BufferedReader br = new BufferedReader(new InputStreamReader(
					(conn.getInputStream())));

			String output;
			while ((output = br.readLine()) != null) {
				response.append(output);
			}
			conn.disconnect();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return response != null ? response.toString() : "";
	}

	public static Collection<String> getRemovedItems(Collection<String> oldList, Collection<String> newList) {
		List<String> list1 = new ArrayList<String>();
		list1.addAll(oldList);
		List<String> list2 = new ArrayList<String>();
		list2.addAll(newList);

		list1.removeAll(list2);
		return list1;
	}
	
	public static Collection<String> getAddedItems(Collection<String> oldList, Collection<String> newList) {
		List<String> list1 = new ArrayList<String>();
		list1.addAll(oldList);
		List<String> list2 = new ArrayList<String>();
		list2.addAll(newList);

		list2.removeAll(list1);
		return list2;
	}
}