package com.walmart.platform.soari.registry.biz.api;

import com.walmart.platform.kernel.exception.layers.business.BusinessException;

public interface CacheManager {
	public void refreshEnvCache() throws BusinessException;
	public void refreshCodeCache() throws BusinessException;
	public void refreshArtifactCache() throws BusinessException;
	public void refreshJIRACache() throws BusinessException;
}
