package com.walmart.platform.soari.registry.biz.api;

import com.walmart.platform.kernel.exception.layers.business.BusinessException;
import com.walmart.platform.soari.registry.common.enums.ReportType;

public interface DashboardManager {
	public String getReport(ReportType reportType) throws BusinessException;
}
