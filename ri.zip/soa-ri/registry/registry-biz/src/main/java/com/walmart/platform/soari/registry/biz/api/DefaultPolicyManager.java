package com.walmart.platform.soari.registry.biz.api;

import java.util.List;

import com.walmart.platform.kernel.exception.layers.business.BusinessException;
import com.walmart.platform.soari.registry.common.dto.DefaultPolicy;

public interface DefaultPolicyManager {
	
	/**
	 * Fetches all the policies
	 * 
	 * @return list of all policies
	 * @throws BusinessException
	 */
	List<DefaultPolicy> getPolicies() throws BusinessException;
	
	/**
	 * Fetches policy by id
	 * 
	 * @param id Identifier for DefaultPolicy being searched
	 * @return Matched policy or null
	 * @throws BusinessException
	 */
	DefaultPolicy getPolicyById(String id) throws BusinessException;
	
	/**
	 * Fetches policy by name
	 * 
	 * @param name Name for DefaultPolicy being searched
	 * @return Matched policy or null
	 * @throws BusinessException
	 */
	DefaultPolicy getPolicyByName(String name) throws BusinessException;
	
	/**
	 * Fetches list of policies by matching name 
	 * 
	 * @param searchName Name of the policy being searched for
	 * @param searchValue Matching criteria
	 * @return list of policies matching criteria
	 * @throws BusinessException
	 */
	List<DefaultPolicy> searchPolicies(String searchName, String searchValue) throws BusinessException;
	
	/**
	 * Creates a new policy, checks for duplicates
	 * 
	 * @param policy DefaultPolicy to be added
	 * @return Newly-added policy or null
	 * @throws BusinessException
	 */
	DefaultPolicy addPolicy(DefaultPolicy policy) throws BusinessException;
	
	/**
	 * Updates a policy 
	 * 
	 * @param policy DefaultPolicy to be updated
	 * @return updated/newly-created policy or null
	 * @throws BusinessException
	 */
	DefaultPolicy updatePolicy(DefaultPolicy policy) throws BusinessException;
	
	/**
	 * Updates policy status 
	 * 
	 * @param id Identifier for DefaultPolicy
	 * @param action [activate, deactivate, delete]
	 * @param actionBy 'modifiedBy' in Entity Table
	 * @return updated DefaultPolicy
	 * @throws BusinessException
	 */
	DefaultPolicy updatePolicyStatus(String id, String action, String actionBy)throws BusinessException;
}
