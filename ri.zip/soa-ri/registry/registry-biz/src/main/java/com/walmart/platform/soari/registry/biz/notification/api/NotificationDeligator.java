package com.walmart.platform.soari.registry.biz.notification.api;

import java.util.List;

import com.walmart.platform.kernel.exception.layers.business.BusinessException;
import com.walmart.platform.soari.registry.common.dto.Subscription;
import com.walmart.platform.soari.registry.common.enums.AuditType;
import com.walmart.platform.soari.registry.domain.AuditDO;
import com.walmart.platform.soari.registry.domain.ServiceDO;

public interface NotificationDeligator {
	public void notifySubscriptionCreated(String recipient, Subscription subscription) throws BusinessException;
	public void notifyServiceUpdate(ServiceDO service, List<AuditDO> audits, AuditType auditType) throws BusinessException;
	public void notifyServiceUpdate(ServiceDO service, AuditDO audit, AuditType auditType) throws BusinessException;
	public String createJiraTicket(String projectKey, Subscription subscription) throws BusinessException;
}
