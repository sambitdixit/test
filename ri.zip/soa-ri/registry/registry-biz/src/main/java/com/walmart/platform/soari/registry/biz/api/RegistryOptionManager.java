package com.walmart.platform.soari.registry.biz.api;

import java.util.List;

import com.walmart.platform.kernel.exception.layers.business.BusinessException;
import com.walmart.platform.soari.registry.common.dto.RegistryOption;
import com.walmart.platform.soari.registry.common.enums.RegistryPolicyCodeType;

public interface RegistryOptionManager {
	
	/**
	 * Fetches the list of RegistryOptions having type as 'type'
	 * 
	 * @param type RegistryPolicyCode's type
	 * @return list of matching RegistryOptions
	 * @throws BusinessException
	 */
	List<RegistryOption> getOptionsByType(RegistryPolicyCodeType type) throws BusinessException;
	
	/**
	 * Gets total no. of options present in RegistryPolicyCodeType
	 * 
	 * @return no. of Options
	 * @throws BusinessException
	 */
	Long getOptionCount() throws BusinessException;
}
