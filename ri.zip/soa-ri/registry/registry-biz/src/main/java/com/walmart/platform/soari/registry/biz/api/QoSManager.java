package com.walmart.platform.soari.registry.biz.api;

import java.util.List;

import com.walmart.platform.kernel.exception.layers.business.BusinessException;
import com.walmart.platform.soari.registry.common.dto.QoS;

public interface QoSManager {
	
	/**
	 * Fetches all existing qos
	 * 
	 * @return list of all existing QoS
	 * @throws BusinessException
	 */
	List<QoS> getQoS() throws BusinessException;
	
	/**
	 * Fetches a QoS by Id
	 * 
	 * @param id Identifier of the QoS being searched
	 * @return QoS matched by id or null
	 * @throws BusinessException
	 */
	QoS getQoSById(String id) throws BusinessException;
	
	/**
	 * Fetches a QoS by Name
	 * @param name Name of the QoS being serached
	 * @return QoS matched by name or null
	 * @throws BusinessException
	 */
	QoS getQoSByName(String name) throws BusinessException;
	
	/**
	 * Fetches list of QoS by matching name
	 *
	 * @param searchName Name of the QoS being searched
	 * @param searchValue Matching criteria
	 * @return list of QoS containing matching QoS
	 * @throws BusinessException
	 */
	List<QoS> searchQoS(String searchName, String searchValue) throws BusinessException;
	
	/**
	 * Creates a new QoS
	 * 
	 * @param qos QoS to be created
	 * @return newly created QoS
	 * @throws BusinessException
	 */
	QoS addQoS(QoS qos) throws BusinessException;
	
	/**
	 * Method to update an existing QoS. This will first checks if QoS exists.
	 * Also checks if other QoS has the same name, If QoS doesn't exists then
	 * create a new QoS
	 * 
	 * @param qos QoS to be updated
	 * @return updated/newly-created QoS
	 * @throws BusinessException
	 */
	QoS updateQoS(QoS qos) throws BusinessException;
	
	/**
	 * updates the status of QoS
	 * 
	 * @param id unique identifier for the QoS
	 * @param action [activate, deactivate, delete]
	 * @param actionBy 'modifiedBy' in Entity Table
	 * @return updated/newly-created QoS or null
	 * @throws BusinessException
	 */
	QoS updateQoSStatus(String id, String action, String actionBy) throws BusinessException;
}
