package com.walmart.platform.soari.registry.biz.mapper.impl;

import org.dozer.CustomConverter;
import org.dozer.MappingException;

import com.walmart.platform.soari.registry.biz.util.BizUtil;

public class CustomStringEnumMapperImpl implements CustomConverter{

	/**
	 * Converts/Maps source object to either string or enum 
	 * If not possible then throws MappingException
	 * 
	 * @param destination destination object , unused presently
	 * @param source source object to be converted
	 * @param sourceClass class for source
	 * @param destinationClass class for destination, has to be string or enum
	 */
	@Override
	public Object convert(Object destination, Object source, Class<?> destinationClass, Class<?> sourceClass) {
	    if(source == null) {
	        return null;
	    }
	    if(destinationClass != null){
	        if(destinationClass.getSimpleName().equalsIgnoreCase("String")){
	            return source.toString();
	        }else if( destinationClass.isEnum()){
	            return BizUtil.getEnum(destinationClass, source);
	        }else{
	            throw new MappingException(new StringBuilder("Converter ").append(this.getClass().getSimpleName())
	                       .append(" was used incorrectly. Arguments were: ")
	                       .append(destinationClass.getClass().getName())
	                       .append(" and ")
	                       .append(source).toString());
	        }
	    }
	    return null;
	}
}
