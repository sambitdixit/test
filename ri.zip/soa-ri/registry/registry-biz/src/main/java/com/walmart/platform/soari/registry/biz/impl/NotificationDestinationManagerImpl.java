
package com.walmart.platform.soari.registry.biz.impl;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.walmart.platform.kernel.exception.layers.business.BusinessException;
import com.walmart.platform.kernel.exception.layers.dao.DataAccessException;
import com.walmart.platform.soari.registry.biz.api.NotificationDestinationManager;
import com.walmart.platform.soari.registry.biz.mapper.api.DozerMapper;
import com.walmart.platform.soari.registry.biz.util.BizUtil;
import com.walmart.platform.soari.registry.common.dto.NotificationDestination;
import com.walmart.platform.soari.registry.common.enums.EntityType;
import com.walmart.platform.soari.registry.common.enums.RegistryPolicyCodeType;
import com.walmart.platform.soari.registry.common.enums.SearchFieldType;
import com.walmart.platform.soari.registry.domain.EntityDO;
import com.walmart.platform.soari.registry.domain.NotificationDestinationDO;
import com.walmart.platform.soari.registry.domain.AuditDO;
import com.walmart.platform.soari.registry.domain.RegistryPolicyCode;
import com.walmart.platform.soari.registry.domain.dao.api.NotificationDestinationDAO;
import com.walmart.platform.soari.registry.domain.dao.api.AuditDAO;
import com.walmart.platform.soari.registry.domain.dao.impl.RegistryPolicyCodeDAOImpl;
import com.walmart.platform.soari.registry.server.common.error.ErrorCode;
import com.walmart.platform.soari.registry.server.common.exception.ExceptionHandler;
import com.walmart.platform.soari.registry.server.common.exception.ServiceRegistryException;
import com.walmart.platform.soari.registry.server.common.util.CommonConstants;

/**
 * A class to perform business logic for mapping/transformation of DTO to Domain
 * objects and invoke Persistence APIs
 * 
 * @author sbonde
 * 
 */
@Service("notificationDestinationManager")
public class NotificationDestinationManagerImpl implements NotificationDestinationManager {

	private static final Logger LOG = LoggerFactory
			.getLogger(NotificationDestinationManagerImpl.class);

	@Autowired
	private NotificationDestinationDAO notificationDestinationDAO;

	@Autowired
	private DozerMapper mapper;

	@Autowired
	private ExceptionHandler exceptionHandler;

	@Autowired
	private AuditDAO auditDAO;

	@Override
	@Transactional(rollbackFor={BusinessException.class})
	public List<NotificationDestination> getNotificationDestinations() throws BusinessException {
		LOG.debug("Executing getNotificationDestinations ");
		List<NotificationDestination> notificationDestinations = new ArrayList<NotificationDestination>(0);
		try {
			List<NotificationDestinationDO> notificationDestinationDOs = notificationDestinationDAO.findAll();
			notificationDestinations = mapper.mapToList(notificationDestinationDOs, NotificationDestination.class);
		} catch (Exception ex) {
			LOG.error(MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE,
					ex.getMessage()));
			exceptionHandler.handleBusinessException(ex);
		}
		return notificationDestinations;
	}

	/**
	 * Method to get a NotificationDestination by Id
	 */
	@Override
	@Transactional(rollbackFor={BusinessException.class})
	public NotificationDestination getNotificationDestinationById(String id) throws BusinessException {
		LOG.debug("Executing getNotificationDestinationById for : " + id);
		NotificationDestination result = null;
		try {
			if (StringUtils.isEmpty(id)) {
				throw new ServiceRegistryException(
						ErrorCode.BIZ_INVALID_NOTIFICATION_DESTINATION_ID,
						CommonConstants.INVALID_NOTIFICATION_DESTINATION_ID);
			} else {
				NotificationDestinationDO notificationDestinationDO = notificationDestinationDAO.findOne(id);
				if (notificationDestinationDO != null) {
					result = mapper.map(notificationDestinationDO, NotificationDestination.class);
				}
			}
		} catch (Exception ex) {
			LOG.error(MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE,
					ex.getMessage()));
			exceptionHandler.handleBusinessException(ex);
		}
		return result;
	}

	/**
	 * Method to create a new NotificationDestination
	 */
	@Override
	@Transactional(rollbackFor={BusinessException.class})
	public NotificationDestination addNotificationDestination(NotificationDestination notificationDestination) throws BusinessException {
		LOG.debug("Executing addNotificationDestination " + notificationDestination.getName());
		NotificationDestination result = null;
		try {
			BizUtil.validateCreatedBy(EntityType.NOTIFICATION_DESTINATION, notificationDestination.getCreatedBy());
			validateNotificationName(notificationDestination.getName());
			if (isDuplicate(notificationDestination.getName(), null)) {
				throw new ServiceRegistryException(
						ErrorCode.BIZ_DUPLICATE_NOTIFICATION_DESTINATION, MessageFormat.format(
								CommonConstants.DUPLICATE_NOTIFICATION_DESTINATION_NAME,
								notificationDestination.getName()));
			} else {
				NotificationDestinationDO notificationDestinationDO = mapper.map(notificationDestination, NotificationDestinationDO.class);
				notificationDestinationDO = notificationDestinationDAO.save(notificationDestinationDO);
				audit(notificationDestinationDO);
				// TODO:Call for Notification about the change
				result = mapper.map(notificationDestinationDO, NotificationDestination.class);
			}
		} catch (Exception ex) {
			LOG.error(MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE,
					ex.getMessage()));
			exceptionHandler.handleBusinessException(ex);
		}
		return result;
	}

	/**
	 * Method to update an existing NotificationDestination. This will first checks if NotificationDestination
	 * exists. Also checks if other NotificationDestination has the same name, If NotificationDestination doesn't
	 * exists then create a new NotificationDestination
	 */
	@Override
	@Transactional(rollbackFor={BusinessException.class})
	public NotificationDestination updateNotificationDestination(NotificationDestination notificationDestination) throws BusinessException {
		String notificationDestinationId = notificationDestination.getId();
		LOG.debug("Executing updateNotificationDestination [id, name] : [" + notificationDestinationId + ","
				+ notificationDestination.getName() + "]");
		NotificationDestination result = null;
		try {
			validateNotificationName(notificationDestination.getName());
			if (isDuplicate(notificationDestination.getName(), notificationDestinationId)) {
				throw new ServiceRegistryException(
						ErrorCode.BIZ_DUPLICATE_NOTIFICATION_DESTINATION, MessageFormat.format(
								CommonConstants.DUPLICATE_NOTIFICATION_DESTINATION_NAME,
								notificationDestination.getName()));
			} else {
				NotificationDestinationDO notificationDestinationDO = null;
				if (!StringUtils.isEmpty(notificationDestinationId)) {
					notificationDestinationDO = notificationDestinationDAO.findOne(notificationDestinationId);
				}
				// NotificationDestination doesn't exists then create new NotificationDestination
				if (notificationDestinationDO == null) {
					BizUtil.validateCreatedBy(EntityType.NOTIFICATION_DESTINATION, notificationDestination.getCreatedBy());
					notificationDestinationDO = mapper.map(notificationDestination, NotificationDestinationDO.class);
					notificationDestinationDO = notificationDestinationDAO.save(notificationDestinationDO);
					audit(notificationDestinationDO);
					result = mapper.map(notificationDestinationDO, NotificationDestination.class);
					return result;
				}
				BizUtil.validateModifiedBy(EntityType.NOTIFICATION_DESTINATION, notificationDestination.getModifiedBy());
				List<AuditDO> audits = BizUtil
						.getAuditDetails(notificationDestination, notificationDestinationDO);
				if (!audits.isEmpty()) {
					mapper.map(notificationDestination, notificationDestinationDO);
					notificationDestinationDO = notificationDestinationDAO.save(notificationDestinationDO);
					auditDAO.save(audits);
					// TODO:Call for Notification about the change
				}
				result = mapper.map(notificationDestinationDO, NotificationDestination.class);
			}
		} catch (Exception ex) {
			LOG.error(MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE,
					ex.getMessage()));
			exceptionHandler.handleBusinessException(ex);
		}
		return result;
	}

	@Override
	@Transactional(rollbackFor={BusinessException.class})
	public NotificationDestination updateNotificationDestinationStatus(String id, String action, String actionBy)
			throws BusinessException {
		LOG.debug("Executing updateNotificationDestinationStatus for : " + id);
		NotificationDestination notificationDestination = null;
		try {
			NotificationDestinationDO notificationDestinationDO = notificationDestinationDAO.findOne(id);
			if (notificationDestinationDO == null) {
				throw new ServiceRegistryException(
						ErrorCode.BIZ_NOTIFICATION_DESTINATION_NOT_FOUND, MessageFormat.format(
								CommonConstants.NOTIFICATION_DESTINATION_NOT_FOUND,
								String.valueOf(id)));
			} else {
				String statusValue = BizUtil.toStatus(action);
				RegistryPolicyCode statusType = RegistryPolicyCodeDAOImpl.getCode(RegistryPolicyCodeType.STATUS, statusValue.toUpperCase());
				if (statusType == null) {
					throw new ServiceRegistryException(
							ErrorCode.BIZ_INVALID_STATUS_TYPE,
							MessageFormat.format(
									CommonConstants.INVALID_STATUS_TYPE,
									String.valueOf(id)));
				} else {
					if (statusType.getCode().equalsIgnoreCase(
							notificationDestinationDO.getStatus())) {
						throw new ServiceRegistryException(
								ErrorCode.BIZ_INVALID_ACTION_TYPE,
								MessageFormat
										.format(CommonConstants.INVALID_ACTION_TYPE,
												String.valueOf(id)));
					}
					BizUtil.validateModifiedBy(EntityType.NOTIFICATION_DESTINATION, actionBy);
					notificationDestinationDO.setStatus(statusType.getCode());
					notificationDestinationDO.setModifiedBy(actionBy);
					notificationDestinationDO = notificationDestinationDAO.save(notificationDestinationDO);
					auditStatus(notificationDestinationDO, statusValue);
					notificationDestination = mapper.map(notificationDestinationDO, NotificationDestination.class);
				}
			}
		} catch (Exception ex) {
			LOG.error(MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE,
					ex.getMessage()));
			exceptionHandler.handleBusinessException(ex);
		}
		return notificationDestination;
	}

	/**
	 * Method to fetch NotificationDestination by name
	 */
	@Override
	@Transactional(rollbackFor={BusinessException.class})
	public NotificationDestination getNotificationDestinationByName(String name) throws BusinessException {
		LOG.debug("Executing getNotificationDestinationByName for : " + name);
		NotificationDestination result = null;
		try {
			List<NotificationDestinationDO> notificationDestinationDOs = notificationDestinationDAO.findByName(name);
			if (notificationDestinationDOs != null && !notificationDestinationDOs.isEmpty()) {
				result = mapper.map(notificationDestinationDOs.get(0), NotificationDestination.class);
			}
		} catch (Exception ex) {
			LOG.error(MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE,
					ex.getMessage()));
			exceptionHandler.handleBusinessException(ex);
		}
		return result;
	}

	/**
	 * Method to fetch NotificationDestinations by matching name
	 */
	@Override
	@Transactional(rollbackFor={BusinessException.class})
	public List<NotificationDestination> searchNotificationDestinations(String searchName, String searchValue)
			throws BusinessException {
		LOG.debug("Executing searchNotificationDestinations for : " + searchName);
		List<NotificationDestination> result = new ArrayList<NotificationDestination>(0);
		List<NotificationDestinationDO> notificationDestinationDOs = null;
		try {
			if (StringUtils.isEmpty(searchName)) {
				notificationDestinationDOs = notificationDestinationDAO.findAll();
			}

			else {
				if (!BizUtil.isValidNotificationDestinationSearchOption(searchName)) {
					throw new ServiceRegistryException(
							ErrorCode.BIZ_INVALID_SEARCH_NAME,
							CommonConstants.INVALID_SEARCH_NAME);
				}
				if (SearchFieldType.STATUS.toString().equalsIgnoreCase(
						searchName)) {
					List<String> statusTypes = BizUtil
							.getStatusCriteria(searchValue);
					notificationDestinationDOs = notificationDestinationDAO.findByStatus(statusTypes);
				} else if (SearchFieldType.NAME.toString().equalsIgnoreCase(
						searchName)) {
					notificationDestinationDOs = notificationDestinationDAO.findByMatchingName(searchValue);
				}
			}
			if (notificationDestinationDOs != null && !notificationDestinationDOs.isEmpty()) {
				result = mapper.mapToList(notificationDestinationDOs, NotificationDestination.class);
			}
		} catch (Exception ex) {
			LOG.error(MessageFormat.format(CommonConstants.EXCEPTION_MESSAGE,
					ex.getMessage()));
			exceptionHandler.handleBusinessException(ex);
		}
		return result;
	}

	/**
	 * This method checks if other NotificationDestination already exists with the same name
	 * 
	 * @param notificationDestinationName
	 * @param id
	 *            (to be pass null in case of ADD use case)
	 * @return
	 * @throws Exception
	 */
	private boolean isDuplicate(String notificationDestinationName, String id)
			throws DataAccessException {
		List<NotificationDestinationDO> existingNotificationDestinations = notificationDestinationDAO.findByName(notificationDestinationName);
		if (existingNotificationDestinations != null && !existingNotificationDestinations.isEmpty()) {
			// If id == null means it is update else it is add NotificationDestination use case
			if (id != null) {
				for (NotificationDestinationDO notificationDestinationDO : existingNotificationDestinations) {
					if (!notificationDestinationDO.getId().equals(id)) {
						return true;
					}
				}
			} else {
				return true;
			}
		}
		return false;
	}

	/**
	 * NOTE : removed throws ServiceRegistryException since it is unchecked exception
	 * @param name
	 */
	private void validateNotificationName(String name) {
		if(StringUtils.isEmpty(name)) {
			throw new ServiceRegistryException(ErrorCode.BIZ_INVALID_NOTIFICATION_DESTINATION_NAME,
					MessageFormat.format(CommonConstants.INVALID_NOTIFICATION_DESTINATION_NAME,
							name));
		}
	}

	private void audit(NotificationDestinationDO notificationDestination)
			throws DataAccessException {
		AuditDO audit = BizUtil.getAddAudit(notificationDestination);
		auditDAO.save(audit);
	}
	private void auditStatus(EntityDO entity, String oldValue)
			throws DataAccessException {
		AuditDO audit = BizUtil.getStatusAudit(entity, oldValue);
		auditDAO.save(audit);
	}
}
