package com.walmart.platform.soari.registry.biz.api;

import java.util.List;

import com.walmart.platform.kernel.exception.layers.business.BusinessException;
import com.walmart.platform.soari.registry.common.dto.Consumer;
import com.walmart.platform.soari.registry.common.dto.ServiceSearchBean;
import com.walmart.platform.soari.registry.common.dto.Subscription;
import com.walmart.platform.soari.registry.common.dto.SubscriptionRequest;

public interface ConsumerManager {
	
	/**
	 * Fetch all the consumers
	 * 
	 * @return list of all consumers
	 * @throws BusinessException
	 */
	List<Consumer> getConsumers() throws BusinessException;
	
	/**
	 * Fetches a consumer by Id
	 * 
	 * @param id Identifier for consumer
	 * @return matching consumer or null
	 * @throws BusinessException
	 */
	Consumer getById(String id) throws BusinessException;
	
	/**
	 * Creates a new consumer, checks for duplicates too
	 * 
	 * @param consumer New consumer to be added
	 * @return Newly added consumer or null
	 * @throws BusinessException
	 */
	Consumer addConsumer(Consumer consumer) throws BusinessException;
	
	/**
	 * Method to update an existing Consumer. This will first checks if Consumer
	 * exists. Also checks if other Consumer has the same name, If Consumer doesn't
	 * exists then create a new Consumer
	 * 
	 * @param consumer
	 * @return updated consumer or null
	 * @throws BusinessException
	 */
	Consumer updateConsumer(Consumer consumer) throws BusinessException;
	
	/**
	 * Updates status of consumer identified by Consumer
	 * 
	 * @param id Identifier for Consumer
	 * @param action [activate, deactivate, delete]
	 * @param actionBy 'modifiedBy' in Entity Table
	 * @return updated/newly created consumer or null 
	 * @throws BusinessException
	 */
	Consumer updateConsumerStatus(String id, String action, String actionBy)throws BusinessException;
	
	/**
	 * Updates the subscription
	 * 
	 * @param subscription Subscription object
	 * @return updated/newly-created subscription or null
	 * @throws BusinessException
	 */
	Subscription updateSubscription(SubscriptionRequest subscription) throws BusinessException;
	
	/**
	 * Fetches list of all subscriptions for consumer matching 'search'
	 * 
	 * @param search 
	 * @return list of all subscriptions for the consumer
	 * @throws BusinessException
	 */
	List<Subscription> searchConsumerSubscriptions(ServiceSearchBean search) throws BusinessException;
	
	/**
	 * Creates the subscription for the consumer identified by 'consumerId'
	 * 
	 * @param consumerId Identifier for consumer
	 * @param subscriptions Subscription to be added
	 * @return Added subscription or null
	 * @throws BusinessException
	 */
	Subscription addSubscription(String consumerId, SubscriptionRequest subscription)throws BusinessException;
	
	/**
	 * Fetches list of all subscription belonging to consumer identified by 'consumerId'
	 * 
	 * @param consumerId Identifier for consumer
	 * @return list of all subscriptions
	 * @throws BusinessException
	 */
	List<Subscription> getSubscriptions(String consumerId) throws BusinessException;
	
	/**
	 * Updates status of subscription 
	 * 
	 * @param subscriptionId Identifier for subscription
	 * @param action [activate, deactivate, delete]
	 * @param actionBy 'modifiedBy' in Entity Table
	 * @return updated subscription
	 * @throws BusinessException
	 */
	Subscription updateSubscriptionStatus(String subscriptionId, String action, String actionBy)throws BusinessException;
	
	/**
	 * Removes Subscription identified by 'subscriptionId'
	 * 
	 * @param subscriptionId Identifier for subscription
	 * @param actionBy 'modifiedBy' in Entity Table
	 * @throws BusinessException
	 */
	void deleteSubscription(String subscriptionId, String actionBy)throws BusinessException;
}
