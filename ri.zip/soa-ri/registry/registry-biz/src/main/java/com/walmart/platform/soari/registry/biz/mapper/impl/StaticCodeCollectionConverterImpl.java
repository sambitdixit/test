package com.walmart.platform.soari.registry.biz.mapper.impl;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import org.dozer.DozerConverter;
import org.dozer.MappingException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.walmart.platform.soari.registry.biz.util.BizUtil;
import com.walmart.platform.soari.registry.domain.RegistryPolicyCode;
import com.walmart.platform.soari.registry.domain.dao.api.NotificationDestinationDAO;

@SuppressWarnings("rawtypes")
@Service("staticCodeCollectionConverter")
public class StaticCodeCollectionConverterImpl extends
		DozerConverter<Collection, Collection> {

	private static final Logger LOG = LoggerFactory
			.getLogger(StaticCodeCollectionConverterImpl.class);

	@Autowired
	private NotificationDestinationDAO notificationDestinationDAO;

	public StaticCodeCollectionConverterImpl() {
		super(Collection.class, Collection.class);
	}

	/**
	 * Converts source collection to destination collection
	 * NOTE: ambiguous java doc, need to edited
	 * 
	 * @param source
	 * @param destination
	 * @return
	 */
	@Override
	public synchronized Collection convertTo(Collection source, Collection destination) {
		return convert(source, destination);
	}

	/**
	 * Converts from source collection to destination collection
	 * NOTE: ambiguous java doc, need to edited
	 * 
	 * @param source
	 * @param destination
	 * @return
	 */
	@Override
	public synchronized Collection convertFrom(Collection source, Collection destination) {
		return convert(source, destination);
	}
	
	/**
	 * Converts source to destination
	 * NOTE: in-complete java doc, need to edited
	 * 
	 * @param source
	 * @param destination
	 * @return
	 */
	private Collection convert(Collection source, Collection destination) {
		Set<Object> result = new HashSet<Object>(0);
		String field = getParameter();
		try {
			if (source == null) {
				return null;
			}
			for (Object o : source) {
				if (o.getClass().getSimpleName()
						.equals(String.class.getSimpleName())) {
					String registryPolicyCode = BizUtil.convertFrom(field, o.toString(), null);
					if (registryPolicyCode != null) {
						result.add(registryPolicyCode);
					}
				} else if (o instanceof RegistryPolicyCode) {
					result.add(((RegistryPolicyCode) o).getCode());
				} 
			}
		} catch (Exception ex) {
			LOG.error("Error while coverting collection"+ex.getMessage());
			LOG.error("with stack trace", ex);
			//throw new MappingException(MessageFormat.format("Failed to map {0} for :{1}", field, source));
			throw new MappingException(ex.getMessage());
		}
		return result;
	}
	/*private Collection convert(Collection source, Collection destination) {
		Set<Object> result = new HashSet<Object>(0);
		try {
			if (source == null) {
				return null;
			}
			for (Object o : source) {
				if (o.getClass().getSimpleName()
						.equals(String.class.getSimpleName())) {
					String field = getParameter();
					if("NOTIFICATION_DESTINATION".equalsIgnoreCase(field)) {
						List<NotificationDestinationDO> notificationDestinations = notificationDestinationDAO.findByName(o.toString());
						if(notificationDestinations != null && !notificationDestinations.isEmpty()) {
							result.add(notificationDestinations.get(0));
						}
					} else {
						String registryPolicyCode = BizUtil.convertFrom(field, o.toString(), null);
						if (registryPolicyCode != null) {
							result.add(registryPolicyCode);
						}
					}
				} else if (o instanceof RegistryPolicyCode) {
					result.add(((RegistryPolicyCode) o).getCode());
				}  else if (o instanceof NotificationDestinationDO) {
					result.add(((NotificationDestinationDO) o).getName());
				} 
			}
		} catch (Exception ex) {
			LOG.error("Error while coverting collection"+ex.getMessage());
			LOG.error("with stack trace", ex);
			throw new MappingException(MessageFormat.format("Failed to map {0}", source));
		}
		return result;
	}*/

}
