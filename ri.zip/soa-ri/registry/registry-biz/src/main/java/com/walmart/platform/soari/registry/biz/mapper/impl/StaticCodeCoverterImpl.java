package com.walmart.platform.soari.registry.biz.mapper.impl;

import java.text.MessageFormat;

import org.apache.commons.lang.StringUtils;
import org.dozer.DozerConverter;
import org.dozer.MappingException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.walmart.platform.kernel.exception.layers.dao.DataAccessException;
import com.walmart.platform.soari.registry.biz.util.BizUtil;

@Service("staticCodeConverter")
public class StaticCodeCoverterImpl extends
		DozerConverter<String, String> {
	
	private static final Logger LOG = LoggerFactory.getLogger(StaticCodeCoverterImpl.class);

	/**
	 * no-arg constructor
	 */
	public StaticCodeCoverterImpl() {
		super(String.class, String.class);
	}

	/**
	 * Returns code for RegistryPolicyCode source if not null
	 * otherwise returns null
	 * 
	 * @param source RegistryPolicyCode being converted
	 * @param destination
	 */
	@Override
	public synchronized String convertTo(String source, String destination) {
		return source;
	}
	
	/**
	 * Converts 'source' to corresponding RegistryPolicyCode 
	 * 
	 * @param source
	 * @param destination
	 */
	@Override
	public synchronized String convertFrom(String source,
			String destination) {
		String result = null;
		try {
			String fieldName = getParameter();
			if(StringUtils.isEmpty(source)) {
				return null;
			}
			result = BizUtil.convertFrom(fieldName, source, destination);
			
		} catch (DataAccessException ex) {
			LOG.error("Error while covertin RegistryPolicyCode"+ex.getMessage());
			LOG.error("with stack trace", ex);
			throw new MappingException(MessageFormat.format("Failed to map {0}", source));
		}
		return result;
	}

}
