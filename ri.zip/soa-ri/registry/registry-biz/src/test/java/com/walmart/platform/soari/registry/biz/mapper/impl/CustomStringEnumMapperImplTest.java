package com.walmart.platform.soari.registry.biz.mapper.impl;


import org.dozer.CustomConverter;
import org.dozer.MappingException;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.walmart.platform.soari.registry.common.enums.UrlType;

public class CustomStringEnumMapperImplTest {

	@InjectMocks CustomConverter customConverter = new CustomStringEnumMapperImpl();
	
	@BeforeMethod(alwaysRun=true)  
	public void init() throws Exception {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test(enabled = true)
	public void testConvertSourceNull() {
		Object result = customConverter.convert(UrlType.CONTRACT.toString(), null, String.class, UrlType.class);
		Assert.assertEquals(null, result);
	}
	
	@Test(enabled = true)
	public void testConvertDestinationClassNull() {
		Object result = customConverter.convert(UrlType.CONTRACT.toString(),  UrlType.CONTRACT, null, UrlType.class);
		Assert.assertEquals(null, result);
	}
	
	@Test(enabled = true)
	public void testConvertStringToEnum() {
		Object result = customConverter.convert(null, UrlType.CONTRACT.toString(), UrlType.class, String.class);
		Assert.assertEquals(UrlType.CONTRACT.toString(), result.toString());
	}
	
	@Test(enabled = true)
	public void testConvertEnumToString() {
		Object result = customConverter.convert(null, UrlType.CONTRACT, String.class, UrlType.class);
		Assert.assertEquals(UrlType.CONTRACT.toString(), result.toString());
	}
	
	@SuppressWarnings("unused")
	@Test(enabled = true, expectedExceptions = {MappingException.class})
	public void testConvertHandleException() {
		Object result = customConverter.convert(null, UrlType.CONTRACT, StringBuffer.class, UrlType.class);
		Assert.fail("Invalid Destination class");
	}
	
}
