package com.walmart.platform.soari.registry.biz.impl;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import org.mockito.MockitoAnnotations;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.walmart.platform.soa.config.RegistryConfig;
import com.walmart.platform.soari.registry.biz.api.PolicyManager;
import com.walmart.platform.soari.registry.biz.mapper.api.DozerMapper;

import com.walmart.platform.soari.registry.common.dto.Policy;
import com.walmart.platform.soari.registry.common.enums.SearchFieldType;
import com.walmart.platform.soari.registry.domain.PolicyDO;
import com.walmart.platform.soari.registry.domain.AuditDO;
import com.walmart.platform.soari.registry.domain.dao.api.PolicyDAO;
import com.walmart.platform.soari.registry.domain.dao.api.AuditDAO;
import com.walmart.platform.soari.registry.server.common.exception.ExceptionHandler;
import com.walmart.platform.soari.registry.server.common.exception.ServiceRegistryException;

public class PolicyManagerImplTest extends AbstractBusinessTest {

	@Mock private PolicyDAO policyDAO;
	@Mock private DozerMapper mapper;
	@Mock private ExceptionHandler exceptionHandler;
	@Mock private AuditDAO auditDAO;
	@Mock private RegistryConfig registryConfig;
	@InjectMocks private PolicyManager policyManager = new PolicyManagerImpl();
	
	@BeforeMethod(alwaysRun=true)  
	public void init() throws Exception {
		MockitoAnnotations.initMocks(this);
		when(policyDO.getName()).thenReturn(TEST_POLICY_NAME);
		when(policyDO.getId()).thenReturn(TEST_POLICY_ID);
		when(policy.getName()).thenReturn(TEST_POLICY_NAME);
		when(policy.getCreatedBy()).thenReturn("Test");
		when(policy.getModifiedBy()).thenReturn("Test");
		when(policy.getData()).thenReturn(getSamplePolicyData());
		when(policy.getId()).thenReturn(TEST_POLICY_ID);
		when(mapper.mapToList(policyDOs, PolicyDO.class)).thenReturn(policyDOs);
		Mockito.doNothing().when(mapper).map(Matchers.anyListOf(PolicyDO.class), Matchers.anyListOf(Policy.class));
		when(mapper.mapToList(policies, Policy.class)).thenReturn(policies);
		Mockito.doNothing().when(mapper).map(Matchers.anyListOf(Policy.class), Matchers.anyListOf(PolicyDO.class));
		when(mapper.map(policy, PolicyDO.class)).thenReturn(policyDO);
		when(mapper.map(policyDO, Policy.class)).thenReturn(policy);
		Mockito.doNothing().when(exceptionHandler).handleBusinessException(Matchers.any(Exception.class));
		when(exception.getMessage()).thenReturn(TEST_EXCEPTION_MESSAGE);
		when(auditDAO.save((AuditDO)Matchers.anyObject())).thenReturn(auditDO);
		when(auditDAO.save(Matchers.anyListOf(AuditDO.class))).thenReturn(audits);
		when(audits.isEmpty()).thenReturn(false);
//		when(registryPolicyCodeDAO.findCode(Matchers.any(RegistryPolicyCodeType.class), Matchers.anyString())).thenReturn(status);
	}

	@Test(enabled = true)
	public void testGetPolicyById() throws Exception {
		when(policyDAO.findOne(TEST_POLICY_ID)).thenReturn(policyDO);
		policyManager.getPolicyById(TEST_POLICY_ID);
		verify(mapper, times(1)).map(policyDO, Policy.class);
		verify(exceptionHandler, never()).handleBusinessException(exception);
	}
	
	@Test(enabled = true)
	public void testGetPolicyByIdNull() throws Exception {
		when(policyDAO.findOne(TEST_POLICY_ID)).thenReturn(policyDO);
		policyManager.getPolicyById(null);
		verify(mapper, never()).map(policyDO, Policy.class);
		verify(exceptionHandler, times(1)).handleBusinessException((ServiceRegistryException)Matchers.any());
	}
	
	@Test(enabled = true)
	public void testGetPolicyByIdHandleException() throws Exception {
		when(policyDAO.findOne(TEST_POLICY_ID)).thenThrow(exception);
		policyManager.getPolicyById(TEST_POLICY_ID);
		verify(mapper, never()).map(policyDO, Policy.class);
		verify(exceptionHandler, times(1)).handleBusinessException(exception);
	}

	@Test
	public void testAddPolicy() throws Exception {
		PolicyDO newPolicyDO = new PolicyDO();
		newPolicyDO.setId(TEST_POLICY_ID);
		List<PolicyDO> policyDOs = new ArrayList<PolicyDO>(0);
		//policyDOs.add(newPolicyDO);
		when(policyDAO.findByName(Matchers.anyString())).thenReturn(policyDOs);
		when(policyDAO.save(policyDO)).thenReturn(policyDO);
		policyManager.addPolicy(policy);
		verify(policyDAO, times(1)).findByName(Matchers.anyString());
		verify(mapper, times(1)).map(policyDO, Policy.class);
		verify(mapper, times(1)).map(policy, PolicyDO.class);
		verify(exceptionHandler, never()).handleBusinessException(exception);
	}
	
	@Test
	public void testAddPolicyCheckDuplicate() throws Exception {
		PolicyDO newPolicyDO = new PolicyDO();
		newPolicyDO.setId(TEST_POLICY_ID);
		List<PolicyDO> policyDOs = new ArrayList<PolicyDO>(0);
		policyDOs.add(newPolicyDO);
		when(policyDAO.findByName(Matchers.anyString())).thenReturn(policyDOs);
		when(policyDAO.save(policyDO)).thenReturn(policyDO);
		policyManager.addPolicy(policy);
		verify(policyDAO, times(1)).findByName(Matchers.anyString());
		verify(mapper, never()).map(policyDO, Policy.class);
		verify(mapper, never()).map(policy, PolicyDO.class);
		verify(exceptionHandler, times(1)).handleBusinessException((ServiceRegistryException)Matchers.any());
	}
	
	@Test
	public void testAddPolicyHandleException() throws Exception {
		when(policyDAO.findByName(Matchers.anyString())).thenReturn(new ArrayList<PolicyDO>(0));
		when(policyDAO.save(policyDO)).thenThrow(exception);
		policyManager.addPolicy(policy);
		verify(policyDAO, times(1)).findByName(Matchers.anyString());
		verify(mapper, times(1)).map(policy, PolicyDO.class);
		verify(mapper, never()).map(policyDO, Policy.class);
		verify(exceptionHandler, times(1)).handleBusinessException(exception);
	}
	
	@Test
	public void testUpdatePolicyAddIfMissing() throws Exception {
		PolicyDO newPolicyDO = new PolicyDO();
		newPolicyDO.setId(TEST_POLICY_ID);
		List<PolicyDO> policyDOs = new ArrayList<PolicyDO>(0);
		policyDOs.add(newPolicyDO);
		when(policyDAO.save(policyDO)).thenReturn(policyDO);
		when(policyDAO.findByName(Matchers.anyString())).thenReturn(policyDOs);
		policyManager.updatePolicy(policy);
		verify(policyDAO, times(1)).findByName(Matchers.anyString());
		verify(mapper, times(1)).map(policy, PolicyDO.class);
		verify(mapper, times(1)).map(policyDO, Policy.class);
		verify(policyDAO, times(1)).save(policyDO);
		verify(exceptionHandler, never()).handleBusinessException(Matchers.any(ServiceRegistryException.class));
	}
	
	@Test
	public void testUpdatePolicyAddIfMissingNullId() throws Exception {
		when(policy.getId()).thenReturn(null);
		PolicyDO newPolicyDO = new PolicyDO();
		newPolicyDO.setId(TEST_POLICY_ID);
		List<PolicyDO> policyDOs = new ArrayList<PolicyDO>(0);
		policyDOs.add(newPolicyDO);
		when(policyDAO.save(policyDO)).thenReturn(policyDO);
		when(policyDAO.findByName(Matchers.anyString())).thenReturn(null);
		policyManager.updatePolicy(policy);
		verify(policyDAO, times(1)).findByName(Matchers.anyString());
		verify(mapper, times(1)).map(policy, PolicyDO.class);
		verify(mapper, times(1)).map(policyDO, Policy.class);
		verify(policyDAO, times(1)).save(policyDO);
		verify(exceptionHandler, never()).handleBusinessException(Matchers.any(ServiceRegistryException.class));
	}
	
	@Test
	public void testUpdatePolicyAddIfMissingNoExiting() throws Exception {
		when(policy.getId()).thenReturn(null);
		PolicyDO newPolicyDO = new PolicyDO();
		newPolicyDO.setId(TEST_POLICY_ID);
		List<PolicyDO> policyDOs = new ArrayList<PolicyDO>(0);
		policyDOs.add(newPolicyDO);
		when(policyDAO.save(policyDO)).thenReturn(policyDO);
		when(policyDAO.findByName(Matchers.anyString())).thenReturn(new ArrayList<PolicyDO>(0));
		policyManager.updatePolicy(policy);
		verify(policyDAO, times(1)).findByName(Matchers.anyString());
		verify(mapper, times(1)).map(policy, PolicyDO.class);
		verify(mapper, times(1)).map(policyDO, Policy.class);
		verify(policyDAO, times(1)).save(policyDO);
		verify(exceptionHandler, never()).handleBusinessException(Matchers.any(ServiceRegistryException.class));
	}
	
	@Test
	public void testUpdatePolicyDuplicate() throws Exception {
		PolicyDO newPolicyDO = new PolicyDO();
		//Different ID to have duplicate Policy
		newPolicyDO.setId(TEST_POLICY_ID+"_2");
		List<PolicyDO> policyDOs = new ArrayList<PolicyDO>(0);
		policyDOs.add(newPolicyDO);
		when(policyDAO.save(policyDO)).thenReturn(policyDO);
		when(policyDAO.findByName(Matchers.anyString())).thenReturn(policyDOs);
		policyManager.updatePolicy(policy);
		verify(policyDAO, times(1)).findByName(Matchers.anyString());
		verify(mapper, never()).map(policy, PolicyDO.class);
		verify(mapper, never()).map(policyDO, Policy.class);
		verify(policyDAO, never()).save(policyDO);
		verify(exceptionHandler, times(1)).handleBusinessException(Matchers.any(ServiceRegistryException.class));
	}
	
	@Test
	public void testUpdatePolicyHandleExceptionWhileAdd() throws Exception {
		PolicyDO newPolicyDO = new PolicyDO();
		//Different ID to have duplicate Policy
		newPolicyDO.setId(TEST_POLICY_ID);
		List<PolicyDO> policyDOs = new ArrayList<PolicyDO>(0);
		policyDOs.add(newPolicyDO);
		when(policyDAO.findOne(TEST_POLICY_ID)).thenReturn(null);
		when(policyDAO.save(policyDO)).thenThrow(exception);
		when(policyDAO.findByName(Matchers.anyString())).thenReturn(policyDOs);
		policyManager.updatePolicy(policy);
		verify(policyDAO, times(1)).findByName(Matchers.anyString());
		verify(mapper, times(1)).map(policy, PolicyDO.class);
		verify(mapper, never()).map(policyDO, Policy.class);
		verify(policyDAO, times(1)).save(policyDO);
		verify(exceptionHandler, times(1)).handleBusinessException(exception);
	}
	
	@Test
	public void testUpdatePolicy() throws Exception {
		PolicyDO newPolicyDO = new PolicyDO();
		//Same Policy ID so that no other Policy with same name exists
		when(policy.getName()).thenReturn("OLD_NAME");
		when(policyDO.getName()).thenReturn("NEW_NAME");
		newPolicyDO.setId(TEST_POLICY_ID);
		List<PolicyDO> policyDOs = new ArrayList<PolicyDO>(0);
		policyDOs.add(newPolicyDO);
		when(policyDAO.findOne(TEST_POLICY_ID)).thenReturn(policyDO);
		when(policyDAO.save(policyDO)).thenReturn(policyDO);
		when(policyDAO.findByName(Matchers.anyString())).thenReturn(policyDOs);
		when(registryConfig.isNotificationEnabled()).thenReturn("false");
		policyManager.updatePolicy(policy);
		verify(policyDAO, times(1)).findByName(Matchers.anyString());
		verify(policyDAO, times(1)).save(policyDO);
		verify(mapper, times(1)).map(policyDO, Policy.class);
		verify(auditDAO, times(1)).save(Matchers.anyCollectionOf(AuditDO.class));
		verify(exceptionHandler, never()).handleBusinessException(exception);
	}
	
	@Test
	public void testUpdatePolicyNoUpdate() throws Exception {
		PolicyDO newPolicyDO = new PolicyDO();
		//Same Policy ID so that no other Policy with same name exists
		when(policy.getName()).thenReturn("NEW_NAME");
		when(policyDO.getName()).thenReturn("NEW_NAME");
		when(policyDO.getData()).thenReturn(getSamplePolicyData());
		newPolicyDO.setId(TEST_POLICY_ID);
		List<PolicyDO> policyDOs = new ArrayList<PolicyDO>(0);
		policyDOs.add(newPolicyDO);
		when(policyDAO.findOne(TEST_POLICY_ID)).thenReturn(policyDO);
		when(policyDAO.save(policyDO)).thenReturn(policyDO);
		when(policyDAO.findByName(Matchers.anyString())).thenReturn(policyDOs);
		when(registryConfig.isNotificationEnabled()).thenReturn("false");
		policyManager.updatePolicy(policy);
		verify(policyDAO, times(1)).findByName(Matchers.anyString());
		verify(policyDAO, never()).save(policyDO);
		verify(mapper, never()).map(policyDO, Policy.class);
		verify(mapper, never()).map(policy, policyDO);
		verify(auditDAO, never()).save(Matchers.anyCollectionOf(AuditDO.class));
		verify(exceptionHandler, never()).handleBusinessException(exception);
	}
	
	@Test
	public void testUpdatePolicyHandleException() throws Exception {
		PolicyDO newPolicyDO = new PolicyDO();
		//Same Policy ID so that no other Policy with same name exists
		newPolicyDO.setId(TEST_POLICY_ID);
		when(policy.getName()).thenReturn("OLD_NAME");
		when(policyDO.getName()).thenReturn("NEW_NAME");
		List<PolicyDO> policyDOs = new ArrayList<PolicyDO>(0);
		policyDOs.add(newPolicyDO);
		when(policyDAO.findOne(TEST_POLICY_ID)).thenReturn(policyDO);
		when(policyDAO.save(policyDO)).thenThrow(exception);
		when(policyDAO.findByName(Matchers.anyString())).thenReturn(policyDOs);
		policyManager.updatePolicy(policy);
		verify(policyDAO, times(1)).findByName(Matchers.anyString());
		verify(policyDAO, times(1)).save(policyDO);
		verify(mapper, never()).map(policyDO, Policy.class);
		verify(auditDAO, never()).save(audits);
		verify(exceptionHandler, times(1)).handleBusinessException(exception);
	}
	
	@Test(enabled = true)
	public void testGetPolicyByName() throws Exception {
		List<PolicyDO> policyDOList = new ArrayList<PolicyDO>(0);
		policyDOList.add(policyDO);
		when(policyDAO.findByName(TEST_POLICY_NAME)).thenReturn(policyDOList);
		policyManager.getPolicyByName(TEST_POLICY_NAME);
		verify(mapper, times(1)).map(policyDO, Policy.class);
		verify(policyDAO, times(1)).findByName(TEST_POLICY_NAME);
		verify(exceptionHandler, never()).handleBusinessException(exception);
	}
	
	@Test(enabled = true)
	public void testGetPolicyByNameNullList() throws Exception {
		when(policyDAO.findByName(TEST_POLICY_NAME)).thenReturn(null);
		policyManager.getPolicyByName(TEST_POLICY_NAME);
		verify(mapper, never()).map(policyDO, Policy.class);
		verify(policyDAO, times(1)).findByName(TEST_POLICY_NAME);
		verify(exceptionHandler, never()).handleBusinessException(exception);
	}
	
	@Test(enabled = true)
	public void testGetPolicyByNameEmptyList() throws Exception {
		when(policyDAO.findByName(TEST_POLICY_NAME)).thenReturn(new ArrayList<PolicyDO>(0));
		policyManager.getPolicyByName(TEST_POLICY_NAME);
		verify(mapper, never()).map(policyDO, Policy.class);
		verify(policyDAO, times(1)).findByName(TEST_POLICY_NAME);
		verify(exceptionHandler, never()).handleBusinessException(exception);
	}
	
	@Test(enabled = true)
	public void testGetPolicyByNameHandleException() throws Exception {
		Exception ex = Mockito.mock(IllegalArgumentException.class);
		when(policyDAO.findByName(TEST_POLICY_NAME)).thenThrow(ex);
		policyManager.getPolicyByName(TEST_POLICY_NAME);
		verify(mapper, never()).map(policyDO, Policy.class);
		verify(policyDAO, times(1)).findByName(TEST_POLICY_NAME);
		verify(exceptionHandler, times(1)).handleBusinessException(ex);
	}
	@Test
	public void testSearchPoliciesByName() throws Exception {
		when(policyDAO.findByMatchingName(Matchers.anyString())).thenReturn(policyDOs);
		policyManager.searchPolicies(SearchFieldType.NAME.toString(), "xyz");
		verify(policyDAO, times(1)).findByMatchingName(Matchers.anyString());
		verify(mapper).mapToList(policyDOs, Policy.class);
		verify(exceptionHandler, never()).handleBusinessException(exception);
	}
	
	@Test
	public void testSearchPoliciesByNameHandleException() throws Exception {
		when(policyDAO.findByMatchingName(Matchers.anyString())).thenThrow(exception);
		policyManager.searchPolicies(SearchFieldType.NAME.toString(), "xyz");
		verify(policyDAO, times(1)).findByMatchingName(Matchers.anyString());
		verify(mapper, never()).mapToList(policyDOs, Policy.class);
		verify(exceptionHandler, times(1)).handleBusinessException(exception);
	}
}
