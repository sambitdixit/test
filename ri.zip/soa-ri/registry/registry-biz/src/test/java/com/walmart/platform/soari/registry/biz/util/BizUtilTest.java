package com.walmart.platform.soari.registry.biz.util;

import java.io.Serializable;


import org.dozer.MappingException;
import org.mockito.MockitoAnnotations;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.walmart.platform.soari.registry.biz.impl.AbstractBusinessTest;
import com.walmart.platform.soari.registry.common.enums.StatusType;

public class BizUtilTest  extends AbstractBusinessTest {

	@BeforeMethod(alwaysRun=true)  
	public void init() throws Exception {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test(enabled = true)
	public void tesGetEnum() throws Exception {
		Object actual = BizUtil.getEnum(StatusType.class, StatusType.ACTIVE.toString());
		Assert.assertEquals(StatusType.ACTIVE, actual);
	}
	
	//@Test(enabled = true, expectedExceptions = {MappingException.class})
	public void tesGetEnumException() throws Exception {
		BizUtil.getEnum(String.class, StatusType.ACTIVE.toString());
	}
	
	@Test(enabled = true, expectedExceptions = {MappingException.class})
	public void tesGetEnumUndefined() throws Exception {
		BizUtil.getEnum(StatusType.class, "XYZ");
	}
	
	@Test(enabled = true)
	public void tesGetEnumClassWithNoMethod() throws Exception {
		//A class with no methods
		BizUtil.getEnum(Serializable.class, "XYZ");
	}

}
