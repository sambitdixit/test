package com.walmart.platform.soari.registry.biz.mapper.impl;

import org.dozer.classmap.ClassMap;
import org.dozer.fieldmap.FieldMap;
import org.hibernate.collection.spi.PersistentCollection;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.walmart.platform.soari.registry.common.dto.Service;
import com.walmart.platform.soari.registry.common.dto.ServiceVersion;
import com.walmart.platform.soari.registry.domain.ServiceDO;

public class DozerCustomFieldMapperTest {

	@InjectMocks private DozerCustomFieldMapper dozerCustomFieldMapper = new DozerCustomFieldMapper();
	
	@BeforeMethod(alwaysRun=true)  
	public void init() throws Exception {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test(enabled = true)
	public void testMapToList() throws Exception {
		Service service = Mockito.mock(Service.class);
		ServiceVersion serviceVersion = Mockito.mock(ServiceVersion.class);
		ClassMap classMap = Mockito.mock(ClassMap.class);
		FieldMap fieldMapping = Mockito.mock(FieldMap.class);
		dozerCustomFieldMapper.mapField(service, ServiceDO.class, serviceVersion, classMap, fieldMapping);
	}
	
	@Test(enabled = true)
	public void testMapToListProxy() throws Exception {
		Service service = Mockito.mock(Service.class);
		PersistentCollection serviceVersion = Mockito.mock(PersistentCollection.class);
		ClassMap classMap = Mockito.mock(ClassMap.class);
		FieldMap fieldMapping = Mockito.mock(FieldMap.class);
		dozerCustomFieldMapper.mapField(service, ServiceDO.class, serviceVersion, classMap, fieldMapping);
	}
}
