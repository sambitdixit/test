package com.walmart.platform.soari.registry.biz.mapper.impl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.walmart.platform.soari.registry.common.dto.Service;
import com.walmart.platform.soari.registry.domain.ServiceDO;

public class DozerMapperImplTest {

	@InjectMocks private DozerMapperImpl dozerMapperImpl = new DozerMapperImpl();
	
	@BeforeMethod(alwaysRun=true)  
	public void init() throws Exception {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test(enabled = true)
	public void testMapServiceDOToList() throws Exception {
		List<ServiceDO> services = new ArrayList<ServiceDO>(0);
		ServiceDO serviceDO = new ServiceDO();
		services.add(serviceDO);
		dozerMapperImpl.mapToList(services, Service.class);
	}
	
	@Test(enabled = true)
	public void testMapServiceDOSetToList() throws Exception {
		Set<ServiceDO> services = new HashSet<ServiceDO>(0);
		ServiceDO serviceDO = new ServiceDO();
		services.add(serviceDO);
		dozerMapperImpl.mapToList(services, Service.class);
	}

}
