package com.walmart.platform.soari.registry.biz.impl;

import java.util.List;
import java.util.Set;

import org.dozer.MappingException;
import org.mockito.Mock;

import com.walmart.platform.kernel.exception.layers.business.BusinessException;
import com.walmart.platform.kernel.exception.layers.dao.DataAccessException;
import com.walmart.platform.soari.registry.common.dto.Policy;
import com.walmart.platform.soari.registry.common.dto.QoS;
import com.walmart.platform.soari.registry.common.dto.Service;
import com.walmart.platform.soari.registry.common.dto.ServiceVersion;
import com.walmart.platform.soari.registry.domain.PolicyDO;
import com.walmart.platform.soari.registry.domain.AuditDO;
import com.walmart.platform.soari.registry.domain.RegistryPolicyCode;
import com.walmart.platform.soari.registry.domain.ServiceDO;
import com.walmart.platform.soari.registry.domain.ServiceVersionDO;
import com.walmart.platform.soari.registry.server.common.exception.ServiceRegistryException;

public class AbstractBusinessTest {
	
	@Mock protected DataAccessException dataAccessException;
	
	@Mock protected BusinessException businessException;
	
	@Mock protected MappingException mappingException;
	
	@Mock protected RuntimeException exception;
	
	@Mock protected ServiceRegistryException serviceRegistryException;
	
	@Mock protected ServiceDO serviceDO;
	
	@Mock protected Service service;
	
	protected List<Service> services;
	@Mock protected List<ServiceDO> serviceDOs;
	@Mock protected Set<ServiceVersionDO> serviceVersionDOs;
	@Mock protected List<ServiceVersion> serviceVersions;
	protected List<QoS> qosParameters;
	@Mock protected RegistryPolicyCode status;
	
	@Mock protected ServiceVersion serviceVersion;
	
	@Mock protected ServiceVersionDO serviceVersionDO;
	
	@Mock protected QoS qosParameter;
	
	@Mock protected PolicyDO policyDO;
	
	@Mock protected Policy policy;
	
	@Mock protected List<Policy> policies;
	
	@Mock protected List<PolicyDO> policyDOs;
	@Mock protected AuditDO auditDO;
	@Mock protected List<AuditDO> audits;
	
	protected static final String TEST_POLICY_NAME = "TEST_POLICY";
	protected static final String TEST_POLICY_NAME_UPDATE = "TEST_POLICY_UPDATE";
	protected static final String TEST_POLICY_VERSION = "1.0";
	protected static final String TEST_POLICY_CREATED_BY = "TESTNG";
	protected static final String TEST_POLICY_ID = "10L";
	
	protected static final String TEST_SERVICE_VERSION_NUMBER = "1.0";
	protected static final String TEST_SERVICE_VERSION_VERSION_UPDATE = "2.0";
	
	
	protected static final String TEST_EXCEPTION_MESSAGE = "An error has occured";
	
	protected static final String TEST_SERVICE_VERSION_ID = "TEST_SERVICE_VERSION_ID";
	
	protected static final String TEST_SERVICE_NAME = "TEST_SERVICE_NAME";
	protected static final String TEST_SERVICE_ID = "TEST_SERVICE_ID";
	protected static final String TEST_QoS_NAME = "TEST_QoS_NAME";
	protected static final String TEST_QoS_ID = "TEST_QoS_ID";
	
	protected String getSamplePolicyData() {
		StringBuffer sb = new StringBuffer();
		sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
		sb.append("<!--Max error count alert policy -->");
		sb.append("<p:PolicyDefinition type=\"SLA\" order=\"2\" flow=\"RESPONSE\" ");
		sb.append("	xmlns:p=\"http://platform.walmart.com/soa/policy/definition/model\"");
		sb.append("	xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"");
		sb.append("	xsi:schemaLocation=\"http://platform.walmart.com/soa/policy/definition/model policy-schema.xsd \">");
		sb.append(" <Rule id=\"max_error_alert_policy\">");
		sb.append(" <if leftTerm=\"REQUEST_ERROR_COUNT\" op=\"&gt;\" rightTerm=\"QOS_MAX_ERROR_ALERT\" />");
		sb.append(" <then>");
		sb.append(" <action>");
		sb.append(" <type>ALERT</type>");
		sb.append(" <value>true</value>");
		sb.append(" </action>");
		sb.append(" </then>");
		sb.append(" </Rule>");
		sb.append("</p:PolicyDefinition>");
		return sb.toString();
	}
	
}
