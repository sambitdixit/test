--liquibase formatted sql

-- general
-- do make schema changes backward compatible. all changes that change backward compatibility should be done in post-scripts.
-- do not modify a changeset that has already been released, add a new one.
-- do not include data changes in this script.
-- changeset definition format: {author}:{release}_{env} dbms:mysql context:{env}
-- {author}: the author of the changeset
-- {release}: the release containing this changeset. Do not use quotes, '-' or '.'. Safe characters include '0-9, a-z, A-Z, _'
-- {env}: if appropriate, an environment name can be included making the changeset conditional to a specific environmemt. (dev, qa, preprod, prod)



--changeset dbaas:soa_release_3_0_14 dbms:oracle
CREATE TABLE SERVICE_VERSION_ATTR
(
   SRC_VERSION_ID VARCHAR2(36) not null,
   NAME VARCHAR2(128) not null,
   VALUE VARCHAR2(128) not null
) TABLESPACE SOA_LARGE_DAT1;

ALTER TABLE SERVICE_VERSION_ATTR ADD CONSTRAINT PK_SRC_VRSN_ATTR PRIMARY KEY(SRC_VERSION_ID, NAME);

ALTER TABLE SERVICE_VERSION_ATTR ADD CONSTRAINT FK_SRC_VRSN_ATTR_VRSN FOREIGN KEY
(
   SRC_VERSION_ID
)
REFERENCES SERVICE_VERSION(ID)
;

--changeset dbaas:soa_release_4_0_3 dbms:oracle
ALTER TABLE SERVICE_VERSION_ATTR MODIFY VALUE VARCHAR2(256);
