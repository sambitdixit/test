--liquibase formatted sql

-- general
-- do make schema changes backward compatible. all changes that change backward compatibility should be done in post-scripts.
-- do not modify a changeset that has already been released, add a new one.
-- do not include data changes in this script.
-- changeset definition format: {author}:{release}_{env} dbms:mysql context:{env}
-- {author}: the author of the changeset
-- {release}: the release containing this changeset. Do not use quotes, '-' or '.'. Safe characters include '0-9, a-z, A-Z, _'
-- {env}: if appropriate, an environment name can be included making the changeset conditional to a specific environmemt. (dev, qa, preprod, prod)



--changeset dbaas:soa_release_3_0_12 dbms:oracle   

UPDATE SERVICE_VERSION T SET T.VERSION = (SELECT E.VERSION FROM ENTITY E WHERE E.ID = T.ID);
UPDATE SERVICE_VERSION T SET T.CREATED_BY = (SELECT E.CREATED_BY FROM ENTITY E WHERE E.ID = T.ID);
UPDATE SERVICE_VERSION T SET T.CREATED_AT = (SELECT E.CREATED_AT FROM ENTITY E WHERE E.ID = T.ID);
UPDATE SERVICE_VERSION T SET T.MODIFIED_BY = (SELECT E.MODIFIED_BY FROM ENTITY E WHERE E.ID = T.ID);
UPDATE SERVICE_VERSION T SET T.MODIFIED_AT = (SELECT E.MODIFIED_AT FROM ENTITY E WHERE E.ID = T.ID);
UPDATE SERVICE_VERSION T SET T.STATUS = (SELECT E.STATUS FROM ENTITY E WHERE E.ID = T.ID);

--changeset dbaas:soa_release_3_0_12_3 dbms:oracle   
UPDATE SERVICE_VERSION S SET S.STATUS = (SELECT C.CODE FROM REGISTRY_POLICY_CODE C WHERE C.ID = S.STATUS);