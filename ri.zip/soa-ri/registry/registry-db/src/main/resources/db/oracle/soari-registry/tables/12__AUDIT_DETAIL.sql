--liquibase formatted sql

-- general
-- do make schema changes backward compatible. all changes that change backward compatibility should be done in post-scripts.
-- do not modify a changeset that has already been released, add a new one.
-- do not include data changes in this script.
-- changeset definition format: {author}:{release}_{env} dbms:mysql context:{env}
-- {author}: the author of the changeset
-- {release}: the release containing this changeset. Do not use quotes, '-' or '.'. Safe characters include '0-9, a-z, A-Z, _'
-- {env}: if appropriate, an environment name can be included making the changeset conditional to a specific environmemt. (dev, qa, preprod, prod)



--changeset dbaas:soa_release_1_0 dbms:oracle                       
                                                                

  CREATE TABLE  "AUDIT_DETAIL"
   (	"ID" VARCHAR2(36) NOT NULL ENABLE,
	"OPTYPE" VARCHAR2(36) NOT NULL ENABLE,
	"FIELD" VARCHAR2(36) NOT NULL ENABLE,
	"OLD_VALUE" VARCHAR2(128),
	"NEW_VALUE" VARCHAR2(128),
	"ENTITY_ID" VARCHAR2(36) NOT NULL ENABLE,
	"VERSION" NUMBER(22,0),
	"MODIFIED_BY" VARCHAR2(128),
	"MODIFIED_AT" TIMESTAMP (6),
	 PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS
  TABLESPACE "SOA_LARGE_IDX1"	ENABLE,
	 CONSTRAINT "FK_AUDIT_DTL_ENTITY" FOREIGN KEY ("ENTITY_ID")
	  REFERENCES  "ENTITY" ("ID") ENABLE
   ) SEGMENT CREATION IMMEDIATE
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255
 NOCOMPRESS LOGGING
  TABLESPACE "SOA_LARGE_DAT1" ;

--rollback DROP TABLE AUDIT_DETAIL ;                                      

--changeset dbaas:soa_release_1_1 dbms:oracle          

CREATE INDEX IDX_AUDIT_DETAIL_ENTITY_ID ON AUDIT_DETAIL (ENTITY_ID) TABLESPACE SOA_LARGE_IDX1;

CREATE INDEX IDX_AUDIT_DETAIL_ENTITY_TIME ON AUDIT_DETAIL (ENTITY_ID,MODIFIED_AT) TABLESPACE SOA_LARGE_IDX1;             

--changeset dbaas:soa_release_3_0_12 dbms:oracle 
ALTER TABLE "AUDIT_DETAIL"
ADD
   (
	"ENTITY_TYPE" VARCHAR2(36) DEFAULT ' ' NOT NULL
   );
   
--changeset dbaas:soa_release_3_0_12_1 dbms:oracle   
ALTER TABLE "AUDIT_DETAIL" DROP CONSTRAINT "FK_AUDIT_DTL_ENTITY";
--changeset dbaas:soa_release_4_0_2 dbms:oracle
ALTER TABLE AUDIT_DETAIL MODIFY OLD_VALUE  VARCHAR2(256);
ALTER TABLE AUDIT_DETAIL MODIFY NEW_VALUE  VARCHAR2(256);