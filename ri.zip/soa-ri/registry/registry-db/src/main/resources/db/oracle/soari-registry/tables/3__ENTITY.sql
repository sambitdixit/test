--liquibase formatted sql

-- general
-- do make schema changes backward compatible. all changes that change backward compatibility should be done in post-scripts.
-- do not modify a changeset that has already been released, add a new one.
-- do not include data changes in this script.
-- changeset definition format: {author}:{release}_{env} dbms:mysql context:{env}
-- {author}: the author of the changeset
-- {release}: the release containing this changeset. Do not use quotes, '-' or '.'. Safe characters include '0-9, a-z, A-Z, _'
-- {env}: if appropriate, an environment name can be included making the changeset conditional to a specific environmemt. (dev, qa, preprod, prod)



--changeset dbaas:soa_release_1_0 dbms:oracle                       
                                                                

  CREATE TABLE  "ENTITY"
   (	"ID" VARCHAR2(36) NOT NULL ENABLE,
	"VERSION" NUMBER,
	"CREATED_BY" VARCHAR2(128),
	"CREATED_AT" TIMESTAMP (6),
	"MODIFIED_BY" VARCHAR2(128),
	"MODIFIED_AT" TIMESTAMP (6),
	"ENTITY_TYPE" VARCHAR2(36),
	"STATUS" VARCHAR2(36) NOT NULL ENABLE,
	 PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS
  TABLESPACE "SOA_SMALL_IDX1"	ENABLE,
	 CONSTRAINT "FK_ENTITY_STATUS" FOREIGN KEY ("STATUS")
	  REFERENCES  "REGISTRY_POLICY_CODE" ("ID") ENABLE
   ) SEGMENT CREATION IMMEDIATE
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255
 NOCOMPRESS LOGGING
  TABLESPACE "SOA_SMALL_DAT1" ;

--rollback DROP TABLE ENTITY ;                                      
--changeset dbaas:soa_release_4_0_1 dbms:oracle
CREATE INDEX IDX_ENTTY_STATS ON ENTITY (STATUS) TABLESPACE SOA_SMALL_IDX1;
CREATE INDEX IDX_ENTTY_TYPE ON ENTITY (ENTITY_TYPE) TABLESPACE SOA_SMALL_IDX1;