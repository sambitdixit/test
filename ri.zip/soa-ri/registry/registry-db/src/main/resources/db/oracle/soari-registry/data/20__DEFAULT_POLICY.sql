--liquibase formatted sql

-- general
-- do make schema changes backward compatible. all changes that change backward compatibility should be done in post-scripts.
-- do not modify a changeset that has already been released, add a new one.
-- do not include data changes in this script.
-- changeset definition format: {author}:{release}_{env} dbms:mysql context:{env}
-- {author}: the author of the changeset
-- {release}: the release containing this changeset. Do not use quotes, '-' or '.'. Safe characters include '0-9, a-z, A-Z, _'
-- {env}: if appropriate, an environment name can be included making the changeset conditional to a specific environmemt. (dev, qa, preprod, prod)



--changeset dbaas:soa_release_4_0_10 dbms:oracle
INSERT INTO DEFAULT_POLICY (ID,NAME,DESCRIPTION,TYPE,DATA,EXEC_ORDER,FLOW,STATUS,CONTEXT) values ('56c902f1958411e29e960420420c9x78','MaxUrlLengthPolicy','Maximum URL length policy','SLA',
'<?xml version="1.0" encoding="UTF-8"?>
<!--Check max url length of a request url and allow/deny accordingly. -->
<p:PolicyDefinition type="SLA" order="2" flow="REQUEST" context="ESB_OR_SERVICE"
	xmlns:p="http://platform.walmart.com/soa/policy/definition/model"
	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	xsi:schemaLocation="http://platform.walmart.com/soa/policy/definition/model policy-schema.xsd ">
	<Rule id="max_url_length_policy">
		<if leftTerm="REQUEST_URL_LENGTH" op="&lt;" rightTerm="QOS_MAX_URL_LENGTH" />
		<then>
			<action>
				<type>ALLOW</type>
				<value>true</value>
			</action>
		</then>
	</Rule>
	<AlertThreshold>
		<total>150</total>
		<withinPeriod>15000</withinPeriod>
	</AlertThreshold>
</p:PolicyDefinition>',
'2','REQUEST','ACTIVE','ESB_OR_SERVICE'); 

INSERT INTO DEFAULT_POLICY (ID,NAME,DESCRIPTION,TYPE,DATA,EXEC_ORDER,FLOW,STATUS,CONTEXT) values ('56c902f1958411e29e960421420c9x78','MaxDataSizePolicy','Max Data Size policy','SLA',
'<?xml version="1.0" encoding="UTF-8"?>
<!--Max data size allowed policy. -->
<p:PolicyDefinition type="SLA" order="2" flow="ESB_OR_SERVICE"
	xmlns:p="http://platform.walmart.com/soa/policy/definition/model"
	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	xsi:schemaLocation="http://platform.walmart.com/soa/policy/definition/model policy-schema.xsd ">
	<Rule id="max_data_size_policy">
		<if leftTerm="REQUEST_DATA_SIZE" op="&lt;" rightTerm="QOS_MAX_DATA_SIZE"/>
		<then>
			<action>
				<type>ALLOW</type>
				<value>true</value>
			</action>
		</then>
	</Rule>
</p:PolicyDefinition>',
'3','REQUEST','ACTIVE','ESB_OR_SERVICE'); 

INSERT INTO DEFAULT_POLICY (ID,NAME,DESCRIPTION,TYPE,DATA,EXEC_ORDER,FLOW,STATUS,CONTEXT) values ('56c902f1958411e29e960422420c9x78','MaxNetworkLatencyPolicy','Max Network Latency policy','SLA',
'<?xml version="1.0" encoding="UTF-8"?>
<!--Max response time allowed policy -->
<p:PolicyDefinition type="SLA" order="2" flow="RESPONSE" context="ESB_OR_SERVICE"
	xmlns:p="http://platform.walmart.com/soa/policy/definition/model"
	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	xsi:schemaLocation="http://platform.walmart.com/soa/policy/definition/model policy-schema.xsd ">
	<Rule id="max_response_time_policy">
		<if leftTerm="REQUEST_NETWORK_LATENCY" op="&lt;" rightTerm="QOS_MAX_NETWORK_LATENCY" />
		<then>
			<action>
				<type>ALLOW</type>
				<value>true</value>
			</action>
		</then>
	</Rule>
</p:PolicyDefinition>',
'2','RESPONSE','ACTIVE','ESB_OR_SERVICE'); 

INSERT INTO DEFAULT_POLICY (ID,NAME,DESCRIPTION,TYPE,DATA,EXEC_ORDER,FLOW,STATUS,CONTEXT) values ('56c902f1958411e29e960423420c9x78','MaxResponseTimePolicy','Max Response Time policy','SLA',
'<?xml version="1.0" encoding="UTF-8"?>
<!--Max response time allowed policy -->
<p:PolicyDefinition type="SLA" order="2" flow="RESPONSE" context="ESB_OR_SERVICE"
	xmlns:p="http://platform.walmart.com/soa/policy/definition/model"
	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	xsi:schemaLocation="http://platform.walmart.com/soa/policy/definition/model policy-schema.xsd ">
	<Rule id="max_response_time_policy">
		<if leftTerm="REQUEST_RESPONSE_TIME" op="&lt;" rightTerm="QOS_MAX_RESPONSE_TIME" />
		<then>
			<action>
				<type>ALLOW</type>
				<value>true</value>
			</action>
		</then>
	</Rule>
</p:PolicyDefinition>',
'1','RESPONSE','ACTIVE','ESB_OR_SERVICE'); 

INSERT INTO DEFAULT_POLICY (ID,NAME,DESCRIPTION,TYPE,DATA,EXEC_ORDER,FLOW,STATUS,CONTEXT) values ('56c902f1958411e29e960424420c9x78','MaxRoundTripTimePolicy','Max Round Trip Time Policy','SLA',
'<?xml version="1.0" encoding="UTF-8"?>
<!--Max roundtrip time allowed policy -->
<p:PolicyDefinition type="SLA" order="2" flow="RESPONSE" context="ESB_OR_SERVICE"
	xmlns:p="http://platform.walmart.com/soa/policy/definition/model"
	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	xsi:schemaLocation="http://platform.walmart.com/soa/policy/definition/model policy-schema.xsd ">
	<Rule id="max_roundtrip_time_policy">
		<if leftTerm="REQUEST_ROUND_TRIP_TIME" op="&lt;" rightTerm="QOS_MAX_ROUND_TRIP_TIME" />
		<then>
			<action>
				<type>ALLOW</type>
				<value>true</value>
			</action>
		</then>
	</Rule>
	<AlertThreshold>
		<total>3</total>
		<withinPeriod>20000</withinPeriod>
	</AlertThreshold>
</p:PolicyDefinition>',
'2','RESPONSE','ACTIVE','ESB_OR_SERVICE'); 

INSERT INTO DEFAULT_POLICY (ID,NAME,DESCRIPTION,TYPE,DATA,EXEC_ORDER,FLOW,STATUS,CONTEXT) values ('56c902f1958411e29e960425420c9x78','ThrottlePolicy','ThrottlePolicy','SLA',
'<?xml version="1.0" encoding="UTF-8"?>
<!-- Throttle policy -->
<p:PolicyDefinition xmlns:p="http://platform.walmart.com/soa/policy/definition/model" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" type="THROTTLING" order="0" flow="REQUEST" context="ESB" xsi:schemaLocation="http://platform.walmart.com/soa/policy/definition/model policy-schema.xsd ">
   <Rule id="throttling_policy">
      <if leftTerm="REQUEST_SERVICE_NAME" op="!=" rightTerm="null" />
      <then>
         <action>
            <type>THROTTLE_ALERT</type>
            <value>QOS_THROTTLE</value>
         </action>
      </then>
   </Rule>
</p:PolicyDefinition>',
'0','REQUEST','ACTIVE','ESB'); 
