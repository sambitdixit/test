--liquibase formatted sql

-- general
-- do make schema changes backward compatible. all changes that change backward compatibility should be done in post-scripts.
-- do not modify a changeset that has already been released, add a new one.
-- do not include data changes in this script.
-- changeset definition format: {author}:{release}_{env} dbms:mysql context:{env}
-- {author}: the author of the changeset
-- {release}: the release containing this changeset. Do not use quotes, '-' or '.'. Safe characters include '0-9, a-z, A-Z, _'
-- {env}: if appropriate, an environment name can be included making the changeset conditional to a specific environmemt. (dev, qa, preprod, prod)



--changeset dbaas:soa_release_3_0_10 dbms:oracle

CREATE TABLE CONSUMER
(
   ID VARCHAR2(36),
   CONSUMER_ID VARCHAR2(128) NOT NULL
) TABLESPACE SOA_LARGE_DAT1
;

ALTER TABLE CONSUMER ADD CONSTRAINT PK_CONSUMER PRIMARY KEY
(
   ID
) using index tablespace SOA_LARGE_IDX1
;

ALTER TABLE CONSUMER ADD CONSTRAINT UK_CONSUMER UNIQUE (CONSUMER_ID) using index tablespace SOA_LARGE_IDX1;

ALTER TABLE CONSUMER ADD CONSTRAINT FK_CONSUMER_ENTITY FOREIGN KEY
(
   ID
)
REFERENCES ENTITY(ID)
;

--changeset dbaas:soa_release_3_0_12 dbms:oracle   

ALTER TABLE "CONSUMER"
ADD
   (
     "VERSION" NUMBER,
	"CREATED_BY" VARCHAR2(128),
	"CREATED_AT" TIMESTAMP (6),
	"MODIFIED_BY" VARCHAR2(128),
	"MODIFIED_AT" TIMESTAMP (6),
	"ENTITY_TYPE" VARCHAR2(36),
	"STATUS" VARCHAR2(36) DEFAULT ' ' NOT NULL
   );

--changeset dbaas:soa_release_3_0_12_1 dbms:oracle      
ALTER TABLE "CONSUMER"
DROP CONSTRAINT "FK_CONSUMER_ENTITY";     

ALTER TABLE "CONSUMER"
DROP COLUMN ENTITY_TYPE;