--liquibase formatted sql

-- general
-- do make schema changes backward compatible. all changes that change backward compatibility should be done in post-scripts.
-- do not modify a changeset that has already been released, add a new one.
-- do not include data changes in this script.
-- changeset definition format: {author}:{release}_{env} dbms:mysql context:{env}
-- {author}: the author of the changeset
-- {release}: the release containing this changeset. Do not use quotes, '-' or '.'. Safe characters include '0-9, a-z, A-Z, _'
-- {env}: if appropriate, an environment name can be included making the changeset conditional to a specific environmemt. (dev, qa, preprod, prod)



--changeset dbaas:soa_release_1_0 dbms:oracle                       
                                                                

  CREATE TABLE  "NOTIFICATION_DESTINATION"
   (	"ID" VARCHAR2(36) NOT NULL ENABLE,
	"TYPE" VARCHAR2(36) NOT NULL ENABLE,
	"NAME" VARCHAR2(128) NOT NULL ENABLE,
	"URL" VARCHAR2(128) NOT NULL ENABLE,
	"ENV" VARCHAR2(36) NOT NULL ENABLE,
	"AVAILABILITY_TIER" VARCHAR2(36) NOT NULL ENABLE,
	 PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS
  TABLESPACE "SOA_SMALL_IDX1"	ENABLE,
	 CONSTRAINT "FK_NOTIFICATION_TYPE" FOREIGN KEY ("TYPE")
	  REFERENCES  "REGISTRY_POLICY_CODE" ("ID") ENABLE
   ) SEGMENT CREATION IMMEDIATE
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255
 NOCOMPRESS LOGGING
  TABLESPACE "SOA_SMALL_DAT1" ;

--rollback DROP TABLE NOTIFICATION_DESTINATION ;                                      

--changeset dbaas:soa_release_3_0_12 dbms:oracle   

ALTER TABLE "NOTIFICATION_DESTINATION"
ADD
   (
     "VERSION" NUMBER,
	"CREATED_BY" VARCHAR2(128),
	"CREATED_AT" TIMESTAMP (6),
	"MODIFIED_BY" VARCHAR2(128),
	"MODIFIED_AT" TIMESTAMP (6),
	"STATUS" VARCHAR2(36) DEFAULT ' ' NOT NULL
   );
 
--changeset dbaas:soa_release_3_0_12_3 dbms:oracle 
ALTER TABLE "NOTIFICATION_DESTINATION"
DROP CONSTRAINT FK_NOTIFICATION_TYPE; 
