--liquibase formatted sql

-- general
-- do make schema changes backward compatible. all changes that change backward compatibility should be done in post-scripts.
-- do not modify a changeset that has already been released, add a new one.
-- do not include data changes in this script.
-- changeset definition format: {author}:{release}_{env} dbms:mysql context:{env}
-- {author}: the author of the changeset
-- {release}: the release containing this changeset. Do not use quotes, '-' or '.'. Safe characters include '0-9, a-z, A-Z, _'
-- {env}: if appropriate, an environment name can be included making the changeset conditional to a specific environmemt. (dev, qa, preprod, prod)



--changeset dbaas:soa_release_1_0 dbms:oracle                       
                                                                

  CREATE TABLE  "POLICY"
   (	"ID" VARCHAR2(36) NOT NULL ENABLE,
	"NAME" VARCHAR2(128) NOT NULL ENABLE,
	"DESCRIPTION" VARCHAR2(128) NOT NULL ENABLE,
	"TYPE" VARCHAR2(36) NOT NULL ENABLE,
	"DATA" CLOB,
	"EXEC_ORDER" NUMBER(4,0),
	"FLOW" VARCHAR2(36),
	 PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS
  TABLESPACE "SOA_SMALL_IDX1"	ENABLE,
	 CONSTRAINT "FK_POLICY_ENTITY" FOREIGN KEY ("ID")
	  REFERENCES  "ENTITY" ("ID") ENABLE,
	 CONSTRAINT "FK_POLICY_TYPE" FOREIGN KEY ("TYPE")
	  REFERENCES  "REGISTRY_POLICY_CODE" ("ID") ENABLE,
	 CONSTRAINT "FK_POLICY_FLOW_TYPE" FOREIGN KEY ("FLOW")
	  REFERENCES  "REGISTRY_POLICY_CODE" ("ID") ENABLE
   ) SEGMENT CREATION IMMEDIATE
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255
 NOCOMPRESS LOGGING
  TABLESPACE "SOA_SMALL_DAT1"
 LOB ("DATA") STORE AS BASICFILE (
  TABLESPACE "SOA_SMALL_DAT1" ENABLE STORAGE IN ROW CHUNK 8192 RETENTION
  NOCACHE LOGGING ) ;

--rollback DROP TABLE POLICY ;                                      

--changeset dbaas:soa_release_3_0_12 dbms:oracle   

ALTER TABLE "POLICY"
ADD
   (
     "VERSION" NUMBER,
	"CREATED_BY" VARCHAR2(128),
	"CREATED_AT" TIMESTAMP (6),
	"MODIFIED_BY" VARCHAR2(128),
	"MODIFIED_AT" TIMESTAMP (6),
	"STATUS" VARCHAR2(36) DEFAULT ' ' NOT NULL
   );

--changeset dbaas:soa_release_3_0_12_1 dbms:oracle   
ALTER TABLE "POLICY"
DROP CONSTRAINT "FK_POLICY_ENTITY";      

--changeset dbaas:soa_release_3_0_12_3 dbms:oracle
ALTER TABLE "POLICY"
DROP CONSTRAINT FK_POLICY_FLOW_TYPE; 
ALTER TABLE "POLICY"
DROP CONSTRAINT FK_POLICY_TYPE; 

--changeset dbaas:soa_release_3_0_14 dbms:oracle
ALTER TABLE POLICY ADD(CONTEXT VARCHAR2(36));
--changeset dbaas:soa_release_4_0_1 dbms:oracle
UPDATE POLICY SET CONTEXT = 'ESB' WHERE CONTEXT IS NULL;

--changeset dbaas:soa_release_4_0_9 dbms:oracle
CREATE INDEX IDX_POLICY_NAME ON POLICY (NAME) TABLESPACE SOA_SMALL_IDX1;
CREATE INDEX IDX_POLICY_TYPE ON POLICY (TYPE) TABLESPACE SOA_SMALL_IDX1;
CREATE INDEX IDX_POLICY_STATUS ON POLICY (STATUS) TABLESPACE SOA_SMALL_IDX1;