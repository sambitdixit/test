--liquibase formatted sql

-- general
-- do make schema changes backward compatible. all changes that change backward compatibility should be done in post-scripts.
-- do not modify a changeset that has already been released, add a new one.
-- do not include data changes in this script.
-- changeset definition format: {author}:{release}_{env} dbms:mysql context:{env}
-- {author}: the author of the changeset
-- {release}: the release containing this changeset. Do not use quotes, '-' or '.'. Safe characters include '0-9, a-z, A-Z, _'
-- {env}: if appropriate, an environment name can be included making the changeset conditional to a specific environmemt. (dev, qa, preprod, prod)



--changeset dbaas:soa_release_1_0 dbms:oracle                       
                                                                

  CREATE TABLE  "SERVICE_VERSION_URL"
   (	"SRV_VERSION_ID" VARCHAR2(36) NOT NULL ENABLE,
	"URL_ID" VARCHAR2(36) NOT NULL ENABLE,
	 CONSTRAINT "PK_SRV_VRSN_URL" PRIMARY KEY ("SRV_VERSION_ID", "URL_ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS
  TABLESPACE "SOA_SMALL_IDX1"	ENABLE,
	 CONSTRAINT "FK_SRV_VRSN_URL" FOREIGN KEY ("URL_ID")
	  REFERENCES  "URL" ("ID") ENABLE,
	 CONSTRAINT "FK_SRV_VRSN_URL_VRSN" FOREIGN KEY ("SRV_VERSION_ID")
	  REFERENCES  "SERVICE_VERSION" ("ID") ENABLE
   ) SEGMENT CREATION IMMEDIATE
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255
 NOCOMPRESS LOGGING
  TABLESPACE "SOA_SMALL_DAT1" ;

--rollback DROP TABLE SERVICE_VERSION_URL ;
--changeset dbaas:soa_release_4_0_1 dbms:oracle                                      
CREATE INDEX IDX_SRV_VRSN_URL ON SERVICE_VERSION_URL (URL_ID,SRV_VERSION_ID) TABLESPACE SOA_SMALL_IDX1;