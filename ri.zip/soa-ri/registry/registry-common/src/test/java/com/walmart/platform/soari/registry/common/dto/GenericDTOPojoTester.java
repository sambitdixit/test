package com.walmart.platform.soari.registry.common.dto;


import org.testng.annotations.Test;

import com.openpojo.reflection.PojoClassFilter;
import com.openpojo.reflection.filters.FilterEnum;
import com.walmart.platform.soari.registry.common.dto.DTOPojoTestUtil;

/**
 * The Class GenericPojoTester.
 */
 
public class GenericDTOPojoTester {
 
    // The package to test
    /** The Constant POJO_PACKAGE. */
    private static final String POJO_PACKAGE = "com.walmart.platform.soari.registry.common.dto";
 
    /** The pojo class filters. */
    private final PojoClassFilter[] pojoClassFilters = {new FilterEnum()};
 
    /**
     * Test pojo structure and behavior.
     */
    @Test
    public void testPojoStructureAndBehavior() {
        final DTOPojoTestUtil pojoTestUtil = new DTOPojoTestUtil();
        pojoTestUtil.testPojoStructureAndBehavior(POJO_PACKAGE, pojoClassFilters);
    }
}

