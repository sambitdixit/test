package com.walmart.platform.soari.registry.common.dto;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "ConsumerSubscription")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name="ConsumerSubscription")
public class ConsumerSubscription implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String consumerId;
	private String communicationType;
	
	/**
	 * @return the consumerId
	 */
	public String getConsumerId() {
		return consumerId;
	}
	/**
	 * @param consumerId the consumerId to set
	 */
	public void setConsumerId(String consumerId) {
		this.consumerId = consumerId;
	}
	/**
	 * @return the communicationType
	 */
	public String getCommunicationType() {
		return communicationType;
	}
	/**
	 * @param communicationType the communicationType to set
	 */
	public void setCommunicationType(String communicationType) {
		this.communicationType = communicationType;
	}
	
	@Override
	public String toString() {
		return "ConsumerSubscription [consumerId=" + consumerId
				+ ", communicationType=" + communicationType + "]";
	}
	
}
