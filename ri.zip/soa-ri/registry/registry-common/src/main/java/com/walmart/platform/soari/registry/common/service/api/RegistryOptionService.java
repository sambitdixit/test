package com.walmart.platform.soari.registry.common.service.api;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;
import static javax.ws.rs.core.MediaType.APPLICATION_XML;
import static javax.ws.rs.core.MediaType.TEXT_XML;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

import com.walmart.platform.kernel.exception.layers.service.ServiceException;
import com.walmart.platform.soa.common.service.wrappers.ServiceResponse;
import com.walmart.platform.soari.registry.common.dto.RegistryOptionList;
import com.walmart.platform.soari.registry.common.enums.RegistryPolicyCodeType;

@Path("/registry/option")
public interface RegistryOptionService {

	/**
	 * Fetches list of all the options corresponding to 'type'
	 * 
	 * @param type {@link RegistryPolicyCodeType}
	 * @return list of matching policies
	 * @throws ServiceException
	 */
	@GET
	@Produces({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	ServiceResponse<RegistryOptionList> getOptionsByType(@QueryParam("type") RegistryPolicyCodeType type) throws ServiceException;

}
