package com.walmart.platform.soari.registry.common.service.api;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;
import static javax.ws.rs.core.MediaType.APPLICATION_XML;
import static javax.ws.rs.core.MediaType.TEXT_XML;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import com.walmart.platform.kernel.exception.layers.service.ServiceException;
import com.walmart.platform.soa.common.service.wrappers.ServiceResponse;
import  com.walmart.platform.soari.registry.common.enums.ReportType;

@Path("/registry/dashboard")
public interface DashboardService {

	String REPORT_TYPE = "reportType";

	@GET
	@Path("/{reportType}")
	@Produces({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	public ServiceResponse<String> getReport(@PathParam(REPORT_TYPE) ReportType reportType) throws ServiceException;
}
