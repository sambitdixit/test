package com.walmart.platform.soari.registry.common.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "NotificationDestinationList")
public class NotificationDestinationList implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@XmlElementWrapper(name = "notificationDestinations")
	@XmlElement(name = "notificationDestinations")
	private List<NotificationDestination> notificationDestinations = null;

	/**
	 * @return the notificationDestinations
	 */
	public List<NotificationDestination> getNotificationDestinations() {
		if(notificationDestinations == null) {
			notificationDestinations = new ArrayList<NotificationDestination>(0);
		}
		return notificationDestinations;
	}

	/**
	 * @param notificationDestinations the notificationDestinations to set
	 */
	public void setNotificationDestinations(
			List<NotificationDestination> notificationDestinations) {
		this.notificationDestinations = notificationDestinations;
	}

}
