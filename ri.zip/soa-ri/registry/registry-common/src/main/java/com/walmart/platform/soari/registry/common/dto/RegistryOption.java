package com.walmart.platform.soari.registry.common.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.walmart.platform.soari.registry.common.enums.RegistryPolicyCodeType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name="RegistryCode")
@XmlRootElement(name = "RegistryCode")
public class RegistryOption {

	private String id;
	private RegistryPolicyCodeType type;
	private String code;
	private String description;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public RegistryPolicyCodeType getType() {
		return type;
	}
	public void setType(RegistryPolicyCodeType type) {
		this.type = type;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
}
