package com.walmart.platform.soari.registry.common.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "SubscriptionRequest")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name="SubscriptionRequest")
public class SubscriptionRequest extends BaseDTO {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	protected String serviceVersionId;
	protected String communicationType;
	protected String consumerId;
	/**
	 * @return the serviceVersionId
	 */
	public String getServiceVersionId() {
		return serviceVersionId;
	}
	/**
	 * @param serviceVersionId the serviceVersionId to set
	 */
	public void setServiceVersionId(String serviceVersionId) {
		this.serviceVersionId = serviceVersionId;
	}
	/**
	 * @return the communicationType
	 */
	public String getCommunicationType() {
		return communicationType;
	}
	/**
	 * @param communicationType the communicationType to set
	 */
	public void setCommunicationType(String communicationType) {
		this.communicationType = communicationType;
	}
	/**
	 * @return the consumerId
	 */
	public String getConsumerId() {
		return consumerId;
	}
	/**
	 * @param consumerId the consumerId to set
	 */
	public void setConsumerId(String consumerId) {
		this.consumerId = consumerId;
	}
	
}
