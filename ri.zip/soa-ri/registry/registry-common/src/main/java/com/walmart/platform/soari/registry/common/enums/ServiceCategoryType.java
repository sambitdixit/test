package com.walmart.platform.soari.registry.common.enums;

public enum ServiceCategoryType {
	BIZ, UTIL, PROC, INFRA, DATA
}
