package com.walmart.platform.soari.registry.common.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Policies
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "DefaultPolicyList")
public class DefaultPolicyList implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@XmlElementWrapper(name = "DefaultPolicies")
	@XmlElement(name = "DefaultPolicy")
	private List<DefaultPolicy> defaultPolicies = null;

	public DefaultPolicyList() {

	}

	public DefaultPolicyList(List<DefaultPolicy> policies) {
		this.defaultPolicies = policies;
	}

	
	public List<DefaultPolicy> getPolicies() {
		if(defaultPolicies == null) {
			defaultPolicies = new ArrayList<DefaultPolicy>(0);
		}
		return defaultPolicies;
	}

	public void setPolicies(List<DefaultPolicy> policies) {
		this.defaultPolicies = policies;
	}

	@Override
	public String toString() {
		return "DefaultPolicyList [default_policies=" + defaultPolicies + "]";
	}

}
