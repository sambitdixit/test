package com.walmart.platform.soari.registry.common.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Services
 */
@XmlRootElement(name = "ServiceList")
@XmlAccessorType(XmlAccessType.FIELD)
public class ServiceList implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@XmlElementWrapper(name = "services")
	@XmlElement(name = "service")
	private List<Service> services = null;

	public ServiceList() {

	}

	public ServiceList(List<Service> services) {
		this.services = services;
	}

	public List<Service> getServices() {
		if(services == null) {
			services = new ArrayList<Service>(0);
		}
		return services;
	}

	public void setServices(List<Service> services) {
		this.services = services;
	}

	@Override
	public String toString() {
		return "ServiceList [services=" + services + "]";
	}

	
}
