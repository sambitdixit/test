package com.walmart.platform.soari.registry.common.enums;

public enum StatusType {
	ACTIVE, INACTIVE, DELETED, AVAILABLE
}
