package com.walmart.platform.soari.registry.common.dto;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

/**
 * @author msing37
 *
 */
public abstract class BaseDTO implements Serializable{
	
	/**
	 * class version id
	 */
	private static final long serialVersionUID = 1L;
	
	/** The created by. */
	private String createdBy;
	
	/** The created at. */
	private Timestamp createdAt;
	
	/** The modified by. */
	private String modifiedBy;
	
	/** The modified at. */
	private Timestamp modifiedAt;

    /** The id. */
    private String id;

    /** The status. */
    private String status ="ACTIVE";
    
	private String resourceUri;
	
	/**
	 * @return the resourceUri
	 */
	public String getResourceUri() {
		return resourceUri;
	}

	/**
	 * @param resourceUri the resourceUri to set
	 */
	public void setResourceUri(String resourceUri) {
		this.resourceUri = resourceUri;
	}

	/**
	 * getter for the createdBy
	 * @return
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * setter for the createdBy
	 * @param createdBy
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return
	 */
	@XmlJavaTypeAdapter(TimestampAdapter.class)
	public Timestamp getCreatedAt() {
		return createdAt;
	}

	/**
	 * @param createdAt
	 */
	public void setCreatedAt(Timestamp createdAt) {
		this.createdAt = createdAt;
	}

	/**
	 * @return
	 */
	public String getModifiedBy() {
		return modifiedBy;
	}

	/**
	 * @param modifiedBy
	 */
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	/**
	 * returns time when last modified
	 * @return
	 */
	@XmlJavaTypeAdapter(TimestampAdapter.class)
	public Timestamp getModifiedAt() {
		return modifiedAt;
	}

	/**
	 * set the modification time
	 * @param modifiedAt
	 */
	public void setModifiedAt(Timestamp modifiedAt) {
		this.modifiedAt = modifiedAt;
	}

	/**
	 * Returns the identifier 
	 * @return
	 */
	public String getId() {
		return id;
	}

	/**
	 * Setter for the identifier
	 * @param id
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * Getter for the status
	 * @return
	 */
	public String getStatus() {
		return status;
	}
	
	/**
	 * Setter for the status
	 * @param status
	 */
	public void setStatus(String status) {
		this.status = status;
	}

}
