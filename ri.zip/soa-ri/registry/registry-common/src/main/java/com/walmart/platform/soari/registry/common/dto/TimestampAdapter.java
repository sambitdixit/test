package com.walmart.platform.soari.registry.common.dto;

import java.sql.Timestamp;
import java.util.Date;

import javax.xml.bind.annotation.adapters.XmlAdapter;

public class TimestampAdapter extends XmlAdapter<Date, Timestamp> {
	
	
	/**
	 * Extract date from SQL time-stamp
	 * 
	 * @param v {@link Timestamp}
	 */
	public Date marshal(Timestamp v) {
		return new Date(v.getTime());
	}

	/**
	 * Wraps date into a SQL time-stamp
	 * 
	 * @param v {@link Date}
	 */
	public Timestamp unmarshal(Date v) {
		return new Timestamp(v.getTime());
	}
}
