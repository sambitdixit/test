package com.walmart.platform.soari.registry.common.enums;

public enum AttributeType {
	APPLICATION_ID,SERVICE_STATUS, SERVICE_USAGE, SERVICE_CATEGORY, SERVICE_DOAMIN, SERVICE_OWNER, SERVICE_VERSION_STATUS
}
