package com.walmart.platform.soari.registry.common.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "AuditList")
public class AuditList implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@XmlElementWrapper(name = "auditList")
	@XmlElement(name = "audit")
	private List<Audit> auditList = null;

	/**
	 * @return the auditList
	 */
	public List<Audit> getAuditList() {
		if(auditList == null) {
			auditList = new ArrayList<Audit>(0);
		}
		return auditList;
	}

	/**
	 * @param auditList the auditList to set
	 */
	public void setAuditList(List<Audit> auditList) {
		this.auditList = auditList;
	}


}
