package com.walmart.platform.soari.registry.common.dto;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 * The DTO class for the Service.
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name="Service")
@XmlRootElement(name = "Service")
public class Service extends BaseDTO {
	private static final long serialVersionUID = 1L;

	private String category;

	private String description;

	private String owner;

	private String name;

	private String applicationId;

	private String domain;

	private String usage;
	
	private String environment;
	
	private Boolean notificationRequested = Boolean.FALSE;
	
	@XmlElementWrapper(name = "notificationFor")
	@XmlElement(name = "notificationFor")
	private Set<String> notificationFor = null;

	@XmlElementWrapper(name = "serviceVersions")
	@XmlElement(name = "serviceVersion")
	private List<ServiceVersion> serviceVersions = null;

	@XmlElementWrapper(name = "notificationTypes")
	@XmlElement(name = "notificationType")
	private Set<String> notificationTypes = null;

	private String jiraProject;
	
	public Service() {
	}

	public String getCategory() {
		return this.category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getOwner() {
		return this.owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}

	public List<ServiceVersion> getServiceVersions() {
		if(serviceVersions == null) {
			serviceVersions = new ArrayList<ServiceVersion>(0);
		}
		return serviceVersions;
	}

	public void setServiceVersions(List<ServiceVersion> serviceVersions) {
		this.serviceVersions = serviceVersions;
	}

	public String getDomain() {
		return domain;
	}

	public void setDomain(String domain) {
		this.domain = domain;
	}

	public String getUsage() {
		return usage;
	}

	public void setUsage(String usage) {
		this.usage = usage;
	}

	/**
	 * @return the environment
	 */
	public String getEnvironment() {
		return environment;
	}

	/**
	 * @param environment the environment to set
	 */
	public void setEnvironment(String environment) {
		this.environment = environment;
	}

	/**
	 * @return the notificationRequested
	 */
	public Boolean getNotificationRequested() {
		return notificationRequested;
	}

	/**
	 * @param notificationRequested the notificationRequested to set
	 */
	public void setNotificationRequested(Boolean notificationRequested) {
		this.notificationRequested = notificationRequested;
	}

	/**
	 * @return the notificationFor
	 */
	public Set<String> getNotificationFor() {
		if(notificationFor == null) {
			notificationFor = new HashSet<String>(0);
		}
		return notificationFor;
	}

	/**
	 * @param notificationFor the notificationFor to set
	 */
	public void setNotificationFor(Set<String> notificationFor) {
		this.notificationFor = notificationFor;
	}

	/**
	 * @return the notificationTypes
	 */
	public Set<String> getNotificationTypes() {
		if(notificationTypes == null) {
			notificationTypes = new HashSet<String>(0);
		}
		return notificationTypes;
	}

	/**
	 * @param notificationTypes the notificationTypes to set
	 */
	public void setNotificationTypes(Set<String> notificationTypes) {
		this.notificationTypes = notificationTypes;
	}

	/**
	 * @return the jiraProject
	 */
	public String getJiraProject() {
		return jiraProject;
	}

	/**
	 * @param jiraProject the jiraProject to set
	 */
	public void setJiraProject(String jiraProject) {
		this.jiraProject = jiraProject;
	}

	@Override
	public String toString() {
		return "Service [category=" + category + ", description=" + description
				+ ", owner=" + owner + ", name=" + name + ", applicationId="
				+ applicationId + ", domain=" + domain + ", usage=" + usage
				+ ", environment=" + environment + ", notificationRequested="
				+ notificationRequested + ", notificationFor="
				+ notificationFor + ", serviceVersions=" + serviceVersions
				+ ", notificationTypes=" + notificationTypes + ", jiraProject="
				+ jiraProject + "]";
	}

	
}