package com.walmart.platform.soari.registry.common.dto;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

/**
 * The DTO class for the ServiceVersionDetail.
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ServiceVersion")
@XmlRootElement(name = "ServiceVersion")
public class ServiceVersion extends BaseDTO {
	private static final long serialVersionUID = 1L;

	@XmlJavaTypeAdapter(TimestampAdapter.class)
	private Timestamp activationEndDate;

	@XmlJavaTypeAdapter(TimestampAdapter.class)
	private Timestamp activationStartDate;

	private String availabilityTier;

	private String esbReference;

	@XmlElementWrapper(name = "urls")
	@XmlElement(name = "url")
	private List<Url> urls = null;

	private String environment;

	@XmlJavaTypeAdapter(TimestampAdapter.class)
	private Timestamp publicationDate;

	private String serVersion;

	@XmlElementWrapper(name = "qosParameters")
	@XmlElement(name = "qosParameter")
	private List<QoS> qosParameters = null;

	@XmlElementWrapper(name = "policies")
	@XmlElement(name = "policy")
	private List<Policy> policies = null;

	@XmlElementWrapper(name = "attributes")
	@XmlElement(name = "attribute")
	private List<Attribute> attributes = null;

	@XmlElementWrapper(name = "consumerSubscriptions")
	@XmlElement(name = "consumerSubscription")
	private List<ConsumerSubscription> consumerSubscriptions;

	public ServiceVersion() {
	}

	public Timestamp getActivationEndDate() {
		return activationEndDate;
	}

	public void setActivationEndDate(Timestamp activationEndDate) {
		this.activationEndDate = activationEndDate;
	}

	public Timestamp getActivationStartDate() {
		return activationStartDate;
	}

	public void setActivationStartDate(Timestamp activationStartDate) {
		this.activationStartDate = activationStartDate;
	}

	public String getEnvironment() {
		return this.environment;
	}

	public void setEnvironment(String environment) {
		this.environment = environment;
	}

	public String getEsbReference() {
		return esbReference;
	}

	public void setEsbReference(String esbReference) {
		this.esbReference = esbReference;
	}

	public Timestamp getPublicationDate() {
		return publicationDate;
	}

	public void setPublicationDate(Timestamp publicationDate) {
		this.publicationDate = publicationDate;
	}

	public List<QoS> getQoSParameters() {
		if (qosParameters == null) {
			qosParameters = new ArrayList<QoS>(0);
		}
		return this.qosParameters;
	}

	public void setQoSParameters(List<QoS> qosParameters) {
		this.qosParameters = qosParameters;
	}

	public List<Policy> getPolicies() {
		if (policies == null) {
			policies = new ArrayList<Policy>(0);
		}
		return this.policies;
	}

	public void setPolicies(List<Policy> policies) {
		this.policies = policies;
	}

	public List<Url> getUrls() {
		if (urls == null) {
			urls = new ArrayList<Url>(0);
		}
		return urls;
	}

	public void setUrls(List<Url> urls) {
		this.urls = urls;
	}

	public String getSerVersion() {
		return serVersion;
	}

	public void setSerVersion(String serVersion) {
		this.serVersion = serVersion;
	}

	public String getAvailabilityTier() {
		return availabilityTier;
	}

	public void setAvailabilityTier(String availabilityTier) {
		this.availabilityTier = availabilityTier;
	}

	/**
	 * @return the attributes
	 */
	public List<Attribute> getAttributes() {
		if (attributes == null) {
			attributes = new ArrayList<Attribute>(0);
		}
		return attributes;
	}

	/**
	 * @param attributes
	 *            the attributes to set
	 */
	public void setAttributes(List<Attribute> attributes) {
		this.attributes = attributes;
	}

	/**
	 * Gets the list of consumerSubscriptions.
	 * 
	 * @return
	 */
	public List<ConsumerSubscription> getConsumerSubscriptions() {
		if (consumerSubscriptions == null) {
			consumerSubscriptions = new ArrayList<ConsumerSubscription>(0);
		}
		return consumerSubscriptions;
	}

	/**
	 * Sets the list of ConsumerSubscription.
	 * 
	 * @param consumerSubscriptions
	 */
	public void setConsumerSubscriptions(
			List<ConsumerSubscription> consumerSubscriptions) {
		this.consumerSubscriptions = consumerSubscriptions;
	}

	@Override
	public String toString() {
		return "ServiceVersion [activationEndDate=" + activationEndDate
				+ ", activationStartDate=" + activationStartDate
				+ ", availabilityTier=" + availabilityTier + ", esbReference="
				+ esbReference + ", urls=" + urls + ", environment="
				+ environment + ", publicationDate=" + publicationDate
				+ ", serVersion=" + serVersion + ", qosParameters="
				+ qosParameters + ", policies=" + policies + ", attributes="
				+ attributes + ", consumerSubscriptions="
				+ consumerSubscriptions + "]";
	}

	/*@Override
	public String toString() {
		return this.getId() + ":" + this.serVersion;
	}*/
	
}