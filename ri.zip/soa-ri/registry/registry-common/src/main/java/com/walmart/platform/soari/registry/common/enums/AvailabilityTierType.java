package com.walmart.platform.soari.registry.common.enums;

public enum AvailabilityTierType {
	TIER1, TIER2, TIER3, SDC, NDC, EDC
}
