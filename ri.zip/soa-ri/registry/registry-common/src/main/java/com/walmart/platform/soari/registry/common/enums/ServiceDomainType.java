package com.walmart.platform.soari.registry.common.enums;

public enum ServiceDomainType {
	B2C, B2B, B2E
}
