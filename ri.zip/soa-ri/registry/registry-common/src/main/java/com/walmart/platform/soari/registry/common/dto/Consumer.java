package com.walmart.platform.soari.registry.common.dto;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 * The DTO class for the CONSUMER
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name="Consumer")
@XmlRootElement(name = "Consumer")
public class Consumer extends BaseDTO {
	/**
	 * class version ID for serialization
	 */
	private static final long serialVersionUID = 1L;

	private String consumerId;
	private List<Subscription> subscriptions = null;
	
	/**
	 * no-arg constructor
	 */
	public Consumer() {
	}

	
	/**
	 * @return the consumerId
	 */
	public String getConsumerId() {
		return consumerId;
	}


	/**
	 * @param consumerId the consumerId to set
	 */
	public void setConsumerId(String consumerId) {
		this.consumerId = consumerId;
	}


	/**
	 * @return the subscriptions
	 */
	public List<Subscription> getSubscriptions() {
		if(subscriptions == null) {
			subscriptions = new ArrayList<Subscription>(0);
		}
		return subscriptions;
	}


	/**
	 * @param subscriptions the subscriptions to set
	 */
	public void setSubscriptions(List<Subscription> subscriptions) {
		this.subscriptions = subscriptions;
	}

	/**
	 * over-ridden implements of Object's toString()
	 */
	@Override
	public String toString() {
		return "Consumer [consumerId=" + consumerId + ", subscriptions="
				+ subscriptions + "]";
	}


	
}