package com.walmart.platform.soari.registry.common.dto;

import java.io.Serializable;


public class ServiceSearchBean implements Serializable  {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * 
	 */
	private String category;
	private String description;
	private String owner;
	private String name;
	private String applicationId;
	private String domain;
	private String usage;
	private String environment;
	private String esbReference;
	private String serVersion;
	private String availabilityTier;
	private String versionStatus;
	private String consumerId;
	private String communicationType;
	private String subscriptonStatus;
	private String status;
	
	
	public String getStatus() {
		return status;
	}
	
	public void setStatus(String status) {
		this.status = status;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}

	public String getDomain() {
		return domain;
	}

	public void setDomain(String domain) {
		this.domain = domain;
	}

	public String getUsage() {
		return usage;
	}

	public void setUsage(String usage) {
		this.usage = usage;
	}

	public String getEnvironment() {
		return environment;
	}

	public void setEnvironment(String environment) {
		this.environment = environment;
	}

	public String getEsbReference() {
		return esbReference;
	}

	public void setEsbReference(String esbReference) {
		this.esbReference = esbReference;
	}

	public String getSerVersion() {
		return serVersion;
	}

	public void setSerVersion(String serVersion) {
		this.serVersion = serVersion;
	}

	public String getAvailabilityTier() {
		return availabilityTier;
	}

	public void setAvailabilityTier(String availabilityTier) {
		this.availabilityTier = availabilityTier;
	}

	public String getVersionStatus() {
		return versionStatus;
	}

	public void setVersionStatus(String versionStatus) {
		this.versionStatus = versionStatus;
	}

	/**
	 * @return the consumerId
	 */
	public String getConsumerId() {
		return consumerId;
	}

	/**
	 * @param consumerId
	 *            the consumerId to set
	 */
	public void setConsumerId(String consumerId) {
		this.consumerId = consumerId;
	}

	/**
	 * @return the communicationType
	 */
	public String getCommunicationType() {
		return communicationType;
	}

	/**
	 * @param communicationType
	 *            the communicationType to set
	 */
	public void setCommunicationType(String communicationType) {
		this.communicationType = communicationType;
	}

	/**
	 * @return the subscriptonStatus
	 */
	public String getSubscriptonStatus() {
		return subscriptonStatus;
	}

	/**
	 * @param subscriptonStatus
	 *            the subscriptonStatus to set
	 */
	public void setSubscriptonStatus(String subscriptonStatus) {
		this.subscriptonStatus = subscriptonStatus;
	}

}
