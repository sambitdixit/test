package com.walmart.platform.soari.registry.common.enums;

public enum EnvironmentType {
	DEV, QA, BUILD
}
