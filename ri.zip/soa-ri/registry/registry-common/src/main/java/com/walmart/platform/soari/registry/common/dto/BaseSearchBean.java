package com.walmart.platform.soari.registry.common.dto;

import java.io.Serializable;


public class BaseSearchBean implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String status;
	
	/**
	 * getter for status
	 * 
	 * @return status
	 */
	public String getStatus() {
		return status;
	}
	
	/**
	 * setter for status
	 * 
	 * @param status
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	
}
