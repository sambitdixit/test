package com.walmart.platform.soari.registry.common.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Policies
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "PolicyList")
public class PolicyList implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@XmlElementWrapper(name = "policies")
	@XmlElement(name = "policy")
	private List<Policy> policies = null;

	public PolicyList() {

	}

	public PolicyList(List<Policy> policies) {
		this.policies = policies;
	}

	
	public List<Policy> getPolicies() {
		if(policies == null) {
			policies = new ArrayList<Policy>(0);
		}
		return policies;
	}

	public void setPolicies(List<Policy> policies) {
		this.policies = policies;
	}

	@Override
	public String toString() {
		return "PolicyList [policies=" + policies + "]";
	}

}
