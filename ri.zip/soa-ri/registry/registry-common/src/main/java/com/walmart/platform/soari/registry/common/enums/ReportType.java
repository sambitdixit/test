package com.walmart.platform.soari.registry.common.enums;

public enum ReportType {
	SERVICES_PER_ENVIRONMENT("Services Per Environment"), 
	SERVICE_CATEGORIES_PER_ENVIRONMENT("Services In Category Per Environment"), 
	SERVICES_PER_MONTH("Services Registered Per Month"), 
	ENVIRONMENTS_PER_SERVICE("Environments Services Registered In"), 
	CONSUMERS_PER_ENVIRONMENT("Consumers Per Environment"), 
	CUNSUMER_SUBSCRIPTIONS_PER_ENVIRONMENT("Consumer Subscription Per Environment"),
	CONSUMER_SUBSCRIPTIONS_PER_SERVICE("Consumer Subscription Per Service"),
	SERVICES_PER_CONSUMER("Services Per Consumer"), 
	SUBSCRIPTIONS_PER_ENVIRONMENT("Subscriptions Per Environment");
	
	private String description;

	ReportType(String description) {
		this.description = description;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}


}
