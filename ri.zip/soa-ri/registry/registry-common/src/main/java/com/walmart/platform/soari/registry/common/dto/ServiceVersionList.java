package com.walmart.platform.soari.registry.common.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ServiceVersionList
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "ServiceVersionList")
public class ServiceVersionList implements Serializable {
	
	/**
	 * class version id for serialization 
	 */
	private static final long serialVersionUID = 1L;
	
	
	@XmlElementWrapper(name = "serviceVersions")
	@XmlElement(name = "serviceVersion")
	private List<ServiceVersion> serviceVersions = null;

	/**
	 * no-arg constructor
	 */
	public ServiceVersionList() {

	}

	/**
	 * Constructor
	 * 
	 * @param serviceVersionDetails
	 */
	public ServiceVersionList(List<ServiceVersion> serviceVersions) {
		this.serviceVersions = serviceVersions;
	}

	/**
	 * @return the serviceVersions
	 */
	public List<ServiceVersion> getServiceVersions() {
		if(serviceVersions == null) {
			serviceVersions = new ArrayList<ServiceVersion>(0);
		}
		return serviceVersions;
	}

	/**
	 * @param serviceVersions the serviceVersions to set
	 */
	public void setServiceVersions(List<ServiceVersion> serviceVersions) {
		this.serviceVersions = serviceVersions;
	}

}
