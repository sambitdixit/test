package com.walmart.platform.soari.registry.common.enums;

public enum QoSType {

	SLA,THROTTLING,MEDIATION,SECURITY;
}
