package com.walmart.platform.soari.registry.common.service.api;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;
import static javax.ws.rs.core.MediaType.APPLICATION_XML;
import static javax.ws.rs.core.MediaType.TEXT_XML;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

import com.walmart.platform.kernel.exception.layers.service.ServiceException;
import com.walmart.platform.soa.common.service.wrappers.ServiceRequest;
import com.walmart.platform.soa.common.service.wrappers.ServiceResponse;
import com.walmart.platform.soari.registry.common.dto.Consumer;
import com.walmart.platform.soari.registry.common.dto.ConsumerList;
import com.walmart.platform.soari.registry.common.dto.ServiceSearchBean;
import com.walmart.platform.soari.registry.common.dto.ServiceVersionSubscription;
import com.walmart.platform.soari.registry.common.dto.Subscription;
import com.walmart.platform.soari.registry.common.dto.SubscriptionList;
import com.walmart.platform.soari.registry.common.dto.SubscriptionRequest;


@Path("/registry/consumer")
public interface ConsumerService {

	/**
	 * Fetch all the consumers
	 * 
	 * @return ServiceResponse containing list of all consumers
	 * @throws ServiceException
	 */
	@GET
	@Produces({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	ServiceResponse<ConsumerList> getConsumers() throws ServiceException;

	/**
	 * Fetches a consumer by Id
	 * 
	 * @param id Identifier for consumer
	 * @return ServiceResponse containing matching consumer or null
	 * @throws ServiceException
	 */
	@GET
	@Path("/{id}")
	@Produces({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	ServiceResponse<Consumer> getConsumer(@PathParam("id") String id)
			throws ServiceException;

	/**
	 * Creates a new consumer, checks for duplicates too
	 * 
	 * @param request ServiceRequest containing new consumer to be added
	 * @return ServiceResponse containing newly added consumer or null
	 * @throws ServiceException
	 */
	@POST
	@Produces({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	@Consumes({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	ServiceResponse<Consumer> addConsumer(ServiceRequest<Consumer> request)
			throws ServiceException;

	/**
	 * Updates status of consumer identified by Consumer
	 * 
	 * @param id Identifier for Consumer
	 * @param action [activate, deactivate, delete]
	 * @param actionBy 'modifiedBy' in Entity Table
	 * @return ServiceResponse containing updated/newly created consumer or null 
	 * @throws ServiceException
	 */
	@PUT
	@Path("/{id}")
	@Produces({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	@Consumes({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	ServiceResponse<Consumer> updateConsumerStatus(
			@PathParam("id") String id,
			@QueryParam("action") String action,
			@QueryParam("actionBy") String actionBy) throws ServiceException;

	/**
	 * Method to update an existing Consumer. This will first checks if Consumer
	 * exists. Also checks if other Consumer has the same name, If Consumer doesn't
	 * exists then create a new Consumer
	 * 
	 * @param request ServiceRequest containing consumer to be updated
	 * @return ServiceResponse containing updated consumer
	 * @throws ServiceException
	 */
	@PUT
	@Produces({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	@Consumes({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	ServiceResponse<Consumer> updateConsumer(ServiceRequest<Consumer> request)
			throws ServiceException;

	/**
	 * Fetches list of all subscriptions for consumer matching 'search'
	 * 
	 * @param search 
	 * @return ServiceResponse containing list of all subscriptions for the consumer
	 * @throws ServiceException
	 */
	@GET
	@Path("/subscription/search")
	@Produces({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	ServiceResponse<SubscriptionList> searchSubscriptions(@QueryParam("")ServiceSearchBean search) throws ServiceException;

	/**
	 * Creates the subscription for the consumer identified by 'consumerId'
	 * 
	 * @param consumerId Identifier for consumer
	 * @param subscriptions Subscription to be added
	 * @return ServiceResponse containing added subscription or null
	 * @throws ServiceException
	 */
	@Path("/{consumerId}/subscription")
	@POST
	@Produces({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	@Consumes({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	ServiceResponse<Subscription> addSubscription(@PathParam("consumerId")String consumerId, ServiceRequest<SubscriptionRequest> request) throws ServiceException;

	/**
	 * Creates the subscription for the consumer identified by 'consumerId'
	 * 
	 * @param consumerId Identifier for consumer
	 * @param subscriptions Subscription to be added
	 * @return ServiceResponse containing added subscription or null
	 * @throws ServiceException
	 */
	@Path("/subscription")
	@POST
	@Produces({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	@Consumes({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	ServiceResponse<Subscription> addSubscription(ServiceRequest<ServiceVersionSubscription> request) throws ServiceException;

	/**
	 * Fetches list of all subscription belonging to consumer identified by 'consumerId'
	 * 
	 * @param consumerId Identifier for consumer
	 * @return ServiceResponse containing list of all subscriptions
	 * @throws ServiceException
	 */
	@Path("/{consumerId}/subscription")
	@GET
	@Produces({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	@Consumes({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	 ServiceResponse<SubscriptionList> getSubscriptions(@PathParam("consumerId")String consumerId) throws ServiceException;


	/**
	 * Updates status of subscription 
	 * 
	 * @param subscriptionId Identifier for subscription
	 * @param action [activate, deactivate, delete]
	 * @param actionBy 'modifiedBy' in Entity Table
	 * @return ServiceResponse containing updated subscription
	 * @throws ServiceException
	 */
	@Path("/subscription/{subscriptionId}")
	@PUT
	@Produces({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	@Consumes({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	ServiceResponse<Subscription> updateSubscriptionStatus(@PathParam("subscriptionId") String subscriptionId,
			@QueryParam("action") String action,
			@QueryParam("actionBy") String actionBy) throws ServiceException;

	/**
	 * Updates the subscription
	 * 
	 * @param request ServiceRequest containing subscription object
	 * @return ServiceResponse containing updated/newly-created subscription or null
	 * @throws ServiceException
	 */
	@Path("/subscription")
	@PUT
	@Produces({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	@Consumes({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	ServiceResponse<Subscription> updateSubscription(ServiceRequest<SubscriptionRequest> request) throws ServiceException;

	/**
	 * Removes Subscription identified by 'subscriptionId'
	 * 
	 * @param subscriptionId Identifier for subscription
	 * @param actionBy 'modifiedBy' in Entity Table
	 * @throws ServiceException
	 */
	@Path("/subscription/{subscriptionId}")
	@DELETE
	@Produces({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	@Consumes({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	ServiceResponse<Subscription> deleteSubscription(@PathParam("subscriptionId") String subscriptionId,
			@QueryParam("actionBy") String actionBy) throws ServiceException;
}