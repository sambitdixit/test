package com.walmart.platform.soari.registry.common.service.api;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;
import static javax.ws.rs.core.MediaType.APPLICATION_XML;
import static javax.ws.rs.core.MediaType.TEXT_XML;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

import com.walmart.platform.kernel.exception.layers.service.ServiceException;
import com.walmart.platform.soa.common.service.wrappers.ServiceRequest;
import com.walmart.platform.soa.common.service.wrappers.ServiceResponse;
import com.walmart.platform.soari.registry.common.dto.NotificationDestination;
import com.walmart.platform.soari.registry.common.dto.NotificationDestinationList;

@Path("/registry/notification")
public interface NotificationDestinationService {

	
	/**
	 * Fetches list of NotificationDestination with matching criteria
	 * 
	 * @param searchName Name for NotificationDestination
	 * @param searchValue matching criteria
	 * @return ServiceResponse containing list of all matching NotificationDestination
	 * @throws ServiceException
	 */
	@GET
	@Produces({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	ServiceResponse<NotificationDestinationList> searchNotificationDestinations(
			@QueryParam("name") String searchName,
			@QueryParam("value") String searchValue) throws ServiceException;

	/**
	 * Fetches list of all NotificationDestination
	 * 
	 * @return ServiceResponse containing list of all NotificationDestination
	 * @throws ServiceException
	 */
	/*
	 * @GET
	 * 
	 * @Produces({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	 */
	ServiceResponse<NotificationDestinationList> getNotificationDestinations()
			throws ServiceException;

	/**
	 * Fetches NotificationDestination by Id  
	 * @param id Identifier of NotificationDestination being searched
	 * @return ServiceResponse containing Matching NotificationDestination
	 * @throws ServiceException
	 */
	@GET
	@Path("/{notificationDestinationId}")
	@Produces({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	ServiceResponse<NotificationDestination> getNotificationDestination(
			@PathParam("notificationDestinationId") String id)
			throws ServiceException;

	/**
	 * Creates a new NotificationDestination, checks for duplicates too 
	 * 
	 * @param request ServiceRequest containing new NotificationDestination to be created
	 * @return ServiceResponse containing newly-created NotificationDestination
	 * @throws ServiceException
	 */
	@POST
	@Produces({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	@Consumes({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	ServiceResponse<NotificationDestination> addNotificationDestination(
			ServiceRequest<NotificationDestination> request)
			throws ServiceException;

	/**
	 * Updates status of NotificationDestination
	 * 
	 * @param id Identifier for NotificationDestination
	 * @param action [activate, deactivate, delete]
	 * @param actionBy 'modifiedBy' in Entity Table
	 * @return ServiceResponse containing updated NotificationDestination
	 * @throws ServiceException
	 */
	@PUT
	@Path("/{notificationDestinationId}")
	@Produces({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	@Consumes({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	ServiceResponse<NotificationDestination> updateNotificationDestinationStatus(
			@PathParam("notificationDestinationId") String notificationDestinationId,
			@QueryParam("action") String action,
			@QueryParam("actionBy") String actionBy) throws ServiceException;

	/**
	 * Updates NotificationDestination
	 * 
	 * @param request ServiceRequest containing NotificationDestination to be updated
	 * @return ServiceResponse containing updated NotificationDestination
	 * @throws ServiceException
	 */
	@PUT
	@Produces({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	@Consumes({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	ServiceResponse<NotificationDestination> updateNotificationDestination(
			ServiceRequest<NotificationDestination> request)
			throws ServiceException;
}
