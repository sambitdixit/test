package com.walmart.platform.soari.registry.common.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ConsumerList
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "ConsumerList")
public class ConsumerList implements Serializable {
private static final long serialVersionUID = 1L;
	
	@XmlElementWrapper(name = "consumers")
	@XmlElement(name = "consumer")
	private List<Consumer> consumers;

	/**
	 * @return the consumers
	 */
	public List<Consumer> getConsumers() {
		if(consumers == null) {
			consumers = new ArrayList<Consumer>(0);
		}
		return consumers;
	}

	/**
	 * @param consumers the consumers to set
	 */
	public void setConsumers(List<Consumer> consumers) {
		this.consumers = consumers;
	}
	
}
