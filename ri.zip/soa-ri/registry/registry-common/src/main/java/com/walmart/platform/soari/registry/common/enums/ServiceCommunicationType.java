package com.walmart.platform.soari.registry.common.enums;

public enum ServiceCommunicationType {
	ESB_PROXY, DIRECT, LOCAL
}
