package com.walmart.platform.soari.registry.common.service.api;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;
import static javax.ws.rs.core.MediaType.APPLICATION_XML;
import static javax.ws.rs.core.MediaType.TEXT_XML;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

import com.walmart.platform.kernel.exception.layers.service.ServiceException;
import com.walmart.platform.soa.common.service.wrappers.ServiceResponse;

@Path("/registry/healthcheck")
public interface RegistryHealthCheckService {

	/**
	 * Gets total no. of options present in RegistryPolicyCodeType
	 * 
	 * @return ServiceResponse containing no. of RegistryOptions
	 * @throws ServiceException
	 */
	@GET
	@Produces({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	ServiceResponse<Long> getOptionCount() throws ServiceException;

	@GET
	@Produces({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	@Path("/ecv")
	ServiceResponse<Integer> getCurrentEcvStatus() throws ServiceException;
	
	@GET
	@Produces({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	@Path("/updateEcv")
	ServiceResponse<Integer> updateEcvStatus(@QueryParam("status") int status) throws ServiceException;
	
}
