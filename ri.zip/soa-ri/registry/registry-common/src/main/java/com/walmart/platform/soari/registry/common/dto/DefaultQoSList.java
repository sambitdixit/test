package com.walmart.platform.soari.registry.common.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "DefaultQoSList")
public class DefaultQoSList implements Serializable {

	/**
	 * class version id for serialization
	 */
	private static final long serialVersionUID = 1L;

	@XmlElementWrapper(name = "DefaultQoSList")
	@XmlElement(name = "DefaultQos")
	private List<DefaultQoS> defaultQosList = null;

	/**
	 * @return the qosList
	 */
	public List<DefaultQoS> getQosList() {
		if(defaultQosList == null) {
			defaultQosList = new ArrayList<DefaultQoS>(0);
		}
		return defaultQosList;
	}

	/**
	 * @param qosList the qosList to set
	 */
	public void setQosList(List<DefaultQoS> qosList) {
		this.defaultQosList = qosList;
	}

}
