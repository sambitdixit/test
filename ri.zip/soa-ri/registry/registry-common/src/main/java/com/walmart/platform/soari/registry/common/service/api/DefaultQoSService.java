package com.walmart.platform.soari.registry.common.service.api;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;
import static javax.ws.rs.core.MediaType.APPLICATION_XML;
import static javax.ws.rs.core.MediaType.TEXT_XML;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

import com.walmart.platform.kernel.exception.layers.service.ServiceException;
import com.walmart.platform.soa.common.service.wrappers.ServiceRequest;
import com.walmart.platform.soa.common.service.wrappers.ServiceResponse;
import com.walmart.platform.soari.registry.common.dto.DefaultQoS;
import com.walmart.platform.soari.registry.common.dto.DefaultQoSList;

@Path("/registry/default/qos")
public interface DefaultQoSService {
	
	/**
	 * Fetch QoS by matching name
	 *
	 * @param name Name of the QoS being searched
	 * @param value Matching criteria
	 * @return ServiceReposne containing matching QoS
	 * @throws BusinessException
	 */
	@GET
	@Produces({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	ServiceResponse<DefaultQoSList> searchQoS(@QueryParam("name") String name, @QueryParam("value") String value) throws ServiceException;

	/**
	 * Fetches all existing QoS
	 * 
	 * @return ServiceResponse containing a list of all existing QoS
	 * @throws BusinessException
	 */
	/*@GET
	@Produces({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })*/
	ServiceResponse<DefaultQoSList> getQoS() throws ServiceException;

	/**
	 * Fetches a QoS by Id
	 * 
	 * @param id Identifier of the QoS being searched
	 * @return ServiceResponse contains QoS matched by id
	 * @throws BusinessException
	 */
	@GET
	@Path("/{id}")
	@Produces({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	ServiceResponse<DefaultQoS> getQoS(@PathParam("id") String id) throws ServiceException;
	
	/**
	 * Fetch QoS by matching name
	 *
	 * @param name Name of the QoS being searched
	 * @param value Matching criteria
	 * @return ServiceReposne containing matching QoS
	 * @throws BusinessException
	 */
	@POST
	@Produces({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	@Consumes({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	ServiceResponse<DefaultQoS> addQoS(
			 ServiceRequest<DefaultQoS> request)
			throws ServiceException;
	
	/**
	 * updates the status of QoS
	 * 
	 * @param id unique identifier for the QoS
	 * @param action [activate, deactivate, delete]
	 * @param actionBy 'modifiedBy' in Entity Table
	 * @return ServiceResponse containing updated/newly-created QoS
	 * @throws BusinessException
	 */
	@PUT
	@Path("/{id}")
	@Produces({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	@Consumes({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	ServiceResponse<DefaultQoS> updateQoSStatus(@PathParam("id")String qosId, @QueryParam("action")String action, @QueryParam("actionBy")String actionBy)
			throws ServiceException;
	
	/**
	 * Method to update an existing QoS. This will first checks if QoS exists.
	 * Also checks if other QoS has the same name, If QoS doesn't exists then
	 * create a new QoS
	 * 
	 * @param qos QoS to be updated
	 * @return ServiceResponse containing updated/newly-created QoS
	 * @throws BusinessException
	 */
	@PUT
	@Produces({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	@Consumes({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	ServiceResponse<DefaultQoS> updateQoS(ServiceRequest<DefaultQoS> request)
			throws ServiceException;

}

