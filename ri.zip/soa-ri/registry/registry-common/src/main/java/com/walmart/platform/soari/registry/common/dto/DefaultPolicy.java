package com.walmart.platform.soari.registry.common.dto;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 * The DTO class for the POLICY
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name="DefaultPolicy")
@XmlRootElement(name = "DefaultPolicy")
public class DefaultPolicy implements Serializable {
	private static final long serialVersionUID = 1L;

	private String name;

	private String description;
	
	private String type;
	
	private String data;
	
	private Integer order;
	
	private String flow;
	
	private String context;
	
	private String id;
	 
	private String status;
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public DefaultPolicy() {
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * @return the data
	 */
	public String getData() {
		return data;
	}

	/**
	 * @param data the data to set
	 */
	public void setData(String data) {
		this.data = data;
	}

	/**
	 * @return the order
	 */
	public Integer getOrder() {
		return order;
	}

	/**
	 * @param order the order to set
	 */
	public void setOrder(Integer order) {
		this.order = order;
	}

	
	/**
	 * @return the flow
	 */
	public String getFlow() {
		return flow;
	}

	/**
	 * @param flow the flow to set
	 */
	public void setFlow(String flow) {
		this.flow = flow;
	}

	/**
	 * @return the context
	 */
	public String getContext() {
		return context;
	}

	/**
	 * @param context the context to set
	 */
	public void setContext(String context) {
		this.context = context;
	}

	@Override
	public String toString() {
		return "DefaultPolicy [name=" + name + ", description=" + description
				+ ", type=" + type + ", data=" + data + ", order=" + order
				+ ", flow=" + flow + ", context=" + context + ", id=" + id
				+ ", status=" + status + "]";
	}

	
}