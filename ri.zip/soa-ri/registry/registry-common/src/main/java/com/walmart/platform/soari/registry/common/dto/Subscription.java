package com.walmart.platform.soari.registry.common.dto;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 * The DTO class for the Subscription
 * 
 */
@XmlRootElement(name = "Subscription")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name="Subscription")
//public class Subscription extends BaseDTO {
public class Subscription extends SubscriptionRequest {
	
	/**
	 * class version id for serialization
	 */
	private static final long serialVersionUID = 1L;
	//private String serviceVersionId;
	private String versionNumber;
	private String serviceName;
	private String serviceId;
	private String environment;
	//private String communicationType;
	//private String consumerId;
	private String requestUrl;
	
	private String applicationId;
	private String serviceStatus;
	private String serviceCategory;
	private String serviceUsage;
	private String serviceDomain;
	private String serviceOwner;
	private String serviceVersionStatus;
	
	@XmlElementWrapper(name = "alternateUrls")
	@XmlElement(name = "alternateUrl")
	private List<String> alternateUrls = null;
	
	@XmlElementWrapper(name="qosParameters")
	@XmlElement(name="qosParameter")
	private List<QoS> qosParameters = null;
	
	@XmlElementWrapper(name="policies")
	@XmlElement(name="policy")
	private List<Policy> policies = null;

	@XmlElementWrapper(name="attributes")
	@XmlElement(name="attribute")
	private List<Attribute> attributes = null;

	public Subscription() {
		super();
		this.setStatus("INACTIVE");
	}
	/**
	 * @return the serviceVersionId
	 */
	public String getServiceVersionId() {
		return serviceVersionId;
	}
	/**
	 * @param serviceVersionId the serviceVersionId to set
	 */
	public void setServiceVersionId(String serviceVersionId) {
		this.serviceVersionId = serviceVersionId;
	}
	/**
	 * @return the versionNumber
	 */
	public String getVersionNumber() {
		return versionNumber;
	}
	/**
	 * @param versionNumber the versionNumber to set
	 */
	public void setVersionNumber(String versionNumber) {
		this.versionNumber = versionNumber;
	}
	/**
	 * @return the serviceName
	 */
	public String getServiceName() {
		return serviceName;
	}
	/**
	 * @param serviceName the serviceName to set
	 */
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}
	/**
	 * @return the environment
	 */
	public String getEnvironment() {
		return environment;
	}
	/**
	 * @param environment the environment to set
	 */
	public void setEnvironment(String environment) {
		this.environment = environment;
	}
	/**
	 * @return the consumerId
	 */
	public String getConsumerId() {
		return consumerId;
	}
	/**
	 * @return the communicationType
	 */
	public String getCommunicationType() {
		return communicationType;
	}
	/**
	 * @param communicationType the communicationType to set
	 */
	public void setCommunicationType(String communicationType) {
		this.communicationType = communicationType;
	}
	/**
	 * @param consumerId the consumerId to set
	 */
	public void setConsumerId(String consumerId) {
		this.consumerId = consumerId;
	}
	/**
	 * @return the serviceId
	 */
	public String getServiceId() {
		return serviceId;
	}
	/**
	 * @param serviceId the serviceId to set
	 */
	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}
	/**
	 * @return the requestUrl
	 */
	public String getRequestUrl() {
		return requestUrl;
	}
	/**
	 * @param requestUrl the requestUrl to set
	 */
	public void setRequestUrl(String requestUrl) {
		this.requestUrl = requestUrl;
	}
	/**
	 * @return the qosParameters
	 */
	public List<QoS> getQosParameters() {
		if(qosParameters == null) {
			qosParameters = new ArrayList<QoS>(0);
		}
		return qosParameters;
	}
	/**
	 * @param qosParameters the qosParameters to set
	 */
	public void setQosParameters(List<QoS> qosParameters) {
		this.qosParameters = qosParameters;
	}
	/**
	 * @return the policies
	 */
	public List<Policy> getPolicies() {
		if(policies == null) {
			policies = new ArrayList<Policy>(0);
		}
		return policies;
	}
	/**
	 * @param policies the policies to set
	 */
	public void setPolicies(List<Policy> policies) {
		this.policies = policies;
	}
	/**
	 * @return the attributes
	 */
	public List<Attribute> getAttributes() {
		if(attributes == null) {
			attributes = new ArrayList<Attribute>(0);
		}
		return attributes;
	}
	/**
	 * @param attributes the attributes to set
	 */
	public void setAttributes(List<Attribute> attributes) {
		this.attributes = attributes;
	}
	/**
	 * @return the alternateUrls
	 */
	public List<String> getAlternateUrls() {
		if(alternateUrls == null) {
			alternateUrls = new ArrayList<String>(0);
		}
		return alternateUrls;
	}
	/**
	 * @param alternateUrls the alternateUrls to set
	 */
	public void setAlternateUrls(List<String> alternateUrls) {
		this.alternateUrls = alternateUrls;
	}
	/**
	 * @return the applicationId
	 */
	public String getApplicationId() {
		return applicationId;
	}
	/**
	 * @param applicationId the applicationId to set
	 */
	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}
	/**
	 * @return the serviceStatus
	 */
	public String getServiceStatus() {
		return serviceStatus;
	}
	/**
	 * @param serviceStatus the serviceStatus to set
	 */
	public void setServiceStatus(String serviceStatus) {
		this.serviceStatus = serviceStatus;
	}
	/**
	 * @return the serviceCategory
	 */
	public String getServiceCategory() {
		return serviceCategory;
	}
	/**
	 * @param serviceCategory the serviceCategory to set
	 */
	public void setServiceCategory(String serviceCategory) {
		this.serviceCategory = serviceCategory;
	}
	/**
	 * @return the serviceUsage
	 */
	public String getServiceUsage() {
		return serviceUsage;
	}
	/**
	 * @param serviceUsage the serviceUsage to set
	 */
	public void setServiceUsage(String serviceUsage) {
		this.serviceUsage = serviceUsage;
	}
	/**
	 * @return the serviceDomain
	 */
	public String getServiceDomain() {
		return serviceDomain;
	}
	/**
	 * @param serviceDomain the serviceDomain to set
	 */
	public void setServiceDomain(String serviceDomain) {
		this.serviceDomain = serviceDomain;
	}
	/**
	 * @return the serviceOwner
	 */
	public String getServiceOwner() {
		return serviceOwner;
	}
	/**
	 * @param serviceOwner the serviceOwner to set
	 */
	public void setServiceOwner(String serviceOwner) {
		this.serviceOwner = serviceOwner;
	}
	/**
	 * @return the serviceVersionStatus
	 */
	public String getServiceVersionStatus() {
		return serviceVersionStatus;
	}
	/**
	 * @param serviceVersionStatus the serviceVersionStatus to set
	 */
	public void setServiceVersionStatus(String serviceVersionStatus) {
		this.serviceVersionStatus = serviceVersionStatus;
	}
	
}
