package com.walmart.platform.soari.registry.common.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 * The DTO class for the POLICY
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name="QoS")
@XmlRootElement(name = "QoS")
public class QoS extends BaseDTO {
	/**
	 * class version id for serialization
	 */
	private static final long serialVersionUID = 1L;
	private String name;
	private String description;
	private String type;
	private String value;

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 *            the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description
	 *            the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type
	 *            the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}
	
	/**
	 * @return the value
	 */
	public String getValue() {
		return value;
	}

	/**
	 * @param value the value to set
	 */
	public void setValue(String value) {
		this.value = value;
	}

	@Override
	public String toString() {
		return "QoS [name=" + name + ", description=" + description + ", type="
				+ type + ", value=" + value + "]";
	}

	
	
}
