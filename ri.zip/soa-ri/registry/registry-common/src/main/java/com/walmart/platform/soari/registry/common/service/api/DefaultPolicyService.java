package com.walmart.platform.soari.registry.common.service.api;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;
import static javax.ws.rs.core.MediaType.APPLICATION_XML;
import static javax.ws.rs.core.MediaType.TEXT_XML;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

import com.walmart.platform.kernel.exception.layers.service.ServiceException;
import com.walmart.platform.soa.common.service.wrappers.ServiceRequest;
import com.walmart.platform.soa.common.service.wrappers.ServiceResponse;
import com.walmart.platform.soari.registry.common.dto.DefaultPolicyList;
import com.walmart.platform.soari.registry.common.dto.DefaultPolicy;


@Path("/registry/default/policy")
public interface DefaultPolicyService {

	/**
	 * Fetches list of policies by matching name 
	 * 
	 * @param searchName Name of the policy being searched for
	 * @param searchValue Matching criteria
	 * @return ServiceResponse containing list of policies matching criteria
	 * @throws ServiceException
	 */
	@GET
	@Produces({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	ServiceResponse<DefaultPolicyList> searchPolicies(
			@QueryParam("name") String searchName,
			@QueryParam("value") String searchValue) throws ServiceException;

	/**
	 * Fetches all the policies
	 * 
	 * @return ServiceResponse containing list of all policies
	 * @throws ServiceException
	 */
	/*
	 * @GET
	 * 
	 * @Produces({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	 */
	ServiceResponse<DefaultPolicyList> getPolicies() throws ServiceException;
	
	/**
	 * Fetches policy by id
	 * 
	 * @param id Identifier for DefaultPolicy being searched
	 * @return ServiceResponse containing matched policy or null
	 * @throws ServiceException
	 */
	@GET
	@Path("/{policyId}")
	@Produces({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	ServiceResponse<DefaultPolicy> getPolicy(@PathParam("policyId") String id)
			throws ServiceException;

	/**
	 * Creates a new policy, checks for duplicates
	 * 
	 * @param ServiceReqest containing policy to be added
	 * @return ServiceResponse containing newly-added policy or null
	 * @throws ServiceException
	 */
	@POST
	@Produces({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	@Consumes({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	ServiceResponse<DefaultPolicy> addPolicy(ServiceRequest<DefaultPolicy> request)
			throws ServiceException;

	/**
	 * Updates policy status 
	 * 
	 * @param id Identifier for DefaultPolicy
	 * @param action [activate, deactivate, delete]
	 * @param actionBy 'modifiedBy' in Entity Table
	 * @return ServiceResponse containing updated DefaultPolicy
	 * @throws ServiceException
	 */
	@PUT
	@Path("/{policyId}")
	@Produces({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	@Consumes({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	ServiceResponse<DefaultPolicy> updatePolicyStatus(
			@PathParam("policyId") String policyId,
			@QueryParam("action") String action,
			@QueryParam("actionBy") String actionBy) throws ServiceException;

	/**
	 * Updates a policy 
	 * 
	 * @param ServiceReqest containing policy to be updated
	 * @return ServiceResponse containing updated/newly-created policy or null
	 * @throws ServiceException
	 */
	@PUT
	@Produces({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	@Consumes({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	ServiceResponse<DefaultPolicy> updatePolicy(ServiceRequest<DefaultPolicy> request)
			throws ServiceException;

}