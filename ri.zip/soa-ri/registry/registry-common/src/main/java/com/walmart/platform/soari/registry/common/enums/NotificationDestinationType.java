package com.walmart.platform.soari.registry.common.enums;

public enum NotificationDestinationType {
	JMS, ZK, EMAIL, JIRA
}
