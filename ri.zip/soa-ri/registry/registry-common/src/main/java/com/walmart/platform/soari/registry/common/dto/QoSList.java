package com.walmart.platform.soari.registry.common.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "QoSList")
public class QoSList implements Serializable {

	/**
	 * class version id for serialization
	 */
	private static final long serialVersionUID = 1L;

	@XmlElementWrapper(name = "qosList")
	@XmlElement(name = "qos")
	private List<QoS> qosList = null;

	/**
	 * @return the qosList
	 */
	public List<QoS> getQosList() {
		if(qosList == null) {
			qosList = new ArrayList<QoS>(0);
		}
		return qosList;
	}

	/**
	 * @param qosList the qosList to set
	 */
	public void setQosList(List<QoS> qosList) {
		this.qosList = qosList;
	}

}
