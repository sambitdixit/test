package com.walmart.platform.soari.registry.common.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Policies
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "RegistryOptionList")
public class RegistryOptionList implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@XmlElementWrapper(name = "options")
	@XmlElement(name = "option")
	private List<RegistryOption> options = null;

	public RegistryOptionList() {

	}

	public List<RegistryOption> getOptions() {
		if(options == null) {
			options = new ArrayList<RegistryOption>(0);
		}
		return options;
	}


	public void setOptions(List<RegistryOption> options) {
		this.options = options;
	}

	@Override
	public String toString() {
		return "RegistryOptionList [options=" + options + "]";
	}
	
	

}
