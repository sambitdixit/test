package com.walmart.platform.soari.registry.common.enums;

public enum UrlType {
	ENDPOINT, ENDPOINT_ALTERNATE, ESB_PROXY, CONTRACT, API_DOC, API_SAMPLE_CLIENT_CODE, ESB_ALTERNATE, LOCAL_ENDPOINT;
}
