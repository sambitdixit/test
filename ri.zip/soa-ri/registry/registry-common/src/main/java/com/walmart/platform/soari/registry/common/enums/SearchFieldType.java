package com.walmart.platform.soari.registry.common.enums;

public enum SearchFieldType {
	CATEGORY, DESCRIPTION, OWNER, DOMAIN, USAGE, NAME, STATUS, AVAILABILITY_TIER, ESB_REFERENCE, APPLICATION, ENVIRONMENT
}
