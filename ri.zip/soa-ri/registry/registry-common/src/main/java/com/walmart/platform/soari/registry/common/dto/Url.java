package com.walmart.platform.soari.registry.common.dto;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "Url")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Url")
public class Url implements Serializable {

	/**
	 * class version id for serialization
	 */
	private static final long serialVersionUID = 1L;
	private String id;
	private String url;
	private String type;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	@Override
	public String toString() {
		return "Url [id=" + id + ", url=" + url + ", type=" + type + "]";
	}
	
	
}
