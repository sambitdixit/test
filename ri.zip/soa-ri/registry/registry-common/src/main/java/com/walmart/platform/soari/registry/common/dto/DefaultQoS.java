package com.walmart.platform.soari.registry.common.dto;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 * The DTO class for the POLICY
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name="DefaultQoS")
@XmlRootElement(name = "DefaultQoS")
public class DefaultQoS implements Serializable {
	/**
	 * class version id for serialization
	 */
	private static final long serialVersionUID = 1L;
	private String name;
	private String description;
	private String type;
	private String value;
	private String environment;
	private String category;
	private String status;
	private String id;
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getEnvironment() {
		return environment;
	}

	public void setEnvironment(String environment) {
		this.environment = environment;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 *            the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description
	 *            the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type
	 *            the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}
	
	/**
	 * @return the value
	 */
	public String getValue() {
		return value;
	}

	/**
	 * @param value the value to set
	 */
	public void setValue(String value) {
		this.value = value;
	}

	@Override
	public String toString() {
		return "DefaultQoS [name=" + name + ", description=" + description
				+ ", type=" + type + ", value=" + value + ", environment="
				+ environment + ", category=" + category + ", status=" + status
				+ "]";
	}	
}
