package com.walmart.platform.soari.registry.common.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * SubscriptionList
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "SubscriptionList")
public class SubscriptionList implements Serializable {

	/**
	 * class version id for serialization
	 */
	private static final long serialVersionUID = 1L;
	
	@XmlElementWrapper(name = "subscriptions")
	@XmlElement(name = "subscription")
	private List<Subscription> subscriptions = null;

	/**
	 * @return the subscriptions
	 */
	public List<Subscription> getSubscriptions() {
		if(subscriptions == null) {
			subscriptions = new ArrayList<Subscription>(0);
		}
		return subscriptions;
	}

	/**
	 * @param subscriptions the subscriptions to set
	 */
	public void setSubscriptions(List<Subscription> subscriptions) {
		this.subscriptions = subscriptions;
	}

	
}
