package com.walmart.platform.soari.registry.common.enums;

public enum PolicyType {
	SECURITY, SLA, THROTTLING, MEDIATION;
}
