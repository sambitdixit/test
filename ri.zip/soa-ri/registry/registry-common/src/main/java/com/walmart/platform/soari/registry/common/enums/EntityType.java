	package com.walmart.platform.soari.registry.common.enums;

public enum EntityType {
	DEFAULT_POLICY,POLICY, SERVICE, SRVC_VERSION, QoS_PARAMETER, AUDIT, DEFAULT_QoS, QoS, NOTIFICATION_DESTINATION, CONSUMER, SUBSCRIPTION
}
