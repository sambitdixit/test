package com.walmart.platform.soari.registry.common.service.api;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;
import static javax.ws.rs.core.MediaType.APPLICATION_XML;
import static javax.ws.rs.core.MediaType.TEXT_XML;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

import com.walmart.platform.kernel.exception.layers.service.ServiceException;
import com.walmart.platform.soa.common.service.wrappers.ServiceRequest;
import com.walmart.platform.soa.common.service.wrappers.ServiceResponse;
import com.walmart.platform.soari.registry.common.dto.PolicyList;
import com.walmart.platform.soari.registry.common.dto.QoS;
import com.walmart.platform.soari.registry.common.dto.QoSList;
import com.walmart.platform.soari.registry.common.dto.Service;
import com.walmart.platform.soari.registry.common.dto.ServiceList;
import com.walmart.platform.soari.registry.common.dto.ServiceSearchBean;
import com.walmart.platform.soari.registry.common.dto.ServiceVersion;

@Path("/registry")
public interface RegistryService {

	/**
	 * Fetches all the services
	 * 
	 * @return ServiceResponse containing list of all services
	 * @throws ServiceException
	 */
	@GET
	@Produces({ "application/json", "application/xml", "text/json","text/xml" })
	ServiceResponse<ServiceList> getServices() throws ServiceException;
	
	String SERVICE_ID = "serviceId";
	String SERVICE_VERSION_ID = "serviceVersionId";
	
	/**
	 * Fetches a service by id
	 * 
	 * @param id Identifier for service
	 * @return ServiceResponse containing matching service or null
	 * @throws ServiceException
	 */
	@GET
	@Path("/service/{serviceId}")
	@Produces({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	ServiceResponse<Service> getService(@PathParam(SERVICE_ID) String id)
			throws ServiceException;

	/**
	 * Creates a new service
	 * Also checks for duplicates 
	 * 
	 * @param request ServiceRequest containing service to be added
	 * @return ServiceResponse containing newly-created service or null
	 * @throws ServiceException
	 */
	@POST
	@Path("/service")
	@Produces({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	@Consumes({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	ServiceResponse<Service> addService(ServiceRequest<Service> request)
			throws ServiceException;

	/**
	 * Updates an existing service or creates a new service if non-existent 
	 * 
	 * @param request ServiceRequest containing service to be updated
	 * @return ServiceResponse containing  updated/newly-created service or null
	 * @throws ServiceException
	 */
	@PUT
	@Path("/service")
	@Produces({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	@Consumes({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	ServiceResponse<Service> updateService(
			ServiceRequest<Service> request) throws ServiceException;

	/**
	 * Updates service status
	 * 
	 * @param id Identifier for the service
	 * @param action [activate, deactivate, delete]
	 * @param actionBy 'modifiedBy' in Entity Table
	 * @return ServiceResponse containing updated service or null
	 * @throws ServiceException
	 */
	@PUT
	@Path("/service/{serviceId}")
	@Produces({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	@Consumes({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	ServiceResponse<Service> updateServiceStatus(
			@PathParam(SERVICE_ID) String serviceId,
			@QueryParam("action") String action,
			@QueryParam("actionBy") String actionBy) throws ServiceException;

	/** 
	 * Fetches list of service with name matching with 'name' 
	 * Uses '%name%' pattern for matching
	 * 
	 * @param serviceName Name of service to being searched
	 * @return ServiceResponse containing list of matching services
	 * @throws ServiceException
	 */
	@GET
	@Path("/service/name/{serviceName}")
	@Produces({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	ServiceResponse<ServiceList> findServices(
			@PathParam("serviceName") String serviceName)
			throws ServiceException;

	/**
	 * Fetches list of service with matching name and criteria
	 * 
	 * @param searchName Name of service to being searched
	 * @param searchValue Matching criteria
	 * @return ServiceResponse containing list of matching services
	 * @throws ServiceException
	 */
	@GET
	@Path("/service")
	@Produces({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	ServiceResponse<ServiceList> searchServices(
			@QueryParam("name") String searchName,
			@QueryParam("value") String searchValue) throws ServiceException;

	/**
	 * Fetches list of services with matching description
	 * 
	 * @param search
	 * @return ServiceResponse containing list of matching services
	 * @throws ServiceException
	 */
	@GET
	//@Path("/search/service/")
	@Path("/service/search")
	@Produces({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	ServiceResponse<ServiceList> searchServices(@QueryParam("")ServiceSearchBean search) throws ServiceException;

	/**
	 * Fetch the service version of service identified by 'serviceId'
	 * 
	 * @param serviceId Identifier for the service
	 * @param serviceVersion  Service Version to be searched for
	 * @return ServiceResponse containing Matching service version or null
	 * @throws ServiceException
	 */
	// == APIs for Service Versions
	@GET
	@Path("/service/{serviceId}/version/{serviceVersion}")
	@Produces({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	@Consumes({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	ServiceResponse<ServiceVersion> getServiceVersion(
			@PathParam(SERVICE_ID) String serviceId,
			@PathParam("serviceVersion") String serviceVersion)
			throws ServiceException;

	/**
	 * Creates a new Service Version
	 * 
	 * @param serviceId Identifier for the service
	 * @param request ServiceRequest containing new service version to be created
	 * @return ServiceResponse containing newly-created service version or null
	 * @throws ServiceException
	 */
	@POST
	@Path("/service/{serviceId}/version")
	@Produces({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	@Consumes({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	ServiceResponse<ServiceVersion> addServiceVersion(
			@PathParam("serviceId") String serviceId,
			ServiceRequest<ServiceVersion> request) throws ServiceException;

	/**
	 * Updates service version
	 * Checks for duplicates as well
	 * 
	 * @param serviceId Identifier for the service
	 * @param ServiceRequest containing new service version for the service
	 * @return ServiceResponse containing updated service version or null
	 * @throws ServiceException
	 */
	@PUT
	@Path("/service/{serviceId}/version")
	@Produces({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	@Consumes({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	ServiceResponse<ServiceVersion> updateServiceVersion(
			@PathParam(SERVICE_ID) String serviceId,
			ServiceRequest<ServiceVersion> request) throws ServiceException;

	/**
	 * Updates the service version status
	 * 
	 * @param id Identifier for service version
	 * @param action [activate, deactivate, delete]
	 * @param actionBy 'modifiedBy' in Entity Table
	 * @return ServiceResponse containing Updated service version or null
	 * @throws ServiceException
	 */
	@PUT
	// @Path("/version/{serviceVersionId}/status/{status}")
	@Path("/service/version/{serviceVersionId}")
	@Produces({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	@Consumes({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	ServiceResponse<ServiceVersion> updateServiceVersionStatus(
			@PathParam(SERVICE_VERSION_ID) String serviceVersionId,
			@QueryParam("action") String action,
			@QueryParam("actionBy") String actionBy) throws ServiceException;

	// == APIs for Service Policies
	@GET
	@Path("/service/version/{serviceVersionId}/policy")
	@Produces({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	@Consumes({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	ServiceResponse<PolicyList> getServiceVersionPolicies(
			@PathParam(SERVICE_VERSION_ID) String serviceVersionId)
			throws ServiceException;

	@POST
	@Path("/service/version/{serviceVersionId}/policy/{policyId}")
	@Produces({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	@Consumes({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	ServiceResponse<ServiceVersion> addServiceVersionPolicy(
			@PathParam(SERVICE_VERSION_ID) String serviceVersionId,
			@PathParam("policyId") String policyId) throws ServiceException;

	@DELETE
	@Path("/service/version/{serviceVersionId}/policy/{policyId}")
	@Produces({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	@Consumes({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	ServiceResponse<ServiceVersion> deleteServiceVersionPolicy(
			@PathParam(SERVICE_VERSION_ID) String serviceVersionId,
			@PathParam("policyId") String policyId) throws ServiceException;

	// ==APIs for Service Parameters

	@GET
	@Path("/service/version/{serviceVersionId}/qos")
	@Produces({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	ServiceResponse<QoSList> getServiceVersionParameters(
			@PathParam(SERVICE_VERSION_ID) String serviceVersionId)
			throws ServiceException;

	@POST
	@Path("/service/version/{serviceVersionId}/qos")
	@Produces({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	@Consumes({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	ServiceResponse<QoS> addServiceVersionParameter(
			@PathParam(SERVICE_VERSION_ID) String serviceVersionId,
			ServiceRequest<QoS> request) throws ServiceException;

	@PUT
	@Path("/service/version/{serviceVersionId}/qos")
	@Produces({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	@Consumes({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	ServiceResponse<QoS> updateServiceVersionParameter(
			@PathParam(SERVICE_VERSION_ID) String serviceVersionId,
			ServiceRequest<QoS> request) throws ServiceException;

	@DELETE
	@Path("/service/version/{serviceVersionId}/qos/{qosId}")
	@Produces({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	@Consumes({ APPLICATION_JSON, APPLICATION_XML, TEXT_XML })
	ServiceResponse<QoS> deleteServiceVersionParameter(
			@PathParam(SERVICE_VERSION_ID) String serviceVersionId,
			@PathParam("qosId") String qosId) throws ServiceException;
	
}
