/**
 * Provides the classes necessary to transfer the data to client. 
 * 
 */
@javax.xml.bind.annotation.XmlSchema(namespace = "http://dto.common.registry.soari.platform.walmart.com", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.walmart.platform.soari.registry.common.dto;