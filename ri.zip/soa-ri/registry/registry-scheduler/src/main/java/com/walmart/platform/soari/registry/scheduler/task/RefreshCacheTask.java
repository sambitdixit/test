package com.walmart.platform.soari.registry.scheduler.task;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.walmart.platform.soari.registry.biz.api.CacheManager;

public class RefreshCacheTask {

	private static final Logger LOG = LoggerFactory
			.getLogger(RefreshCacheTask.class);

	@Autowired
	private CacheManager cacheManager;

	public void refreshCache() {
		LOG.info("Executing refreshCache");
		try {
			refreshCodeCache();
			refreshEnvCache();
			refreshArtifactCache();
			refreshJIRACache();
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
		}
	}
	
	private void refreshEnvCache() {
		LOG.info("Executing refreshEnvCache");
		try {
			cacheManager.refreshEnvCache();
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
		}
	}
	
	private void refreshCodeCache() {
		LOG.info("Executing refreshCodeCache");
		try {
			cacheManager.refreshCodeCache();
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
		}
	}
	
	private void refreshArtifactCache() {
		LOG.info("Executing refreshArtifactCache");
		try {
			cacheManager.refreshArtifactCache();
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
		}
	}
	private void refreshJIRACache() {
		LOG.info("Executing refreshJIRACache");
		try {
			cacheManager.refreshJIRACache();
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
		}
	}
}
