package com.walmart.platform.soari.registry.scheduler.task;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.testng.AbstractTransactionalTestNGSpringContextTests;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.walmart.platform.soari.registry.biz.api.RegistryOptionManager;
import com.walmart.platform.soari.registry.common.dto.RegistryOption;
import com.walmart.platform.soari.registry.common.enums.RegistryPolicyCodeType;

@ContextConfiguration(locations = { "classpath:/META-INF/schedulerContext-test.xml"})
@TransactionConfiguration(transactionManager = "transactionManager", defaultRollback = true)
public class RefreshCacheTaskTest extends AbstractTransactionalTestNGSpringContextTests{

	private static final Logger LOG = LoggerFactory
			.getLogger(RefreshCacheTask.class);

	@Autowired
	private RefreshCacheTask refreshCacheTask;
	
	@Autowired
	private RegistryOptionManager registryOptionManager;
	
	@Test
	public void testRefreshCache() {
		try {
			refreshCacheTask.refreshCache();
			Assert.assertTrue(true);
			List<RegistryOption> options = registryOptionManager.getOptionsByType(RegistryPolicyCodeType.CHANGE_TYPE);
			Assert.assertNotNull(options);
			//Assert.assertFalse(options.isEmpty());
			options = registryOptionManager.getOptionsByType(RegistryPolicyCodeType.CMDB_ENVIRONMENT);
			Assert.assertNotNull(options);
			//Assert.assertFalse(options.isEmpty());
			options = registryOptionManager.getOptionsByType(RegistryPolicyCodeType.CMDB_ARTIFACT);
			Assert.assertNotNull(options);
			//Assert.assertFalse(options.isEmpty());
		} catch (Exception ex) {
			Assert.fail(ex.getMessage());
			LOG.error(ex.getMessage());
		}
	}
}
