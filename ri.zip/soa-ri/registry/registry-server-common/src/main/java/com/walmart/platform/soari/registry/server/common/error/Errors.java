package com.walmart.platform.soari.registry.server.common.error;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import com.walmart.platform.kernel.exception.error.Error;

/**
 * A container class holding all the static error declarations
 * @author ranand
 *
 */
public class Errors {

	private Map<String,Collection<Error>> errors = new HashMap<String,Collection<Error>>();

	public Map<String, Collection<Error>> getErrors() {
		return errors;
	}

	public void setErrors(Map<String, Collection<Error>> errors) {
		this.errors = errors;
	}

}
