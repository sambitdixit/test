package com.walmart.platform.soari.registry.server.common.exception;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import org.dozer.MappingException;
import com.walmart.platform.kernel.exception.ApplicationLayer;
import com.walmart.platform.kernel.exception.error.Error;
import com.walmart.platform.kernel.exception.layers.business.BusinessException;
import com.walmart.platform.kernel.exception.layers.dao.DataAccessException;
import com.walmart.platform.soa.common.exception.ValidationException;
import com.walmart.platform.soa.common.exception.mapper.AbstractExceptionHandler;
import com.walmart.platform.soari.registry.server.common.error.ErrorCode;
import com.walmart.platform.soari.registry.server.common.util.CommonConstants;

public class ExceptionHandler extends AbstractExceptionHandler {
	
	public ExceptionHandler() {
		super();
	}

	/**
	 * handles DataAccessException
	 * @param exception thrown
	 */
	public void handleDataAccessException(Throwable cause)
			throws DataAccessException {
		Error error = null;
		if (cause instanceof RegistryDataAccessException) {
			List<Error> errors = new ArrayList<Error>(0);
			RegistryDataAccessException exception = (RegistryDataAccessException) cause;
			for (ErrorCode errorCode : exception.getErrorCodes()) {
				error = errorMapper.getError(ApplicationLayer.DAO_LAYER,
						errorCode.getErrorCode());
				setErrorInfo(error, exception);
				errors.add(error);
			}
			throw new DataAccessException("Validation exception",
					new ValidationException(errors));
		} else {
			error = errorMapper.getError(ApplicationLayer.DAO_LAYER,
					ErrorCode.DAO_UNEXPECTED_ERROR.getErrorCode());
			setErrorInfo(error, cause);
			throw new DataAccessException(error, cause.getMessage(), cause);
		}
	}

	
	/**
	 * handles BusinessException
	 * @param exception thrown
	 * @throws BusinessException
	 */
	@Override
	public void handleBusinessException(Exception ex) throws BusinessException {
		if (ex instanceof DataAccessException) {
			throw new BusinessException(ex);
		} else if (ex instanceof MappingException) {
			String error = MessageFormat.format(
					CommonConstants.DOZER_MAPPING_EXCEPTION_MESSAGE,
					ex.getMessage());
			handleBusinessException(ErrorCode.BIZ_DOZER_MAPPING.getErrorCode(), error, ex);
		} else if (ex instanceof BusinessException) {
			throw (BusinessException) ex;
		} else if (ex instanceof ServiceRegistryException) {
			ServiceRegistryException exception = (ServiceRegistryException) ex;
			handleBusinessException(exception.getCode().getErrorCode(),
					exception.getMessage(), ex);
		} else if (ex instanceof RegistryDataAccessException) {
			RegistryDataAccessException exception = (RegistryDataAccessException) ex;
			Error error = errorMapper.getError(ApplicationLayer.DAO_LAYER,
					exception.getCode().getErrorCode());
			setErrorInfo(error, ex);
			throw new BusinessException(error, ex.getMessage(), ex);
		} else {
			String error = MessageFormat.format(
					CommonConstants.EXCEPTION_MESSAGE, ex.getMessage());
			handleBusinessException(ErrorCode.BIZ_UNEXPECTED_ERROR.getErrorCode(), error, ex);
		}
	}
	
}
