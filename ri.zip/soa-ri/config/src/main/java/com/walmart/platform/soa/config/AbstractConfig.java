package com.walmart.platform.soa.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;

/**
 * @author sdikshi
 *
 */
public class AbstractConfig {

	protected static final Logger LOGGER = LoggerFactory
			.getLogger(AbstractConfig.class);

	private static boolean isScmEnabled = false;
	public static final String ARTIFACT_ID = "soari-config";

	/*
	 * static{ String scmEnabledStr =
	 * System.getProperty("com.walmart.platform.config.scm.enable","false");
	 * isScmEnabled = Boolean.valueOf(scmEnabledStr); }
	 */

	public boolean isSCMEnabled() {
		String scmEnabledStr = System.getProperty(
				"com.walmart.platform.config.scm.enable", "false");
		isScmEnabled = Boolean.valueOf(scmEnabledStr);
		return isScmEnabled;
	}

	public String getValue(String propertyName, Environment env) {
		/*
		 * if (isSCMEnabled()) { return configuration.getString(propertyName); }
		 */
		if (env != null) {
			return env.getProperty(propertyName);
		} else {
			String value = System.getProperty(propertyName);
			if (value != null && value.trim().length() > 0
					&& !value.startsWith("%")) {
				// If case the zookeeper value doesnot get populated from Oneops
				LOGGER.debug(
						"Value of property {} begins with '%'. Possibly value : {} is not set correctly. Setting value as null",
						propertyName, value);
				return value;
			}
		}
		return null;
		
	}
}
