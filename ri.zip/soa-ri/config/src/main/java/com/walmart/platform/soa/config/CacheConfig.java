package com.walmart.platform.soa.config;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;

//import com.walmart.platform.scm.client.Configuration;
//import com.walmart.platform.scm.client.SCM;
//import com.walmart.platform.scm.client.context.Context;

/**
 * Spring Config bean to load all cache related properties in the runtime as
 * bean attributes.
 * 
 * @author sdikshi
 * @author ranand
 * 
 */
@Configuration("cacheConfig")
@PropertySource({ "classpath:environmentConfig/${com.walmart.platform.config.runOnEnv:default}/cache-config.properties" })
public class CacheConfig extends AbstractConfig implements
		ApplicationContextAware {

	/**
	 * 
	 * @return
	 */
	public static final String CONFIG_NAME = "cache-config-final";

	//private com.walmart.platform.scm.client.Configuration configuration = null;
	private Environment env;

	public CacheConfig() {
		/*if (isSCMEnabled()) {
			Context context = SCM.getNewContext();
			context.setService(ARTIFACT_ID);
			configuration = SCM.getConfiguration(context, CONFIG_NAME);
		}*/
	}

	@Bean
	public CacheConfig cacheConfig() {
		return new CacheConfig();
	}

	public String getCacheNames() {
		return getValue("cache.names", /*configuration,*/ env);
	}

	public String getCacheEvictionInterval(String cacheName) {
		String property = "cache.eviction." + cacheName;
		return getValue(property, /*configuration,*/ env);
	}

	public String getCacheMaxEntries(String cacheName) {
		String property = "cache.maxentries." + cacheName;
		return getValue(property, /*configuration,*/ env);
	}

	public String getCacheRefresh(String cacheName) {
		String property = "cache.refresh." + cacheName;
		return getValue(property, /*configuration,*/ env);
	}

	@Override
	public void setApplicationContext(ApplicationContext applicationContext)
			throws BeansException {
		env = applicationContext.getEnvironment();

	}

}
