package com.walmart.platform.soa.config;

import java.net.InetAddress;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;

//import com.walmart.platform.scm.client.Configuration;
//import com.walmart.platform.scm.client.SCM;
//import com.walmart.platform.scm.client.context.Context;
//import com.walmart.platform.scm.client.listener.ConfigurationChangeListener;

/**
 * Spring Config bean to load all esb config related properties in the runtime
 * as bean attributes.
 * 
 * @author sdikshi
 * @author ranand
 * @author smenon2
 */
@Configuration("esbConfig")
@PropertySource({ "classpath:environmentConfig/${com.walmart.platform.config.runOnEnv:default}/esb-config.properties" })
public class ESBConfig extends AbstractConfig implements
		ApplicationContextAware {

	private Environment env;

	public static final String CONFIG_NAME = "esb-config-final";

	// private com.walmart.platform.scm.client.Configuration configuration =
	// null;
	// Context context;

	/**
	 * 
	 * @return
	 */
	public ESBConfig() {
		/*
		 * if (isSCMEnabled()) { context = SCM.getNewContext();
		 * context.setService(ARTIFACT_ID); configuration =
		 * SCM.getConfiguration(context, CONFIG_NAME); }
		 */
	}

	@Bean
	public ESBConfig esbConfig() {
		return new ESBConfig();
	}

	/**
	 * 
	 * @return "registry.host.url" property value.
	 */
	public String getRegistryHostUrl() {
		return getValue("registry.host.url", /* configuration, */env);

	}

	/**
	 * @return "esb.registry.cache.refreshInterval" property value. Default
	 *         value 300000
	 */
	public String getEsbRegistyCacheRefreshInterval() {
		String val = getValue("esb.registry.cache.refreshInterval", /*
																	 * configuration
																	 * ,
																	 */env);
		if (val != null && val.trim().length() > 0)
			return val;
		else
			return "300000";
	}

	/**
	 * @return "esb.registry.cache.initialDelay" value. Default value 300000
	 */
	public String getEsbRegistyCacheInitialDelay() {
		String val = getValue("esb.registry.cache.initialDelay", /*
																 * configuration,
																 */env);
		if (val != null && val.trim().length() > 0)
			return val;
		else
			return "300000";
	}

	/**
	 * @return "esb.cluster.name" property value.
	 */
	public String getEsbReference() {
		return getValue("esb.cluster.name", /* configuration, */env);
	}

	/**
	 * @return "esb.tier" property value.
	 */
	public String getEsbTier() {
		return getValue("esb.tier", /* configuration, */env);
	}

	/**
	 * @return "esb.metrics.steptime" property value.
	 */
	public String getMetricsStepTime() {
		return getValue("esb.metrics.steptime", /* configuration, */env);
	}

	/**
	 * 
	 * @return
	 */
	public String getMetricsMaxSteps() {
		return getValue("esb.metrics.maxsteps", /* configuration, */env);
	}

	/**
	 * 
	 * @return
	 */
	public String getAlertDefaultMaxThreshold() {
		return getValue("esb.alert.violation.max.threshold", /* configuration, */
				env);
	}

	/**
	 * 
	 * @return
	 */
	public String getAlertDefaultCheckPeriod() {
		return getValue("esb.alert.check.period", /* configuration, */env);
	}

	/**
	 * 
	 * @return
	 */
	public String getAlertSmtpHost() {
		return getValue("esb.alert.smtp.host", /* configuration, */env);
	}

	/**
	 * 
	 * @return
	 */
	public String getAlertFromEmailAddress() {
		return getValue("esb.alert.from.email", /* configuration, */env);
	}

	/**
	 * 
	 * @return
	 */
	public String getZkClusterEnabled() {
		return getValue("esb.zk.cluster.enabled", /* configuration, */env);
	}

	/**
	 * 
	 * @return
	 */
	public String getZkClusterNodeName() {
		return getValue("esb.zk.cluster.node.name", /* configuration, */env);
	}

	/**
	 * 
	 * @return
	 */
	public String getZkClusterConnectString() {
		String systemEnv = System.getenv("ZKCLSNAME");
		String zkString = null;
		if (systemEnv != null && systemEnv.trim().length() > 0) {
			zkString = getHostOrIpSeparatedByComma(systemEnv, "2181");
		} else {
			zkString = getValue("esb.zk.cluster.connection", /* configuration, */
					env);
		}
		LOGGER.debug("[ESB Config - getZkClusterConnectString] system environment : "
				+ zkString);
		return zkString;
	}

	/**
	 * Returns the canonical-host names or ip addresses separated by comma. 
	 * 
	 * @param host
	 * @param port
	 * @return
	 */
	private String getHostOrIpSeparatedByComma(String host, String port) {
		StringBuilder sb = new StringBuilder();
		try {
			InetAddress[] inetHosts = InetAddress.getAllByName(host);
			int count = 0;
			int length = inetHosts.length;
			for (InetAddress inetHost : inetHosts) {
				++count;
				// This returns either the canonical host name or ip address
				// which ever is resolved. So its safe to use this.
				/*
				String canonicalHostName = inetHost.getCanonicalHostName();
				if (canonicalHostName != null) {
					sb.append(canonicalHostName).append(":").append(port);
					if (count < length) {
						sb.append(",");
					}
				}
				*/
				String hostIP = inetHost.getHostAddress();
				if (hostIP != null) {
					sb.append(hostIP).append(":").append(port);
					if (count < length) {
						sb.append(",");
					}
				}
			}
		} catch (Exception e) {
			LOGGER.error("error while getting host or ip address", e);
		}
		return sb.toString();
	}

	/**
	 * 
	 * @return
	 */
	public String getZkClusterSessionTimeout() {
		return getValue("esb.zk.cluster.session.timeout", /* configuration, */env);
	}

	/**
	 * 
	 */
	public String getIamClientURL() {
		return getValue("iam.client.url", /* configuration, */env);
	}

	/**
	 * 
	 * @return
	 */
	public String getEsbHostName() {
		String esbHostName = getHostName();
		if (esbHostName == null || !esbHostName.isEmpty()) {
			esbHostName = getHostIP();
		}
		return esbHostName;
	}

	private String getHostName() {
		String hostName = null;
		try {
			InetAddress addr = InetAddress.getLocalHost();
			hostName = addr.getHostName();
		} catch (Exception e) {
		}
		return hostName;
	}

	private String getHostIP() {
		String hostIP = null;
		try {
			InetAddress addr = InetAddress.getLocalHost();
			hostIP = addr.getHostAddress();
		} catch (Exception e) {
		}
		return hostIP;
	}

	@Override
	public void setApplicationContext(ApplicationContext applicationContext)
			throws BeansException {
		env = applicationContext.getEnvironment();

	}
}
