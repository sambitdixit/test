package com.walmart.platform.soa.config;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;

//import com.walmart.platform.scm.client.Configuration;
//import com.walmart.platform.scm.client.SCM;
//import com.walmart.platform.scm.client.context.Context;

/**
 * Spring Config bean to load all notification related properties in the runtime as
 * bean attributes. 
 * 
 * @author sdikshi
 * @author ranand
 * @author smenon2
 *
 */
@Configuration("notificationConfig")
@PropertySource({"classpath:environmentConfig/${com.walmart.platform.config.runOnEnv:default}/notification-config.properties"})
public class NotificationConfig extends AbstractConfig implements ApplicationContextAware{

    /**
     *
     * @return
     */
	public static final String CONFIG_NAME = "notification-config-final";
	
	//private com.walmart.platform.scm.client.Configuration configuration = null;
	private Environment env;
	
	@Bean
	public NotificationConfig notificationConfig(){
		return new NotificationConfig();
	}
	
	public NotificationConfig () {
		/*if(isSCMEnabled()){
			Context context = SCM.getNewContext();
			context.setService(ARTIFACT_ID);
			configuration=SCM.getConfiguration(context, CONFIG_NAME);
		}*/
	}
	
	
	/**
	 * 
	 * @return
	 */
	public String getDurableTopicName() {
		return getValue("durable.topic.name", /* configuration, */ env);
	}

	
	@Override
	public void setApplicationContext(ApplicationContext applicationContext)
			throws BeansException {
		env = applicationContext.getEnvironment();
		
	}
}
