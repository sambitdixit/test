package com.walmart.platform.soa.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * RegistryConfig Test
 */
@ContextConfiguration(locations={"classpath:applicationContext.xml"})
public class RegistryConfigTest extends AbstractTestNGSpringContextTests {

	@Autowired
    RegistryConfig registryConfig;

    @Test
    public void testIsNotificationEnabled() {
    	Assert.assertEquals("false", registryConfig.isNotificationEnabled().trim());
    	Assert.assertNotNull(new RegistryConfig().registryConfig());
    }
}
