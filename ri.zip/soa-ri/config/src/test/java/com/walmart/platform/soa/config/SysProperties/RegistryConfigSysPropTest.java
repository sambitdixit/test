package com.walmart.platform.soa.config.SysProperties;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.walmart.platform.soa.config.RegistryConfig;

/**
 * RegistryConfig Test
 */
public class RegistryConfigSysPropTest {

	@BeforeClass
	public void propertyLoader(){
		System.setProperty("notification.enabled", "default");
		System.setProperty("com.walmart.platform.config.scm.enable", "true");
		System.setProperty("com.walmart.platform.config.runOnEnv", "dev");
		System.setProperty("com.walmart.platform.config.appName", "soari-config");			
	}
	
    RegistryConfig registryConfig=new RegistryConfig();

    @Test
    public void testIsNotificationEnabled() {
    	Assert.assertEquals("default", registryConfig.isNotificationEnabled().trim());
    	Assert.assertNotNull(new RegistryConfig().registryConfig());
    }
    
    @AfterClass
    public void propertyUnLoader(){
    	System.clearProperty("notification.enabled");
	}
}
