package com.walmart.platform.soa.config.SCM;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.walmart.platform.soa.config.ESBConfig;

/**
 * ESBConfig Test
 */
public class ESBConfigSCMTest  {

	static{
		System.setProperty("com.walmart.platform.config.scm.enable", "true");
		System.setProperty("com.walmart.platform.config.runOnEnv", "dev");
		System.setProperty("com.walmart.platform.config.appName", "soari-config");			
	}
	
    @Test
    public void testGetRegistryHostUrl() throws InterruptedException {
    	System.setProperty("com.walmart.platform.config.scm.enable", "true");
    	System.setProperty("com.walmart.platform.config.runOnEnv", "dev");
		System.setProperty("com.walmart.platform.config.appName", "soari-config");		
	    ESBConfig esbConfig=new ESBConfig();
    	Assert.assertNotNull(new ESBConfig().esbConfig());
    	Assert.assertEquals("http://q1-soaregistry.glb.qa.walmart.com/registry-app/services/registry/", esbConfig.getRegistryHostUrl());
    }

    @Test
    public void testGetEsbTier() {
    	System.setProperty("com.walmart.platform.config.runOnEnv", "dev");
		System.setProperty("com.walmart.platform.config.appName", "soari-config");		
	    ESBConfig esbConfig=new ESBConfig();
    	Assert.assertEquals("TIER1", esbConfig.getEsbTier());
    }

    @Test
    public void testGetMetricsStepTime() {
    	System.setProperty("com.walmart.platform.config.runOnEnv", "dev");
		System.setProperty("com.walmart.platform.config.appName", "soari-config");		
	    ESBConfig esbConfig=new ESBConfig();
    	Assert.assertEquals("3000", esbConfig.getMetricsStepTime());
    }

    @Test
    public void testGetMetricsMaxSteps() {
    	System.setProperty("com.walmart.platform.config.runOnEnv", "dev");
		System.setProperty("com.walmart.platform.config.appName", "soari-config");		
	    ESBConfig esbConfig=new ESBConfig();
    	Assert.assertEquals("300", esbConfig.getMetricsMaxSteps());
    }

    @Test
    public void testGetZkClusterEnabled() {
    	System.setProperty("com.walmart.platform.config.runOnEnv", "dev");
		System.setProperty("com.walmart.platform.config.appName", "soari-config");		
	    ESBConfig esbConfig=new ESBConfig();
    	Assert.assertEquals("true", esbConfig.getZkClusterEnabled());
    }

    @Test
    public void testGetZkClusterConnectString() {
    	System.setProperty("com.walmart.platform.config.runOnEnv", "dev");
		System.setProperty("com.walmart.platform.config.appName", "soari-config");		
	    ESBConfig esbConfig=new ESBConfig();
    	Assert.assertEquals("sdc-d1-esb-app1.dev.walmart.com:2181,sdc-d1-esb-app2.dev.walmart.com:2181,sdc-d1-esb-app3.dev.walmart.com:2181", esbConfig.getZkClusterConnectString());
    }

    @Test
    public void testGetZkClusterSessionTimeout() {
    	System.setProperty("com.walmart.platform.config.runOnEnv", "dev");
		System.setProperty("com.walmart.platform.config.appName", "soari-config");		
	    ESBConfig esbConfig=new ESBConfig();
    	Assert.assertEquals("30", esbConfig.getZkClusterSessionTimeout());
    }

    @Test
    public void testGetEsbHostName() {
    	System.setProperty("com.walmart.platform.config.runOnEnv", "dev");
		System.setProperty("com.walmart.platform.config.appName", "soari-config");		
	    ESBConfig esbConfig=new ESBConfig();
    	Assert.assertNotNull(esbConfig.getEsbHostName());
    }

    @Test
    public void testGetAlertDefaultMaxThreshold() {
    	System.setProperty("com.walmart.platform.config.runOnEnv", "dev");
		System.setProperty("com.walmart.platform.config.appName", "soari-config");		
	    ESBConfig esbConfig=new ESBConfig();
    	Assert.assertEquals("5", esbConfig.getAlertDefaultMaxThreshold());
    }

    @Test
    public void testGetAlertDefaultCheckPeriod() {
    	System.setProperty("com.walmart.platform.config.runOnEnv", "dev");
		System.setProperty("com.walmart.platform.config.appName", "soari-config");		
	    ESBConfig esbConfig=new ESBConfig();
    	Assert.assertEquals("3000", esbConfig.getAlertDefaultCheckPeriod());
    }

    @Test
    public void testGetAlertSmtpHost() {
    	System.setProperty("com.walmart.platform.config.runOnEnv", "dev");
		System.setProperty("com.walmart.platform.config.appName", "soari-config");		
	    ESBConfig esbConfig=new ESBConfig();
    	Assert.assertEquals("honts3552.homeoffice.wal-mart.com", esbConfig.getAlertSmtpHost());
    }

    @Test
    public void testGetAlertFromEmailAddress() {
    	System.setProperty("com.walmart.platform.config.runOnEnv", "dev");
		System.setProperty("com.walmart.platform.config.appName", "soari-config");		
	    ESBConfig esbConfig=new ESBConfig();
    	Assert.assertEquals("esb-alerts@walmartlabs.com", esbConfig.getAlertFromEmailAddress());
    }

}
