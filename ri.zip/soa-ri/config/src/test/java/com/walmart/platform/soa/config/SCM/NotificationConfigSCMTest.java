package com.walmart.platform.soa.config.SCM;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.walmart.platform.soa.config.NotificationConfig;

/**
 * NotificationConfig Test
 */
public class NotificationConfigSCMTest  {

	static{
		System.setProperty("com.walmart.platform.config.scm.enable", "true");
		System.setProperty("com.walmart.platform.config.runOnEnv", "dev");
		System.setProperty("com.walmart.platform.config.appName", "soari-config");			
	}
	
    @Test
    public void testGetDurableTopicName() {
    	System.setProperty("com.walmart.platform.config.scm.enable", "true");
    	System.setProperty("com.walmart.platform.config.runOnEnv", "dev");
		System.setProperty("com.walmart.platform.config.appName", "soari-config");
		 NotificationConfig notificationConfig=new NotificationConfig();

    	Assert.assertEquals("US.T.SOAREGISTRY.1.0.OBJECT", notificationConfig.getDurableTopicName());
    	Assert.assertNotNull(new NotificationConfig().notificationConfig());
    }

}
