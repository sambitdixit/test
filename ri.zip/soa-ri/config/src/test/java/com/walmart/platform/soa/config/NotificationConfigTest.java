package com.walmart.platform.soa.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * NotificationConfig Test
 */
@ContextConfiguration(locations={"classpath:applicationContext.xml"})
public class NotificationConfigTest extends AbstractTestNGSpringContextTests {

    @Autowired
	NotificationConfig notificationConfig;

    @Test
    public void testGetDurableTopicName() {
    	Assert.assertEquals("US.T.SOAREGISTRY.1.0.OBJECT", notificationConfig.getDurableTopicName());
    	Assert.assertNotNull(new NotificationConfig().notificationConfig());
    }

}
