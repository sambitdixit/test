package com.walmart.platform.soa.config.SysProperties;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.walmart.platform.soa.config.ESBConfig;

public class ESBConfigSysPropTest {

	@BeforeClass
	public void propertyLoader(){
		
		System.setProperty("registry.host.url","http://localhost:63000/registry-app/services/registry/");
		System.setProperty("esb.cluster.name","ESB_REF_ENV");
		System.setProperty("esb.tier","TIER1");

		System.setProperty("esb.metrics.steptime","2000");
		System.setProperty("esb.metrics.maxsteps","20");

		System.setProperty("esb.alert.violation.max.threshold","10");
		System.setProperty("esb.alert.check.period","30000");
		System.setProperty("esb.alert.smtp.host","honts3552.homeoffice.wal-mart.com");
		System.setProperty("esb.alert.from.email","esb-alerts@walmartlabs.com");

		System.setProperty("esb.zk.cluster.enabled","false");
		System.setProperty("esb.zk.cluster.node.name","ESB-NODE1");
		System.setProperty("esb.zk.cluster.connection","127.0.0.1:2181");
		System.setProperty("esb.zk.cluster.session.timeout","25");
		
		System.setProperty("com.walmart.platform.config.scm.enable", "true");
		System.setProperty("com.walmart.platform.config.runOnEnv", "dev");
		System.setProperty("com.walmart.platform.config.appName", "soari-config");
		
	}
	
	ESBConfig esbConfig=new ESBConfig();
	 
	@Test
    public void testGetRegistryHostUrl() throws InterruptedException {
    	Assert.assertEquals("http://localhost:63000/registry-app/services/registry/", esbConfig.getRegistryHostUrl());
    }

    @Test
    public void testGetEsbTier() {
    	Assert.assertEquals("TIER1", esbConfig.getEsbTier());
    }

    @Test
    public void testGetMetricsStepTime() {
    	Assert.assertEquals("2000", esbConfig.getMetricsStepTime());
    }

    @Test
    public void testGetMetricsMaxSteps() {
    	Assert.assertEquals("20", esbConfig.getMetricsMaxSteps());
    }

    @Test
    public void testGetZkClusterEnabled() {
    	Assert.assertEquals("false", esbConfig.getZkClusterEnabled());
    }

    @Test
    public void testGetZkClusterConnectString() {
    	Assert.assertEquals("127.0.0.1:2181", esbConfig.getZkClusterConnectString());
    }

    @Test
    public void testGetZkClusterSessionTimeout() {
    	Assert.assertEquals("25", esbConfig.getZkClusterSessionTimeout());
    }

    @Test
    public void testGetEsbHostName() {
    	Assert.assertNotNull(esbConfig.getEsbHostName());
    }

    @Test
    public void testGetAlertDefaultMaxThreshold() {
    	Assert.assertEquals("10", esbConfig.getAlertDefaultMaxThreshold());
    }

    @Test
    public void testGetAlertDefaultCheckPeriod() {
    	Assert.assertEquals("30000", esbConfig.getAlertDefaultCheckPeriod());
    }

    @Test
    public void testGetAlertSmtpHost() {
    	Assert.assertEquals("honts3552.homeoffice.wal-mart.com", esbConfig.getAlertSmtpHost());
    }

    @Test
    public void testGetAlertFromEmailAddress() {
    	Assert.assertEquals("esb-alerts@walmartlabs.com", esbConfig.getAlertFromEmailAddress());
    }
   
    @AfterClass
    public void propertyUnLoader(){
    	
    	System.clearProperty("registry.host.url");
		System.clearProperty("esb.cluster.name");
		System.clearProperty("esb.tier");

		System.clearProperty("esb.metrics.steptime");
		System.clearProperty("esb.metrics.maxsteps");

		System.clearProperty("esb.alert.violation.max.threshold");
		System.clearProperty("esb.alert.check.period");
		System.clearProperty("esb.alert.smtp.host");
		System.clearProperty("esb.alert.from.email");

		System.clearProperty("esb.zk.cluster.enabled");
		System.clearProperty("esb.zk.cluster.node.name");
		System.clearProperty("esb.zk.cluster.connection");
		System.clearProperty("esb.zk.cluster.session.timeout");
	}    

}
