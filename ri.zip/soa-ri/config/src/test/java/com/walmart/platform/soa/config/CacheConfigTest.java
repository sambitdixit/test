package com.walmart.platform.soa.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * Test for CacheConfig
 */
@ContextConfiguration(locations={"classpath:applicationContext.xml"})
public class CacheConfigTest extends AbstractTestNGSpringContextTests {

    @Autowired
	CacheConfig cacheConfig;

    @Test
    public void testCacheConfig() {
       Assert.assertEquals("esb-service-cache,esb-policy-cache,esb-pk-cache", cacheConfig.getCacheNames());
       Assert.assertEquals("120000", cacheConfig.getCacheEvictionInterval("esb-service-cache"));
       Assert.assertEquals("false", cacheConfig.getCacheRefresh("esb-pk-cache"));
       Assert.assertNotEquals("false", cacheConfig.getCacheRefresh("esb-service-cache"));
       Assert.assertNotNull(new CacheConfig().cacheConfig());
    }

}
