package com.walmart.platform.soa.config.SCM;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.walmart.platform.soa.config.RegistryConfig;

/**
 * RegistryConfig Test
 */
public class RegistryConfigSCMTest {

	static{
		System.setProperty("com.walmart.platform.config.scm.enable", "true");
		System.setProperty("com.walmart.platform.config.runOnEnv", "dev");
		System.setProperty("com.walmart.platform.config.appName", "soari-config");			
	}
	
   

    @Test
    public void testIsNotificationEnabled() {
    	System.setProperty("com.walmart.platform.config.scm.enable", "true");
		System.setProperty("com.walmart.platform.config.runOnEnv", "dev");
		System.setProperty("com.walmart.platform.config.appName", "soari-config");			
		 RegistryConfig registryConfig=new RegistryConfig();
    	Assert.assertEquals("false", registryConfig.isNotificationEnabled().trim());
    	Assert.assertNotNull(new RegistryConfig().registryConfig());
    }
}
