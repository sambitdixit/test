package com.walmart.platform.soa.config.SCM;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.walmart.platform.soa.config.CacheConfig;

/**
 * Test for CacheConfig
 */
public class CacheConfigSCMTest {

	//@BeforeClass
	//public void propertyLoader()
	static{
		System.setProperty("com.walmart.platform.config.scm.enable", "true");
		System.setProperty("com.walmart.platform.config.runOnEnv", "dev");
		System.setProperty("com.walmart.platform.config.appName", "soari-config");
	}
	
   

    @Test()
    public void testCacheConfigSCM() {
    	System.setProperty("com.walmart.platform.config.scm.enable", "true");
    	System.setProperty("com.walmart.platform.config.runOnEnv", "dev");
		System.setProperty("com.walmart.platform.config.appName", "soari-config");
    	 
		CacheConfig cacheConfig= new CacheConfig();
    	Assert.assertEquals("esb-service-cache,esb-policy-cache,esb-pk-cache", cacheConfig.getCacheNames());
        Assert.assertEquals("120000", cacheConfig.getCacheEvictionInterval("esb-service-cache"));
        Assert.assertEquals("false", cacheConfig.getCacheRefresh("esb-pk-cache"));
        Assert.assertNotEquals("false", cacheConfig.getCacheRefresh("esb-service-cache"));
        Assert.assertNotNull(new CacheConfig().cacheConfig());
    }
    
//    @AfterClass
//    public void propertyUnloader()
//    {
//    	System.clearProperty("com.walmart.platform.config.scm.enable");
//		System.clearProperty("com.walmart.platform.config.runOnEnv");
//		System.clearProperty("com.walmart.platform.config.appName");	
//    }

}
