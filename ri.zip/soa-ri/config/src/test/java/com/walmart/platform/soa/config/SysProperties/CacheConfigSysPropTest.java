package com.walmart.platform.soa.config.SysProperties;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.walmart.platform.soa.config.CacheConfig;

/**
 * Test for CacheConfig
 */
public class CacheConfigSysPropTest {

	@BeforeClass
	public void propertyLoader(){
		System.setProperty("cache.names","esb-service-cache,esb-policy-cache,esb-pk-cache");
		
		System.setProperty("cache.eviction.esb-service-cache","12000");
		System.setProperty("cache.maxentries.esb-service-cache","1000");
		
		System.setProperty("cache.eviction.esb-policy-cache","13000");
		System.setProperty("cache.maxentries.esb-policy-cache","1000");
		
		System.setProperty("cache.eviction.esb-pk-cache","14000");
		System.setProperty("cache.maxentries.esb-pk-cache","900");
		
         
		System.setProperty("com.walmart.platform.config.scm.enable", "true");
		System.setProperty("com.walmart.platform.config.runOnEnv", "dev");
		System.setProperty("com.walmart.platform.config.appName", "soari-config");			
	}
	
    CacheConfig cacheConfig= new CacheConfig();

    @Test()
    public void testCacheConfig() {
    	 Assert.assertEquals("esb-service-cache,esb-policy-cache,esb-pk-cache", cacheConfig.getCacheNames());
         Assert.assertEquals("12000", cacheConfig.getCacheEvictionInterval("esb-service-cache"));
         Assert.assertEquals("13000", cacheConfig.getCacheEvictionInterval("esb-policy-cache"));
         Assert.assertEquals("14000", cacheConfig.getCacheEvictionInterval("esb-pk-cache"));
         
         Assert.assertEquals("1000", cacheConfig.getCacheMaxEntries("esb-service-cache"));
         Assert.assertEquals("1000", cacheConfig.getCacheMaxEntries("esb-policy-cache"));
         Assert.assertEquals("900", cacheConfig.getCacheMaxEntries("esb-pk-cache"));
         
         Assert.assertNotNull(new CacheConfig().cacheConfig());
    }

    @AfterClass
    public void propertyUnloader(){
    	System.clearProperty("cache.names");
		
    	System.clearProperty("cache.eviction.esb-service-cache");
    	System.clearProperty("cache.maxentries.esb-service-cache");
		
    	System.clearProperty("cache.eviction.esb-policy-cache");
    	System.clearProperty("cache.maxentries.esb-policy-cache");
		
    	System.clearProperty("cache.eviction.esb-pk-cache");
    	System.clearProperty("cache.maxentries.esb-pk-cache");	
    }
}
