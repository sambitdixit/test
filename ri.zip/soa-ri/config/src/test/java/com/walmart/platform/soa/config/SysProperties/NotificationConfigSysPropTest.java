package com.walmart.platform.soa.config.SysProperties;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.walmart.platform.soa.config.NotificationConfig;

/**
 * NotificationConfig Test
 */
public class NotificationConfigSysPropTest  {

	@BeforeClass
	public void propertyLoader(){
		
		System.setProperty("durable.topic.name","US.T.SOAREGISTRY.2.0.OBJECT");
		System.setProperty("com.walmart.platform.config.scm.enable", "true");
		System.setProperty("com.walmart.platform.config.runOnEnv", "dev");
		System.setProperty("com.walmart.platform.config.appName", "soari-config");			
	}
	
    NotificationConfig notificationConfig=new NotificationConfig();

    @Test
    public void testGetDurableTopicName() {
    	Assert.assertEquals("US.T.SOAREGISTRY.2.0.OBJECT", notificationConfig.getDurableTopicName());
    	Assert.assertNotNull(new NotificationConfig().notificationConfig());
    }
    
    @AfterClass
    public void propertyUnLoader(){
		System.clearProperty("durable.topic.name");
	}

}
