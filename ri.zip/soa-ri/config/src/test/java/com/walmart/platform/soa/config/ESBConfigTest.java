package com.walmart.platform.soa.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * ESBConfig Test
 */
@ContextConfiguration(locations={"classpath:applicationContext.xml"})
public class ESBConfigTest extends AbstractTestNGSpringContextTests {

	@Autowired
    ESBConfig esbConfig2;
    
    
    @Test(enabled=false)
    public void testGetRegistryHostUrl() throws InterruptedException {
    	Assert.assertNotNull(new ESBConfig().esbConfig());
    	Assert.assertEquals("http://localhost:63000/registry-app/services/registry/", esbConfig2.getRegistryHostUrl());
    }

    @Test(enabled=false)
    public void testGetEsbReference() {
    	Assert.assertEquals("ESB_REF1", esbConfig2.getEsbReference());
        Assert.assertNotNull(esbConfig2.esbConfig());
    }

    @Test
    public void testGetEsbTier() {
    	Assert.assertEquals("TIER1", esbConfig2.getEsbTier());
    }

    @Test
    public void testGetMetricsStepTime() {
    	Assert.assertEquals("3000", esbConfig2.getMetricsStepTime());
    }

    @Test(enabled=false)
    public void testGetMetricsMaxSteps() {
    	System.out.println(System.getProperty("com.walmart.platform.config.scm.enable"));
    	Assert.assertEquals(esbConfig2.getMetricsMaxSteps(),"30");
    }

    @Test(enabled=false)
    public void testGetZkClusterEnabled() {
    	Assert.assertEquals("false", esbConfig2.getZkClusterEnabled());
    }

    @Test(enabled=false)
    public void testGetZkClusterNodeName() {
    	Assert.assertEquals("ESB-NODE1", esbConfig2.getZkClusterNodeName());
    }

    @Test(enabled=false)
    public void testGetZkClusterConnectString() {
    	Assert.assertEquals("127.0.0.1:2181", esbConfig2.getZkClusterConnectString());
    }

    @Test
    public void testGetZkClusterSessionTimeout() {
    	Assert.assertEquals("30", esbConfig2.getZkClusterSessionTimeout());
    }

    @Test
    public void testGetEsbHostName() {
    	Assert.assertNotNull(esbConfig2.getEsbHostName());
    }

    @Test
    public void testGetAlertDefaultMaxThreshold() {
    	Assert.assertEquals("5", esbConfig2.getAlertDefaultMaxThreshold());
    }

    @Test
    public void testGetAlertDefaultCheckPeriod() {
    	Assert.assertEquals("3000", esbConfig2.getAlertDefaultCheckPeriod());
    }

    @Test
    public void testGetAlertSmtpHost() {
    	Assert.assertEquals("honts3552.homeoffice.wal-mart.com", esbConfig2.getAlertSmtpHost());
    }

    @Test
    public void testGetAlertFromEmailAddress() {
    	Assert.assertEquals("esb-alerts@walmartlabs.com", esbConfig2.getAlertFromEmailAddress());
    }

}
