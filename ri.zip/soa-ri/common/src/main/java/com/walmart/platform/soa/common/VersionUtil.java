package com.walmart.platform.soa.common;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.walmart.platform.soa.common.util.SOAStringUtil;

/**
 * @author sdikshi
 */
public final class VersionUtil {

    private VersionUtil() {
    }

    private static Pattern pattern = Pattern.compile("/[v|V]\\d+/");

    /**
     *
     * @param url
     * @return
     */
	public static String getVersion(String url) {
		if (SOAStringUtil.isNotBlank(url)) {
			Matcher m = pattern.matcher(url);
			if (m != null && m.find()) {
				String subStr = m.group(0).substring(2, m.group(0).lastIndexOf('/'));
				return subStr + ".0.0";
			}
		}
		return null;
	}
}