package com.walmart.platform.soa.common.logging;

import java.util.List;
import java.util.Map;

import org.apache.cxf.message.Exchange;
import org.apache.cxf.message.Message;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.walmart.platform.logging.client.type.TransactionLogger;
import com.walmart.platform.soa.common.CommonUtil;
import com.walmart.platform.soa.common.HeaderElements;
import com.walmart.platform.soa.common.util.ArtifactVersionUtil;
import com.walmart.platform.soa.common.util.GUIDThreadLocal;
import com.walmart.platform.soa.common.util.IPUtil;
import com.walmart.platform.soa.common.util.SOAStringUtil;

/**
 * This class is used to log transaction data in one central place.
 * 
 * @author sdikshi
 * 
 */
public final class SOATransactionLogger {

	public static final Logger LOGGER = LoggerFactory
			.getLogger(SOATransactionLogger.class);

	/**
	 * logs Start of Transaction. End any not closed transaction so that it does
	 * not impact existing transaction If the previous request errored out did
	 * not got thru the intercepter chain on the return flow, that log
	 * transaction would not have closed. As precautionary step it is better to
	 * close the transaction
	 * 
	 * @param message
	 */
	public static void logServerStartTransaction(Message message) {

		Exchange ex = message.getExchange();

		String method = (String) message.get(Message.HTTP_REQUEST_METHOD);
		String uriStr = (String) message.get(Message.REQUEST_URI);

		String logGrp = method + LoggingConstant.COLON + uriStr;

		Map<String, List<String>> headers = CommonUtil.getProtocolHeaders(message);
		String guid = CommonUtil.getFirst(headers, HeaderElements.CONSUMER_GUID);
		String serviceName = CommonUtil.getFirst(headers,HeaderElements.SERVICE_NAME);
		String serviceVersion = CommonUtil.getFirst(headers,HeaderElements.SERVICE_VERSION);
		String consumerId = CommonUtil.getFirst(headers,HeaderElements.CONSUMER_ID);
		String consumerSourceId = CommonUtil.getFirst(headers,HeaderElements.CONSUMER_SOURCE_ID);
		String consumerHostName = CommonUtil.getFirst(headers,HeaderElements.CONSUMER_NAME);
		String consumerIP = CommonUtil.getFirst(headers,HeaderElements.CONSUMER_IP);
		String consumerInTime = CommonUtil.getFirst(headers,HeaderElements.CONSUMER_IN_TIMESTAMP);
		String consumerAuthToken = CommonUtil.getFirst(headers,HeaderElements.CONSUMER_AUTH_TOKEN);
		String consumerAuthSignature = CommonUtil.getFirst(headers,HeaderElements.CONSUMER_AUTH_SIGNATURE);
		String esbToken = CommonUtil.getFirst(headers,HeaderElements.ESB_SERVICE_TOKEN);
		String userAgent = CommonUtil.getFirst(headers,HeaderElements.USER_AGENT);
		String contentLength = CommonUtil.getFirst(headers,HeaderElements.CONTENT_LENGTH);
		
		StringBuilder sb = new StringBuilder();
		sb.append(LoggingConstant.URI).append(LoggingConstant.EQUALS)
				.append(uriStr).append(LoggingConstant.COMMA)
				.append(LoggingConstant.METHOD).append(LoggingConstant.EQUALS)
				.append(method).append(LoggingConstant.COMMA)
				.append(LoggingConstant.SERVICE_NAME)
				.append(LoggingConstant.EQUALS).append(serviceName)
				.append(LoggingConstant.COMMA)
				.append(LoggingConstant.SERVICE_VERSION)
				.append(LoggingConstant.EQUALS).append(serviceVersion)
				.append(LoggingConstant.COMMA)
				.append(LoggingConstant.CONSUMER_ID)
				.append(LoggingConstant.EQUALS).append(consumerId)
				.append(LoggingConstant.COMMA)
				.append(LoggingConstant.CONSUMER_SOURCE_ID)
				.append(LoggingConstant.EQUALS).append(consumerSourceId)
				.append(LoggingConstant.COMMA)
				.append(LoggingConstant.CLIENT_IP)
				.append(LoggingConstant.EQUALS).append(consumerIP)
				.append(LoggingConstant.COMMA)
				.append(LoggingConstant.CLIENT_NAME)
				.append(LoggingConstant.EQUALS).append(consumerHostName)
				.append(LoggingConstant.COMMA)
				.append(LoggingConstant.CLIENT_IN_TIME)
				.append(LoggingConstant.EQUALS).append(consumerInTime);

		if (SOAStringUtil.isNotBlank(esbToken)) {
			if (esbToken.equals(CommonUtil.ESB_TOKEN)) {
				sb.append(LoggingConstant.COMMA).append(
						LoggingConstant.TRANSACTION_MODE_ESB);
			}
		} else {
			sb.append(LoggingConstant.COMMA).append(
					LoggingConstant.TRANSACTION_MODE_DIRECT);
		}
		if (SOAStringUtil.isNotBlank(consumerAuthToken)) {
			sb.append(LoggingConstant.COMMA).append(
					LoggingConstant.SECURITY_MODE_TOKEN);
			if (consumerAuthToken.equals(CommonUtil.ESB_AUTHENTICATED)) {
				sb.append(LoggingConstant.COMMA).append(
						LoggingConstant.SECURITY_CHECK_AT_ESB);
			} else {
				sb.append(LoggingConstant.COMMA).append(
						LoggingConstant.SECURITY_CHECK_AT_SERVICE);
			}
		}
		if (SOAStringUtil.isNotBlank(consumerAuthSignature)) {
			sb.append(LoggingConstant.COMMA).append(
					LoggingConstant.SECURITY_MODE_SIGNATURE);
			if (consumerAuthSignature.equals(CommonUtil.ESB_AUTHENTICATED)) {
				sb.append(LoggingConstant.COMMA).append(
						LoggingConstant.SECURITY_CHECK_AT_ESB);
			} else {
				sb.append(LoggingConstant.COMMA).append(
						LoggingConstant.SECURITY_CHECK_AT_SERVICE);
			}
		}

		if (SOAStringUtil.isNotBlank(userAgent)) {
			sb.append(LoggingConstant.COMMA)
					.append(LoggingConstant.SOA_USER_AGENT)
					.append(LoggingConstant.EQUALS).append(userAgent);
		}

		if (SOAStringUtil.isNotBlank(contentLength)) {
			sb.append(LoggingConstant.COMMA)
					.append(LoggingConstant.REQUEST_DATA_SIZE)
					.append(LoggingConstant.EQUALS).append(contentLength);
		}
		
		String tranString = sb.toString();

		if (ex != null) {
			ex.put(LoggingConstant.LOG_TRANSACTION_GROUP, logGrp);
		}

		if (SOAStringUtil.isBlank(guid)) {
			guid = TransactionLogger.startTransaction(
					TransactionLogger.TRANSACTION_TYPE_SERVICE, logGrp,
					tranString);
			LOGGER.debug("Starting new transaction at server side with corelation id = {}", guid);
		} else {
			TransactionLogger.startReferenceTransaction(
					TransactionLogger.TRANSACTION_TYPE_SERVICE, logGrp, guid,
					tranString);
			LOGGER.debug("Starting reference transaction at server side with corelation id = {}", guid);
		}

		GUIDThreadLocal.set(guid);
	}

	/**
	 * Logs end transaction at server side.
	 * 
	 * @param message
	 */

	public static void logServerEndTransaction(Message message) {

		Exchange ex = message.getExchange();
		String group = (String) ex.get(LoggingConstant.LOG_TRANSACTION_GROUP);
		String serviceInTime = (String) ((ex
				.get(HeaderElements.SERVICE_IN_TIMESTAMP) != null) ? ex
				.get(HeaderElements.SERVICE_IN_TIMESTAMP)
				: LoggingConstant.BLANK);
		String serviceOutTime = (String) ((ex
				.get(HeaderElements.SERVICE_OUT_TIMESTAMP) != null) ? ex
				.get(HeaderElements.SERVICE_OUT_TIMESTAMP)
				: LoggingConstant.BLANK);

		String localProtocol = (String) ex
				.get(HeaderElements.TRANSACTION_PROTOCOL);
		String protocol = localProtocol != null ? localProtocol
				: LoggingConstant.HTTP;

		String serviceServerIP = (String) ((ex
				.get(HeaderElements.SERVICE_SERVER_IP) != null) ? ex
				.get(HeaderElements.SERVICE_SERVER_IP) : LoggingConstant.BLANK);

		String serviceServerName = (String) ((ex
				.get(HeaderElements.SERVICE_SERVER_NAME) != null) ? ex
				.get(HeaderElements.SERVICE_SERVER_NAME)
				: LoggingConstant.BLANK);

		StringBuilder sb = new StringBuilder(LoggingConstant.COMMA)
				.append(LoggingConstant.TRANSACTION_TYPE_SERVICE)
				.append(LoggingConstant.COMMA)
				.append(LoggingConstant.TRANSACTION_PROTOCOL)
				.append(LoggingConstant.EQUALS).append(protocol);

		sb.append(LoggingConstant.COMMA)
				.append(LoggingConstant.SERVICE_SERVER_IP)
				.append(LoggingConstant.EQUALS).append(serviceServerIP)
				.append(LoggingConstant.COMMA)
				.append(LoggingConstant.SERVICE_SERVER_HOST)
				.append(LoggingConstant.EQUALS).append(serviceServerName)
				.append(LoggingConstant.COMMA)
				.append(LoggingConstant.SERVICE_IN_TIME)
				.append(LoggingConstant.EQUALS).append(serviceInTime)
				.append(LoggingConstant.COMMA)
				.append(LoggingConstant.SERVICE_OUT_TIME)
				.append(LoggingConstant.EQUALS).append(serviceOutTime);
		
		Object obj = ex.get(HeaderElements.SERVICE_CLASS_NAME);
		if(obj!=null) {
			String serviceClassName = (String)obj;
			sb.append(LoggingConstant.COMMA).append(LoggingConstant.SERVICE_CLASS_NAME).append(LoggingConstant.EQUALS).append(serviceClassName);
		}
		
		obj = ex.get(HeaderElements.SERVICE_METHOD_NAME);
		if(obj!=null){
			String serviceMethodName = (String)obj;
			sb.append(LoggingConstant.COMMA).append(LoggingConstant.SERVICE_METHOD_NAME).append(LoggingConstant.EQUALS).append(serviceMethodName);
		}
		
		Object code = message.get(Message.RESPONSE_CODE);
		if (code != null) {
			String statusCode = String.valueOf(code);
			if (statusCode != null) {
				sb.append(LoggingConstant.COMMA)
						.append(LoggingConstant.STATUSCODE)
						.append(LoggingConstant.EQUALS).append(statusCode);
			}
		}
		
		
		
		sb.append(LoggingConstant.COMMA).append(LoggingConstant.X_POWERED_BY)
				.append(LoggingConstant.EQUALS)
				.append(ArtifactVersionUtil.getSOAInterceptor());
		TransactionLogger.endTransaction(group, sb.toString());

		GUIDThreadLocal.unset();
	}

	private static void print(Message message) {
		Exchange ex = message.getExchange();

	}

	/**
	 * Logs start of client side transaction.
	 * 
	 * @param message
	 */
	public static void logClientStartTransaction(Message message) {
		String method = (String) message.get(Message.HTTP_REQUEST_METHOD);
		String uriStr = (String) message.get(Message.REQUEST_URI);

		StringBuilder logGrp = new StringBuilder();
		logGrp.append(method).append(LoggingConstant.COLON).append(uriStr);

		/*
		 * StringBuilder uriGrp = new StringBuilder(LoggingConstant.URI).append(
		 * LoggingConstant.EQUALS).append(uriStr);
		 * 
		 * StringBuilder methodGrp = new StringBuilder(LoggingConstant.METHOD)
		 * .append(LoggingConstant.EQUALS).append(method);
		 */

		// TODO - Check with LogMon team if we need to end all transaction. What
		// will happen in case of both client and server running in same
		// container and jvm. The client transaction will be orphaned.
		// TransactionLogger.endAllTransaction();

		String guid = null;

		/*
		 * if (GUIDThreadLocal.get() != null) { //It means the transaction is
		 * initiated from server side. guid = GUIDThreadLocal.get().toString();
		 * TransactionLogger
		 * .startReferenceTransaction(TransactionLogger.TRANSACTION_TYPE_SERVICE
		 * , logGrp.toString(), guid,null); } else {
		 */
		// It means the transaction is started as stand alone and not initiated
		// from server side.
		guid = TransactionLogger.startTransaction(
				TransactionLogger.TRANSACTION_TYPE_SERVICE, logGrp.toString());
		// }

		Map<String, List<String>> headers = CommonUtil
				.getProtocolHeaders(message);
		CommonUtil.putSingle(headers, HeaderElements.CONSUMER_GUID, guid);

	}

	/**
	 * Logs client side end transaction.
	 * 
	 * @param message
	 */
	public static void logClientEndTransaction(Message message) {
		
		Map<String, List<String>> headers = CommonUtil.getProtocolHeaders(message);
		String uriStr = (message.get(Message.REQUEST_URI) != null) ? (String) message
				.get(Message.REQUEST_URI) : ((message.getExchange().get(
				Message.REQUEST_URI) != null) ? (String) message.getExchange()
				.get(Message.REQUEST_URI) : "");

		StringBuilder uriGrp = new StringBuilder(LoggingConstant.URI).append(
				LoggingConstant.EQUALS).append(uriStr);

		StringBuilder endString = new StringBuilder(LoggingConstant.COMMA);
		endString.append(LoggingConstant.TRANSACTION_TYPE_CLIENT);

		if (headers != null) {
			Exchange ex = message.getExchange();
			String localProtocol = (String) ex
					.get(HeaderElements.TRANSACTION_PROTOCOL);
			String protocol = localProtocol != null ? localProtocol
					: LoggingConstant.HTTP;

			if (protocol != null) {
				endString.append(LoggingConstant.COMMA)
						.append(LoggingConstant.TRANSACTION_PROTOCOL)
						.append(LoggingConstant.EQUALS).append(protocol);
			}
			String consumerInTime = CommonUtil.getFirst(headers,
					HeaderElements.CONSUMER_IN_TIMESTAMP);
			if (consumerInTime != null) {
				endString.append(LoggingConstant.COMMA)
						.append(LoggingConstant.CLIENT_IN_TIME)
						.append(LoggingConstant.EQUALS).append(consumerInTime);
			}
			String consumerOutTime = CommonUtil.getFirst(headers,
					HeaderElements.CONSUMER_OUT_TIMESTAMP);
			if (consumerOutTime != null) {
				endString.append(LoggingConstant.COMMA)
						.append(LoggingConstant.CLIENT_OUT_TIME)
						.append(LoggingConstant.EQUALS).append(consumerOutTime);
			}

			String serviceInTime = CommonUtil.getFirst(headers,
					HeaderElements.SERVICE_IN_TIMESTAMP);
			if (serviceInTime != null) {
				endString.append(LoggingConstant.COMMA)
						.append(LoggingConstant.SERVICE_IN_TIME)
						.append(LoggingConstant.EQUALS).append(serviceInTime);
			}

			String serviceOutTime = CommonUtil.getFirst(headers,
					HeaderElements.SERVICE_OUT_TIMESTAMP);
			if (serviceOutTime != null) {
				endString.append(LoggingConstant.COMMA)
						.append(LoggingConstant.SERVICE_OUT_TIME)
						.append(LoggingConstant.EQUALS).append(serviceOutTime);
			}

			String consumerHostIp = IPUtil.getIPAddr();
			if (consumerHostIp != null) {
				endString.append(LoggingConstant.COMMA)
						.append(LoggingConstant.CLIENT_IP)
						.append(LoggingConstant.EQUALS).append(consumerHostIp);
			}

			String consumerHostName = IPUtil.getObfuscatedHostName();
			if (consumerHostName != null) {
				endString.append(LoggingConstant.COMMA)
						.append(LoggingConstant.CLIENT_NAME)
						.append(LoggingConstant.EQUALS)
						.append(consumerHostName);
			}

			String serviceClassName = CommonUtil.getFirst(headers,
					HeaderElements.SERVICE_CLASS_NAME);
			if(serviceClassName!=null){
				endString.append(LoggingConstant.COMMA)
				.append(LoggingConstant.SERVICE_CLASS_NAME)
				.append(LoggingConstant.EQUALS).append(serviceClassName);
			}
			
			String serviceMethodName = CommonUtil.getFirst(headers,
					HeaderElements.SERVICE_METHOD_NAME);
			if(serviceClassName!=null){
				endString.append(LoggingConstant.COMMA)
				.append(LoggingConstant.SERVICE_METHOD_NAME)
				.append(LoggingConstant.EQUALS).append(serviceMethodName);
			}
			
			String serviceServerName = CommonUtil.getFirst(headers,
					HeaderElements.SERVICE_SERVER_NAME);

			if (serviceServerName != null) {
				endString.append(LoggingConstant.COMMA)
						.append(LoggingConstant.X_SERVED_BY)
						.append(LoggingConstant.EQUALS)
						.append(serviceServerName);
			}
			
			String xPoweredBy = CommonUtil.getFirst(headers,
					LoggingConstant.X_POWERED_BY);
			if (xPoweredBy != null) {
				endString.append(LoggingConstant.COMMA).append(xPoweredBy)
						.append(LoggingConstant.EQUALS).append(xPoweredBy);
			}
		}

		Object code = message.get(Message.RESPONSE_CODE);
		String statusCode = String.valueOf(code);
		if (statusCode != null) {
			endString.append(LoggingConstant.COMMA)
					.append(LoggingConstant.STATUSCODE)
					.append(LoggingConstant.EQUALS).append(statusCode);
		}
		if (SOAStringUtil.isNotBlank(uriStr)) {
			TransactionLogger.endTransaction(uriGrp.toString(),
					endString.toString());
		} else {
			TransactionLogger.endTransaction(endString.toString());
		}

		GUIDThreadLocal.unset();

	}

	/**
	 * This method wraps the logException of logmon's transaction logger.
	 * 
	 * @param message
	 * 
	 * @param e
	 */
	public static void logException(String message, Throwable e) {
		TransactionLogger.logException(message, e);
	}

}
