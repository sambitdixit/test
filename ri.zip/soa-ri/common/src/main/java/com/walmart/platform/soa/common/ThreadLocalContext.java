package com.walmart.platform.soa.common;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * A singleton class which is used to hold thread specific contextual data that
 * can be shared or used across threads.
 * 
 * @author sdikshi
 * 
 */
public final class ThreadLocalContext {

	private static final ThreadLocal<Map<String, Object>> transAttributesHolder = new ThreadLocal<Map<String, Object>>();

	private static final ThreadLocalContext self = new ThreadLocalContext();

	private ThreadLocalContext() {
	}

    /**
     *
     * @return
     */
	public static ThreadLocalContext instance() {
		return self;
	}

	/**
	 * Returns all the attributes stored in current thread local context.
	 * 
	 * @return
	 */
	public Map<String, Object> getTransAttributes() {
		Map<String, Object> attributes = transAttributesHolder.get();
		if (attributes == null) {
			attributes = new ConcurrentHashMap<String, Object>();
			transAttributesHolder.set(attributes);
		}
		return attributes;
	}

	/**
	 * Gets the value from therad local context for specific key.
	 * 
	 * @param key
	 * @return
	 */
	public Object getTransAttribute(String key) {
		return getTransAttributes().get(key);
	}

	/**
	 * Sets a map of key values pairs.
	 * 
	 * @param attribs
	 */
	public void setTransAttributes(Map<String, Object> attribs) {
		if (attribs != null && !attribs.isEmpty()) {
			getTransAttributes().putAll(attribs);
		}
	}

	/**
	 * Set specific key and value to a thread local context.
	 * 
	 * @param key
	 * @param value
	 */
	public void setTransAttribute(String key, Object value) {
		if (key != null && value != null) {
			getTransAttributes().put(key, value);
		}
	}

	/**
	 * Reset all the attributes from thread local context.
	 * 
	 */
	public void removeAllTransAttributes() {
		transAttributesHolder.remove();
	}


}
