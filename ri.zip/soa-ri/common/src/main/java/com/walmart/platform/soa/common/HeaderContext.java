package com.walmart.platform.soa.common;

import java.util.HashMap;
import java.util.Map;

/**
 * A singleton class which is used to hold thread specific header data that
 * can be shared or used across threads.
 * 
 * @author sdikshi
 * 
 */
public final class HeaderContext {

	private static final ThreadLocal<Map<String, String>> headers = new ThreadLocal<Map<String, String>>() {
		 protected HashMap<String,String> initialValue() {
	            return new HashMap<String,String>();
	        }
	};

	private static final HeaderContext self = new HeaderContext();

	private HeaderContext() {
	}

    /**
     *
     * @return
     */
	public static HeaderContext instance() {
		return self;
	}

	/**
	 * Returns all the attributes stored in current thread local context.
	 * 
	 * @return
	 */
	public Map<String, String> getHeaders() {
		Map<String, String> attributes = headers.get();
		if (attributes == null) {
			attributes = new HashMap<String, String>();
			headers.set(attributes);
		}
		return attributes;
	}

	/**
	 * Gets the value from therad local context for specific key.
	 * 
	 * @param key
	 * @return
	 */
	public String getHeader(String key) {
		return getHeaders().get(key);
	}

	/**
	 * Sets a map of key values pairs.
	 * 
	 * @param attribs
	 */
	public void setHeaders(Map<String, String> attribs) {
		if (attribs != null && !attribs.isEmpty()) {
			getHeaders().putAll(attribs);
		}
	}

	/**
	 * Set specific key and value to a thread local context.
	 * 
	 * @param key
	 * @param value
	 */
	public void setHeader(String key, String value) {
		if (key != null && value != null) {
			getHeaders().put(key, value);
		}
	}

	/**
	 * Reset all the attributes from thread local context.
	 * 
	 */
	public void clearHeaders() {
		getHeaders().clear();
	}


}
