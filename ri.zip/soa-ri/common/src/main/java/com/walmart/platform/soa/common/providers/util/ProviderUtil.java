package com.walmart.platform.soa.common.providers.util;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;

import org.apache.cxf.common.classloader.ClassLoaderUtils;
import org.apache.cxf.jaxrs.utils.InjectionUtils;

import com.walmart.platform.soa.common.exception.SOAException;
import com.walmart.platform.soa.common.service.wrappers.ServiceRequest;
import com.walmart.platform.soa.common.service.wrappers.ServiceResponse;
import com.walmart.platform.soa.common.util.SOAStringUtil;

/**
 * @author sdikshi
 *
 */
public abstract class ProviderUtil {
	
	public static final String PAYLOAD_TYPE = "payloadType";
	
	
	/**
	 * Utility method to check actual parameter type.
	 * 
	 * @param genericType
	 * @return
	 */
	public static Type getActualParameterType(Type genericType) {
		if (ParameterizedType.class.isAssignableFrom(genericType.getClass())
				&& InjectionUtils.getRawType(genericType).isAssignableFrom(
						ServiceResponse.class)) {
			ParameterizedType paramType = (genericType instanceof ParameterizedType) ? (ParameterizedType) genericType
					: null;
			if (paramType != null) {
				// Check as in some cases, the returned array be empty
				if (paramType.getActualTypeArguments().length > 0) {
					// Fetch the actual type at index 0
                    return InjectionUtils.getType(paramType.getActualTypeArguments(), 0);
				}
			}
		}
		return null;
	}
	
	public static String getParameterTypes(Type genericType) {
		String types = "";
		if (ParameterizedType.class.isAssignableFrom(genericType.getClass()) && 
				( InjectionUtils.getRawType(genericType).isAssignableFrom(ServiceResponse.class) || 
						InjectionUtils.getRawType(genericType).isAssignableFrom(ServiceRequest.class))) {
			while(genericType instanceof ParameterizedType){
			ParameterizedType paramType = (genericType instanceof ParameterizedType) ? (ParameterizedType) genericType
					: null;
			if (paramType != null) {
				
				// Check as in some cases, the returned array be empty
				if (paramType.getActualTypeArguments().length > 0) {
					// Fetch the actual type at index 0
					genericType =  InjectionUtils.getType(paramType.getActualTypeArguments(), 0);
					Class<?> rawType = InjectionUtils.getRawType(genericType);
					if(rawType!=null){
						if(!SOAStringUtil.isBlank(types)){
							types += ":";
						}
						types += rawType.getName();
					}
				}
				}
			}
		}
		return types;
	}

	
	/**
	 * Utility method which returns the payload class type for the class name
	 * passed
	 * 
	 * @param payloadClass
	 * @return
	 */
	public static Class<?> getPayloadClass(String payloadClass) {
		Class<?> payloadType = null;
		try {
			payloadType = ClassLoaderUtils.loadClass(payloadClass, ProviderUtil.class);
		} catch (ClassNotFoundException e) {
			throw new SOAException("Payload class '" + payloadClass
					+ "' not found", e);
		}

		return payloadType;
	}
	
	

}
