package com.walmart.platform.soa.common;

import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * Utility class to get Oauth 1.0 and OAuth 2.0 specific tokens from http
 * header. For example in case of OAuth 1.0 it will be "oauth_token" where as in
 * case of OAuth 2.0, it will be "Bearer"
 * 
 * @author sambitdikshit
 * 
 */
public final class OAuthUtil {

    private OAuthUtil() {
    }

    /**
	 * Extracts the "OAuth" or "oauth_token" from http header and returns the
	 * token value.
	 * 
	 * @param authzHeader
	 * @return
	 */
	public static String getOAuth10Token(String authzHeader) {
		String oauthToken = null;
		if (authzHeader != null && authzHeader.startsWith("OAuth")
				&& authzHeader.contains("oauth_token=")) {
			int startIndex = authzHeader.indexOf("oauth_token=");
			int len = "oauth_token=".length();
			int firstCommaIndex = authzHeader.indexOf(",");
			if (firstCommaIndex != -1) {
				int endIndex = authzHeader.indexOf(",", startIndex);
				oauthToken = authzHeader.substring(startIndex + len, endIndex);
			} else {
				oauthToken = authzHeader.substring(startIndex + len,
						authzHeader.length());
			}
		}
		return oauthToken;
	}

	/**
	 * Extracts the "Bearer" token from http header and returns the token value.
	 * 
	 * @param authzHeader
	 * @return
	 */
	public static String getOAuth20Token(String authzHeader) {
		String oauthToken = null;
		if (authzHeader != null && authzHeader.startsWith("Bearer")) {
			String[] parts = authzHeader.split(" ");
			if (parts.length == 2) {
				oauthToken = parts[1];
			}
		}
		return oauthToken;
	}

	/**
	 * Check if OAuthToken is passed in Authorization header, if yes,extract it
	 * and set it to consumer_auth_token.
	 * 
	 * @param headers
	 * 
	 */
	public static void checkNReplaceToken(Map<String, List<String>> headers) {
		if (headers != null) {
			if (headers.get(HeaderElements.CONSUMER_AUTH_TOKEN) == null) {
				// check if OAuthToken is passed in Authorization header, if
				// yes,extract it and set it to consumer_auth_token.
				if (headers.containsKey("Authorization")) {
					List<String> hds = headers.get("Authorization");
					if (hds != null && hds.size() > 0) {
						String authzHeader = hds.get(0);
						// Try OAuth2.0 from Authorization header. If not try
						// OAuth1.0
						String oauthToken = getOAuth20Token(authzHeader);
						if (oauthToken == null) {
							oauthToken = getOAuth10Token(authzHeader);
						}

						if (oauthToken != null) {
							headers.put(HeaderElements.CONSUMER_AUTH_TOKEN,
									Collections.singletonList(oauthToken));
						}
					}
				}
			}
		}

	}

}
