package com.walmart.platform.soa.common;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.ws.rs.HttpMethod;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.interceptor.Interceptor;
import org.apache.cxf.jaxrs.model.ClassResourceInfo;
import org.apache.cxf.jaxrs.model.OperationResourceInfo;
import org.apache.cxf.message.Exchange;
import org.apache.cxf.message.Message;
import org.apache.cxf.message.MessageContentsList;

import com.walmart.platform.kernel.exception.error.Error;
import com.walmart.platform.kernel.exception.error.ErrorCategory;
import com.walmart.platform.kernel.exception.error.ErrorSeverity;
import com.walmart.platform.soa.common.exception.HeaderValidationException;
import com.walmart.platform.soa.common.logging.LoggingConstant;
import com.walmart.platform.soa.common.service.wrappers.ServiceResponse;
import com.walmart.platform.soa.common.service.wrappers.Status;
import com.walmart.platform.soa.common.util.ArtifactVersionUtil;
import com.walmart.platform.soa.common.util.IPUtil;
import com.walmart.platform.soa.common.util.SOAStringUtil;


/**
 * @author sdikshi
 *
 */
public final class CommonUtil {

	/**
	 * Private constructor
	 */
	private CommonUtil() {
	}

	private static String env = "";
	public static final String LOCAL_PREFIX = "local";
	public static final String LOCAL_RESPONSE = "LocalResponse";
	public static final String PRIVATE_KEY_ALGO_NAME = "RSA";
	public static final String ENCODING_FORMAT = "PKCS#8";
	public static final String SERVICE_AUTH_HEADERS = "WM_CONSUMER.ID;WM_CONSUMER.INTIMESTAMP";
	public static final String ESB_AUTHENTICATED = "5W63u9Qt4bcA0RvaLs6T";
	public static final String ESB_TOKEN = "h*j10^IA0MPAQ";

	static {
		env = System.getProperty("com.walmart.platform.config.runOnEnv",
				"default");
	}

	/**
	 * Gets the environment value set in "com.walmart.platform.config.runOnEnv"
	 * and if not found returns "default".
	 * 
	 * @return Gets the Environment
	 */
	public static String getEnv() {
		return env;
	}

	/**
	 * Checks if the URL starts with "local://" if yes, then its considered as a
	 * local call.
	 * 
	 * @param url
	 * @return
	 */
	public static boolean isLocalURL(String url) {
		if (SOAStringUtil.isNotBlank(url) && url.startsWith(LOCAL_PREFIX)) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Checks if URL is live or not
	 * 
	 * @param url
	 * @return
	 * @throws IOException
	 */
	public static boolean isLive(String url) throws IOException {
		HttpURLConnection httpConnection = null;
		URL contactURL = new URL(url);
		httpConnection = (HttpURLConnection) contactURL.openConnection();
		httpConnection.setRequestMethod("HEAD");
		httpConnection.connect();
		if (httpConnection.getResponseCode() == HttpURLConnection.HTTP_OK) {
			return true;
		}
		return false;
	}

	/**
	 * 
	 * @param message
	 * @return
	 */
	public static boolean isClient(Message message) {
		Object obj = message.get(Message.REQUESTOR_ROLE);
		if (obj != null) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Checks if the destination type is local transport or not.
	 * 
	 * @param message
	 * @return
	 */
	public static boolean isLocalDestination(Message message) {
		String address = (String) ((message.get(Message.ENDPOINT_ADDRESS) != null) ? message
				.get(Message.ENDPOINT_ADDRESS) : "");
		if (address.startsWith(LOCAL_PREFIX)) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Gets the first element from protocol header list for a specific key.
	 * 
	 * @param headers
	 * @param key
	 * @return
	 */
	public static String getFirst(Map<String, List<String>> headers, String key) {
		String val = null;
		if (headers != null && !headers.isEmpty()) {
			List<String> vals = headers.get(key);
			if (vals != null && vals.size() > 0) {
				val = vals.get(0);
			}
		}
		return val;
	}

	/**
	 * Put the values of a protocol header against a key.
	 * 
	 * @param headers
	 * @param key
	 * @param val
	 */
	public static void putSingle(Map<String, List<String>> headers, String key,
			String val) {
		if (headers != null) {
			headers.put(key, Collections.singletonList(val));
		}
	}

	/**
	 * Gets the protocol headers from message.
	 * 
	 * @param message
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static Map<String, List<String>> getProtocolHeaders(Message message) {
		Map<String, List<String>> headers = (Map<String, List<String>>) message
				.get(Message.PROTOCOL_HEADERS);
		if (headers == null) {
			headers = new TreeMap<String, List<String>>(
					String.CASE_INSENSITIVE_ORDER);
			message.put(Message.PROTOCOL_HEADERS, headers);
		}
		return headers;
	}

	/**
	 * Gets the protocol headers from message's exchange
	 * 
	 * @param message
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static Map<String, List<String>> getExchangeProtocolHeaders(
			Message message) {
		Exchange ex = message.getExchange();
		Map<String, List<String>> headers = (Map<String, List<String>>) ex
				.get(Message.PROTOCOL_HEADERS);
		if (headers == null) {
			headers = new TreeMap<String, List<String>>(
					String.CASE_INSENSITIVE_ORDER);

		}
		ex.put(Message.PROTOCOL_HEADERS, headers);
		message.setExchange(ex);
		return headers;
		// return null;
	}

	/**
	 * 
	 * @param headers
	 * @return
	 */
	public static Map<String, String> getServiceAuthHeaders(
			Map<String, List<String>> headers) {
		Map<String, String> serviceAuthHeaders = new HashMap<String, String>();
		
		// add CONSUMER_ID
		serviceAuthHeaders.put(HeaderElements.CONSUMER_ID,
				CommonUtil.getFirst(headers, HeaderElements.CONSUMER_ID));

		// add CONSUMER_IN_TIMESTAMP
		String consumerInTimestamp = CommonUtil.getFirst(headers,HeaderElements.CONSUMER_IN_TIMESTAMP); 
		if (consumerInTimestamp != null) {
			serviceAuthHeaders.put(HeaderElements.CONSUMER_IN_TIMESTAMP, consumerInTimestamp);
		} else {
			String timeStamp = String.valueOf(System.currentTimeMillis());
			serviceAuthHeaders.put(HeaderElements.CONSUMER_IN_TIMESTAMP,
					timeStamp);
		}
		
		// add CONSUMER_RPIVATE_KEY_VERSION
		String consumerPrivateKeyVersion = CommonUtil.getFirst(headers,HeaderElements.CONSUMER_PRIVATE_KEY_VERSION);
		if(consumerPrivateKeyVersion == null) {
			serviceAuthHeaders.put(HeaderElements.CONSUMER_PRIVATE_KEY_VERSION, "1");
		}
		else {
			serviceAuthHeaders.put(HeaderElements.CONSUMER_PRIVATE_KEY_VERSION, consumerPrivateKeyVersion);
		}
		return serviceAuthHeaders;
	}

	/**
	 * Inject request header elements to exchange context.
	 * 
	 * @param message
	 * @throws Fault
	 */
	public static void injectRequestHeaders(Message message) throws Fault {
		Map<String, List<String>> headers = getProtocolHeaders(message);
		Exchange ex = message.getExchange();
		if (ex != null) {
			String consumerAppId = getFirst(headers, HeaderElements.CONSUMER_ID);
			if(SOAStringUtil.isNotBlank(consumerAppId)){
			ex.put(HeaderElements.CONSUMER_ID, consumerAppId);
			}
			String consumerSourceId = getFirst(headers, HeaderElements.CONSUMER_SOURCE_ID);
			if(SOAStringUtil.isNotBlank(consumerSourceId)){
			 ex.put(HeaderElements.CONSUMER_SOURCE_ID, consumerSourceId);
			}
			
			String consumerAuthToken = getFirst(headers,HeaderElements.CONSUMER_AUTH_TOKEN);
			ex.put(HeaderElements.CONSUMER_AUTH_TOKEN, consumerAuthToken);
			String consumerGuid = getFirst(headers,HeaderElements.CONSUMER_GUID);
			ex.put(HeaderElements.CONSUMER_GUID, consumerGuid);
			String consumerIp = getFirst(headers, HeaderElements.CONSUMER_IP);
			ex.put(HeaderElements.CONSUMER_IP, consumerIp);
			String consumerName = getFirst(headers,HeaderElements.CONSUMER_NAME);
			ex.put(HeaderElements.CONSUMER_NAME, consumerName);
			String consumerInTs = getFirst(headers,HeaderElements.CONSUMER_IN_TIMESTAMP);
			ex.put(HeaderElements.CONSUMER_IN_TIMESTAMP, consumerInTs);
			String consumerType = getFirst(headers,HeaderElements.CONSUMER_TYPE);
			// Check if consumer type is blank, if yes, then set default to
			// "INTERNAL";
			if (SOAStringUtil.isBlank(consumerType)) {
				// Set to default as "INTERNAL".
				consumerType = "INTERNAL";
				putSingle(headers, HeaderElements.CONSUMER_TYPE, consumerType);
			}
			ex.put(HeaderElements.CONSUMER_TYPE, consumerType);
			
			String serviceName = getFirst(headers, HeaderElements.SERVICE_NAME);
			ex.put(HeaderElements.SERVICE_NAME, serviceName);
			String serviceVersion = getFirst(headers,HeaderElements.SERVICE_VERSION);
			ex.put(HeaderElements.SERVICE_VERSION, serviceVersion);
			String serviceEnv = getFirst(headers, HeaderElements.SERVICE_ENV);

			if (SOAStringUtil.isBlank(serviceEnv)) {
				serviceEnv = env;
			}

			ex.put(HeaderElements.SERVICE_ENV, serviceEnv);

			ex.put(HeaderElements.SERVICE_IN_TIMESTAMP,String.valueOf(System.currentTimeMillis()));
			ex.put(HeaderElements.SERVICE_SERVER_NAME,IPUtil.getObfuscatedHostName());
			ex.put(HeaderElements.SERVICE_SERVER_IP, IPUtil.getIPAddr());
			String protocol = getFirst(headers,HeaderElements.TRANSACTION_PROTOCOL);
			//Ideally the protocol value should come only for local. 
			if (SOAStringUtil.isNotBlank(protocol)) {
				ex.put(HeaderElements.TRANSACTION_PROTOCOL, protocol);
			}

			Object contentTypeObj = message.get(Message.CONTENT_TYPE);
			if (contentTypeObj != null) {
				String contentType = contentTypeObj.toString();
				if (contentType.contains(MediaType.WILDCARD)) {
					contentType = MediaType.APPLICATION_JSON;
				}
				ex.put(HeaderElements.CONTENT_TYPE, contentType);
			}

			Object acceptContentTypeObj = message.get(Message.ACCEPT_CONTENT_TYPE);
			if (acceptContentTypeObj != null) {
				String acceptContentType = acceptContentTypeObj.toString();
				if (acceptContentType.contains(MediaType.WILDCARD)) {
					acceptContentType = MediaType.APPLICATION_JSON;
				}
				ex.put(HeaderElements.ACCEPT, acceptContentType);
			}
			
			String userAgent = getFirst(headers,HeaderElements.USER_AGENT);
			if(SOAStringUtil.isNotBlank(userAgent)){
			 ex.put(HeaderElements.USER_AGENT, userAgent);
			}
			
			String contentLength = getFirst(headers,HeaderElements.CONTENT_LENGTH);
			if(SOAStringUtil.isNotBlank(contentLength)){
			 ex.put(HeaderElements.CONTENT_LENGTH, contentLength);
			}
		}
	}

	/**
	 * Injects response header by extracting values from exchange.
	 * 
	 * @param message
	 * @throws Fault
	 */
	public static void injectResponseHeaders(Message message) throws Fault {
		Map<String, List<String>> responseHeaders = getProtocolHeaders(message);
		Exchange ex = message.getExchange();
		if (ex != null) {
			String serviceOutTime = String.valueOf(System.currentTimeMillis());
			ex.put(HeaderElements.SERVICE_OUT_TIMESTAMP, serviceOutTime);
			
			String temp = null;
			String serviceInTime = (temp = (String) ex.get(HeaderElements.SERVICE_IN_TIMESTAMP)) != null ? temp : "";
			String consumerInTime = (temp = (String) ex.get(HeaderElements.CONSUMER_IN_TIMESTAMP)) != null ? temp : ""; 
			
			// Fetch service-related parameters & GUID
			String serviceName = (temp = (String) ex.get(HeaderElements.SERVICE_NAME)) != null ? temp : "";
			String serviceEnv = (temp = (String) ex.get(HeaderElements.SERVICE_ENV)) != null ? temp : "";
			String serviceVersion = (temp = (String) ex.get(HeaderElements.SERVICE_VERSION)) != null ? temp : "";
			String guid = (temp = (String) ex.get(HeaderElements.CONSUMER_GUID)) != null ? temp : "";
			String consumerID = (temp = (String) ex.get(HeaderElements.CONSUMER_ID)) != null ? temp : "";
			String serviceServerName = (temp = (String) ex.get(HeaderElements.SERVICE_SERVER_NAME)) != null ? temp : ""; 
			String serviceServerIP = (temp = (String) ex.get(HeaderElements.SERVICE_SERVER_IP)) != null ? temp : ""; 
			String protocol = (temp = (String) ex.get(HeaderElements.TRANSACTION_PROTOCOL)) != null ? temp : LoggingConstant.HTTP;
			
			/* Below code will extract service class name and method name and set in the exchange and header. */
			Object tempObj = ex.get("org.apache.cxf.jaxrs.model.OperationResourceInfo");
			String serviceMethodName = null;
			String serviceClassName = null;
			ClassResourceInfo clsInfo = null;
			OperationResourceInfo opInfo=null;
			if (tempObj != null) {
				opInfo = (OperationResourceInfo) tempObj;
				serviceMethodName = opInfo.getMethodToInvoke().getName();
				clsInfo = opInfo.getClassResourceInfo();
				if (clsInfo != null) {
					serviceClassName = clsInfo.getResourceClass().getName();
				}
			}
			
			if (serviceClassName == null || serviceClassName.isEmpty()) {
				tempObj = ex.get("root.resource.class");
				if (tempObj != null) {
					clsInfo = (ClassResourceInfo) tempObj;
					serviceClassName = clsInfo.getResourceClass().getName();
				}
			}
			
			
			// Inject service-related parameters & GUID
			
			if(serviceClassName!=null){
				putSingle(responseHeaders, HeaderElements.SERVICE_CLASS_NAME,serviceClassName);
				ex.put(HeaderElements.SERVICE_CLASS_NAME, serviceClassName);
			}
			
			if(serviceMethodName!=null){
				putSingle(responseHeaders, HeaderElements.SERVICE_METHOD_NAME,serviceMethodName);
				ex.put(HeaderElements.SERVICE_METHOD_NAME, serviceMethodName);
			}
			
			putSingle(responseHeaders, HeaderElements.SERVICE_OUT_TIMESTAMP,serviceOutTime);
			putSingle(responseHeaders, HeaderElements.SERVICE_IN_TIMESTAMP,serviceInTime);
			putSingle(responseHeaders, HeaderElements.CONSUMER_IN_TIMESTAMP,consumerInTime);
			putSingle(responseHeaders, HeaderElements.SERVICE_NAME, serviceName);
			putSingle(responseHeaders, HeaderElements.SERVICE_ENV, serviceEnv);
			putSingle(responseHeaders, HeaderElements.SERVICE_VERSION,serviceVersion);
			putSingle(responseHeaders, HeaderElements.CONSUMER_GUID, guid);
			putSingle(responseHeaders, HeaderElements.CONSUMER_ID, consumerID);
			putSingle(responseHeaders, HeaderElements.SERVICE_SERVER_NAME,serviceServerName);
			putSingle(responseHeaders, HeaderElements.SERVICE_SERVER_IP,serviceServerIP);
			//putSingle(responseHeaders, HeaderElements.TRANSACTION_PROTOCOL,protocol);
			putSingle(responseHeaders, LoggingConstant.X_POWERED_BY,ArtifactVersionUtil.getSOAInterceptor());
			if (SOAStringUtil.isNotBlank(protocol)
					&& protocol.startsWith(LOCAL_PREFIX)) {
				if (!(responseHeaders.containsKey(HeaderElements.CONTENT_TYPE))) {
					String contentType = (temp = (String) ex.get(HeaderElements.CONTENT_TYPE)) != null ? temp : MediaType.APPLICATION_XML;
					putSingle(responseHeaders, HeaderElements.CONTENT_TYPE,contentType);
				}
			}
		
			Object code = message.get(Message.RESPONSE_CODE);
			if(code!=null){
			   String statusCode = String.valueOf(code);
			   putSingle(responseHeaders, HeaderElements.HTTP_STATUS_CODE, statusCode);
			}

		}
	}

	/**
	 * Check not null blank values in header and throws header validation
	 * exception if found blank or null.
	 * 
	 * @param message
	 * @throws Fault
	 */
	public static void checkNotNullIfHeaderPresent(Message message)
			throws Fault {
		Map<String, List<String>> headers = getProtocolHeaders(message);
		List<Error> errors = new ArrayList<Error>();

		String consumerAppId = getFirst(headers, HeaderElements.CONSUMER_ID);
		String consumerGuid = getFirst(headers, HeaderElements.CONSUMER_GUID);
		String serviceName = getFirst(headers, HeaderElements.SERVICE_NAME);
		String serviceVersion = getFirst(headers,HeaderElements.SERVICE_VERSION);
		
//		if (SOAStringUtil.isBlank(serviceVersion)) {
//			String uri = (String) message.get(Message.REQUEST_URI);
//			String versionFromUri = VersionUtil.getVersion(uri);
//			if(SOAStringUtil.isNotBlank(versionFromUri)){
//				serviceVersion = versionFromUri;
//			}
//		}
		if (SOAStringUtil.isBlank(serviceVersion)) {
			String uri = (String) message.get(Message.REQUEST_URI);
			serviceVersion = VersionUtil.getVersion(uri);
		}
//		
		
		if (headers.containsKey(HeaderElements.CONSUMER_AUTH_TOKEN)) {
			String consumerAuthToken = getFirst(headers,
					HeaderElements.CONSUMER_AUTH_TOKEN);
			if (SOAStringUtil.isBlank(consumerAuthToken)) {
				errors.add(getHeaderValidationError(HeaderElements.CONSUMER_AUTH_TOKEN));
			}
		}

		if (headers.containsKey(HeaderElements.CONSUMER_AUTH_SIGNATURE)) {
			String consumerAuthToken = getFirst(headers,
					HeaderElements.CONSUMER_AUTH_SIGNATURE);
			if (SOAStringUtil.isBlank(consumerAuthToken)) {
				errors.add(getHeaderValidationError(HeaderElements.CONSUMER_AUTH_SIGNATURE));
			}
		}

		if (headers.containsKey(HeaderElements.CONSUMER_TYPE)) {
			String consumerType = getFirst(headers,
					HeaderElements.CONSUMER_TYPE);
			if (SOAStringUtil.isBlank(consumerType)) {
				errors.add(getHeaderValidationError(HeaderElements.CONSUMER_TYPE));
			}
		}

		if (headers.containsKey(HeaderElements.CONSUMER_IP)) {
			String consumerIp = getFirst(headers, HeaderElements.CONSUMER_IP);
			if (SOAStringUtil.isBlank(consumerIp)) {
				errors.add(getHeaderValidationError(HeaderElements.CONSUMER_IP));
			}
		}

		if (headers.containsKey(HeaderElements.CONSUMER_IN_TIMESTAMP)) {
			String consumerInTs = getFirst(headers,
					HeaderElements.CONSUMER_IN_TIMESTAMP);
			if (SOAStringUtil.isBlank(consumerInTs)) {
				errors.add(getHeaderValidationError(HeaderElements.CONSUMER_IN_TIMESTAMP));
			}
		}

		if (SOAStringUtil.isBlank(consumerGuid)) {
			errors.add(getHeaderValidationError(HeaderElements.CONSUMER_GUID));
		}

		if (SOAStringUtil.isBlank(consumerAppId)) {
			errors.add(getHeaderValidationError(HeaderElements.CONSUMER_ID));
		}

		if (SOAStringUtil.isBlank(serviceName)) {
			errors.add(getHeaderValidationError(HeaderElements.SERVICE_NAME));
		}

		if (SOAStringUtil.isBlank(serviceVersion)) {
			errors.add(getHeaderValidationError(HeaderElements.SERVICE_VERSION));
		}
		
		// check if version is of the form x.y.z, if in x.y format, append ".0"
		/*if(serviceVersion!=null&&serviceVersion.split("\\.").length != 3) {
			if(serviceVersion.split("\\.").length==2){
				serviceVersion = serviceVersion + ".0";
			}
			//errors.add(getInvalidVersionFormatError(HeaderElements.SERVICE_VERSION));
		}*/
				
				
		if (errors.size() > 0) {
			throw new HeaderValidationException(errors);
		}
	}

	/**
	 * Sets the http status code in jax.ws.rs.Response based on service response
	 * status.
	 * 
	 * @param message
	 * @throws Fault
	 */
	public static void setHttpStatusCodes(Message message) throws Fault {
		MessageContentsList objs = MessageContentsList.getContentsList(message);
		if (objs == null || objs.size() == 0) {
			return;
		}
		Object responseObj = objs.get(0);

		// Verify the Response Object
		if (responseObj instanceof ServiceResponse) {

			ServiceResponse<?> svcRes = (ServiceResponse<?>) responseObj;
			Response res = null;
			Status st = svcRes.getStatus();
			if (st.equals(Status.OK)) {
				res = Response.status(javax.ws.rs.core.Response.Status.OK).entity(svcRes).build();
			}else if (st.equals(Status.CREATED)) {
				res = Response.status(javax.ws.rs.core.Response.Status.CREATED).entity(svcRes).build();
			} else if (st.equals(Status.ACCEPTED)) {
				res = Response.status(javax.ws.rs.core.Response.Status.ACCEPTED).entity(svcRes).build();
			} else if (st.equals(Status.NO_CONTENT)) {
				res = Response.status(javax.ws.rs.core.Response.Status.NO_CONTENT).entity(svcRes).build();
			} else if (st.equals(Status.PARTIAL)) {
				res = Response.status(Status.PARTIAL.getCode()).entity(svcRes).build();
			} else if (st.equals(Status.MOVED_PERMANENT)) {
				res = Response.status(Status.MOVED_PERMANENT.getCode()).entity(svcRes).build();
			} else if (st.equals(Status.FOUND)) {
				res = Response.status(Status.FOUND.getCode()).entity(svcRes).build();
			} else if (st.equals(Status.SEE_OTHER)) {
				res = Response.status(Status.SEE_OTHER.getCode()).entity(svcRes).build();
			} else if (st.equals(Status.NOT_MODIFIED)) {
				res = Response.status(Status.NOT_MODIFIED.getCode()).entity(svcRes).build();
			} else if (st.equals(Status.TEMPORARY_REDIRECT)) {
				res = Response.status(Status.TEMPORARY_REDIRECT.getCode()).entity(svcRes).build();
			} else if (st.equals(Status.BAD_REQUEST)) {
				res = Response.status(javax.ws.rs.core.Response.Status.BAD_REQUEST).entity(svcRes).build();
			} else if (st.equals(Status.UNAUTHORIZED)) {
				res = Response.status(javax.ws.rs.core.Response.Status.UNAUTHORIZED).entity(svcRes).build();
			} else if (st.equals(Status.FORBIDDEN)) {
				res = Response.status(javax.ws.rs.core.Response.Status.FORBIDDEN).entity(svcRes).build();
			} else if (st.equals(Status.NOT_FOUND)) {
				res = Response.status(javax.ws.rs.core.Response.Status.NOT_FOUND).entity(svcRes).build();
			} else if (st.equals(Status.METHOD_NOT_ALLOWED)) {
				res = Response.status(Status.METHOD_NOT_ALLOWED.getCode()).entity(svcRes).build();
			} else if (st.equals(Status.NOT_ACCEPTABLE)) {
				res = Response.status(Status.NOT_ACCEPTABLE.getCode()).entity(svcRes).build();
			}  else if (st.equals(Status.REQUEST_TIMEOUT)) {
				res = Response.status(Status.REQUEST_TIMEOUT.getCode()).entity(svcRes).build();
			} else if (st.equals(Status.CONFLICT)) {
				res = Response.status(javax.ws.rs.core.Response.Status.CONFLICT).entity(svcRes).build();
			} else if (st.equals(Status.UNSUPPORTED_MEDIA_TYPE)) {
				res = Response.status(javax.ws.rs.core.Response.Status.UNSUPPORTED_MEDIA_TYPE).entity(svcRes).build();
			} else if (st.equals(Status.FAIL)) {
				res = Response.status(javax.ws.rs.core.Response.Status.INTERNAL_SERVER_ERROR).entity(svcRes).build();
			} else if (st.equals(Status.BAD_GATEWAY)) {
				res = Response.status(javax.ws.rs.core.Response.Status.BAD_GATEWAY).entity(svcRes).build();
			} else if (st.equals(Status.SERVICE_UNAVAILABLE)) {
				res = Response.status(javax.ws.rs.core.Response.Status.SERVICE_UNAVAILABLE).entity(svcRes).build();
			} else {
				res = Response.status(javax.ws.rs.core.Response.Status.OK).entity(svcRes).build();
			}
			// Setting the Res to both Message and MessageContentsList
			objs.set(0, res);
			message.setContent(javax.ws.rs.core.Response.class, res);
		}
	}

	/**
	 * 
	 * @param interceptorClassName
	 * @param iterator
	 */
	public static void removeInterceptor(String interceptorClassName,
			Iterator<Interceptor<? extends Message>> iterator) {
		while (iterator.hasNext()) {
			Interceptor<? extends Message> interceptor = iterator.next();
			if (interceptorClassName.equals(interceptor.getClass().getName())) {
				iterator.remove();
				return;
			}
		}
	}

	/**
	 * 
	 * @param transactionProtocols
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	public static boolean isLocalProtocol(List transactionProtocols) {
		return transactionProtocols != null
				&& transactionProtocols.contains("local");
	}

	
	
	/**
	 * @param consumerGuid
	 * @return
	 */
	/*
	private static Error getInvalidVersionFormatError(String versionNoField) {
		Error err = new Error();
		err.setCategory(ErrorCategory.REQUEST);
		err.setCode(String.valueOf(Status.BAD_REQUEST.getCode()));
		err.setField(versionNoField);
		err.setDescription(versionNoField + " should be in x.y.z format");
		err.setInfo(versionNoField + " should be in x.y.z format");
		err.setSeverity(ErrorSeverity.ERROR);
		return err;
	}
	*/
	
	
	/**
	 * Gets a header validation error object for supplied field.
	 * 
	 * @param field
	 * @return
	 */
	private static Error getHeaderValidationError(String field) {
		Error err = new Error();
		err.setCategory(ErrorCategory.REQUEST);
		err.setCode(String.valueOf(Status.BAD_REQUEST.getCode()));
		err.setField(field);
		err.setDescription(field + " set blank or null");
		err.setInfo(field + " set blank or null");
		err.setSeverity(ErrorSeverity.ERROR);
		return err;
	}

	public static String getAcceptOrContentType(Message message) {
		String acceptType = (String) message.getExchange().getInMessage()
				.get(org.apache.cxf.message.Message.ACCEPT_CONTENT_TYPE);
		if (SOAStringUtil.isNotBlank(acceptType))
			return acceptType;
		else {
			String contentType = (String) message.getExchange().getInMessage()
					.get(org.apache.cxf.message.Message.CONTENT_TYPE);
			return (contentType != null) ? contentType
					: MediaType.APPLICATION_JSON;
		}

	}

	/**
	 * 
	 * @param message
	 */
	public static void handleContentType(Message message) {
		Map<String, List<String>> requestHeaders = getProtocolHeaders(message);
		String method = (String) message.get(Message.HTTP_REQUEST_METHOD);
		String acceptType = CommonUtil.getFirst(requestHeaders,
				Message.ACCEPT_CONTENT_TYPE);
		String contentType = CommonUtil.getFirst(requestHeaders,
				Message.CONTENT_TYPE);
		if (method != null) {
			if (method.equalsIgnoreCase(HttpMethod.GET)
					|| method.equalsIgnoreCase(HttpMethod.DELETE)
					|| (method.equalsIgnoreCase(HttpMethod.POST) && contentType
							.equalsIgnoreCase(MediaType.APPLICATION_FORM_URLENCODED))) {
				if (contentType == null
						|| contentType.equalsIgnoreCase(MediaType.WILDCARD)
						|| contentType
								.equalsIgnoreCase(MediaType.APPLICATION_FORM_URLENCODED)) {
					if (acceptType != null
							&& !acceptType.equalsIgnoreCase(MediaType.WILDCARD)) {
						contentType = acceptType;
					} else if (acceptType != null
							&& acceptType.equalsIgnoreCase(MediaType.WILDCARD)) {
						contentType = MediaType.APPLICATION_JSON;
					}
					putSingle(requestHeaders, Message.CONTENT_TYPE, contentType);
					message.put(Message.CONTENT_TYPE, contentType);
				}
			}
		}
	}

	/**
	 * @param message
	 * @param protocolHeaders
	 * @return
	 */
	public static Map<String, List<String>> getHttpHeaders(Message message,
			Map<String, List<String>> protocolHeaders) {

		Map<String, List<String>> httpHeaders = new HashMap<String, List<String>>();

		String tempValue = (String) message.get(Message.REQUEST_URL);
		httpHeaders.put(HeaderElements.HTTP_REQUEST_URI,
				Arrays.asList(tempValue));

		tempValue = (String) message.get(Message.HTTP_REQUEST_METHOD);
		httpHeaders.put(HeaderElements.HTTP_REQUEST_METHOD,
				Arrays.asList(tempValue));

		return httpHeaders;
	}
}
