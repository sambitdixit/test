package com.walmart.platform.soa.common.logging;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * This singleton class is designed to hold audit specific attributes between
 * threads. It used InheritableThreadLocal to hold the attributes across a
 * parent and child thread.
 * 
 * User(who wants to use it explicitly) of this class must ensure to call reset
 * method at the end of the life of this context since it uses thread local to
 * hold values. if it is not followed, it will not gurantee to clean the context
 * from thread to thread and some of the values set in previous thread context
 * will appear in subsequent thread context.
 * 
 * By default this thread local context will be reset by SOAAuditLogger after
 * SOAAuditLogger.logAuditData method call.
 * 
 * 
 * @author sdikshi
 * 
 */
public final class SOAAuditContext {

	private static final ThreadLocal<Map<String, Map<String, String>>> dataHolder = new ThreadLocal<Map<String, Map<String, String>>>();
	private static final SOAAuditContext self = new SOAAuditContext();

	private SOAAuditContext() {
	}

	/**
	 * This method is used to create a singleton instance of this context.
	 * 
	 * @return
	 */
	public static SOAAuditContext instance() {
		return self;
	}

	/**
	 * This method returns the entire map audited data available in the current
	 * audit context for specific group.
	 * 
	 * @param group
	 * @return
	 */
	public Map<String, String> getData(String group) {
		Map<String, Map<String, String>> data = getData();
		if (data.containsKey(group)) {
			return data.get(group);
		} else {
			Map<String, String> d = new ConcurrentHashMap<String, String>();
			data.put(group, d);
			return d;
		}
	}

	/**
	 * This method returns the entire map audited data available in the current
	 * audit context for all group.
	 * 
	 * 
	 * @return
	 */
	public Map<String, Map<String, String>> getData() {
		Map<String, Map<String, String>> data = dataHolder.get();
		if (data == null) {
			data = new ConcurrentHashMap<String, Map<String, String>>();
			dataHolder.set(data);
		}
		return data;
	}

	/**
	 * Returns the specific value of an audit group and key.
	 * 
	 * @param group
	 * @param key
	 * @return
	 */
	public String getData(String group, String key) {
		return getData(group).get(key);
	}

	/**
	 * Sets the specific audit group, key and audit value. Preferred value for
	 * "value" argument is String type with plain text data without any XML or
	 * Special characters. The reason being these data may create issues during
	 * parsing by Log/Mon AuditLogger.
	 * 
	 * @param group
	 * @param key
	 * @param value
	 */
	public void setData(String group, String key, String value) {
		if (key != null && value != null) {
			getData(group).put(key, value);
		}
	}

	/**
	 * This method resets the entire audit context. It is recommended for user
	 * of this class to call this method at the end of its use. This is called
	 * inside SOAAuditLogger after logAuditData method call.
	 */
	public void reset() {
		dataHolder.remove();
	}

}
