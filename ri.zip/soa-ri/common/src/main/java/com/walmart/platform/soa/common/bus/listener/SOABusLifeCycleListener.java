package com.walmart.platform.soa.common.bus.listener;

import org.apache.cxf.Bus;
import org.apache.cxf.buslifecycle.BusLifeCycleListener;
import org.apache.cxf.buslifecycle.BusLifeCycleManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author sdikshi
 */
public class SOABusLifeCycleListener implements BusLifeCycleListener {

	private static final Logger LOG = LoggerFactory.getLogger(SOABusLifeCycleListener.class);

	private Bus bus = null;

	/**
	 * 
	 * @param bus
	 */
	public SOABusLifeCycleListener(Bus bus) {
		this.bus = bus;
		BusLifeCycleManager blm = bus.getExtension(BusLifeCycleManager.class);
		blm.registerLifeCycleListener(this);
	}

	@Override
	public void initComplete() {
		if(bus!=null) {
			String busId = bus.getId();
			if(LOG.isDebugEnabled())LOG.debug("Bus with id= {} is initialized", busId);
			/* Set this property to enable auto close of response stream */
			 Object autoCloseProperty = bus.getProperty("response.stream.auto.close");
			 if(autoCloseProperty == null){
				bus.setProperty("response.stream.auto.close", "true");
			}
		}
	}

	
	@Override
	public void preShutdown() {
		if(LOG.isDebugEnabled())LOG.debug("Bus with id= {} started shutdown", bus.getId());
	}

	@Override
	public void postShutdown() {
		if(LOG.isDebugEnabled())LOG.debug("Bus with id= {} shutdown completed", bus.getId());
	}
	

}
