package com.walmart.platform.soa.common.providers;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.annotation.Annotation;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.ext.Provider;

import org.apache.cxf.jaxrs.utils.InjectionUtils;
import org.codehaus.jackson.JsonParser;
import org.codehaus.jackson.jaxrs.Annotations;
import org.codehaus.jackson.jaxrs.JacksonJsonProvider;
import org.codehaus.jackson.map.DeserializationConfig;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.SerializationConfig;
import org.codehaus.jackson.map.type.TypeFactory;
import org.codehaus.jackson.type.JavaType;

import com.walmart.platform.soa.common.providers.util.ProviderUtil;
import com.walmart.platform.soa.common.service.wrappers.ServiceResponse;
import com.walmart.platform.soa.common.util.SOAStringUtil;

/**
 * Jackson based json provider. It provides support for json to pojo or
 * viceversa conversion using jackson for json payload.
 * 
 * @author sdikshi
 * 
 */
@Consumes({ MediaType.APPLICATION_JSON, "text/json" })
@Produces({ MediaType.APPLICATION_JSON, "text/json" })
@Provider
public class SOAJacksonJsonProvider extends JacksonJsonProvider {

	public final static Annotations[] BASIC_ANNOTATIONS = { Annotations.JAXB,
			Annotations.JACKSON };

	/**
     *
     */
	public SOAJacksonJsonProvider() {
		super(BASIC_ANNOTATIONS);
		super.configure(DeserializationConfig.Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		super.configure(SerializationConfig.Feature.FAIL_ON_EMPTY_BEANS, false);
	}

	@Override
	public void writeTo(Object t, Class<?> type, Type genericType,
			Annotation[] annotations, MediaType mediaType,
			MultivaluedMap<String, Object> httpHeaders,
			OutputStream entityStream) throws IOException {

		String payloadType = ProviderUtil.getParameterTypes(genericType);
	    if(SOAStringUtil.isNotBlank(payloadType)){
			httpHeaders.add(ProviderUtil.PAYLOAD_TYPE, payloadType);
	    }
		 
		
		super.writeTo(t, type, genericType, annotations, mediaType,
				httpHeaders, entityStream);
	}

	@Override
	public Object readFrom(Class<Object> type, Type genericType,
			Annotation[] annotations, MediaType mediaType,
			MultivaluedMap<String, String> httpHeaders, InputStream entityStream)
			throws IOException {

		 String[] payloadTypes = httpHeaders.getFirst(ProviderUtil.PAYLOAD_TYPE)!=null?
				 httpHeaders.getFirst(ProviderUtil.PAYLOAD_TYPE).split(":"):new String[]{};
		
		JavaType javaType = null;
		
		if (!(genericType instanceof ParameterizedType) && (payloadTypes.length > 0
				&& InjectionUtils.getRawType(genericType).isAssignableFrom(
						ServiceResponse.class))) {
			
			ObjectMapper mapper = locateMapper(type, mediaType);
			TypeFactory typeFactory = mapper.getTypeFactory();
			JsonParser jp = mapper.getJsonFactory().createJsonParser(
					entityStream);
			
			jp.disable(JsonParser.Feature.AUTO_CLOSE_SOURCE);
			
			int i = payloadTypes.length;
			Class<?> cType =  ProviderUtil.getPayloadClass(payloadTypes[--i]);
			javaType = (i>0)?typeFactory.constructParametricType(ProviderUtil.getPayloadClass(payloadTypes[--i]),cType):null;
			
			while(i > 0){
				javaType = typeFactory.constructParametricType(ProviderUtil.getPayloadClass(payloadTypes[--i]),javaType);
			}
			
			javaType = javaType!=null?typeFactory.constructParametricType(type,javaType):
				typeFactory.constructParametricType(type,cType);
			
			return mapper.readValue(jp, javaType);
		}

		return super.readFrom(type, genericType, annotations, mediaType,
				httpHeaders, entityStream);
	}

}