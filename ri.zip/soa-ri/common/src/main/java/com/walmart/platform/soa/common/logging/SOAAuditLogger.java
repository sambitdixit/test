package com.walmart.platform.soa.common.logging;

import java.util.HashMap;
import java.util.Map;

import org.apache.cxf.message.Exchange;
import org.apache.cxf.message.Message;

import com.walmart.platform.logging.client.type.AuditLogger;
import com.walmart.platform.soa.common.HeaderElements;

/**
 * This class is used to log audit data which can be set into AuditContext from
 * anywhere. Users of this class just need do below.
 * 
 * Which ever attributes need to be audited, just set them in respective place
 * like
 * 
 * AuditContext ac = AuditContext.instance(); ac.set("AuditKey", auditValue);
 * 
 * Then logAuditData() method in this class will log the audit data using
 * log/mon AuditLogger.
 * 
 * @author sdikshi
 * 
 */
public final class SOAAuditLogger {
	
	
	private SOAAuditLogger() {
	}

	/**
	 * method which is used to log all soa headers as well as any custom audit
	 * attributes of a service if set in SOAAduditContext as well as
	 * ThreadLocalContext ( which is set only from within soa-ri framework.
	 * 
	 * 
	 */
	public static void logAuditData(Message message) {
		// logs soa-header
		logSOAHeaderAuditData(message);
		logServiceAuditData();
	}

	/**
	 * Method to explicitly audit only service specific audit data set in
	 * SOAAuditContext.
	 * 
	 */
	public static void logServiceAuditData() {
		Map<String, Map<String, String>> allAudit = null;
		SOAAuditContext sac = SOAAuditContext.instance();
		// do all audit here and finally reset.
		allAudit = sac.getData();
		for (Map.Entry<String, Map<String, String>> entry : allAudit.entrySet()) {
			AuditLogger.logAudit(LoggingConstant.SOA_AUDIT, entry.getKey(),
					entry.getValue());
		}
		sac.reset();

	}

	/**
	 * Method to explicitly audit only SOA RI header specific data set in
	 * ThreadLocalContext.
	 * 
	 * 
	 */
	public static void logSOAHeaderAuditData(Message message) {
		
		Map<String, String> headerAuditData = new HashMap<String, String>();
		Exchange ex = message.getExchange();
		
		String consumerGuid = (ex.get(HeaderElements.CONSUMER_GUID) != null) ? (String) ex.get(HeaderElements.CONSUMER_GUID) :null;
		if(consumerGuid!=null && !consumerGuid.isEmpty()) {		
		  headerAuditData.put(HeaderElements.CONSUMER_GUID, consumerGuid);
		}
		
		String consumerAppId = (ex.get(HeaderElements.CONSUMER_ID) != null) ? (String) ex.get(HeaderElements.CONSUMER_ID) : null;
		if(consumerAppId!=null && !consumerAppId.isEmpty()) {
		 headerAuditData.put(HeaderElements.CONSUMER_ID, consumerAppId);
		}
		
		String consumerSourceId = (ex.get(HeaderElements.CONSUMER_SOURCE_ID) != null) ? (String) ex.get(HeaderElements.CONSUMER_SOURCE_ID) :null;
		if(consumerSourceId !=null && !consumerSourceId.isEmpty()){
		 headerAuditData.put(HeaderElements.CONSUMER_SOURCE_ID, consumerSourceId);
		}
		
		String svcName = (ex.get(HeaderElements.SERVICE_NAME) != null) ? (String) ex.get(HeaderElements.SERVICE_NAME) : null;
		if(svcName!=null && !svcName.isEmpty()){
		 headerAuditData.put(HeaderElements.SERVICE_NAME, svcName);
		}
		
		String svcVersion = (ex.get(HeaderElements.SERVICE_VERSION) != null) ? (String) ex.get(HeaderElements.SERVICE_VERSION) :null;
		if(svcVersion != null && !svcVersion.isEmpty()) {
		 headerAuditData.put(HeaderElements.SERVICE_VERSION, svcVersion);
		}
		
		String svcEnv = (ex.get(HeaderElements.SERVICE_ENV) != null) ? (String) ex.get(HeaderElements.SERVICE_ENV) :null;
		if(svcEnv!=null && !svcEnv.isEmpty()) {
		 headerAuditData.put(HeaderElements.SERVICE_ENV, svcEnv);
		}
		
		String consumerIP = (ex.get(HeaderElements.CONSUMER_IP) != null) ? (String) ex.get(HeaderElements.CONSUMER_IP) : null;
		if(consumerIP!=null && !consumerIP.isEmpty()) {
		 headerAuditData.put(HeaderElements.CONSUMER_IP, consumerIP);
		}
		
		String consumerName = (ex.get(HeaderElements.CONSUMER_NAME) != null) ? (String) ex.get(HeaderElements.CONSUMER_NAME) : null;
		if(consumerName!=null && !consumerName.isEmpty()) {
		 headerAuditData.put(HeaderElements.CONSUMER_NAME, consumerName);
		}
		
		String consumerInTs = (ex.get(HeaderElements.CONSUMER_IN_TIMESTAMP) != null) ? (String) ex.get(HeaderElements.CONSUMER_IN_TIMESTAMP) : null;
		if(consumerInTs!=null && !consumerInTs.isEmpty()) {
		 headerAuditData.put(HeaderElements.CONSUMER_IN_TIMESTAMP, consumerInTs);
		}
		
		String consumerOutTs = (ex.get(HeaderElements.CONSUMER_OUT_TIMESTAMP) != null) ? (String) ex.get(HeaderElements.CONSUMER_OUT_TIMESTAMP) : null;
		if(consumerOutTs!=null && !consumerOutTs.isEmpty()) {
		 headerAuditData.put(HeaderElements.CONSUMER_OUT_TIMESTAMP, consumerOutTs);
		}
		
		String consumerType = (ex.get(HeaderElements.CONSUMER_TYPE) != null) ? (String) ex.get(HeaderElements.CONSUMER_TYPE) : null;
		if(consumerType!=null && !consumerType.isEmpty()) {
		 headerAuditData.put(HeaderElements.CONSUMER_TYPE, consumerType);
		}
		
		String svcInTs =  (ex.get(HeaderElements.SERVICE_IN_TIMESTAMP) != null) ? (String)ex.get(HeaderElements.SERVICE_IN_TIMESTAMP): null;
		if(svcInTs!=null && !svcInTs.isEmpty()) {
		 headerAuditData.put(HeaderElements.SERVICE_IN_TIMESTAMP, svcInTs);
		}
		
		String svcOutTs =  (ex.get(HeaderElements.SERVICE_OUT_TIMESTAMP) != null) ? (String)ex.get(HeaderElements.SERVICE_OUT_TIMESTAMP):null;
		if(svcOutTs!=null && !svcOutTs.isEmpty()) {
		 headerAuditData.put(HeaderElements.SERVICE_OUT_TIMESTAMP, svcOutTs);
		}
		
		String svcServerName = (ex.get(HeaderElements.SERVICE_SERVER_NAME) != null) ? (String) ex.get(HeaderElements.SERVICE_SERVER_NAME) : null;
		if(svcServerName!=null && !svcServerName.isEmpty()) {
		 headerAuditData.put(HeaderElements.SERVICE_SERVER_NAME, svcServerName);
		}
		
		String svcIp = (ex.get(HeaderElements.SERVICE_SERVER_IP) != null) ? (String) ex.get(HeaderElements.SERVICE_SERVER_IP) : null;
		if(svcIp!=null && !svcIp.isEmpty()) {
		 headerAuditData.put(HeaderElements.SERVICE_SERVER_IP, svcIp);
		}
		
		String serviceClassName = (ex.get(HeaderElements.SERVICE_CLASS_NAME) != null) ? (String) ex.get(HeaderElements.SERVICE_CLASS_NAME) : null; 
		if(serviceClassName!=null && !serviceClassName.isEmpty()) {		
	     headerAuditData.put(HeaderElements.SERVICE_CLASS_NAME, serviceClassName);
		}
					
	    String serviceMethodName = (ex.get(HeaderElements.SERVICE_METHOD_NAME) != null) ? (String) ex.get(HeaderElements.SERVICE_METHOD_NAME) : null;
		if(serviceMethodName!=null && !serviceMethodName.isEmpty()) {				
		 headerAuditData.put(HeaderElements.SERVICE_METHOD_NAME, serviceMethodName);
		}												
		
		String userAgent = (ex.get(HeaderElements.USER_AGENT) != null) ? (String) ex.get(HeaderElements.USER_AGENT) : null;
		if(userAgent!=null && !userAgent.isEmpty()) {				
			 headerAuditData.put(HeaderElements.USER_AGENT, userAgent);
		}
		
		String contentLength = (ex.get(HeaderElements.CONTENT_LENGTH) != null) ? (String) ex.get(HeaderElements.CONTENT_LENGTH) : null;
		if(contentLength!=null && !contentLength.isEmpty()) {				
			 headerAuditData.put(HeaderElements.CONTENT_LENGTH, contentLength);
		}
		
		AuditLogger.logAudit(LoggingConstant.SOA_AUDIT,LoggingConstant.SOA_AUDIT_HEADER,headerAuditData);

	}

}
