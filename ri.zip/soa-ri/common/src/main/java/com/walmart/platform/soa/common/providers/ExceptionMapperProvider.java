package com.walmart.platform.soa.common.providers;

import java.util.List;

import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.walmart.platform.kernel.exception.error.Error;
import com.walmart.platform.soa.common.exception.ValidationException;
import com.walmart.platform.soa.common.exception.util.ExceptionUtil;
import com.walmart.platform.soa.common.logging.SOATransactionLogger;
import com.walmart.platform.soa.common.service.wrappers.ServiceResponse;
import com.walmart.platform.soa.common.service.wrappers.Status;

/**
 * An ExceptionMapper to wrap any PlatformException or Server Exception as an
 * error into ServiceResponse.
 * 
 * @author sdikshi
 * 
 */
@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML,
		MediaType.TEXT_XML })
@Provider
public class ExceptionMapperProvider implements ExceptionMapper<Throwable> {

	@Context
	protected HttpHeaders headers;

	

	private static final Logger logger = LoggerFactory
			.getLogger(ExceptionMapperProvider.class);

	/**
	 * mapping various Exception to appropriate status code and message
	 * 
	 * @param exception
	 *            the runtime exception to be map
	 * @return appropriate status code base on the RuntimeException type
	 */
	@Override
	public Response toResponse(Throwable exception) {
		return getServerErrorResponse(exception);
	}

	/**
	 * Method to create and wrap an error into ServiceResponse for any non
	 * PlatformException.
	 * 
	 * @param exception
	 * @return
	 */
	private Response getServerErrorResponse(Throwable exception) {
		SOATransactionLogger.logException(
				"Exception handled at ExceptionMapperProvider", exception);
		if (exception instanceof ValidationException) {
			ValidationException validationException = (ValidationException) exception;
			return getValidationErrorResponse(validationException);
		} else {
			return getErrorResponse(exception);
		}
	}

	/**
	 * Method will wrap the given error into ServiceResponse and write to
	 * javax.ws.rs.core.Response with appropriate status code and response
	 * entity.
	 * 
	 * 
	 * @param exception
	 * @return
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private Response getErrorResponse(Throwable cause) {
		logger.error("Exception at getErrorResponse", cause);
		int httpStatus = Status.FAIL.getCode();
		List<Error> errors = ExceptionUtil.getErrorAtServer(cause);
		int exHttpStatus = ExceptionUtil
				.extractHttpErrorCodeFromException(cause);
		/*
		 * First check if the exception has an http status code else look for it
		 * from errors first instance.
		 */
		if (exHttpStatus > 0) {
			httpStatus = exHttpStatus;
		} else {
			/* check if the first error has an http status code */
			if (errors != null && errors.size() > 0) {
				httpStatus = ExceptionUtil.splitAndSetHttpErrorCode(
						errors.get(0)).getCode();
			}
		}
		// if (isServiceResponseRequested(messageContext)) {
		ServiceResponse serviceResponse = new ServiceResponse();
		Status status = ExceptionUtil.mapHttpErrorCodeToStatus(httpStatus);
		ExceptionUtil.setCustomErrorCodes(errors);
		serviceResponse.setStatus(status);
		serviceResponse.getErrors().addAll(errors);
		
		MediaType mediaType = determineResponseMediaType(headers);
		return Response.status(status.getCode()).type(mediaType)
				.entity(serviceResponse).build();
	}

	/**
	 * Handle ValidationException which may have multiple error(s)
	 * 
	 * @param errors
	 * @param exception
	 * @return
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private Response getValidationErrorResponse(ValidationException exception) {
		logger.error("Validation Exception at getValidationErrorResponse= ",
				exception);
		ServiceResponse serviceResponse = new ServiceResponse();
		serviceResponse.getErrors().addAll(exception.getErrors());
		serviceResponse.setStatus(Status.BAD_REQUEST);
		MediaType mediaType = determineResponseMediaType(headers);
		return Response.status(Status.BAD_REQUEST.getCode()).type(mediaType)
				.entity(serviceResponse).build();
	}

	/**
	 * Method to determine the mime types coming in http header.
	 * 
	 * @param headers
	 * @return
	 */
	protected MediaType determineResponseMediaType(HttpHeaders headers) {
		MediaType mediaType = headers.getMediaType();
		if (headers.getMediaType() == null) {
			List<String> mediaTypes = headers
					.getRequestHeader(HttpHeaders.ACCEPT);
			if (acceptApplicationXml(mediaTypes)) {
				return MediaType.APPLICATION_XML_TYPE;
			} else if (acceptTextXml(headers
					.getRequestHeader(HttpHeaders.ACCEPT))) {
				return MediaType.TEXT_XML_TYPE;
			} else if (acceptApplicationJson(headers
					.getRequestHeader(HttpHeaders.ACCEPT))) {
				return MediaType.APPLICATION_JSON_TYPE;
			} else {
				/* default mediatype is json. */
				return MediaType.APPLICATION_JSON_TYPE;
			}
		} else if (mediaType.equals(MediaType.APPLICATION_XML_TYPE)) {
			return MediaType.APPLICATION_XML_TYPE;
		} else if (mediaType.equals(MediaType.TEXT_XML_TYPE)) {
			return MediaType.TEXT_XML_TYPE;
		} else if (mediaType.equals(MediaType.WILDCARD_TYPE)) {
			return MediaType.APPLICATION_JSON_TYPE;
		} else if (mediaType.equals(MediaType.APPLICATION_JSON_TYPE)) {
			return MediaType.APPLICATION_JSON_TYPE;
		} else {
			return mediaType;
		}
	}

	/**
	 * Method to check the mime type is application/xml.
	 * 
	 * @param mediaTypes
	 * @return
	 */
	protected boolean acceptApplicationXml(List<String> mediaTypes) {
		if (mediaTypes != null) {
			for (String requestMediaType : mediaTypes) {
				if (requestMediaType.toLowerCase().contains(
						MediaType.APPLICATION_XML)) {
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * Method to check the mime type is text/xml.
	 * 
	 * @param mediaTypes
	 * @return
	 */
	protected boolean acceptTextXml(List<String> mediaTypes) {
		if (mediaTypes != null) {
			for (String requestMediaType : mediaTypes) {
				if (requestMediaType.toLowerCase().contains(MediaType.TEXT_XML)) {
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * Method to check mime type is application/json.
	 * 
	 * @param mediaTypes
	 * @return
	 */
	protected boolean acceptApplicationJson(List<String> mediaTypes) {
		if (mediaTypes != null) {
			for (String requestMediaType : mediaTypes) {
				if (requestMediaType.toLowerCase().contains(MediaType.APPLICATION_JSON)) {
					return true;
				}
			}
		}
		return false;
	}



}
