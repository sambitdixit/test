package com.walmart.platform.soa.common.providers;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.annotation.Annotation;
import java.lang.reflect.Type;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.ext.Provider;

import org.apache.cxf.jaxrs.ext.MessageContext;
import org.codehaus.jackson.map.ObjectMapper;

import com.walmart.platform.soa.common.CommonUtil;
import com.walmart.platform.soa.common.HeaderElements;

/**
 * Wrapper class which provides support for jackson based json provider along
 * with jaxb provider.
 * 
 * @author sdikshi
 * 
 */
@SuppressWarnings("unchecked")
@Produces({ "application/json", "text/json", "application/xml",
		"application/*+xml", "text/xml","application/x-www-form-urlencoded" })
@Consumes({ "application/json", "text/json", "application/xml",
		"application/*+xml", "text/xml","application/x-www-form-urlencoded" })
@Provider
public class SOAJSONJAXBProvider<T> extends SOAJAXBProvider<T> {

	private SOAJacksonJsonProvider jsonProvider;

    /**
     *
     */
	public SOAJSONJAXBProvider() {
		jsonProvider = new SOAJacksonJsonProvider();
	}

    /**
     *
     * @param type
     */
	public SOAJSONJAXBProvider(String type) {
		// This is defaulted to SOAJacksonJsonProvider as we dont support any
		// other JSON provider by design. This is for the benefit of
		// performance of Jackson vs Jettison
		jsonProvider = new SOAJacksonJsonProvider();
	}

	/**
	 * Check if the request is of json type by checking mediatype.
	 * 
	 * @param mediaType
	 * @return
	 */
	public boolean isJsonType(MediaType mediaType) {
		if (mediaType != null) {
			String subtype = mediaType.getSubtype();
			return "json".equalsIgnoreCase(subtype)
					|| subtype.endsWith("+json");
		}
		return false;
	}

	/**
	 * Check if the request is of xml type by checking mediatype.
	 * 
	 * @param mediaType
	 * @return
	 */
	public boolean isXmlType(MediaType mediaType) {
		if (mediaType != null) {
			String subtype = mediaType.getSubtype();
			return "xml".equalsIgnoreCase(subtype) || subtype.endsWith("+xml");
		}
		return false;
	}

	@Override
	public boolean isWriteable(Class<?> type, Type genericType,
			Annotation[] annotations, MediaType mediaType) {
		if (isJsonType(mediaType)) {
			return jsonProvider.isWriteable(type, genericType, annotations,
					mediaType);
		} else {
			return super.isWriteable(type, genericType, annotations, mediaType);
		}
	}

	@Override
	public long getSize(T t, Class<?> type, Type genericType,
			Annotation[] annotations, MediaType mediaType) {
		if (isJsonType(mediaType)) {
			return jsonProvider.getSize(t, type, genericType, annotations,
					mediaType);
		} else if (isXmlType(mediaType)) {
			return super.getSize(t, type, genericType, annotations, mediaType);
		} else {
			return 0;
		}
	}

	@Override
	public void writeTo(T t, Class<?> type, Type genericType,
			Annotation[] annotations, MediaType mediaType,
			MultivaluedMap<String, Object> httpHeaders,
			OutputStream entityStream) throws IOException {
		if (isJsonType(mediaType)) {
			jsonProvider.writeTo(t, type, genericType, annotations, mediaType,
					httpHeaders, entityStream);
		} else if (isXmlType(mediaType)) {
			super.writeTo(t, type, genericType, annotations, mediaType,
					httpHeaders, entityStream);
		}
	}

	@Override
	public boolean isReadable(Class<?> type, Type genericType,
			Annotation[] annotations, MediaType mediaType) {
		if (isJsonType(mediaType)) {
			return jsonProvider.isReadable(type, genericType, annotations,
					mediaType);
		} else if (isXmlType(mediaType)) {
			return super.isReadable(type, genericType, annotations, mediaType);
		} else {
			return false;
        }
	}

	@Override
	public T readFrom(Class<T> type, Type genericType,
			Annotation[] annotations, MediaType mediaType,
			MultivaluedMap<String, String> httpHeaders, InputStream entityStream)
			throws IOException {

		if (CommonUtil.isLocalProtocol(httpHeaders.get(HeaderElements.TRANSACTION_PROTOCOL))) {
			MessageContext mc = getContext();
			Object serviceResponse = mc.get(CommonUtil.LOCAL_RESPONSE);
			if (serviceResponse != null){
				return type.cast(serviceResponse);
			}
		}
		
		if (isJsonType(mediaType)) {
			return (T) jsonProvider.readFrom((Class<Object>) type, genericType,
					annotations, mediaType, httpHeaders, entityStream);
		} else if (isXmlType(mediaType)) {
			return super.readFrom(type, genericType, annotations, mediaType,
					httpHeaders, entityStream);
		} else {
			return null;
		}
	}

	/**
	 * @param mapper
	 */
	public void setMapper(ObjectMapper mapper) {
		jsonProvider.setMapper(mapper);
	}

	/**
	 * @return the jsonProvider
	 */
	public SOAJacksonJsonProvider getJsonProvider() {
		return jsonProvider;
	}

	public void setJsonProvider(SOAJacksonJsonProvider jsonProvider) {
		this.jsonProvider = jsonProvider;
	}

}
