package com.walmart.platform.soa.common;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * This class is used to hold the skip urls to be excluded during header check
 * in HeaderInterceptor in client and server.
 * 
 * Users need to set the properties to filter attribute like
 * 
 * <bean id="headerSkipFilter"
 * class="com.walmart.platform.soa.common.HeaderSkipFilter"> <property
 * name="filter" value="${soari.header.skip.urls}"/> </bean>
 * 
 * the soari.header.skip.urls property needs to be defined in a properties file
 * like
 * 
 * headerskipfilter.properties #define comma separated list of urls to be
 * skipped. soari.header.skip.urls=/order, address/123
 * 
 * 
 * @author sdikshi
 * 
 */
public class HeaderSkipFilter {

	//@Autowired(required = false)
	private String filter;

	private static final String SKIP_ALL = "*";
	
	
	/**
	 * Checks if the supplied url contains the skip url patterns configured
	 * through properties.
	 * 
	 * @param url
	 * @return
	 */
	public boolean containsURL(String url) {
		boolean isAvailable = false;
		if (url != null) {
			List<String> skipUrls = getList(filter);
			for (String s : skipUrls) {
				isAvailable = (SKIP_ALL.equals(s) || url.contains(s));
				if (isAvailable) {
					break;
                }
			}
		}
		return isAvailable;
	}

	/**
	 * Takes a comma separated url list and return a array list.
	 * 
	 * @param urlList
	 * @return
	 */
	private List<String> getList(String urlList) {
		List<String> skipUrls = new ArrayList<String>();
		if (urlList != null) {
			String[] tokens = urlList.split(",");
			skipUrls = Arrays.asList(tokens);
		}
		return skipUrls;
	}

	/**
	 * @param filter
	 *            the filter to set
	 */
	public void setFilter(String filter) {
		this.filter = filter;
	}

}
