package com.walmart.platform.soa.common.providers;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.annotation.Annotation;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.ext.Provider;
import javax.xml.validation.Schema;

import org.apache.cxf.jaxrs.provider.JAXBElementProvider;

/**
 * JAXB provider to do marshalling and unmarshalling from xml to java pojo and
 * vice versa.
 * 
 * @author sdikshi
 * 
 */
@SuppressWarnings("rawtypes")
@Produces({ "application/xml", "application/*+xml", "text/xml" })
@Consumes({ "application/xml", "application/*+xml", "text/xml" })
@Provider
public class SOAJAXBProvider<T> extends JAXBElementProvider<T> {

    /**
     *
     */
	public SOAJAXBProvider() {
		super.setSingleJaxbContext(true);
		//super.setExtraClass(new Class[] { ServiceRequest.class,ServiceResponse.class });
		/*Map<String, Object> ctxProps = new HashMap<String, Object>();
		ctxProps.put(JAXBRIContext.ANNOTATION_READER, new PayloadAnnotationReader());
		super.setContextProperties(ctxProps);*/
		
	}

	private List<Class> extraClass = new ArrayList<Class>();

    /**
     *
     * @return
     */
	public List<Class> getExtraClass() {
		return extraClass;
	}

    /**
     *
     * @param extraClass
     */
	public void setExtraClass(List<Class> extraClass) {
		this.extraClass = extraClass;
		Class[] clsArr = extraClass.toArray(new Class[extraClass.size()]);
		if (clsArr.length > 0) {
			super.setExtraClass(clsArr);
		}
	}

	@Override
	public void writeTo(T t, Class<?> type, Type genericType,
			Annotation[] annotations, MediaType mediaType,
			MultivaluedMap<String, Object> httpHeaders,
			OutputStream entityStream) throws IOException {
		/*
		 * Type actualType = ProviderUtil.getActualParameterType(genericType);
		 * if (actualType != null) { httpHeaders.add(ProviderUtil.PAYLOAD_TYPE,
		 * InjectionUtils .getActualType(actualType).getName()); }
		 */

		super.writeTo(t, type, genericType, annotations, mediaType,
				httpHeaders, entityStream);
	}

	@Override
	public T readFrom(Class<T> type, Type genericType,
			Annotation[] annotations, MediaType mediaType,
			MultivaluedMap<String, String> httpHeaders, InputStream entityStream)
			throws IOException {
		/*
		 * String payloadClass =
		 * httpHeaders.getFirst(ProviderUtil.PAYLOAD_TYPE); if (payloadClass !=
		 * null) { Class<?> payloadType =
		 * ProviderUtil.getPayloadClass(payloadClass); try { JAXBContext ctx =
		 * super.getClassContext(type); ctx =
		 * super.getClassContext(payloadType); return super.readFrom(type,
		 * genericType, annotations, mediaType, httpHeaders, entityStream); }
		 * catch (JAXBException e) { throw new WebApplicationException(e); } }
		 */
		return super.readFrom(type, genericType, annotations, mediaType,
				httpHeaders, entityStream);
	}

    /**
     *
     * @return
     */
	public Schema getSchema() {
		return super.getSchema();
	}

	protected boolean isSupported(Class type, Type genericType,
			Annotation[] anns) {
		return super.isSupported(type, genericType, anns);
	}

}
