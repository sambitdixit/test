package com.walmart.platform.soa.common.logging;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author sambit dikshit
 * 
 */
public final class PlatformLogger {

	// private static Logger logger =
	// LoggerFactory.getLogger(PlatformLogger.class);
	private PlatformLogger() {
	}

    /**
     *
     * @param message
     */
	public static void log(Object message) {
		System.out.println("" + message);
	}

    /**
     *
     * @param message
     */
	public static void debug(Object message) {
		Logger logger = getLogger();
		if (logger.isDebugEnabled()) {
			logger.debug("" + message);
		}
	}

    /**
     *
     * @param message
     */
	public static void info(Object message) {
		Logger logger = getLogger();
		if (logger.isInfoEnabled()) {
			logger.info("" + message);
		}
	}

    /**
     *
     * @param message
     */
	public static void trace(Object message) {
		Logger logger = getLogger();
		if (logger.isTraceEnabled()) {
			logger.trace("" + message);
		}
	}

    /**
     *
     * @param message
     */
	public static void warn(Object message) {
		Logger logger = getLogger();
		if (logger.isWarnEnabled()) {
			logger.warn("" + message);
		}
	}

    /**
     *
     * @param message
     * @param t
     */
	public static void warn(Object message, Throwable t) {
		Logger logger = getLogger();
		if (logger.isWarnEnabled()) {
			logger.warn("" + message, t);
		}
	}

    /**
     *
     * @param message
     */
	public static void error(Object message) {
		Logger logger = getLogger();
		if (logger.isErrorEnabled()) {
			logger.error("" + message);
		}
	}

    /**
     *
     * @param message
     * @param t
     */
	public static void error(Object message, Throwable t) {
		Logger logger = getLogger();
		if (logger.isErrorEnabled()) {
			logger.error("" + message, t);
		}
	}

    /**
     *
     * @return
     */
	public static Logger getLogger() {
		return LoggerFactory.getLogger(getCallerClassName());
	}

    /**
     *
     * @param clazz
     * @return
     */
	public static Logger getLogger(Class clazz) {
		return LoggerFactory.getLogger(clazz);
	}

    /**
     *
     * @param loggerName
     * @return
     */
	public static Logger getLogger(String loggerName) {
		return LoggerFactory.getLogger(loggerName);
	}

    /**
     *
     * @return
     */
	private static String getCallerClassName() {
		return new Exception().getStackTrace()[2].getClassName();
	}
}
