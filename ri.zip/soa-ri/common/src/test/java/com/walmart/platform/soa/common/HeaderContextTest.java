package com.walmart.platform.soa.common;

import java.util.HashMap;
import java.util.Map;

import org.testng.Assert;
import org.testng.annotations.Test;

public class HeaderContextTest {

	private HeaderContext hdr = HeaderContext.instance();
	
	@Test
	public void getHeader() {
		hdr.setHeader("k1", "v1");
		Assert.assertEquals("v1", hdr.getHeader("k1"));
	}

	@Test
	public void getHeaders() {
		Map<String, String> data = new HashMap<String, String>();
		data.put("k1", "v1");
		data.put("k2", "v2");
		hdr.setHeaders(data);
		Assert.assertEquals(data, hdr.getHeaders());

	}

	@Test
	public void clearHeaders() {
		Map<String, String> data = new HashMap<String, String>();
		data.put("k1", "v1");
		data.put("k2", "v2");
		hdr.setHeaders(data);
		hdr.clearHeaders();
		Assert.assertNotEquals(data, hdr.getHeaders());
	}
}
