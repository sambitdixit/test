package com.walmart.platform.soa.common;

import static com.walmart.platform.soa.common.CommonUtil.checkNotNullIfHeaderPresent;
import static com.walmart.platform.soa.common.CommonUtil.getFirst;
import static com.walmart.platform.soa.common.CommonUtil.getProtocolHeaders;
import static com.walmart.platform.soa.common.CommonUtil.getServiceAuthHeaders;
import static com.walmart.platform.soa.common.CommonUtil.injectRequestHeaders;
import static com.walmart.platform.soa.common.CommonUtil.injectResponseHeaders;
import static com.walmart.platform.soa.common.CommonUtil.isLocalDestination;
import static com.walmart.platform.soa.common.CommonUtil.isLocalProtocol;
import static com.walmart.platform.soa.common.CommonUtil.isLocalURL;
import static com.walmart.platform.soa.common.CommonUtil.setHttpStatusCodes;
import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertNotNull;
import static org.testng.Assert.assertNull;
import static org.testng.Assert.assertTrue;
import static org.testng.Assert.fail;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.message.Exchange;
import org.apache.cxf.message.ExchangeImpl;
import org.apache.cxf.message.Message;
import org.apache.cxf.message.MessageImpl;
import org.testng.Assert;
import org.testng.annotations.Test;

public class CommonUtilTest {

	@Test
	public void testGetFirst() {
		try {
			assertNotNull(CommonUtil.getFirst(getHeaders(), (HeaderElements.CONSUMER_GUID)));
		} catch (Fault e) {
			fail("CommonUtil.getFirst test failed with error message:" + e.getMessage());
		}

        assertNull(getFirst(null, HeaderElements.CONSUMER_GUID));
        assertNull(getFirst(new HashMap<String, List<String>>(), HeaderElements.CONSUMER_GUID));

        Map<String, List<String>> headers = getHeaders();
        headers.remove(HeaderElements.CONSUMER_GUID);

        assertNull(getFirst(headers, HeaderElements.CONSUMER_GUID));

        headers.put(HeaderElements.CONSUMER_GUID, new ArrayList<String>());

        assertNull(getFirst(headers, HeaderElements.CONSUMER_GUID));
	}

	@Test
	public void testGetProtocolHeaders() {
		Message message = new MessageImpl();
		try {
			message.put(Message.PROTOCOL_HEADERS, getHeaders());
			assertNotNull(getProtocolHeaders(message));
            message.remove(Message.PROTOCOL_HEADERS);
            assertNotNull(getProtocolHeaders(message));
		} catch (Fault e) {
			fail("CommonUtil.getProtocolHeaders test failed with error message:" + e.getMessage());
        }
	}

	@Test
	public void testInjectRequestHeaders() {
		Message message = new MessageImpl();
        Map<String, List<String>> headers = getHeaders();
		try {
			message.put(Message.PROTOCOL_HEADERS, headers);
			CommonUtil.injectRequestHeaders(message);
		} catch (Fault e) {
			fail("CommonUtil.injectRequestHeaders test failed with error message:" + e.getMessage());
        }

        try {
            message.put(Message.PROTOCOL_HEADERS, getHeaders());
            Exchange exchange = new ExchangeImpl();
            message.setExchange(exchange);
            CommonUtil.injectRequestHeaders(message);
        } catch (Fault e) {
            fail("CommonUtil.injectRequestHeaders test failed with error message:" + e.getMessage());
        }

        headers.put(HeaderElements.CONSUMER_TYPE, Arrays.asList("WM"));
        headers.put(HeaderElements.SERVICE_ENV, Arrays.asList("Dev"));
        try {
            message.put(Message.PROTOCOL_HEADERS, headers);
            message.put(Message.CONTENT_TYPE, "json");
            injectRequestHeaders(message);
        } catch (Fault e) {
            fail("CommonUtil.injectRequestHeaders test failed with error message:" + e.getMessage());
        }
	}

	@Test
	public void testInjectResponseHeaders() {
		Message message = new MessageImpl();
		try {
			message.put(Message.PROTOCOL_HEADERS, getHeaders());
			injectResponseHeaders(message);
            Exchange exchange = new ExchangeImpl();
            message.setExchange(exchange);
            injectResponseHeaders(message);
		} catch (Fault e) {
			fail("CommonUtil.injectResponseHeaders test failed with error message:" + e.getMessage());
        }

        try {
            Map<String, List<String>> headers = getHeaders();
            message.put(Message.PROTOCOL_HEADERS, headers);
            Exchange exchange = message.getExchange();
            exchange.put(HeaderElements.SERVICE_IN_TIMESTAMP, ""+System.currentTimeMillis());
            exchange.put(HeaderElements.CONSUMER_IN_TIMESTAMP, "" + System.currentTimeMillis());
            exchange.put(HeaderElements.SERVICE_SERVER_NAME, "CA");
            exchange.put(HeaderElements.SERVICE_SERVER_IP, "10.10.10.21");
            injectResponseHeaders(message);

            injectResponseHeaders(message);

            headers.put(HeaderElements.CONTENT_TYPE, Arrays.asList("json"));
            injectResponseHeaders(message);

            headers.remove(HeaderElements.CONTENT_TYPE);
            injectResponseHeaders(message);

            exchange.put(HeaderElements.CONTENT_TYPE, "json");
            injectResponseHeaders(message);
        } catch (Fault e) {
            fail("CommonUtil.injectResponseHeaders test failed with error message:" + e.getMessage());
        }
	}

	@Test
	public void isClient() {
		Message message = new MessageImpl();
		message.put(Message.REQUESTOR_ROLE, new Boolean(true));
		Assert.assertTrue(CommonUtil.isClient(message));
		
		Message message1 = new MessageImpl();
		message1.put(Message.REQUESTOR_ROLE, null);
		Assert.assertFalse(CommonUtil.isClient(message1));
		
	}

	@Test
	public void testIsLocalDestination() {
		Message message = new MessageImpl();
		String url = "local://bookstore";
		message.put(Message.ENDPOINT_ADDRESS, url);
		assertTrue(CommonUtil.isLocalDestination(message));
		Message message1 = new MessageImpl();
		url = "http://bookstore";
		message1.put(Message.ENDPOINT_ADDRESS, url);
		assertFalse(isLocalDestination(message1));
        message1.remove(Message.ENDPOINT_ADDRESS);
        assertFalse(isLocalDestination(message1));
		
	}

	@Test
	public void testIsLocalURL() {
		String url = "local://bookstore";
		assertTrue(isLocalURL(url));
		url = "http://bookstore";
		assertFalse(isLocalURL(url));
		assertFalse(isLocalURL(null));
		assertFalse(isLocalURL(""));
	}

	private Map<String, List<String>> getHeaders() {
		Map<String, List<String>> headers = new HashMap<String, List<String>>();
		headers.put(Message.REQUEST_URI, Arrays.asList("/a/b"));
		headers.put(Message.HTTP_REQUEST_METHOD, Arrays.asList("GET"));
		headers.put(HeaderElements.CONSUMER_GUID, Arrays.asList("a124aBbaj122"));
		headers.put(HeaderElements.CONSUMER_IN_TIMESTAMP, Arrays.asList(String.valueOf(System.currentTimeMillis())));
		headers.put(HeaderElements.CONSUMER_OUT_TIMESTAMP, Arrays.asList(String.valueOf(System.currentTimeMillis())));
		headers.put(HeaderElements.SERVICE_SERVER_NAME, Arrays.asList("test"));
		headers.put(HeaderElements.CONSUMER_NAME, Arrays.asList("test-consumer"));
		headers.put(HeaderElements.CONSUMER_IP, Arrays.asList("127.0.0.1"));
		headers.put(HeaderElements.SERVICE_IN_TIMESTAMP, Arrays.asList(String.valueOf(System.currentTimeMillis())));
		headers.put(HeaderElements.SERVICE_OUT_TIMESTAMP, Arrays.asList(String.valueOf(System.currentTimeMillis())));
		headers.put(Message.RESPONSE_CODE, Arrays.asList("200"));
		return headers;
	}

    @Test
    public void testEnv() {
        assertNotNull(CommonUtil.getEnv());
    }

    @Test
    public void testPutSingle() {
        try {
            CommonUtil.putSingle(null, "key", "value");
        } catch (Exception e) {
            fail("NO Exception expected");
        }
    }

    @Test
    public void testIsLocalProtocol() {
        assertFalse(isLocalProtocol(null));
        List txList = new ArrayList();
        txList.add("local");
        assertTrue(isLocalProtocol(txList));
        txList.clear();
        txList.add("non");
        assertFalse(isLocalProtocol(txList));
    }

    @Test
    public void testGetServiceAuthHeaders() {
        Map<String,String> serviceAuthHeaders = getServiceAuthHeaders(getHeaders());
        assertNotNull(serviceAuthHeaders);

        Map<String, List<String>> headers = getHeaders();
        headers.remove(HeaderElements.CONSUMER_IN_TIMESTAMP);
        getServiceAuthHeaders(headers);
        assertNotNull(serviceAuthHeaders);
    }

    @Test
    public void testCheckNotNullIfHeaderPresent() {
        Message message = new MessageImpl();
        Map<String, List<String>> headers = getHeaders();
        message.put(Message.PROTOCOL_HEADERS, headers);
        try {
            checkNotNullIfHeaderPresent(message);
            fail("Exception expected");
        } catch (Exception e) {
            assertTrue(true);
        }

        headers.put(HeaderElements.SERVICE_VERSION, Arrays.asList("1.0.0"));
        headers.put(HeaderElements.CONSUMER_AUTH_TOKEN, Arrays.asList("sdadjhkhlk"));
        headers.put(HeaderElements.SERVICE_NAME, Arrays.asList("CA"));
        headers.put(HeaderElements.CONSUMER_ID, Arrays.asList("CA"));
        headers.put(HeaderElements.CONSUMER_GUID, Arrays.asList("cgid"));
        checkNotNullIfHeaderPresent(message);

        try {
            headers.put(HeaderElements.CONSUMER_AUTH_TOKEN, Arrays.asList(""));
            checkNotNullIfHeaderPresent(message);
            fail("Exception expected");
        } catch (Exception e) {
            assertTrue(true);
        }

        try {
            headers.put(HeaderElements.CONSUMER_AUTH_TOKEN, Arrays.asList("sdadjhkhlk"));
            headers.put(HeaderElements.SERVICE_NAME, Arrays.asList(""));
            checkNotNullIfHeaderPresent(message);
            fail("Exception expected");
        } catch (Exception e) {
            assertTrue(true);
        }

        try {
            headers.put(HeaderElements.SERVICE_NAME, Arrays.asList("CA"));
            headers.put(HeaderElements.CONSUMER_TYPE, Arrays.asList(""));
            checkNotNullIfHeaderPresent(message);
            fail("Exception expected");
        } catch (Exception e) {
            assertTrue(true);
        }

        try {
            headers.put(HeaderElements.CONSUMER_TYPE, Arrays.asList("WM"));
            headers.put(HeaderElements.CONSUMER_IP, Arrays.asList(""));
            checkNotNullIfHeaderPresent(message);
            fail("Exception expected");
        } catch (Exception e) {
            assertTrue(true);
        }

        try {
            headers.put(HeaderElements.CONSUMER_IP, Arrays.asList("10.10.10.1"));
            headers.put(HeaderElements.CONSUMER_IN_TIMESTAMP, Arrays.asList(""));
            checkNotNullIfHeaderPresent(message);
            fail("Exception expected");
        } catch (Exception e) {
            assertTrue(true);
        }

        headers.put(HeaderElements.CONSUMER_IN_TIMESTAMP, Arrays.asList("as"));
        headers.remove(HeaderElements.CONSUMER_IP);
        headers.remove(HeaderElements.CONSUMER_IN_TIMESTAMP);
        checkNotNullIfHeaderPresent(message);

        try {
            headers.put(HeaderElements.CONSUMER_GUID, Arrays.asList(""));
            checkNotNullIfHeaderPresent(message);
            fail("Exception expected");
        } catch (Exception e) {
            assertTrue(true);
        }

        try {
            headers.put(HeaderElements.CONSUMER_GUID, Arrays.asList("asa"));
            headers.put(HeaderElements.SERVICE_VERSION, Arrays.asList(""));
            checkNotNullIfHeaderPresent(message);
            fail("Exception expected");
        } catch (Exception e) {
            assertTrue(true);
        }
    }

    @Test
    public void testSetHttpStatusCodes() {
        Message message = new MessageImpl();

        try {
            message.setContent(InputStream.class, new ByteArrayInputStream(new byte[10]));
            setHttpStatusCodes(message);
        } catch (Fault f) {
            fail();
        }
    }
}
