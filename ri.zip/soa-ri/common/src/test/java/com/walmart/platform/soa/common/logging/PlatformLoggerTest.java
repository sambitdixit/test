package com.walmart.platform.soa.common.logging;

import org.testng.annotations.Test;

/**
 * PlatformLogger Test class
 */
public class PlatformLoggerTest {

    @Test
    public void testDebug() {
        PlatformLogger.debug("testing debug");
    }

    @Test
    public void testLog() {
        PlatformLogger.log("Testing log");
    }

    @Test
    public void testInfo() {
        PlatformLogger.info("Testing info");
    }

    @Test
    public void testTrace() {
        PlatformLogger.trace("Testing Trace");
    }

    @Test
    public void testWarn() {
        PlatformLogger.warn("Testing warn");
    }

    @Test
    public void testWarn2() {
        PlatformLogger.warn("Testing warn", new Exception("dummy"));
    }
}
