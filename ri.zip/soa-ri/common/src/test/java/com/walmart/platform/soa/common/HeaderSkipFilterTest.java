package com.walmart.platform.soa.common;

import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import org.testng.annotations.Test;

public class HeaderSkipFilterTest {

	@Test
	public void containsURL() {
		HeaderSkipFilter skipFilter = new HeaderSkipFilter();
		skipFilter.setFilter("abc/,/xyz/123,12");
		String urlToTest = "http://localhost:8080/services/abc/123";
		assertTrue(skipFilter.containsURL(urlToTest));
	}

    @Test
    public void testContainsUrlExceptions() {
        HeaderSkipFilter skipFilter = new HeaderSkipFilter();
        assertFalse(skipFilter.containsURL(null));
        skipFilter.setFilter("*,abc/,/xyz/123,12");
        String urlToTest = "http://localhost:8080/services/abc/123/*";
        assertTrue(skipFilter.containsURL(urlToTest));
        String urlN = "http://localhost/service";
         skipFilter.setFilter("abc/,/xyz/123,12");
        assertFalse(skipFilter.containsURL(urlN));
    }

	@Test
	public void containsURLWithNoSkipFilterSet() {
		HeaderSkipFilter skipFilter = new HeaderSkipFilter();
		String urlToTest = "http://localhost:8080/services/abc/123";
		assertFalse(skipFilter.containsURL(urlToTest));
	}

	@Test
	public void containsURLWithNoSkipFilterAndStar() {
		HeaderSkipFilter skipFilter = new HeaderSkipFilter();
		skipFilter.setFilter("*");
		String urlToTest = "http://localhost:8080/services/abc/123";
		assertTrue(skipFilter.containsURL(urlToTest));
	}

}
