package com.walmart.platform.soa.common.providers;

import org.apache.cxf.bus.spring.SpringBusFactory;
import org.apache.cxf.jaxrs.client.JAXRSClientFactoryBean;
import org.apache.cxf.jaxrs.client.WebClient;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.walmart.platform.soa.common.logging.PlatformLogger;
import com.walmart.platform.soa.common.service.wrappers.ServiceResponse;
import com.walmart.platform.soa.common.service.wrappers.Status;
import com.walmart.platform.soa.examples.service.Book;
import com.walmart.platform.soa.examples.service.Chapter;
import com.walmart.platform.test.AbstractClientServerTest;

/**
 * @author ranand
 * 
 */
public class SOAJSONJAXBProviderTest extends AbstractClientServerTest {
	public static final String PORT = BookServiceWrapperServer.PORT;
	private static SOAJSONJAXBProvider jacksonProvider;
	private static SOAJSONJAXBProvider jettisonProvider;

	@BeforeClass
	public void startServers() throws Exception {
		assertTrue(launchServer(BookServiceWrapperServer.class, true),
				"server did not launch correctly");
		jacksonProvider = new SOAJSONJAXBProvider("jackson");
		jettisonProvider =  new SOAJSONJAXBProvider("jettison");
		jacksonProvider.setExtraClass(new Class[] { Book.class,Chapter.class });
		jettisonProvider.setExtraClass(new Class[] { Book.class,Chapter.class });
	}
	

	@Test(threadPoolSize = 1, invocationCount = 1)
	public void getBookTest() throws Exception {
		String endpointAddress = "http://localhost:" + PORT
				+ "/jaxrs/bookstore/books/123";
		WebClient wc = getWebClient(endpointAddress, "jackson");
		long st = System.currentTimeMillis();
		ServiceResponse<Book> res = wc.get(ServiceResponse.class);
		long et = System.currentTimeMillis();
		System.out.println("Time taken==" + (et - st));
		assertEquals(Status.OK, res.getStatus());
		assertEquals(200, wc.getResponse().getStatus());
		PlatformLogger.log("getBook response==" + res);

	}

	@Test(threadPoolSize = 1, invocationCount = 1)
	public void getBookAsJsonTest() throws Exception {
		String endpointAddress = "http://localhost:" + PORT
				+ "/jaxrs/bookstore/books/123";
		WebClient wc = getWebClient(endpointAddress, "jackson");
		String json = wc.accept("application/json").get(String.class);
		assertEquals(200, wc.getResponse().getStatus());
		System.out.println("JSON==" + json);
	}

	@Test(threadPoolSize = 1, invocationCount = 1, timeOut = 10000)
	public void getBookAsXmlTest() throws Exception {
		String endpointAddress = "http://localhost:" + PORT
				+ "/jaxrs/bookstore/books/123";
		WebClient wc = getWebClient(endpointAddress, "jackson");
		String json = wc.accept("text/xml").get(String.class);
		assertEquals(200, wc.getResponse().getStatus());
		System.out.println("XML==" + json);
	}

	@Test(threadPoolSize = 1, invocationCount = 1, timeOut = 10000)
	public void getJettisionJsonTest() throws Exception {
		String endpointAddress = "http://localhost:" + PORT
				+ "/jaxrs/jettison/bookstore/books/123";
		WebClient wc = getWebClient(endpointAddress, "jettison");
		String json = wc.accept("application/json").get(String.class);
		assertEquals(200, wc.getResponse().getStatus());
		System.out.println("JSON==" + json);
	}

	@Test(threadPoolSize = 1, invocationCount = 1)
	public void test404Error() throws Exception {
		String endpointAddress = "http://localhost:" + PORT
				+ "/jaxrs/bookstore_wrong/books/123";
		WebClient wc = getWebClient(endpointAddress, "jackson");
		wc.accept("application/json").get();
		System.out.println("Status=="+wc.getResponse().getStatus());
		assertEquals(Status.NOT_FOUND.getCode(), wc.getResponse().getStatus());
	}

	

	public WebClient getWebClient(String address, String jsonProviderType) {
		WebClient wc = null;
		JAXRSClientFactoryBean bean = new JAXRSClientFactoryBean();
		bean.setThreadSafe(true);
		bean.setBus(SpringBusFactory.getDefaultBus());
		bean.setAddress(address);
		setProviders(bean, jsonProviderType);
		wc = bean.createWebClient();
		return wc;
	}

	private void setProviders(JAXRSClientFactoryBean bean,
			String jsonProviderType) {
		if ("jackson".equals(jsonProviderType))
			bean.setProvider(jacksonProvider);
		else if ("jettison".equals(jsonProviderType))
			bean.setProvider(jettisonProvider);
	}

	/*
	 * @Test(threadPoolSize = 1, invocationCount = 1, timeOut = 10000) public
	 * void addBookTest() throws Exception { String endpointAddress =
	 * "http://localhost:" + PORT + "/jaxrs/bookstore/books"; WebClient wc =
	 * getWebClient(endpointAddress); ServiceRequest<Book> req = new
	 * ServiceRequest<Book>(); req.setHeader(new ServiceHeader());
	 * req.setPayload(new Book("CXF Action 127", 127L)); ServiceResponse<Book>
	 * res = wc.post(req, ServiceResponse.class); assertEquals(Status.OK,
	 * res.getStatus()); assertEquals(200, wc.getResponse().getStatus());
	 * PlatformLogger.log("addBookTest response==" + res);
	 * 
	 * }
	 */
}