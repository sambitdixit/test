package com.walmart.platform.soa.common.listener;

import org.testng.annotations.Test;

public class SOABusLifeCycleListenerTest {

  @Test
  public void SOABusLifeCycleListener() {
   // throw new RuntimeException("Test not implemented");
  }

  @Test
  public void initComplete() {
//    throw new RuntimeException("Test not implemented");
  }

  @Test
  public void postShutdown() {
//    throw new RuntimeException("Test not implemented");
  }

  @Test
  public void preShutdown() {
//    throw new RuntimeException("Test not implemented");
  }
}
