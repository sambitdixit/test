package com.walmart.platform.soa.common;

import static com.walmart.platform.soa.common.OAuthUtil.getOAuth10Token;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNull;

import org.testng.annotations.Test;

public class OAuthUtilTest {

  String dummyToken = "dummy";
  
  @Test
  public void testOAuth10Token() {
	  assertEquals(dummyToken, getOAuth10Token("OAuth oauth_token=" + dummyToken));
      assertNull(getOAuth10Token(null));
  }

  @Test
  public void testOAuth20Token() {
	  assertEquals(dummyToken, OAuthUtil.getOAuth20Token("Bearer " + dummyToken));
  }
}
