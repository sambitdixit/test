package com.walmart.platform.soa.common.providers;

import static org.mockito.Mockito.mock;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;

import org.apache.cxf.jaxrs.impl.MetadataMap;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.walmart.platform.kernel.exception.error.Error;
import com.walmart.platform.kernel.exception.layers.base.PlatformException;
import com.walmart.platform.soa.common.service.wrappers.ServiceResponse;

public class ExceptionMapperProviderTest {

	private ExceptionMapperProvider ep = new ExceptionMapperProvider();

	@Mock
	private HttpHeaders mockHeaders;

	@BeforeClass
	public void setup() {
		MockitoAnnotations.initMocks(this);
		mockHeaders = mock(HttpHeaders.class);
		ReflectionTestUtils.setField(ep, "headers", mockHeaders);
	}

	@Test
	public void getErrorResponse() {
		List<String> headers = new ArrayList<String>();
		headers.add(MediaType.APPLICATION_XML);
		headers.add(MediaType.APPLICATION_JSON);
		MultivaluedMap<String, String> map = new MetadataMap<String, String>();
		map.put(HttpHeaders.ACCEPT, headers);
		Mockito.when(mockHeaders.getRequestHeaders()).thenReturn(map);
		Error err = new Error();
		err.setCode("500.100");
		err.setDescription("test");
		err.setField("f1");
		PlatformException pe = new PlatformException(err,"test",new Exception("Dummy platform exception"));
		Response rs = ep.toResponse(pe);
		Assert.assertEquals(500,rs.getStatus());
	}

	class Dummy {
		public ServiceResponse<DummyBook> dummyMethod() {
			ServiceResponse<DummyBook> res  = new ServiceResponse<DummyBook>();
			DummyBook book = new DummyBook();
			book.setName("dummy book");
			res.setPayload(book);
			return res;
		}
	}
	
	public class DummyBook {
		private String name;
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
	}
}
