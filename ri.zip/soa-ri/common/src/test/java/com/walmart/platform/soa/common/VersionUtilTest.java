package com.walmart.platform.soa.common;

import static com.walmart.platform.soa.common.VersionUtil.getVersion;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNull;

import org.testng.annotations.Test;

public class VersionUtilTest {

    @Test
    public void testGetVersion() {
        String v = getVersion("http://localhost/service/v1/bookstore/books/123");
        assertEquals("1.0.0", v);
    }

    @Test
    public void testVersionAlt() {
        assertNull(getVersion("abc"));
    }
}
