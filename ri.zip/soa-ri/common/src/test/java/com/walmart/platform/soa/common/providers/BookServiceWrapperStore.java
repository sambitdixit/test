package com.walmart.platform.soa.common.providers;

import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

import com.walmart.platform.kernel.exception.error.Error;
import com.walmart.platform.soa.common.logging.PlatformLogger;
import com.walmart.platform.soa.common.service.wrappers.ServiceHeader;
import com.walmart.platform.soa.common.service.wrappers.ServiceRequest;
import com.walmart.platform.soa.common.service.wrappers.ServiceResponse;
import com.walmart.platform.soa.common.service.wrappers.Status;
import com.walmart.platform.soa.examples.service.Book;
import com.walmart.platform.test.utils.RandomDataUtil;

@Path("/bookstore")
public class BookServiceWrapperStore {

	private Map<Long, Book> books = new HashMap<Long, Book>();

	public BookServiceWrapperStore() {
		init();
	}

	@POST
	@Path("/books")
	@Consumes({"application/xml","text/xml","application/json","application/json"})
    @Produces({"application/xml","text/xml","application/json","application/json"})
	public ServiceResponse<Book> addBook(ServiceRequest<Book> request) {
		try {
			Book reqBook = request.getPayload();
			books.put(reqBook.getId(), reqBook);
			ServiceResponse<Book> response = new ServiceResponse<Book>(
					request.getHeader(), reqBook);
			response.setStatus(Status.OK);
			return response;
		} catch (Exception e) {
			String errorMsg = "Post request for book failed. Error is  "+e.toString();
			ServiceResponse<Book> response = new ServiceResponse<Book>();
			response.setStatus(Status.FAIL);
			response.getErrors().add(
					new Error("A100","book",errorMsg, "Bad post request"));
			return response;
		}
	}

	@GET
	@Path("/books/{bookId}")
	@Produces({ "application/xml", "application/json", "text/xml" })
	public ServiceResponse<Book> getBook(@PathParam("bookId") String id) {
		Book book = books.get(Long.parseLong(id));
		if (book != null) {
			ServiceHeader header = new ServiceHeader();
			header.addHeaderAttribute("a1", "a1val");
			header.addHeaderAttribute("a2", "a2val");
			ServiceResponse<Book> response = new ServiceResponse<Book>();
			response.setHeader(header);
			response.setPayload(book);
			response.setStatus(Status.OK);
			return response;
		} else {
			String errorMsg = "Book not found for id ==" + id;
			PlatformLogger.log(errorMsg);
			ServiceResponse<Book> response = new ServiceResponse<Book>();
			response.setStatus(Status.FAIL);
			response.getErrors().add(
					new Error("A100","book",errorMsg, ""));
			return response;
		}
	}
	
	
	@PUT
	@Path("/books")
	public ServiceResponse<Book> updateBook(ServiceRequest<Book> request) {
		Book reqBook = request.getPayload();
		Book b = books.get(reqBook.getId());
		if (b != null) {
			books.put(reqBook.getId(), reqBook);
			b = reqBook;
			ServiceHeader header = new ServiceHeader();
			ServiceResponse<Book> response = new ServiceResponse<Book>(header, b);
			response.setPayload(b);
			response.setStatus(Status.OK);
			return response;
		}
		else
		{
			String errorMsg = "Book not found for id ==" + reqBook.getId();
			PlatformLogger.log(errorMsg);
			ServiceResponse<Book> response = new ServiceResponse<Book>();
			response.setStatus(Status.FAIL);
			response.getErrors().add(
					new Error("A100","book",errorMsg, ""));
			return response;
		}
		
	}

	public String init() {
		books.clear();
		long bookId = 123;
		Book book = new Book();
		book.setId(bookId);
		book.setName("CXF in Action");

		books.put(book.getId(), book);

		// data for 2K
		long bookId02 = 1;
		Book book02 = new Book();
		book02.setId(bookId02);
		book02.setName(RandomDataUtil.get2KBRandomString());
		books.put(book02.getId(), book02);

		// data for 20K
		long bookId20 = 20;
		Book book20 = new Book();
		book20.setId(bookId20);
		book20.setName(RandomDataUtil.get2KBRandomString());
		books.put(book20.getId(), book20);

		// data for 2MB
		long bookId2 = 2;
		Book book2 = new Book();
		book2.setId(bookId2);
		book2.setName(RandomDataUtil.get2MBRandomString());
		books.put(book2.getId(), book2);

		// data for 6MB
		long bookId6 = 6;
		Book book6 = new Book();
		book6.setId(bookId6);
		book6.setName(RandomDataUtil.get6MBRandomString());
		books.put(book6.getId(), book6);

		return "OK";
	}

}