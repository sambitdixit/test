package com.walmart.platform.soa.common.providers;

import org.apache.cxf.Bus;
import org.apache.cxf.bus.spring.SpringBusFactory;

import com.walmart.platform.test.AbstractServerTest;
import com.walmart.platform.test.utils.PortUtil;

public class BookServiceWrapperServer extends AbstractServerTest {
	public static final String PORT = PortUtil.getPortNumber("jaxbjsonprovider");
	private static final String SERVER_CONFIG_FILE = "jaxbjsonprovider/server.xml";
	private static Bus bus;

	protected void run() {
		SpringBusFactory bf = new SpringBusFactory();
		bus = bf.createBus(SERVER_CONFIG_FILE);
		try {
			new BookServiceWrapperServer();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public static void main(String[] args) {
		try {
			BookServiceWrapperServer s = new BookServiceWrapperServer();
			s.start();
		} catch (Exception ex) {
			ex.printStackTrace();
			System.exit(-1);
		} finally {
			System.out.println("done!");
		}
	}
	
	public static Bus getBus(){
		return bus;
	}
}
