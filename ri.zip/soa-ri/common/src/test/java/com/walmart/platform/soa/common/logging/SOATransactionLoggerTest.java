package com.walmart.platform.soa.common.logging;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.message.Exchange;
import org.apache.cxf.message.ExchangeImpl;
import org.apache.cxf.message.Message;
import org.apache.cxf.message.MessageImpl;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.walmart.platform.soa.common.HeaderElements;

public class SOATransactionLoggerTest {

	@Test
	public void logClientEndTransaction() {
		Message message = new MessageImpl();
		Exchange ex = new ExchangeImpl();
		message.setExchange(ex);
		try {
			message.put(Message.PROTOCOL_HEADERS,
					getClientTransactionHeaders());
			SOATransactionLogger.logClientEndTransaction(message);
		} catch (Fault e) {
			Assert.fail("SOATransactionLogger.logClientEndTransaction test failed with error message:"
					+ e.getMessage());
		}
	}

	@Test
	public void logClientStartTransaction() {
		Message message = new MessageImpl();
		Exchange ex = new ExchangeImpl();
		message.setExchange(ex);
		try {
			message.put(Message.PROTOCOL_HEADERS,
					getClientTransactionHeaders());
			SOATransactionLogger.logClientStartTransaction(message);
		} catch (Fault e) {
			Assert.fail("SOATransactionLogger.logClientStartTransaction test failed with error message:"
					+ e.getMessage());
		}
	}

	@Test
	public void logServerEndTransaction() {
		Message message = new MessageImpl();
		Exchange ex = new ExchangeImpl();
		message.setExchange(ex);
		try {
			message.put(Message.PROTOCOL_HEADERS,
					getServerTransactionHeaders());
			SOATransactionLogger.logServerEndTransaction(message);
		} catch (Fault e) {
			Assert.fail("SOATransactionLogger.logServerEndTransaction test failed with error message:"
					+ e.getMessage());
		}
	}

	@Test
	public void logServerStartTransaction() {
		Message message = new MessageImpl();
		Exchange ex = new ExchangeImpl();
		message.setExchange(ex);
		try {
			message.put(Message.PROTOCOL_HEADERS,
					getServerTransactionHeaders());
			SOATransactionLogger.logServerStartTransaction(message);
		} catch (Fault e) {
			Assert.fail("SOATransactionLogger.logServerStartTransaction test failed with error message:"
					+ e.getMessage());
		}
	}

	private Map<String, List<String>> getClientTransactionHeaders() {
		Map<String, List<String>> headers = new HashMap<String, List<String>>();
		headers.put(Message.REQUEST_URI, Arrays.asList("/a/b"));
		headers.put(Message.HTTP_REQUEST_METHOD, Arrays.asList("GET"));
		headers.put(HeaderElements.CONSUMER_GUID, Arrays.asList("a124aBbaj122"));
		headers.put(HeaderElements.CONSUMER_IN_TIMESTAMP,Arrays.asList(String.valueOf(System.currentTimeMillis())));
		headers.put(HeaderElements.CONSUMER_OUT_TIMESTAMP,
				Arrays.asList(String.valueOf(System.currentTimeMillis())));
		headers.put(HeaderElements.SERVICE_SERVER_NAME, Arrays.asList("test"));
		headers.put(Message.RESPONSE_CODE, Arrays.asList("200"));
		return headers;
	}
	
	private Map<String, List<String>> getServerTransactionHeaders() {
		Map<String, List<String>> headers = new HashMap<String, List<String>>();
		headers.put(Message.REQUEST_URI, Arrays.asList("/a/b"));
		headers.put(Message.HTTP_REQUEST_METHOD, Arrays.asList("GET"));
		headers.put(HeaderElements.CONSUMER_GUID, Arrays.asList("a124aBbaj122"));
		headers.put(HeaderElements.CONSUMER_IN_TIMESTAMP,
				Arrays.asList(String.valueOf(System.currentTimeMillis())));
		headers.put(HeaderElements.CONSUMER_OUT_TIMESTAMP,
				Arrays.asList(String.valueOf(System.currentTimeMillis())));
		headers.put(HeaderElements.SERVICE_SERVER_NAME, Arrays.asList("test"));
		headers.put(HeaderElements.CONSUMER_NAME, Arrays.asList("test-consumer"));
		headers.put(HeaderElements.CONSUMER_IP, Arrays.asList("127.0.0.1"));
		headers.put(HeaderElements.SERVICE_IN_TIMESTAMP,Arrays.asList(String.valueOf(System.currentTimeMillis())));
		headers.put(HeaderElements.SERVICE_OUT_TIMESTAMP,Arrays.asList(String.valueOf(System.currentTimeMillis())));
		headers.put(Message.RESPONSE_CODE, Arrays.asList("200"));
		return headers;
	}
}
