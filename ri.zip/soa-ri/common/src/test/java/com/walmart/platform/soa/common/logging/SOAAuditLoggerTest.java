package com.walmart.platform.soa.common.logging;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import org.apache.cxf.message.Exchange;
import org.apache.cxf.message.ExchangeImpl;
import org.apache.cxf.message.Message;
import org.apache.cxf.message.MessageImpl;
import org.testng.annotations.Test;

public class SOAAuditLoggerTest {

	@Test
	public void logAuditData() {
		Message m = new MessageImpl();
		Exchange ex = new ExchangeImpl();
		m.setExchange(ex);
		ex.put("k1", "value1");
		ex.put("k2", "value2");
		SOAAuditContext ctx = SOAAuditContext.instance();
		ctx.setData("g1", "k1", "v1");
		ctx.setData("g1", "k2", "v2");
		ctx.setData("g1", "k3", "v3");
        assertEquals("v3", ctx.getData("g1", "k3"));

        // null should get in
        ctx.setData(null, null, "value");

		SOAAuditLogger.logAuditData(m);
		assertTrue(true);
	}

	@Test
	public void logSOAHeaderAuditData() {
		Message m = new MessageImpl();
		Exchange ex = new ExchangeImpl();
		m.setExchange(ex);
		ex.put("k1", "value1");
		ex.put("k2", "value2");
		// There are more element inside SOAHeader, so it should fail.
		SOAAuditLogger.logSOAHeaderAuditData(m);
		assertTrue(true);

	}

	@Test
	public void logServiceAuditData() {
		SOAAuditContext ctx = SOAAuditContext.instance();
		ctx.setData("g1", "k1", "v1");
		ctx.setData("g1", "k2", "v2");
		ctx.setData("g1", "k3", "v3");
		SOAAuditLogger.logServiceAuditData();
		assertTrue(true);
	}
}
