package com.walmart.platform.soa.common.providers;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.OutputStream;
import java.io.Writer;
import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.PropertyException;
import javax.xml.bind.ValidationEventHandler;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlAdapter;
import javax.xml.bind.attachment.AttachmentMarshaller;
import javax.xml.namespace.QName;
import javax.xml.stream.XMLEventWriter;
import javax.xml.stream.XMLStreamWriter;
import javax.xml.transform.Result;
import javax.xml.validation.Schema;

import org.apache.cxf.jaxrs.ext.xml.XMLSource;
import org.apache.cxf.jaxrs.impl.MetadataMap;
import org.apache.cxf.jaxrs.model.ClassResourceInfo;
import org.apache.cxf.jaxrs.utils.ResourceUtils;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.w3c.dom.Node;
import org.xml.sax.ContentHandler;

public class SOAJAXBProviderTest {

	@SuppressWarnings("unchecked")
	@Test
	public void testReadFromISO() throws Exception {

		String eWithAcute = "\u00E9";
		String nameStringUTF16 = "F" + eWithAcute + "lix";
		String bookStringUTF16 = "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>"
				+ "<Book><name>" + nameStringUTF16 + "</name></Book>";

		byte[] iso88591bytes = bookStringUTF16.getBytes("ISO-8859-1");

		SOAJAXBProvider p = new SOAJAXBProvider();
		Book book = (Book) p.readFrom((Class) Book.class, null,
				new Annotation[] {},
				MediaType.valueOf(MediaType.APPLICATION_XML), null,
				new ByteArrayInputStream(iso88591bytes));
		Assert.assertEquals(book.getName(), nameStringUTF16);
		Assert.assertNotNull(p.getExtraClass());
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testReadChineeseChars() throws Exception {

		String nameStringUTF16 = "中文";

		String bookStringUTF16 = "<Book><name>" + nameStringUTF16
				+ "</name></Book>";
		SOAJAXBProvider p = new SOAJAXBProvider();
		Book book = (Book) p
				.readFrom(
						(Class) Book.class,
						null,
						new Annotation[] {},
						MediaType.valueOf(MediaType.APPLICATION_XML
								+ ";charset=UTF-8"),
						null,
						new ByteArrayInputStream(bookStringUTF16
								.getBytes("UTF-8")));
		Assert.assertEquals(book.getName(), nameStringUTF16);
	}

	@Test
	public void testSingleJAXBContext() throws Exception {
		ClassResourceInfo cri = ResourceUtils.createClassResourceInfo(
				JAXBResource.class, JAXBResource.class, true, true);
		SOAJAXBProvider provider = new SOAJAXBProvider();
		provider.setSingleJaxbContext(true);
		provider.init(Collections.singletonList(cri));
		JAXBContext bookContext = provider.getJAXBContext(Book.class,
				Book.class);
		Assert.assertNotNull(bookContext);
		JAXBContext superBookContext = provider.getJAXBContext(SuperBook.class,
				SuperBook.class);
		Assert.assertSame(bookContext, superBookContext);
	}

	@Test
	public void testExtraClass() throws Exception {
		ClassResourceInfo cri = ResourceUtils.createClassResourceInfo(
				BookStore.class, BookStore.class, true, true);
		SOAJAXBProvider provider = new SOAJAXBProvider();
		provider.setSingleJaxbContext(true);
		provider.setExtraClass(new Class[] { SuperBook.class });
		provider.init(Collections.singletonList(cri));
		JAXBContext bookContext = provider.getJAXBContext(Book.class,
				Book.class);
		Assert.assertNotNull(bookContext);
		JAXBContext superBookContext = provider.getJAXBContext(SuperBook.class,
				SuperBook.class);
		Assert.assertSame(bookContext, superBookContext);
	}

	@Test
	public void testExtraClassWithoutSingleContext() throws Exception {
		ClassResourceInfo cri = ResourceUtils.createClassResourceInfo(
				BookStore.class, BookStore.class, true, true);
		SOAJAXBProvider provider = new SOAJAXBProvider();
		provider.setExtraClass(new Class[] { SuperBook.class });
		provider.init(Collections.singletonList(cri));
		JAXBContext bookContext = provider.getJAXBContext(Book.class,
				Book.class);

		ByteArrayOutputStream os = new ByteArrayOutputStream();
		bookContext.createMarshaller().marshal(new SuperBook("name", 1L, 2L),
				os);
		SuperBook book = (SuperBook) bookContext.createUnmarshaller()
				.unmarshal(new ByteArrayInputStream(os.toByteArray()));
		Assert.assertEquals(2L, book.getSuperId());
	}

	@Test
	public void testExtraClassWithGenerics() throws Exception {
		SOAJAXBProvider provider = new SOAJAXBProvider();
		provider.setExtraClass(new Class[] { XmlObject.class });
		testXmlList(provider);
	}

	@Test
	public void testExtraClassWithGenericsAndSingleContext() throws Exception {
		ClassResourceInfo cri = ResourceUtils.createClassResourceInfo(
				XmlListResource.class, XmlListResource.class, true, true);
		SOAJAXBProvider provider = new SOAJAXBProvider();
		provider.setExtraClass(new Class[] { XmlObject.class });
		provider.init(Collections.singletonList(cri));
		testXmlList(provider);

	}

	@SuppressWarnings("unchecked")
	private void testXmlList(SOAJAXBProvider provider) throws Exception {

		List<XmlObject> list = new ArrayList<XmlObject>();
		for (int i = 0; i < 10; i++) {
			MyObject o = new MyObject();
			o.setName("name #" + i);
			list.add(new XmlObject(o));
		}
		XmlList<XmlObject> xmlList = new XmlList<XmlObject>(list);

		JAXBContext context = provider.getJAXBContext(XmlList.class,
				XmlList.class);

		ByteArrayOutputStream os = new ByteArrayOutputStream();
		context.createMarshaller().marshal(xmlList, os);
		XmlList<XmlObject> list2 = (XmlList<XmlObject>) context
				.createUnmarshaller().unmarshal(
						new ByteArrayInputStream(os.toByteArray()));

		List<XmlObject> actualList = list2.getList();
		Assert.assertEquals(10, actualList.size());
		for (int i = 0; i < 10; i++) {
			XmlObject object = actualList.get(i);
			Assert.assertEquals("name #" + i, object.getAttribute().getName());
		}
	}

	@Test
	public void testIsWriteableList() throws Exception {
		testIsWriteableCollection("getBooks");
	}

	@Test
	public void testIsWriteableCollection() throws Exception {
		testIsWriteableCollection("getBookCollection");
	}

	@Test
	public void testIsWriteableSet() throws Exception {
		testIsWriteableCollection("getBookSet");
	}

	@Test
	public void testIsSupportedWithJaxbIndex() {
		SOAJAXBProvider provider = new SOAJAXBProvider();
		Assert.assertTrue(provider.isSupported(Book.class, Book.class,
				new Annotation[] {}));
	}

	@Test
	public void testIsWriteableJAXBElements() throws Exception {
		testIsWriteableCollection("getBookElements");
	}

	private void testIsWriteableCollection(String mName) throws Exception {
		SOAJAXBProvider provider = new SOAJAXBProvider();
		provider.setCollectionWrapperName("foo");
		Method m = CollectionsResource.class.getMethod(mName, new Class[0]);
		Assert.assertTrue(provider.isWriteable(m.getReturnType(),
				m.getGenericReturnType(), new Annotation[0],
				MediaType.TEXT_XML_TYPE));
	}

	@Test
	public void testWriteCollection() throws Exception {
		doWriteUnqualifiedCollection(true, "getBookCollection",
				"setBookCollection", Collection.class);
	}

	@Test
	public void testWriteList() throws Exception {
		doWriteUnqualifiedCollection(true, "getBooks", "setBooks", List.class);
	}

	@Test
	public void testWriteSet() throws Exception {
		doWriteUnqualifiedCollection(true, "getBookSet", "setBookSet",
				Set.class);
	}

	@Test
	public void testWriteCollectionJaxbName() throws Exception {
		doWriteUnqualifiedCollection(false, "getBooks", "setBooks", List.class);
	}

	@Test
	public void testWriteArray() throws Exception {
		doWriteUnqualifiedCollection(true, "getBooksArray", "setBooksArray",
				Book[].class);
	}

	public void doWriteUnqualifiedCollection(boolean setName, String mName,
			String setterName, Class<?> type) throws Exception {
		SOAJAXBProvider provider = new SOAJAXBProvider();
		if (setName) {
			provider.setCollectionWrapperName("Books");
		}
		List<Book> books = new ArrayList<Book>();
		books.add(new Book("CXF in Action", 123L));
		books.add(new Book("CXF Rocks", 124L));
		Object o = type.isArray() ? books.toArray()
				: type == Set.class ? new HashSet<Book>(books) : books;

		Method m = CollectionsResource.class.getMethod(mName, new Class[0]);
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		provider.writeTo(o, m.getReturnType(), m.getGenericReturnType(),
				new Annotation[0], MediaType.TEXT_XML_TYPE,
				new MetadataMap<String, Object>(), bos);
		doReadUnqualifiedCollection(bos.toString(), setterName, type);
	}

	@Test
	public void testWriteJAXBElementCollection() throws Exception {
		doTestWriteJAXBCollection("getBookElements");
	}

	@Test
	public void testWriteJAXBElementCollection2() throws Exception {
		doTestWriteJAXBCollection("getBookElements2");
	}

	@Test
	public void testWriteDerivedType() throws Exception {
		SOAJAXBProvider provider = new SOAJAXBProvider();
		provider.setJaxbElementClassNames(Collections.singletonList(Book.class
				.getName()));
		Book b = new SuperBook("CXF in Action", 123L, 124L);

		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		provider.writeTo(b, Book.class, Book.class, new Annotation[0],
				MediaType.TEXT_XML_TYPE, new MetadataMap<String, Object>(), bos);
		readSuperBook(bos.toString(), true);
	}

	@Test
	public void testWriteDerivedType2() throws Exception {
		SOAJAXBProvider provider = new SOAJAXBProvider();
		Book b = new SuperBook("CXF in Action", 123L, 124L);

		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		provider.writeTo(b, Book.class, Book.class, new Annotation[0],
				MediaType.TEXT_XML_TYPE, new MetadataMap<String, Object>(), bos);

		readSuperBook(bos.toString(), false);
	}

	@Test
	public void testWriteWithCustomPrefixes() throws Exception {
		SOAJAXBProvider provider = new SOAJAXBProvider();
		provider.setNamespacePrefixes(Collections.singletonMap("http://tags",
				"prefix"));
		TagVO2 tag = new TagVO2("a", "b");

		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		provider.writeTo(tag, TagVO2.class, TagVO2.class, new Annotation[0],
				MediaType.TEXT_XML_TYPE, new MetadataMap<String, Object>(), bos);
		Assert.assertTrue(bos.toString().contains("prefix:thetag"));
	}

//	@Test
//	public void testWriteCollectionWithCustomPrefixes() throws Exception {
//		SOAJAXBProvider provider = new SOAJAXBProvider();
//		provider.setNamespacePrefixes(Collections.singletonMap("http://tags",
//				"prefix"));
//		TagVO2 tag = new TagVO2("a", "b");
//		List<TagVO2> tags = Collections.singletonList(tag);
//		ByteArrayOutputStream bos = new ByteArrayOutputStream();
//		provider.writeTo(tags, List.class,
//				new ParameterizedCollectionType<TagVO2>(TagVO2.class),
//				new Annotation[0], MediaType.TEXT_XML_TYPE,
//				new MetadataMap<String, Object>(), bos);
//		Assert.assertTrue(bos.toString().contains("prefix:thetag"));
//		Assert.assertFalse(bos.toString().contains("ns1:thetag"));
//	}

	@Test
	public void testWriteWithoutXmlRootElement() throws Exception {
		doTestWriteWithoutXmlRootElement("SuperBook", false, false);
	}

	@Test
	public void testWriteWithoutXmlRootElement2() throws Exception {
		doTestWriteWithoutXmlRootElement("SuperBook", true, false);
	}

	@Test
	public void testWriteWithoutXmlRootElement3() throws Exception {
		doTestWriteWithoutXmlRootElement("{http://books}SuperBook", false,
				false);
	}

	@Test
	public void testWriteWithoutXmlRootElement4() throws Exception {
		doTestWriteWithoutXmlRootElement("SuperBook", true, true);
	}

	public void doTestWriteWithoutXmlRootElement(String name,
			boolean unmarshalAsJaxbElement, boolean marshalAsJaxbElement)
			throws Exception {
		SOAJAXBProvider provider = new SOAJAXBProvider();
		if (!marshalAsJaxbElement) {
			provider.setJaxbElementClassMap(Collections.singletonMap(
					SuperBook.class.getName(), name));
		} else {
			provider.setMarshallAsJaxbElement(marshalAsJaxbElement);
		}
		SuperBook b = new SuperBook("CXF in Action", 123L, 124L);

		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		provider.writeTo(b, SuperBook.class, SuperBook.class,
				new Annotation[0], MediaType.TEXT_XML_TYPE,
				new MetadataMap<String, Object>(), bos);
		readSuperBook2(bos.toString(), unmarshalAsJaxbElement);
	}

	@Test
	public void testWriteCollectionWithoutXmlRootElement() throws Exception {
		SOAJAXBProvider provider = new SOAJAXBProvider();
		provider.setCollectionWrapperName("{http://superbooks}SuperBooks");
		provider.setJaxbElementClassMap(Collections.singletonMap(
				SuperBook.class.getName(), "{http://superbooks}SuperBook"));
		SuperBook b = new SuperBook("CXF in Action", 123L, 124L);
		List<SuperBook> books = Collections.singletonList(b);

		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		provider.writeTo(books, List.class, SuperBook.class, new Annotation[0],
				MediaType.TEXT_XML_TYPE, new MetadataMap<String, Object>(), bos);
		String expected = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
				+ "<ns1:SuperBooks xmlns:ns1=\"http://superbooks\">"
				+ "<SuperBook>" + "<id>123</id>"
				+ "<name>CXF in Action</name><superId>124</superId>"
				+ "</SuperBook>" + "</ns1:SuperBooks>";
		Assert.assertEquals(bos.toString(), expected);
	}

	@Test
	public void testWriteWithoutXmlRootElementDerived() throws Exception {
		SOAJAXBProvider provider = new SOAJAXBProvider();
		provider.setJaxbElementClassMap(Collections.singletonMap(
				Book.class.getName(), "Book"));
		Book b = new SuperBook("CXF in Action", 123L, 124L);

		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		provider.writeTo(b, Book.class, Book.class, new Annotation[0],
				MediaType.TEXT_XML_TYPE, new MetadataMap<String, Object>(), bos);
		readSuperBook2(bos.toString(), false);
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testWriteWithXmlRootElementAndPackageInfo() throws Exception {
		SOAJAXBProvider provider = new SOAJAXBProvider();
		Book book = new Book("test book", 333);
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		provider.writeTo(book, Book.class, Book.class, new Annotation[0],
				MediaType.TEXT_XML_TYPE, new MetadataMap<String, Object>(), bos);
		Assert.assertTrue(bos.toString().contains("book"));
		ByteArrayInputStream is = new ByteArrayInputStream(bos.toByteArray());
		Book book2 = (Book) provider.readFrom((Class) Book.class, Book.class,
				new Annotation[0], MediaType.TEXT_XML_TYPE,
				new MetadataMap<String, String>(), is);
		Assert.assertEquals(book2.getId(), book.getId());
	}

	@Test
	@SuppressWarnings("unchecked")
	public void testWriteWithoutXmlRootElementObjectFactory() throws Exception {
		SOAJAXBProvider provider = new SOAJAXBProvider();
		provider.setJaxbElementClassMap(Collections.singletonMap(
				SuperBook.class.getName(), "{http://books}SuperBook"));
		SuperBook b = new SuperBook("CXF in Action", 123L, 124L);

		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		provider.writeTo(b, SuperBook.class, SuperBook.class,
				new Annotation[0], MediaType.TEXT_XML_TYPE,
				new MetadataMap<String, Object>(), bos);
		SOAJAXBProvider provider2 = new SOAJAXBProvider();
		ByteArrayInputStream is = new ByteArrayInputStream(bos.toByteArray());
		SuperBook book = (SuperBook) provider2.readFrom(
				(Class) SuperBook.class, SuperBook.class, new Annotation[0],
				MediaType.TEXT_XML_TYPE, new MetadataMap<String, String>(), is);
		Assert.assertEquals(124L, book.getSuperId());
	}

	@SuppressWarnings("unchecked")
	private void readSuperBook(String data, boolean xsiTypeExpected)
			throws Exception {
		if (xsiTypeExpected) {
			Assert.assertTrue(data.contains("xsi:type"));
		}
		SOAJAXBProvider provider = new SOAJAXBProvider();
		ByteArrayInputStream is = new ByteArrayInputStream(data.getBytes());
		SuperBook book = (SuperBook) provider.readFrom((Class) SuperBook.class,
				SuperBook.class, new Annotation[0], MediaType.TEXT_XML_TYPE,
				new MetadataMap<String, String>(), is);
		Assert.assertEquals(124L, book.getSuperId());
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testReadSuperBookWithJaxbElement() throws Exception {
		final String data = "<BookNoRootElement>"
				+ "<name>superbook</name><id>111</id>" + "</BookNoRootElement>";
		SOAJAXBProvider provider = new SOAJAXBProvider();
		provider.setUnmarshallAsJaxbElement(true);
		ByteArrayInputStream is = new ByteArrayInputStream(data.getBytes());
		BookNoRootElement book = (BookNoRootElement) provider.readFrom(
				(Class) BookNoRootElement.class, BookNoRootElement.class,
				new Annotation[0], MediaType.TEXT_XML_TYPE,
				new MetadataMap<String, String>(), is);
		Assert.assertEquals(111L, book.getId());
		Assert.assertEquals("superbook", book.getName());
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testReadSuperBookWithJaxbElementAndTransform() throws Exception {
		final String data = "<BookNoRootElement xmlns=\"http://books\">"
				+ "<name>superbook</name><id>111</id>" + "</BookNoRootElement>";
		SOAJAXBProvider provider = new SOAJAXBProvider();
		provider.setUnmarshallAsJaxbElement(true);
		provider.setInTransformElements(Collections.singletonMap(
				"{http://books}*", ""));
		ByteArrayInputStream is = new ByteArrayInputStream(data.getBytes());
		BookNoRootElement book = (BookNoRootElement) provider.readFrom(
				(Class) BookNoRootElement.class, BookNoRootElement.class,
				new Annotation[0], MediaType.TEXT_XML_TYPE,
				new MetadataMap<String, String>(), is);
		Assert.assertEquals(111L, book.getId());
		Assert.assertEquals("superbook", book.getName());
	}

	@SuppressWarnings("unchecked")
	private void readSuperBook2(String data, boolean unmarshalAsJaxbElement)
			throws Exception {
		SOAJAXBProvider provider = new SOAJAXBProvider();
		if (!unmarshalAsJaxbElement) {
			provider.setJaxbElementClassMap(Collections.singletonMap(
					SuperBook.class.getName(), "SuperBook"));
		} else {
			provider.setUnmarshallAsJaxbElement(true);
		}
		ByteArrayInputStream is = new ByteArrayInputStream(data.getBytes());
		SuperBook book = (SuperBook) provider.readFrom((Class) SuperBook.class,
				SuperBook.class, new Annotation[0], MediaType.TEXT_XML_TYPE,
				new MetadataMap<String, String>(), is);
		Assert.assertEquals(124L, book.getSuperId());
	}

	private void doTestWriteJAXBCollection(String mName) throws Exception {
		SOAJAXBProvider provider = new SOAJAXBProvider();
		List<JAXBElement<Book>> books = new ArrayList<JAXBElement<Book>>();
		books.add(new JAXBElement<Book>(new QName("Books"), Book.class, null,
				new Book("CXF in Action", 123L)));
		books.add(new JAXBElement<Book>(new QName("Books"), Book.class, null,
				new Book("CXF Rocks", 124L)));

		Method m = CollectionsResource.class.getMethod(mName, new Class[0]);
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		provider.writeTo(books, m.getReturnType(), m.getGenericReturnType(),
				new Annotation[0], MediaType.TEXT_XML_TYPE,
				new MetadataMap<String, Object>(), bos);
		doReadUnqualifiedCollection(bos.toString(), "setBooks", List.class);
	}

	@Test
	public void testWriteQualifiedCollection() throws Exception {
		SOAJAXBProvider provider = new SOAJAXBProvider();
		provider.setCollectionWrapperName("{http://tags}tags");
		List<TagVO2> tags = new ArrayList<TagVO2>();
		tags.add(new TagVO2("A", "B"));
		tags.add(new TagVO2("C", "D"));
		Method m = CollectionsResource.class.getMethod("getTags", new Class[0]);
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		provider.writeTo(tags, m.getReturnType(), m.getGenericReturnType(),
				new Annotation[0], MediaType.TEXT_XML_TYPE,
				new MetadataMap<String, Object>(), bos);
		doReadQualifiedCollection(bos.toString(), false);
	}

	@Test
	public void testInNsElementFromLocal() throws Exception {
		String data = "<?xml version='1.0' encoding='UTF-8'?>"
				+ "<thetag><group>B</group><name>A</name></thetag>";
		readTagVO2AfterTransform(data, "thetag");
	}

	@Test
	public void testInNsElementFromNsElement() throws Exception {
		String data = "<?xml version='1.0' encoding='UTF-8'?>"
				+ "<t:thetag2 xmlns:t=\"http://bar\"><group>B</group><name>A</name></t:thetag2>";
		readTagVO2AfterTransform(data, "{http://bar}thetag2");
	}

	@Test
	public void testInAppendElementNoNs() throws Exception {
		String data = "<tags><list><group>b</group><name>a</name></list></tags>";
		readAppendElementsNoNs(data,
				Collections.singletonMap("tags", "ManyTags"));
	}

	@Test
	public void testInAppendElementNoNs2() throws Exception {
		String data = "<ManyTags><list><group>b</group><name>a</name></list></ManyTags>";
		readAppendElementsNoNs(data, Collections.singletonMap("list", "tags"));
	}

	@SuppressWarnings("unchecked")
	private void readAppendElementsNoNs(String data,
			Map<String, String> appendMap) throws Exception {
		SOAJAXBProvider provider = new SOAJAXBProvider();
		provider.setInAppendElements(appendMap);
		ByteArrayInputStream is = new ByteArrayInputStream(data.getBytes());
		Object o = provider.readFrom((Class) ManyTags.class, ManyTags.class,
				new Annotation[0], MediaType.TEXT_XML_TYPE,
				new MetadataMap<String, String>(), is);
		ManyTags holder = (ManyTags) o;
		Assert.assertNotNull(holder);
		TagVO tag = holder.getTags().getTags().get(0);
		Assert.assertEquals("a", tag.getName());
		Assert.assertEquals("b", tag.getGroup());
	}

	@Test
	@SuppressWarnings("unchecked")
	public void testInDropElement() throws Exception {
		String data = "<Extra><ManyTags><tags><list><group>b</group><name>a</name></list></tags>"
				+ "</ManyTags></Extra>";
		SOAJAXBProvider provider = new SOAJAXBProvider();
		provider.setInDropElements(Collections.singletonList("Extra"));
		ByteArrayInputStream is = new ByteArrayInputStream(data.getBytes());
		Object o = provider.readFrom((Class) ManyTags.class, ManyTags.class,
				new Annotation[0], MediaType.TEXT_XML_TYPE,
				new MetadataMap<String, String>(), is);
		ManyTags holder = (ManyTags) o;
		Assert.assertNotNull(holder);
		TagVO tag = holder.getTags().getTags().get(0);
		Assert.assertEquals("a", tag.getName());
		Assert.assertEquals("b", tag.getGroup());
	}

	@Test
	public void testInLocalFromLocal() throws Exception {
		String data = "<?xml version='1.0' encoding='UTF-8'?>"
				+ "<thetag><group>B</group><name>A</name></thetag>";
		readTagVOAfterTransform(data, "thetag");
	}

	@Test
	public void testInLocalFromNsElement() throws Exception {
		String data = "<?xml version='1.0' encoding='UTF-8'?>"
				+ "<t:thetag2 xmlns:t=\"http://bar\"><group>B</group><name>A</name></t:thetag2>";
		readTagVOAfterTransform(data, "{http://bar}thetag2");
	}

	@SuppressWarnings("unchecked")
	private void readTagVO2AfterTransform(String data, String keyValue)
			throws Exception {
		SOAJAXBProvider provider = new SOAJAXBProvider();
		Map<String, String> map = new HashMap<String, String>();
		map.put(keyValue, "{http://tags}thetag");
		provider.setInTransformElements(map);
		ByteArrayInputStream is = new ByteArrayInputStream(data.getBytes());
		Object o = provider.readFrom((Class) TagVO2.class, TagVO2.class,
				new Annotation[0], MediaType.TEXT_XML_TYPE,
				new MetadataMap<String, String>(), is);
		TagVO2 tag2 = (TagVO2) o;
		Assert.assertEquals("A", tag2.getName());
		Assert.assertEquals("B", tag2.getGroup());
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testInNsElementsFromLocals() throws Exception {
		String data = "<?xml version='1.0' encoding='UTF-8'?>"
				+ "<tagholder><thetag><group>B</group><name>A</name></thetag></tagholder>";
		SOAJAXBProvider provider = new SOAJAXBProvider();
		Map<String, String> map = new HashMap<String, String>();
		map.put("tagholder", "{http://tags}tagholder");
		map.put("thetag", "{http://tags}thetag");
		provider.setInTransformElements(map);
		ByteArrayInputStream is = new ByteArrayInputStream(data.getBytes());
		Object o = provider.readFrom((Class) TagVO2Holder.class,
				TagVO2Holder.class, new Annotation[0], MediaType.TEXT_XML_TYPE,
				new MetadataMap<String, String>(), is);
		TagVO2Holder holder = (TagVO2Holder) o;
		TagVO2 tag2 = holder.getTagValue();
		Assert.assertEquals("A", tag2.getName());
		Assert.assertEquals("B", tag2.getGroup());
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testInNsElementsFromLocalsWildcard() throws Exception {
		String data = "<?xml version='1.0' encoding='UTF-8'?>"
				+ "<tagholder><thetag><group>B</group><name>A</name></thetag></tagholder>";
		SOAJAXBProvider provider = new SOAJAXBProvider();
		Map<String, String> map = new LinkedHashMap<String, String>();
		map.put("group", "group");
		map.put("name", "name");
		map.put("*", "{http://tags}*");
		provider.setInTransformElements(map);
		ByteArrayInputStream is = new ByteArrayInputStream(data.getBytes());
		Object o = provider.readFrom((Class) TagVO2Holder.class,
				TagVO2Holder.class, new Annotation[0], MediaType.TEXT_XML_TYPE,
				new MetadataMap<String, String>(), is);
		TagVO2Holder holder = (TagVO2Holder) o;
		TagVO2 tag2 = holder.getTagValue();
		Assert.assertEquals("A", tag2.getName());
		Assert.assertEquals("B", tag2.getGroup());
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testInNsElementsFromLocalsWildcard2() throws Exception {
		String data = "<?xml version='1.0' encoding='UTF-8'?>"
				+ "<ns2:tagholder xmlns:ns2=\"http://tags2\" attr=\"attribute\"><ns2:thetag><group>B</group>"
				+ "<name>A</name></ns2:thetag></ns2:tagholder>";
		SOAJAXBProvider provider = new SOAJAXBProvider();
		Map<String, String> map = new LinkedHashMap<String, String>();
		map.put("group", "group");
		map.put("name", "name");
		map.put("{http://tags2}*", "{http://tags}*");
		provider.setInTransformElements(map);
		ByteArrayInputStream is = new ByteArrayInputStream(data.getBytes());
		Object o = provider.readFrom((Class) TagVO2Holder.class,
				TagVO2Holder.class, new Annotation[0], MediaType.TEXT_XML_TYPE,
				new MetadataMap<String, String>(), is);
		TagVO2Holder holder = (TagVO2Holder) o;
		TagVO2 tag2 = holder.getTagValue();
		Assert.assertEquals("A", tag2.getName());
		Assert.assertEquals("B", tag2.getGroup());
	}

	@SuppressWarnings("unchecked")
	private void readTagVOAfterTransform(String data, String keyValue)
			throws Exception {
		SOAJAXBProvider provider = new SOAJAXBProvider();
		Map<String, String> map = new HashMap<String, String>();
		map.put(keyValue, "tagVO");
		provider.setInTransformElements(map);
		ByteArrayInputStream is = new ByteArrayInputStream(data.getBytes());
		Object o = provider.readFrom((Class) TagVO.class, TagVO.class,
				new Annotation[0], MediaType.TEXT_XML_TYPE,
				new MetadataMap<String, String>(), is);
		TagVO tag2 = (TagVO) o;
		Assert.assertEquals("A", tag2.getName());
		Assert.assertEquals("B", tag2.getGroup());
	}

	@Test
	public void testOutAttributesAsElements() throws Exception {
		SOAJAXBProvider provider = new SOAJAXBProvider();
		Map<String, String> map = new HashMap<String, String>();
		map.put("{http://tags}thetag", "thetag");
		map.put("{http://tags}tagholder", "tagholder");
		provider.setOutTransformElements(map);
		provider.setAttributesToElements(true);
		TagVO2 tag = new TagVO2("A", "B");
		TagVO2Holder holder = new TagVO2Holder();
		holder.setTag(tag);

		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		provider.writeTo(holder, TagVO2Holder.class, TagVO2Holder.class,
				new Annotation[0], MediaType.TEXT_XML_TYPE,
				new MetadataMap<String, Object>(), bos);
		String expected = "<?xml version='1.0' encoding='UTF-8'?><tagholder><attr>attribute</attr>"
				+ "<thetag><group>B</group><name>A</name></thetag></tagholder>";
		Assert.assertEquals(expected, bos.toString());
	}

	// @Test
	public void testOutAttributesAsElementsForList() throws Exception {

		// Provider
		SOAJAXBProvider provider = new SOAJAXBProvider();
		provider.setCollectionWrapperName("tagholders");
		Map<String, String> map = new HashMap<String, String>();
		map.put("{http://tags}*", "*");
		provider.setOutTransformElements(map);
		provider.setAttributesToElements(true);

		// data setup
		TagVO2 tag = new TagVO2("A", "B");
		TagVO2Holder holder = new TagVO2Holder();
		holder.setTag(tag);
		List<TagVO2Holder> list = new ArrayList<SOAJAXBProviderTest.TagVO2Holder>();
		list.add(holder);

		// ParameterizedType required for Lists of Objects
		ParameterizedType type = new ParameterizedType() {
			public Type getRawType() {
				return List.class;
			}

			public Type getOwnerType() {
				return null;
			}

			public Type[] getActualTypeArguments() {
				return new Type[] { TagVO2Holder.class };
			}
		};

		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		provider.writeTo(list, ArrayList.class, type, new Annotation[0],
				MediaType.TEXT_XML_TYPE, new MetadataMap<String, Object>(), bos);

		String expected = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
				+ "<tagholders><tagholder><attr>attribute</attr>"
				+ "<thetag><group>B</group><name>A</name></thetag></tagholder></tagholders>";
		Assert.assertEquals(expected, bos.toString());
	}

	@Test
	public void testOutAppendElementsDiffNs() throws Exception {
		SOAJAXBProvider provider = new SOAJAXBProvider();
		Map<String, String> map = new HashMap<String, String>();
		map.put("{http://tags}thetag", "{http://tagsvo2}t");
		provider.setOutAppendElements(map);
		TagVO2 tag = new TagVO2("A", "B");
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		provider.writeTo(tag, TagVO2.class, TagVO2.class, new Annotation[0],
				MediaType.TEXT_XML_TYPE, new MetadataMap<String, Object>(), bos);
		String expected = "<?xml version='1.0' encoding='UTF-8'?><ps1:t xmlns:ps1=\"http://tagsvo2\">"
				+ "<ns2:thetag xmlns:ns2=\"http://tags\"><group>B</group><name>A</name></ns2:thetag></ps1:t>";
		Assert.assertEquals(expected, bos.toString());
	}

	@Test
	public void testOutAppendNsElementBeforeLocal() throws Exception {
		SOAJAXBProvider provider = new SOAJAXBProvider();
		Map<String, String> map = new HashMap<String, String>();
		map.put("tagVO", "{http://tagsvo2}t");
		provider.setOutAppendElements(map);
		TagVO tag = new TagVO("A", "B");
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		provider.writeTo(tag, TagVO.class, TagVO.class, new Annotation[0],
				MediaType.TEXT_XML_TYPE, new MetadataMap<String, Object>(), bos);
		String expected = "<?xml version='1.0' encoding='UTF-8'?><ps1:t xmlns:ps1=\"http://tagsvo2\">"
				+ "<tagVO><group>B</group><name>A</name></tagVO></ps1:t>";
		Assert.assertEquals(expected, bos.toString());
	}

	@Test
	public void testOutAppendLocalBeforeLocal() throws Exception {
		SOAJAXBProvider provider = new SOAJAXBProvider();
		Map<String, String> map = new HashMap<String, String>();
		map.put("tagVO", "supertag");
		provider.setOutAppendElements(map);
		TagVO tag = new TagVO("A", "B");
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		provider.writeTo(tag, TagVO.class, TagVO.class, new Annotation[0],
				MediaType.TEXT_XML_TYPE, new MetadataMap<String, Object>(), bos);
		String expected = "<?xml version='1.0' encoding='UTF-8'?>"
				+ "<supertag><tagVO><group>B</group><name>A</name></tagVO></supertag>";
		Assert.assertEquals(expected, bos.toString());
	}

	@Test
	public void testOutAppendElementsSameNs() throws Exception {
		SOAJAXBProvider provider = new SOAJAXBProvider();
		Map<String, String> map = new HashMap<String, String>();
		map.put("{http://tags}thetag", "{http://tags}t");
		provider.setOutAppendElements(map);
		TagVO2 tag = new TagVO2("A", "B");
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		provider.writeTo(tag, TagVO2.class, TagVO2.class, new Annotation[0],
				MediaType.TEXT_XML_TYPE, new MetadataMap<String, Object>(), bos);
		String expected = "<?xml version='1.0' encoding='UTF-8'?>"
				+ "<ns2:t xmlns:ns2=\"http://tags\"><ns2:thetag><group>B</group><name>A</name></ns2:thetag>"
				+ "</ns2:t>";
		Assert.assertEquals(expected, bos.toString());
	}

	@Test
	public void testOutElementsMapLocalNsToLocalNs() throws Exception {
		SOAJAXBProvider provider = new SOAJAXBProvider();
		Map<String, String> map = new HashMap<String, String>();
		map.put("{http://tags}thetag", "{http://tagsvo2}t");
		provider.setOutTransformElements(map);
		TagVO2 tag = new TagVO2("A", "B");
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		provider.writeTo(tag, TagVO2.class, TagVO2.class, new Annotation[0],
				MediaType.TEXT_XML_TYPE, new MetadataMap<String, Object>(), bos);
		String expected = "<?xml version='1.0' encoding='UTF-8'?>"
				+ "<ns2:t xmlns:ns2=\"http://tagsvo2\"><group>B</group><name>A</name></ns2:t>";
		Assert.assertEquals(expected, bos.toString());

	}

	@Test
	public void testOutElementsMapLocalNsToLocal() throws Exception {
		SOAJAXBProvider provider = new SOAJAXBProvider();
		Map<String, String> map = new HashMap<String, String>();
		map.put("{http://tags}thetag", "t");
		provider.setOutTransformElements(map);
		TagVO2 tag = new TagVO2("A", "B");
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		provider.writeTo(tag, TagVO2.class, TagVO2.class, new Annotation[0],
				MediaType.TEXT_XML_TYPE, new MetadataMap<String, Object>(), bos);
		String expected = "<?xml version='1.0' encoding='UTF-8'?>"
				+ "<t><group>B</group><name>A</name></t>";
		Assert.assertEquals(expected, bos.toString());
	}

	@Test
	public void testOutElementsMapLocalNsToLocalWildcard() throws Exception {
		SOAJAXBProvider provider = new SOAJAXBProvider();
		Map<String, String> map = new HashMap<String, String>();
		map.put("{http://tags}*", "*");
		provider.setOutTransformElements(map);
		TagVO2 tag = new TagVO2("A", "B");
		TagVO2Holder holder = new TagVO2Holder();
		holder.setTag(tag);
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		provider.writeTo(holder, TagVO2Holder.class, TagVO2Holder.class,
				new Annotation[0], MediaType.TEXT_XML_TYPE,
				new MetadataMap<String, Object>(), bos);
		String expected = "<?xml version='1.0' encoding='UTF-8'?>"
				+ "<tagholder attr=\"attribute\"><thetag><group>B</group><name>A</name></thetag></tagholder>";
		Assert.assertEquals(expected, bos.toString());
	}

	@Test
	public void testOutElementsMapLocalNsToLocalWildcard2() throws Exception {
		SOAJAXBProvider provider = new SOAJAXBProvider();
		Map<String, String> map = new HashMap<String, String>();
		map.put("{http://tags}*", "{http://tags2}*");
		provider.setOutTransformElements(map);
		TagVO2 tag = new TagVO2("A", "B");
		TagVO2Holder holder = new TagVO2Holder();
		holder.setTag(tag);
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		provider.writeTo(holder, TagVO2Holder.class, TagVO2Holder.class,
				new Annotation[0], MediaType.TEXT_XML_TYPE,
				new MetadataMap<String, Object>(), bos);

		String expected = "<?xml version='1.0' encoding='UTF-8'?>"
				+ "<ns2:tagholder xmlns:ns2=\"http://tags2\" attr=\"attribute\"><ns2:thetag><group>B</group>"
				+ "<name>A</name></ns2:thetag></ns2:tagholder>";
		Assert.assertEquals(expected, bos.toString());
	}

	@Test
	public void testOutElementsMapLocalToLocalNs() throws Exception {
		SOAJAXBProvider provider = new SOAJAXBProvider();
		Map<String, String> map = new HashMap<String, String>();
		map.put("tagVO", "{http://tags}thetag");
		provider.setOutTransformElements(map);
		TagVO tag = new TagVO("A", "B");
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		provider.writeTo(tag, TagVO.class, TagVO.class, new Annotation[0],
				MediaType.TEXT_XML_TYPE, new MetadataMap<String, Object>(), bos);
		String expected = "<?xml version='1.0' encoding='UTF-8'?>"
				+ "<ps1:thetag xmlns:ps1=\"http://tags\"><group>B</group><name>A</name></ps1:thetag>";
		Assert.assertEquals(expected, bos.toString());
	}

	@Test
	public void testOutElementsMapLocalToLocal() throws Exception {
		SOAJAXBProvider provider = new SOAJAXBProvider();
		Map<String, String> map = new HashMap<String, String>();
		map.put("tagVO", "thetag");
		map.put("group", "group2");
		provider.setOutTransformElements(map);
		TagVO tag = new TagVO("A", "B");
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		provider.writeTo(tag, TagVO.class, TagVO.class, new Annotation[0],
				MediaType.TEXT_XML_TYPE, new MetadataMap<String, Object>(), bos);
		String expected = "<?xml version='1.0' encoding='UTF-8'?>"
				+ "<thetag><group2>B</group2><name>A</name></thetag>";
		Assert.assertEquals(expected, bos.toString());
	}

	@Test
	public void testDropElements() throws Exception {
		SOAJAXBProvider provider = new SOAJAXBProvider();
		List<String> list = new ArrayList<String>();
		list.add("tagVO");
		list.add("ManyTags");
		list.add("list");
		provider.setOutDropElements(list);
		ManyTags many = new ManyTags();
		Tags tags = new Tags();
		tags.addTag(new TagVO("A", "B"));
		tags.addTag(new TagVO("C", "D"));
		many.setTags(tags);
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		provider.writeTo(many, ManyTags.class, ManyTags.class,
				new Annotation[0], MediaType.TEXT_XML_TYPE,
				new MetadataMap<String, Object>(), bos);
		String expected = "<?xml version='1.0' encoding='UTF-8'?>"
				+ "<tags><group>B</group><name>A</name><group>D</group><name>C</name></tags>";
		Assert.assertEquals(expected, bos.toString());
	}

	@Test
	public void testDropQualifiedElements() throws Exception {
		SOAJAXBProvider provider = new SOAJAXBProvider();
		List<String> list = new ArrayList<String>();
		list.add("{http://tags}thetag");
		provider.setOutDropElements(list);
		Map<String, String> map = new HashMap<String, String>();
		map.put("name", "");
		provider.setOutTransformElements(map);
		TagVO2 tag = new TagVO2("A", "B");
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		provider.writeTo(tag, TagVO2.class, TagVO2.class, new Annotation[0],
				MediaType.TEXT_XML_TYPE, new MetadataMap<String, Object>(), bos);
		String expected = "<?xml version='1.0' encoding='UTF-8'?>"
				+ "<group>B</group>";
		Assert.assertEquals(expected, bos.toString());

	}

	@Test
	public void testReadUnqualifiedCollection() throws Exception {
		String data = "<Books><Book><id>123</id><name>CXF in Action</name>"
				+ "</Book><Book><id>124</id><name>CXF Rocks</name></Book></Books>";
		doReadUnqualifiedCollection(data, "setBooks", List.class);
	}

	@Test
	@SuppressWarnings("unchecked")
	public void testReadMalformedXML() throws Exception {
		SOAJAXBProvider provider = new SOAJAXBProvider();
		try {
			provider.readFrom((Class) Book.class, Book.class,
					new Annotation[0], MediaType.TEXT_XML_TYPE,
					new MetadataMap<String, String>(),
					new ByteArrayInputStream("<Book>".getBytes()));
			Assert.fail("404 is expected");
		} catch (WebApplicationException ex) {
			Assert.assertEquals(400, ex.getResponse().getStatus());
		}
	}

	@SuppressWarnings("unchecked")
	private void doReadUnqualifiedCollection(String data, String mName,
			Class<?> type) throws Exception {
		SOAJAXBProvider provider = new SOAJAXBProvider();
		Method m = CollectionsResource.class.getMethod(mName,
				new Class[] { type });
		ByteArrayInputStream is = new ByteArrayInputStream(data.getBytes());
		Object o = provider.readFrom((Class) m.getParameterTypes()[0],
				m.getGenericParameterTypes()[0], new Annotation[0],
				MediaType.TEXT_XML_TYPE, new MetadataMap<String, String>(), is);
		Assert.assertNotNull(o);
		Book b1 = null;
		Book b2 = null;
		if (type.isArray()) {
			Assert.assertEquals(2, ((Book[]) o).length);
			b1 = ((Book[]) o)[0];
			b2 = ((Book[]) o)[1];
		} else if (type == Set.class) {
			Set<Book> set = (Set) o;
			List<Book> books = new ArrayList<Book>(new TreeSet<Book>(set));
			b1 = books.get(0);
			b2 = books.get(1);
		} else {
			List<Book> books = (List<Book>) o;
			b1 = books.get(0);
			b2 = books.get(1);
		}

		Assert.assertEquals(123, b1.getId());
		Assert.assertEquals("CXF in Action", b1.getName());

		Assert.assertEquals(124, b2.getId());
		Assert.assertEquals("CXF Rocks", b2.getName());
	}

	@SuppressWarnings("unchecked")
	public void doReadQualifiedCollection(String data, boolean isArray)
			throws Exception {
		SOAJAXBProvider provider = new SOAJAXBProvider();
		Method m = null;
		if (!isArray) {
			m = CollectionsResource.class.getMethod("setTags",
					new Class[] { List.class });
		} else {
			m = CollectionsResource.class.getMethod("setTagsArray",
					new Class[] { TagVO2[].class });
		}

		ByteArrayInputStream is = new ByteArrayInputStream(data.getBytes());
		Object o = provider.readFrom((Class) m.getParameterTypes()[0],
				m.getGenericParameterTypes()[0], new Annotation[0],
				MediaType.TEXT_XML_TYPE, new MetadataMap<String, String>(), is);
		Assert.assertNotNull(o);
		TagVO2 t1 = null;
		TagVO2 t2 = null;
		if (!isArray) {
			Assert.assertEquals(2, ((List) o).size());
			t1 = (TagVO2) ((List) o).get(0);
			t2 = (TagVO2) ((List) o).get(1);
		} else {
			Assert.assertEquals(2, ((Object[]) o).length);
			t1 = (TagVO2) ((Object[]) o)[0];
			t2 = (TagVO2) ((Object[]) o)[1];
		}
		Assert.assertEquals("A", t1.getName());
		Assert.assertEquals("B", t1.getGroup());

		Assert.assertEquals("C", t2.getName());
		Assert.assertEquals("D", t2.getGroup());
	}

	@Test
	public void testSetSchemasFromClasspath() {
		SOAJAXBProvider provider = new SOAJAXBProvider();
		List<String> locations = new ArrayList<String>();
		locations.add("classpath:/test.xsd");
		provider.setSchemas(locations);
		Schema s = provider.getSchema();
		Assert.assertNotNull(s, "schema can not be read from classpath");
	}

	@Test
	public void testSetSchemasFromDisk() throws Exception {
		SOAJAXBProvider provider = new SOAJAXBProvider();
		List<String> locations = new ArrayList<String>();
		String loc = getClass().getClassLoader().getResource("test.xsd")
				.toURI().getPath();

		locations.add(loc);
		provider.setSchemas(locations);
		Schema s = provider.getSchema();
		Assert.assertNotNull(s, "schema can not be read from disk");
	}

	@Test
	public void testWriteWithFailedValidation() throws Exception {
		SOAJAXBProvider provider = new SOAJAXBProvider();
		List<String> locations = new ArrayList<String>();
		String loc = getClass().getClassLoader().getResource("test.xsd")
				.toURI().getPath();
		locations.add(loc);
		provider.setSchemas(locations);
		Schema s = provider.getSchema();
		Assert.assertNotNull(s, "schema can not be read from disk");

		provider.setValidateOutput(true);
		provider.setValidateBeforeWrite(true);

		try {
			provider.writeTo(new Book(), Book.class, Book.class,
					new Annotation[] {}, MediaType.TEXT_XML_TYPE,
					new MetadataMap<String, Object>(),
					new ByteArrayOutputStream());
			Assert.fail("Validation exception expected");
		} catch (Exception ex) {
			Throwable cause = ex.getCause();
			Assert.assertTrue(cause.getMessage().contains(
					"Cannot find the declaration of element"));
		}

	}

	@Test
	public void testIsReadableWithJaxbIndex() {
		SOAJAXBProvider p = new SOAJAXBProvider();
		Assert.assertTrue(p.isReadable(Book.class, Book.class,
				new Annotation[] {}, MediaType.APPLICATION_XML_TYPE));
	}

	@Test
	public void testResponseIsNotReadable() {
		SOAJAXBProvider p = new SOAJAXBProvider();
		Assert.assertFalse(p.isReadable(Response.class, Response.class,
				new Annotation[] {}, MediaType.APPLICATION_XML_TYPE));
	}

	@Test
	public void testResponseIsNotReadable2() {
		SOAJAXBProvider p = new SOAJAXBProvider();
		p.setUnmarshallAsJaxbElement(true);
		Assert.assertFalse(p.isReadable(Response.class, Response.class,
				new Annotation[] {}, MediaType.APPLICATION_XML_TYPE));
	}

	@Test
	public void testXMLSourceIsNotReadable() {
		SOAJAXBProvider p = new SOAJAXBProvider();
		Assert.assertFalse(p.isReadable(XMLSource.class, XMLSource.class,
				new Annotation[] {}, MediaType.APPLICATION_XML_TYPE));
	}

	@Test
	public void testSetMarshallProperties() throws Exception {
		Map<String, Object> props = new HashMap<String, Object>();
		props.put(Marshaller.JAXB_FORMATTED_OUTPUT, true);
		props.put(Marshaller.JAXB_SCHEMA_LOCATION, "foo.xsd");
		final TestMarshaller m = new TestMarshaller();
		SOAJAXBProvider provider = new SOAJAXBProvider() {
			@Override
			protected Marshaller createMarshaller(Object obj, Class cls,
					Type genericType, String enc) throws JAXBException {
				return m;
			}
		};

		provider.setMarshallerProperties(props);
		provider.writeTo("123", String.class, (Type) String.class,
				new Annotation[] {}, MediaType.APPLICATION_XML_TYPE,
				new MetadataMap<String, Object>(), new ByteArrayOutputStream());

		Assert.assertEquals(props, m.getProperties(),
				"Marshall properties have not been set");
	}

	private static class TestMarshaller implements Marshaller {

		private Map<String, Object> props = new HashMap<String, Object>();

		public TestMarshaller() {

		}

		public Map getProperties() {
			return props;
		}

		public <A extends XmlAdapter> A getAdapter(Class<A> type) {
			// TODO Auto-generated method stub
			return null;
		}

		public AttachmentMarshaller getAttachmentMarshaller() {
			// TODO Auto-generated method stub
			return null;
		}

		public ValidationEventHandler getEventHandler() throws JAXBException {
			return null;
		}

		public Listener getListener() {
			return null;
		}

		public Node getNode(Object contentTree) throws JAXBException {
			return null;
		}

		public Object getProperty(String name) throws PropertyException {
			return null;
		}

		public Schema getSchema() {
			return null;
		}

		public void marshal(Object jaxbElement, Result result)
				throws JAXBException {
		}

		public void marshal(Object jaxbElement, OutputStream os)
				throws JAXBException {
		}

		public void marshal(Object jaxbElement, File output)
				throws JAXBException {
		}

		public void marshal(Object jaxbElement, Writer writer)
				throws JAXBException {
		}

		public void marshal(Object jaxbElement, ContentHandler handler)
				throws JAXBException {
		}

		public void marshal(Object jaxbElement, Node node) throws JAXBException {
		}

		public void marshal(Object jaxbElement, XMLStreamWriter writer)
				throws JAXBException {
		}

		public void marshal(Object jaxbElement, XMLEventWriter writer)
				throws JAXBException {
		}

		public void setAdapter(XmlAdapter adapter) {
		}

		public <A extends XmlAdapter> void setAdapter(Class<A> type, A adapter) {
		}

		public void setAttachmentMarshaller(AttachmentMarshaller am) {
		}

		public void setEventHandler(ValidationEventHandler handler)
				throws JAXBException {
		}

		public void setListener(Listener listener) {
		}

		public void setProperty(String name, Object value)
				throws PropertyException {
			props.put(name, value);
		}

		public void setSchema(Schema schema) {
		}

	}

	@XmlRootElement(name = "tagholder", namespace = "http://tags")
	public static class TagVO2Holder {
		@XmlElement(name = "thetag", namespace = "http://tags")
		private TagVO2 t;
		@XmlAttribute
		private String attr = "attribute";

		public void setTag(TagVO2 tag) {
			this.t = tag;
		}

		public TagVO2 getTagValue() {
			return t;
		}

		public String getAttribute() {
			return attr;
		}
	}

	@Path("/")
	public static class JAXBResource {
		@GET
		public Book getBook() {
			return null;
		}

		@GET
		public SuperBook getSuperBook() {
			return null;
		}
	}

	@XmlRootElement(name = "list")
	public static class XmlList<A> {
		private List<A> list;

		public XmlList() {
		}

		public XmlList(List<A> l) {
			list = l;
		}

		public List<A> getList() {
			return list;
		}

		public void setList(List<A> l) {
			list = l;
		}
	}

	@XmlType
	public static class XmlObject {
		private MyObject attribute;

		public XmlObject() {
			// no-op
		}

		public XmlObject(MyObject a) {
			attribute = a;
		}

		@XmlElement(name = "attribute")
		public MyObject getAttribute() {
			return attribute;
		}

		public void setAttribute(MyObject a) {
			attribute = a;
		}
	}

	public static class MyObject {
		private String name;

		public String getName() {
			return name;
		}

		public void setName(String n) {
			name = n;
		}
	}

	@Path("/test")
	public class XmlListResource {
		@GET
		@Path("/jaxb")
		public XmlList<XmlObject> testJaxb() {
			return null;
		}
	}

	public static class BookNoRootElement {
		private String name;
		private long id;

		public BookNoRootElement() {
		}

		public BookNoRootElement(String name, long id) {
			this.name = name;
			this.id = id;
		}

		public void setName(String n) {
			name = n;
		}

		public String getName() {
			return name;
		}

		public void setId(long i) {
			id = i;
		}

		public long getId() {
			return id;
		}
	}

	@XmlRootElement
	public static class TagVO {
		private String name;
		private String group;

		public TagVO() {

		}

		public TagVO(String name, String group) {
			this.name = name;
			this.group = group;
		}

		public void setName(String n) {
			this.name = n;
		}

		public void setGroup(String g) {
			this.group = g;
		}

		public String getName() {
			return name;
		}

		public String getGroup() {
			return group;
		}

	}

	@XmlRootElement(name = "thetag", namespace = "http://tags")
	public static class TagVO2 extends TagVO {

		public TagVO2() {

		}

		public TagVO2(String name, String group) {
			super(name, group);
		}
	}

	@XmlRootElement(name = "Tags")
	public static class Tags {
		private List<TagVO> list = new ArrayList<TagVO>();

		public Tags() {
		}

		public Tags(List<TagVO> tags) {
			list.addAll(tags);
		}

		public void addTag(TagVO tag) {
			list.add(tag);
		}

		@XmlElement(name = "list")
		public List<TagVO> getTags() {
			return list;
		}
	}

	@XmlRootElement(name = "ManyTags")
	public static class ManyTags {
		private Tags tags;

		public ManyTags() {
		}

		public void setTags(Tags t) {
			tags = t;
		}

		public Tags getTags() {
			return tags;
		}
	}

	@XmlRootElement(name = "SuperBook")
	public static class SuperBook extends Book {
		private long superId;

		public SuperBook() {
		}

		public SuperBook(String name, long id, long superId) {
			super(name, id);
			this.superId = superId;
		}

		public void setSuperId(long i) {
			superId = i;
		}

		public long getSuperId() {
			return superId;
		}
	}

	@XmlRootElement(name = "Book")
	@XmlSeeAlso({ SuperBook.class })
	public static class Book implements Comparable<Book> {
		private String name;
		private long id = 0;
		private Map<Long, Chapter> chapters = new HashMap<Long, Chapter>();

		public Book() {
		}

		public Book(String name, long id) {
			this.name = name;
			this.id = id;
		}

		public void setName(String n) {
			name = n;
		}

		public String getName() {
			return name;
		}

		public void setId(long i) {
			id = i;
		}

		public long getId() {
			return id;
		}

		@Path("chapters/{chapterid}/")
		@GET
		public Chapter getChapter(@PathParam("chapterid") int chapterid) {
			return chapters.get(new Long(chapterid));
		}

		public int hashCode() {
			return (name != null) ? name.hashCode() * 37 : "test".hashCode()
					+ new Long(id).hashCode();
		}

		public boolean equals(Object o) {
			if (!(o instanceof Book)) {
				return false;
			}
			Book other = (Book) o;

			return other.name.equals(name) && other.id == id;

		}

		public int compareTo(Book b) {
			Long i1 = new Long(getId());
			Long i2 = new Long(b.getId());
			return i1.compareTo(i2);
		}
	}

	@XmlRootElement(name = "Chapter")
	public static class Chapter {
		private String title;
		private long id;

		public Chapter() {
		}

		public void setTitle(String n) {
			title = n;
		}

		public String getTitle() {
			return title;
		}

		public void setId(long i) {
			id = i;
		}

		public long getId() {
			return id;
		}
	}

	public class CollectionsResource {
		@GET
		public List<Book> getBooks() {
			return null;
		}

		@GET
		public Collection<Book> getBookCollection() {
			return null;
		}

		@GET
		public List<JAXBElement<Book>> getBookElements() {
			return null;
		}

		@GET
		public List<JAXBElement> getBookElements2() {
			return null;
		}

		@GET
		public Set<Book> getBookSet() {
			return null;
		}

		@GET
		public List<TagVO2> getTags() {
			return null;
		}

		@GET
		public Book[] getBooksArray() {
			return null;
		}

		@POST
		public void setBooks(List<Book> books) {
		}

		@POST
		public void setBooksArray(Book[] books) {
		}

		@POST
		public void setTags(List<TagVO2> tags) {
		}

		@POST
		public void setTagsArray(TagVO2[] tags) {
		}

		@POST
		public void setBookCollection(Collection<Book> books) {
		}

		@POST
		public void setBookSet(Set<Book> books) {
		}
	}

	@Path("/bookstore/")
	public class BookStore extends BookSuperClass implements BookInterface {

		public BookStore() {
		}

		public Book getBook(String id) {
			return null;
		}

		@Override
		public Book getNewBook(String id, Boolean isNew) {
			return null;
		}

		@POST
		@Path("/books")
		public Response addBook(Book book) {
			return null;
		}

		@PUT
		@Path("/books/")
		public Response updateBook(Book book) {
			return null;
		}

		@DELETE
		@Path("/books/{bookId}/")
		public Response deleteBook(@PathParam("bookId") String id) {
			return null;
		}

		@Override
		public String getDescription() {
			// TODO Auto-generated method stub
			return null;
		}

		public String getAuthor() {
			// TODO Auto-generated method stub
			return null;
		}
	}

	public abstract class BookSuperClass {

		@GET
		@Path("/path")
		@Produces("text/bar")
		@Consumes("text/foo")
		public abstract String getDescription();

		@Path("/books/{bookId}/{new}")
		public abstract Book getNewBook(@PathParam("bookId") String id,
				@PathParam("new") Boolean isNew);
	}

	public interface BookInterface {

		@GET
		@Path("/path2")
		@Produces("text/bar2")
		@Consumes("text/foo2")
		String getAuthor();

		@Path("/books/{bookId}")
		Book getBook(@PathParam("bookId") String id);
	}

}
