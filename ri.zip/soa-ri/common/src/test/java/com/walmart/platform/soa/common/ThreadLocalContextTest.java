package com.walmart.platform.soa.common;

import java.util.HashMap;
import java.util.Map;

import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class ThreadLocalContextTest {

	private ThreadLocalContext ctx = ThreadLocalContext.instance();

	@BeforeMethod
	public void clean(){
		ctx.removeAllTransAttributes();
	}
	
	@Test
	public void getTransAttribute() {
		ctx.setTransAttribute("k1", "v1");
		Assert.assertEquals("v1", ctx.getTransAttribute("k1"));
	}

	@Test
	public void getTransAttributes() {
		Map<String, Object> data = new HashMap<String, Object>();
		data.put("k1", "v1");
		data.put("k2", "v2");
		ctx.setTransAttributes(data);
		Assert.assertEquals(data, ctx.getTransAttributes());

	}

	@Test
	public void removeAllTransAttributes() {
		Map<String, Object> data = new HashMap<String, Object>();
		data.put("k1", "v1");
		data.put("k2", "v2");
		ctx.setTransAttributes(data);
		ctx.removeAllTransAttributes();
		Assert.assertNotEquals(data, ctx.getTransAttributes());
	}
}
