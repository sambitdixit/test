package com.walmart.platform.soa.common.providers.util;

import java.lang.reflect.Type;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.walmart.platform.soa.common.service.wrappers.ServiceResponse;
import com.walmart.platform.soa.examples.service.Book;

public class ProviderUtilTest {

	@Test
	public void getActualParameterType() {
		ServiceResponse<Book> sr = new ServiceResponse<Book>();
		Type actulaType = ProviderUtil.getActualParameterType(sr.getClass());
		Assert.assertNull(actulaType);
	}

	@Test
	public void getParameterTypes() {
		ServiceResponse<Book> sr = new ServiceResponse<Book>();
		String actulaTypes = ProviderUtil.getParameterTypes(sr.getClass());
		Assert.assertNotNull(actulaTypes);
	}

	
	@Test
	public void getPayloadClass() {
		Assert.assertNotNull(ProviderUtil
				.getPayloadClass("com.walmart.platform.soa.common.providers.SOAJSONJAXBProvider"));
	}
}
