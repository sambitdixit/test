package com.walmart.platform.soa.cache.impl.chm;

import static org.testng.Assert.assertNotNull;
import static org.testng.Assert.assertNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.walmart.platform.soa.cache.Cache;
import com.walmart.platform.soa.cache.CacheManager;

/**
 * Test Class for CHM Manager
 */
@ContextConfiguration(locations={"classpath:/META-INF/cache-context.xml"})
public class CHMManagerTest extends AbstractTestNGSpringContextTests {
	
	@Autowired
	private CacheManager cacheManager;

    @BeforeClass
    public void init() {
        cacheManager.init();
        assertNotNull(cacheManager.getCache("esb-service-cache"));
        assertNotNull(cacheManager.getCache("esb-policy-cache"));
        
    }

    @Test
    public void testAddCache() {
        cacheManager.addCache("dummy");
        assertNotNull(cacheManager.getCache("dummy"));
        cacheManager.addCache("dummy");
    }

    @Test
    public void testGetCacheNotExist() {
        assertNull(cacheManager.getCache("emptyCache"));
    }

    @Test
    public void testRemoveCache() {
        cacheManager.addCache("dummy");
        assertNotNull(cacheManager.getCache("dummy"));
        cacheManager.removeCache("dummy");
        assertNull(cacheManager.getCache("dummy"));
        cacheManager.stop();
    }

    @Test
    public void testRemoveAll() {
        cacheManager.addCache("cache1");
        cacheManager.addCache("cache2");
        cacheManager.removeAll();
        assertNull(cacheManager.getCache("cache1"));
        cacheManager.stop();
    }

    @Test
    public void testClearAll() {
        cacheManager.addCache("cache1");
        Cache<Integer, Integer> cache = cacheManager.getCache("cache1");
        cache.put(1, 1);
        cache.put(2, 2);
        long t1 = System.nanoTime();
        cache.get(1);
        System.out.println("Time taken=>"+(System.nanoTime()-t1));
        cacheManager.addCache("cache2");
        cacheManager.clearAll();
        assertNull(cache.get(1));
        cacheManager.stop();
    }

    @Test
    public void testStop() {
        cacheManager.addCache("cache1");
        Cache<Integer, Integer> cache = cacheManager.getCache("cache1");
        cache.put(1, 1);
        cache.put(2, 2);
        cacheManager.addCache("cache2");
        cacheManager.stop();
        assertNull(cacheManager.getCache("cache1"));
        cacheManager.stop();
    }

}
