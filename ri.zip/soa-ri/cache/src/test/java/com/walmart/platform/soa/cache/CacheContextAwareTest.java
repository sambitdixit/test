package com.walmart.platform.soa.cache;

import static org.junit.Assert.assertTrue;

import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;
import org.testng.annotations.Test;

/**
 * CacheContextAwareTest
 */
@ContextConfiguration(locations={"classpath:/META-INF/cache-context.xml"})
public class CacheContextAwareTest extends AbstractTestNGSpringContextTests {

    @Test
    public void testInitApplicationContext() {
        assertTrue(true);
    }

}
