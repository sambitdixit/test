package com.walmart.platform.soa.cache.impl.chm;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * CHMCacheStats test class
 */
public class CHMCacheStatsTest {

    CHMCache cache;
    CHMCacheStats cacheStats;

    @BeforeClass
    public void setUp() {
        cache = new CHMCache("StatsCache");
        cache.put("1", "1");
        cache.put("2", "2");
        cache.get("1");
        cache.get("2");
        cache.get("3");
        cacheStats = new CHMCacheStats(cache);
    }

    @Test
    public void testStats() {
        assertEquals(2, cacheStats.getCurrentCacheSize());
        assertEquals(CHMCache.DEFAULT_EVICTOR_INTERVAL, cacheStats.getEvictionInterval());
        assertEquals("StatsCache", cacheStats.getCacheName());
        assertEquals("1", cacheStats.getValueForKey("1"));
        assertEquals(2, cacheStats.getCurrentCacheSize());
        assertEquals(3, cacheStats.getHitCount());
        assertEquals(1, cacheStats.getMissCount());
        assertEquals(CHMCache.DEFAULT_CAPACITY, cacheStats.getMaxCacheSize());
        assertNull(cacheStats.getValueForKey("4"));
        assertNotNull(cacheStats.retrieveAllKeys());
        cache.invalidateAll();
        assertNotNull(cacheStats.retrieveAllKeys());
    }

    @Test
    public void test() {
        CHMCache cache = new CHMCache("t");
        System.out.println("--> "+cache.getKeys());
    }

}
