package com.walmart.platform.soa.cache.impl.chm;

import static org.testng.Assert.assertNotNull;

import com.walmart.platform.soa.cache.Cache;

/**
 *
 */
public class CHMCacheBenchMark {

    Cache<String, String> cache;
    CHMCacheManager chmCacheManager;

    public void init() {
    	chmCacheManager = new CHMCacheManager();
    	chmCacheManager.init();
        cache = chmCacheManager.getCache("benchmark");

        // populate 10K entries
        for (int i = 0; i < 10000; i++) {
            cache.put("Key-"+i,"Value-"+1);
        }
    }

    public void destroy() {
    	chmCacheManager.stop();
    }

    public void testGetFixedKeys(int num) {
        String key1 = "Key-10";
        String key2 = "Key-1100";
        String key3 = "Key-999";
        String key4 = "Key-0";
        String key5 = "Key-5000";
        System.out.println("Running test cases");
        long t1 = System.currentTimeMillis();
        for (int i = 0; i < num; i++) {
            assertNotNull(cache.get(key1));
            assertNotNull(cache.get(key2));
            assertNotNull(cache.get(key3));
            assertNotNull(cache.get(key4));
            assertNotNull(cache.get(key5));
        }
        long t2 = System.currentTimeMillis();
        System.out.println(String.format("Total time for %d gets = %d ms", num * 5 ,(t2 - t1)));
    }

    public static void main(String[] args) {
        CHMCacheBenchMark benchMark = new CHMCacheBenchMark();
        benchMark.init();
        benchMark.testGetFixedKeys(2000000);
        benchMark.testGetFixedKeys(5000000);
        benchMark.testGetFixedKeys(20000000);
//        benchMark.destroy();
    }
    

}
