package com.walmart.platform.soa.cache.impl.chm;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.testng.annotations.Test;

/**
 * CHM Cache Test
 */
public class ChmCacheTest {

    @Test
    public void testCacheEvictionOnCapacity() {
        CHMCache<String, Integer> cache = new CHMCache<String, Integer>("testCacheEvictionOnCapacity", 100, 100);

        for (int i = 0; i < 200; i++) {
            cache.put("K-"+i, i);
        }
        try {
        	//Sleep for 500 ms.
            Thread.sleep(500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        List<String> keys = cache.getKeys();
        assertEquals(100, keys.size());
    }

    
 
    @Test
    public void testGetName() {
        String name = "TestName";
        CHMCache<String, Integer> cache = new CHMCache<String, Integer>(name, 100, 10000);
        assertEquals(name, cache.getName());
    }

    @Test
    public void testRemove() {
        CHMCache<String, Integer> cache = new CHMCache<String, Integer>("testRemove", 100, 10000);
        cache.put("K-1", 1);
        cache.remove("K-1");
        assertNull(cache.get("K-1"));
    }

    @Test
    public void testGet() {
        int value = 1;
        CHMCache<String, Integer> cache = new CHMCache<String, Integer>("testGet", 100, 10000);
        cache.put("Key-1", value);
        assertEquals(value, (int)cache.get("Key-1"));
        assertEquals(1, cache.getHitCount());
        assertEquals(0, cache.getMissCount());
        cache.get("dummy");
        assertEquals(1, cache.getMissCount());
        assertEquals(100, cache.getCapacity());
        assertEquals(1, cache.getCurrentSize());
        assertEquals(10000, cache.getEvictionInterval());
        assertNotNull(cache.toString());

        CHMCache<String, Integer> cacheNoName = new CHMCache<String, Integer>();
        assertNull(cacheNoName.getName());
    }

    @Test
    public void testNullKeySet() {
        CHMCache<String, Integer> cache = new CHMCache<String, Integer>("testNullKeySet", 100, 10000);
        assertTrue(cache.getKeys().isEmpty());
    }
}
