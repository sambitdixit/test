package com.walmart.platform.soa.cache;


/**
 * @author sdikshi
 * @author ranand
 *
 */
public interface CacheManager {

    /**
     *
     */
	void init();

    /**
     *
     */
	void stop();

    /**
     *
     * @param cacheName
     */
	void addCache(String cacheName);
	
	/**
	 * @param cacheName
	 * @param capacity
	 * @param evictionIntervalMillis
	 */
	void addCache(String cacheName, int capacity, int evictionIntervalMillis);
	

    /**
     *
     * @param cacheName
     * @param <K>
     * @param <V>
     * @return
     */
	<K,V> Cache<K,V> getCache(String cacheName);

    /**
     *
     * @param cacheName
     */
	void removeCache(String cacheName);

    /**
     *
     */
	void removeAll();

    /**
     *
     */
	void clearAll();
}
