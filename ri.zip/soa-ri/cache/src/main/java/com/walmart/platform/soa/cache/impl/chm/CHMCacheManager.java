package com.walmart.platform.soa.cache.impl.chm;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.walmart.platform.soa.cache.Cache;
import com.walmart.platform.soa.cache.CacheManager;
import com.walmart.platform.soa.config.CacheConfig;

/**
 * Cache Manager for CHM cache
 * @author sdikshi
 */
public class CHMCacheManager implements CacheManager {

	private static final Logger LOGGER = LoggerFactory.getLogger(CHMCacheManager.class);
	private Map<String, CHMCache> caches = new ConcurrentHashMap<String, CHMCache>();
	private CacheConfig cacheConfig;

	@Override
	public void init() {
		try {
			if(LOGGER.isDebugEnabled()) LOGGER.debug("Initializing Cache Manager");
			if(cacheConfig!=null) {
			String cacheName = cacheConfig.getCacheNames();
			if(LOGGER.isDebugEnabled()) LOGGER.debug("Following caches shall be configured - " + cacheName);
			if (cacheName != null) {
				String[] cacheNames = cacheName.split(",");
				for (String cache : cacheNames) {
					if(LOGGER.isDebugEnabled()) LOGGER.debug("configuring cache - " + cache);
					// Get eviction time property
					String cacheEvictionProp = (cacheConfig.getCacheEvictionInterval(cache)!=null)?cacheConfig.getCacheEvictionInterval(cache):"10000" ;
					// get max entries properties
					String cacheMaxEntriesProp = (cacheConfig.getCacheMaxEntries(cache)!=null)?cacheConfig.getCacheMaxEntries(cache):"10000" ;
					addCache(cache,Integer.parseInt(cacheMaxEntriesProp),Integer.parseInt(cacheEvictionProp));
				}
			  }
			}
		} catch (Exception e) {
			LOGGER.error("Exception occurred while initializing cache manager",e);
			throw new RuntimeException("CHM initialization failed.." + e);
		}
	}

	@Override
	public void stop() {
		for (String cacheName : caches.keySet()) {
			if (cacheName != null) {
				caches.get(cacheName).dispose();
				caches.remove(cacheName);
			}
		}
	}

	@Override
	public void addCache(String cacheName) {
		if (!caches.containsKey(cacheName)) {
			caches.put(cacheName, new CHMCache(cacheName));
		}
	}

	@Override
	public void addCache(String cacheName, int capacity,
			int evictionIntervalMillis) {
		if (!caches.containsKey(cacheName)) {
			caches.put(cacheName, new CHMCache(cacheName, capacity,
					evictionIntervalMillis));
		}
	}

	@Override
	public <K, V> Cache<K, V> getCache(String cacheName) {
		return caches.get(cacheName);
	}

	@Override
	public void removeCache(String cacheName) {
		CHMCache removedCache = caches.remove(cacheName);
		removedCache.dispose();
	}

	@Override
	public void removeAll() {
		for (String cacheName : caches.keySet()) {
			if (cacheName != null) {
				caches.get(cacheName).dispose();
				caches.remove(cacheName);
			}
		}
	}

	@Override
	public void clearAll() {
		for (CHMCache cache : caches.values()) {
			if (cache != null) {
				cache.invalidateAll();
			}
		}
	}

	public void setCacheConfig(CacheConfig cacheConfig) {
		this.cacheConfig = cacheConfig;
	}
}
