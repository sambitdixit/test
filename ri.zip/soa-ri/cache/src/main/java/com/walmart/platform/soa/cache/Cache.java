package com.walmart.platform.soa.cache;

import java.util.List;

/**
 * @author sdikshi
 * @author ranand
 * 
 * @param <K>
 * @param <V>
 */

public interface Cache<K, V> {

    /**
     * Returns the name of the Cache
     *
     * @return  Name of the Cache
     */
	String getName();

    /**
     * Get the key from cache
     *
     * @param key   Cache Key
     * @return      Cache value
     */
	V get(K key);

    /**
     *
     * @param key
     * @param value
     */
	void put(K key, V value);
	
    /**
     *
     * @param key
     * @return
     */
	boolean remove(K key);

    /**
     *
     */
	void invalidateAll();

    /**
     *
     * @return
     */
	List<K> getKeys();

    /**
     * Dispose of the Cache. Used to handle shutdown function related to a Cache
     */
    void dispose();
}
