package com.walmart.platform.soa.cache;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ApplicationObjectSupport;

/**
 * @author sdikshi
 * @author ranand
 * 
 * This class is intended to register the spring application context's 
 * shutdown hooks. This would result in graceful shutdown of the 
 * spring container.
 */
public class CacheContextAware extends ApplicationObjectSupport {

	@Override
	public void initApplicationContext(ApplicationContext applicationContext)
			throws BeansException {
		super.initApplicationContext(applicationContext);
		if (AbstractApplicationContext.class.isAssignableFrom(applicationContext.getClass())) {
			((AbstractApplicationContext) applicationContext).registerShutdownHook();
		}
	}
	

}
