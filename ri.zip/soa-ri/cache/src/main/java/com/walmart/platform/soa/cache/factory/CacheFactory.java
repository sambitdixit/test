package com.walmart.platform.soa.cache.factory;

import com.walmart.platform.soa.cache.Cache;
import com.walmart.platform.soa.cache.CacheManager;

/**
 * @author sdikshi
 * @author ranand
 * 
 */
public class CacheFactory implements ICacheFactory {

	
	private CacheManager cacheManager ;
	
	public static final String ESB_SERVICE_CACHE = "esb-service-cache";
	public static final String ESB_POLICY_CACHE = "esb-policy-cache";
	public static final String ESB_PK_CACHE = "esb-pk-cache";
	
	// Name of the cache for storing the API Level information
	public static final String ESB_APILEVEL_CACHE = "esb-apilevel-cache";
	
	public static final String REPORTS_COMMON_CACHE = "reports-common-cache";
	public static final String REPORTS_SERVICEVERSION_CACHE = "reports-sv-cache";
	public static final String REPORTS_POLICY_CACHE = "reports-policy-cache";
	
    /**
     *
     * @param name
     * @param <K>
     * @param <V>
     * @return
     */
    public <K, V> Cache<K, V> getCache(String name) {
		return cacheManager.getCache(name);
	}

    /**
     *
     * @param cacheManager
     */
	public void setCacheManager(CacheManager cacheManager) {
		this.cacheManager = cacheManager;
	}

}
