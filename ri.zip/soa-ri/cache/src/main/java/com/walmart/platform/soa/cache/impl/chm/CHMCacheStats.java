package com.walmart.platform.soa.cache.impl.chm;

import java.util.List;

/**
 * Implementation of CHM Cache stats
 * 
 * @author sdikshi
 * 
 */
public class CHMCacheStats implements CHMCacheStatsMBean {

    private final CHMCache chmCache;

    /**
     *
     * @param cache Backing cache
     */
    public CHMCacheStats(CHMCache cache) {
        this.chmCache = cache;
    }

    /**
     * @see com.walmart.platform.soa.cache.impl.chm.CHMCacheStatsMBean#getCurrentCacheSize()
     */
    public long getCurrentCacheSize() {
        return chmCache.getCurrentSize();
    }

    /**
     * @see com.walmart.platform.soa.cache.impl.chm.CHMCacheStatsMBean#getMaxCacheSize()
     */
    public long getMaxCacheSize() {
        return chmCache.getCapacity();
    }

    /**
     * @see CHMCacheStatsMBean#getCacheName()
     */
    public String getCacheName() {
        return chmCache.getName();
    }

    /**
     * @see CHMCacheStatsMBean#getEvictionInterval()
     */
    public int getEvictionInterval() {
        return chmCache.getEvictionInterval();
    }

    /**
     * @see CHMCacheStatsMBean#getHitCount()
     */
    public long getHitCount() {
        return chmCache.getHitCount();
    }

    /**
     * @see CHMCacheStatsMBean#getMissCount()
     */
    public long getMissCount() {
        return chmCache.getMissCount();
    }

    @Override
    public String getValueForKey(String key) {

        Object value = chmCache.get(key);
        if(value != null) {
            return value.toString();
        }

        return null;
    }

    @Override
    public String retrieveAllKeys() {
        List keys = chmCache.getKeys();
        return keys.toString();
    }


}
