package com.walmart.platform.soa.cache.impl.chm;

import java.lang.management.ManagementFactory;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

import javax.management.MBeanServer;
import javax.management.ObjectName;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.walmart.platform.soa.cache.Cache;

/**
 * Concurrent HashMap based Cache implementation
 * @author sdikshi
 */
public class CHMCache<K, V> implements Cache<K, V> {

	private static final Logger logger = LoggerFactory
			.getLogger(CHMCache.class);

	// Hit count
	private AtomicLong hitCount = new AtomicLong(0);

	// Miss count
	private AtomicLong missCount = new AtomicLong(0);

	/**
	 * Default capacity of the Map
	 */
	public static final int DEFAULT_CAPACITY = 1000;

	/**
	 * Default evictor interval, defaults to 10 sec
	 */
	public static final int DEFAULT_EVICTOR_INTERVAL = 10000;

	
	/**
	 * Capacity of the Cache, post which eviction needs to happen
	 */
	private int capacity = DEFAULT_CAPACITY;

	/**
	 * Eviction interval in ms
	 */
	private int evictionInterval = DEFAULT_EVICTOR_INTERVAL;

	
	private ConcurrentHashMap<K, Value<V>> cache = new ConcurrentHashMap<K, Value<V>>();

	// Evictor Thread
	private ScheduledExecutorService evictor = Executors
			.newScheduledThreadPool(1);

	// Name of Cache
	private String cacheName;
	
	/**
	 * 
	 * @return
	 */
	public int getCapacity() {
		return capacity;
	}

	/**
	 * 
	 * @return
	 */
	public int getEvictionInterval() {
		return evictionInterval;
	}

	/**
	 * 
	 * @return
	 */
	public long getHitCount() {
		return hitCount.longValue();
	}

	/**
	 * 
	 * @return
	 */
	public long getMissCount() {
		return missCount.longValue();
	}

	

	/**
	 * Default constructor
	 */
	public CHMCache() {
		initCache();
	}

	/**
	 * 
	 * @param cacheName
	 */
	public CHMCache(String cacheName) {
		this(cacheName, DEFAULT_CAPACITY, DEFAULT_EVICTOR_INTERVAL);
	}
	
	
	/**
	 * Constructor to override default properties
	 * 
	 * @param cacheName
	 *            name of cache
	 * @param capacity
	 *            size of the cache
	 * @param evictionIntervalMillis
	 *            Eviction interval in milliseconds
	 * 
	 */
	public CHMCache(String cacheName, int capacity, int evictionIntervalMillis) {
		this.cacheName = cacheName;
		this.evictionInterval = evictionIntervalMillis;
		this.capacity = capacity;
		initCache();
	}

	/**
	 * Initializes the cache, startes the evictor thread and resgiters the MBean
	 */
	private void initCache() {

		evictor.scheduleAtFixedRate(new Runnable() {
			@Override
			public void run() {
				evict();
			}
		}, 0, evictionInterval, TimeUnit.MILLISECONDS);

		// Add JMX support
		try {
			CHMCacheStats chmCacheStats = new CHMCacheStats(this);
			MBeanServer mBeanServer = ManagementFactory
					.getPlatformMBeanServer();
			ObjectName name = new ObjectName(
					"com.walmart.platform.soa.cache:type=" + cacheName);
			mBeanServer.registerMBean(chmCacheStats, name);
		} catch (Exception ex) {
			logger.error("Error while registering for JMX", ex);
		}
	}

	@Override
	public String getName() {
		return this.cacheName;
	}

	/**
	 * Returns the cache size
	 * 
	 * @return size of the cache
	 */
	public long getCurrentSize() {
		return cache.size();
	}

	@Override
	public V get(K key) {
		Value<V> value = cache.get(key);

		if (value == null) {
			missCount.incrementAndGet();
			return null;
		}
		hitCount.incrementAndGet();
		return value.value;
	}

	@Override
	public void put(K key, V value) {
		cache.put(key, new Value<V>(value));
	}

	@Override
	public boolean remove(K key) {
		return cache.remove(key) != null;
	}

	@Override
	public void invalidateAll() {
		cache.clear();
	}

	@Override
	public List<K> getKeys() {
		Enumeration<K> keys = cache.keys();
		List<K> keyList = null;
		if (keys != null) {
			keyList = Collections.list(keys);
		}
		return keyList;
	}

	@Override
	public void dispose() {
		cache.clear();
		if (evictor != null) {
			evictor.shutdown();
		}
		try {
			ManagementFactory.getPlatformMBeanServer().unregisterMBean(
					new ObjectName("com.walmart.platform.soa.cache:type="
							+ cacheName));
		} catch (Exception e) {
			logger.error("Error un-registering mbean", e);
		}
	}

	/**
	 * Private class to store time created for an entry
	 */
	private class Value<V> {

		// Value
		private V value;

		// time created
		private long timeCreated;

		/**
		 * 
		 * @param value
		 */
		public Value(V value) {
			this.value = value;
			this.timeCreated = System.currentTimeMillis();
		}

		/**
		 * 
		 * @return
		 */
		public long getTimeCreated() {
			return timeCreated;
		}

		@Override
		public String toString() {
			return String.format("Time Created: %d", timeCreated);
		}

	}

	/**
	 * Comparator to sort Map entries based on creation time
	 */
	private class MapEntryValueComparator implements
			Comparator<Map.Entry<K, Value<V>>> {
		@Override
		public int compare(Map.Entry<K, Value<V>> kValueEntry,
				Map.Entry<K, Value<V>> kValueEntry1) {
			if (kValueEntry.getValue().getTimeCreated() < kValueEntry1
					.getValue().getTimeCreated()) {
				return -1;
			} else if (kValueEntry.getValue().getTimeCreated() > kValueEntry1
					.getValue().getTimeCreated()) {
				return 1;
			}
			return 0;
		}
	}


	/**
	 * Evictor function to evict oldest entry
	 */
	private void evict() {
		if (cache.size() <= capacity) {
			// do nothing as capacity has reached
			logger.debug("Cache size within limit. No need for eviction");
			return;
		}
		logger.debug("Calculating entries for eviction");
		List<Map.Entry<K, Value<V>>> list = new ArrayList<Map.Entry<K, Value<V>>>(
				cache.size());
		list.addAll(cache.entrySet());
		Collections.sort(list, new MapEntryValueComparator());
		while (cache.size() > capacity) {
			Map.Entry<K, Value<V>> mapKey = list.remove(0);
			cache.remove(mapKey.getKey());
		}
	}

}
