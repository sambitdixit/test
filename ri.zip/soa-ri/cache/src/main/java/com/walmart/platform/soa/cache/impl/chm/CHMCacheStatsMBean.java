package com.walmart.platform.soa.cache.impl.chm;

/**
 * MBean for the CHM Cache
 * 
 * @author sdikshi
 * 
 */
public interface CHMCacheStatsMBean {

    /**
     * Gets current size of cache
     *
     * @return current cache size
     */
    long getCurrentCacheSize();

    /**
     * Max size of the Cache
     *
     * @return  Max size of cache
     */
    long getMaxCacheSize();

    /**
     * Returns the cache name
     *
     * @return Name of the cache
     */
    String getCacheName();

    /**
     * Returns Eviction interval
     *
     * @return  Eviction interval
     */
    int getEvictionInterval();

    /**
     * Returns Hit count (number of times entries was found) since the cache was created
     *
     * @return  Hit count
     */
    long getHitCount();

    /**
     * Returns Miss count (number of times entries was not found) since the cache was created
     *
     * @return  Hit count
     */
    long getMissCount();

    /**
     * Gets the value of object for the key
     *
     * @param key   Key whose value is to be fetched
     * @return      Value associated with the key
     */
    String getValueForKey(String key);

    /**
     * Returns all the keys for the cache
     *
     * @return  All keys present in the cache
     */
    String retrieveAllKeys();

}
