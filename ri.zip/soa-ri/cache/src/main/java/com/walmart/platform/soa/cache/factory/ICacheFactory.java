package com.walmart.platform.soa.cache.factory;

import com.walmart.platform.soa.cache.Cache;
import com.walmart.platform.soa.cache.CacheManager;

/**
 * @author sdikshi
 */
public interface ICacheFactory {

    /**
     *
     * @param name
     * @param <K>
     * @param <V>
     * @return
     */
	<K, V> Cache<K, V> getCache(String name);

    /**
     *
     * @param cacheManager
     */
	void setCacheManager(CacheManager cacheManager);

}